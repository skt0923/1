# mode-menu 三页共用设置入口

> 职责：一张已归档的任务卡，记录该任务的范围、结论与遗留问题。
> 不负责：不记录当前进度（进度在 docs/交接与台账.md 台账节）。

状态：verify（已构建，待真机逐页点验）

范围：三个页面（展示 / 玩法二 / 港区）右上角各一个「设置」按钮，点开弹层可切到任一页；当前页按钮置灰。

## 改动

| 文件 | 动作 |
|---|---|
| `scripts/ModeMenu.lua` | 新建：`Create` / `SetPageVisible` / `Select` / `Destroy` / `Shutdown`；只接参数，id 与回调由调用方传入（不写死玩法数值、模块接口） |
| `scripts/modes/M1_Port/Mode.lua` | 接入；弹层打开时吞开火输入；Stop 末尾 `ModeMenu.Shutdown()` |
| （原玩法二，已删除） | 接入；删除顶部「展示页面 / 港区行动」两键。该文件已随玩法二删除，现由 `scripts/modes/M2_LootRun/Mode.lua` 承接 |
| `scripts/Showcase/Interface.lua` | 接入；显隐改走 `SetPageVisible`；重建前销毁旧菜单 |
| `scripts/modes/M1_Port/Data/Weapon.lua` | 弹药文字 `rightMargin` 48→132 |

## 约定

- 按钮固定最右上（right 12 / top 8），其余内容避让。
- `UI.SetRoot` 单根：菜单根包住页面根，页面在下层、按钮与弹层在上层。
- 切换走调用方注入的 `onSelect`，菜单不 require Router。

## 观测点

- `[UI][MENU] -> OK | event=init|create|open|close|select|page-visible|destroy|shutdown`
- `[UI][MENU] -> NONE | event=select reason=current`（点当前页）
- `[ROUTER][REQUEST] / [ROUTER][ENTER]` 与各页 `[MODE] stop/dispose`

## 验收

1. 三页右上角都有「设置」，点击出弹层，当前页置灰；
2. 依次切三页各一次，画面切换且无 ERROR，返回后原页可再进；
3. M1 弹层打开时点背后不触发开火；
4. 退出/切页时 `[M1][MODE] dispose`、`[UI][MENU] shutdown` 成对出现，无 `Dispose` 报错。

## 自检

未接入自检，沿用既有「自检后置」裁定，台账在案；本卡由人工点验。
