# physics-01 真机骨骼物理不可用

> 职责：一张已归档的任务卡，记录该任务的范围、结论与遗留问题。
> 不负责：不记录当前进度（进度在 docs/交接与台账.md 台账节）。

状态：todo
改动：无（阻塞：运行时缺 KawaiiPhysics 绑定）
阻塞依据：反馈 53103 真机引擎 release-1.35，日志 `[Character] PHYSICS_UNAVAILABLE` 与 8 条 `Component type 62DD3C27 not known`；待平台提供含该组件的运行时后复核
