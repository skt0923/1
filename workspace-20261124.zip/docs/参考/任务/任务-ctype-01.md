# ctype-01 引擎版本与 KawaiiPhysics

> 职责：一张已归档的任务卡，记录该任务的范围、结论与遗留问题。
> 不负责：不记录当前进度（进度在 docs/交接与台账.md 台账节）。

状态：verify
结论：设备预览客户端运行时为 1.35，`KawaiiPhysics` 需要 ≥1.36。客户端仍是 1.35 时，项目把 `engine` / `engine-res` 固定到 1.36.x 会导致启动失败；升版本必须先升级客户端，不能只改项目配置。
版本写法：`engine` 只接受精确版本（如 `1.36.12`），`engine-res` 才接受版本线（如 `1.36`）。
失败记录：build 30 与 build 32（均为 1.36.12）真机报「加载失败 / 未找到启动资源」；反馈 53166 日志首行 `UrhoX: version/release-1.35`，`engine-startup` 404，56 条 ERROR。
已回滚：build 33 恢复 `tag: stable`，engine `client=096cb295`，与 build 31 一致。
待验/下一步：升级 TapTap/预览客户端到 ≥1.36 后再测；届时从 1.36 起按版本逐档往上试，客户端能进再固定。
