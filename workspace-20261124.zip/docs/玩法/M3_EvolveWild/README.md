# evolve_wild · 沙盒建造生存SOC（M3_EvolveWild）

> 职责：玩法三的一切文档入口与状态。
> 不负责：不放跨玩法通用规范，不放其他玩法的内容。

## 定位

evolve_wild：沙盒建造生存SOC。长期战局、自由建家、科技成长、领地攻防，没有统一撤离/缩圈。

## 状态

骨架场景：目录、`Mode.lua`、菜单注册已就位，可以进入；玩法机制尚未实现，场景内只有空场地与塔啦啦展示角色。

## 结构树

```
M3_EvolveWild/
└── Mode.lua          入口与骨架场景
```

## 文档与代码对照

| 路径 | 内容 |
|---|---|
| `scripts/modes/M3_EvolveWild/Mode.lua` | 入口与骨架场景 |
| `scripts/modes/M3_EvolveWild/Data/` | 玩法数值（待建） |
| `docs/玩法/M3_EvolveWild/` | 本目录 |

## 待建

- 玩法循环与数值表（`Data/`）
- 按系统域分层（`Art/`、`Hud/`、`View/`、`Weapon/` 等，按规则第 13 节第 7 条，视实际内容而定）
- 自检按钮、探针与期望值（规则第 26 节）
