# battle_royale · 淘汰缩圈竞技（M4_BattleRoyale）

> 职责：玩法四的一切文档入口与状态。
> 不负责：不放跨玩法通用规范，不放其他玩法的内容。

## 定位

battle_royale：淘汰缩圈竞技。不断缩小安全区，活到最后获胜。

## 状态

骨架场景：目录、`Mode.lua`、菜单注册已就位，可以进入；玩法机制尚未实现，场景内只有空场地与塔啦啦展示角色。

## 结构树

```
M4_BattleRoyale/
└── Mode.lua          入口与骨架场景
```

## 文档与代码对照

| 路径 | 内容 |
|---|---|
| `scripts/modes/M4_BattleRoyale/Mode.lua` | 入口与骨架场景 |
| `scripts/modes/M4_BattleRoyale/Data/` | 玩法数值（待建） |
| `docs/玩法/M4_BattleRoyale/` | 本目录 |

## 待建

- 玩法循环与数值表（`Data/`）
- 按系统域分层（`Art/`、`Hud/`、`View/`、`Weapon/` 等，按规则第 13 节第 7 条，视实际内容而定）
- 自检按钮、探针与期望值（规则第 26 节）
