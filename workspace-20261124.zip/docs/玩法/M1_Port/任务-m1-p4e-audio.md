# 任务卡：P4-E 音效（13-audio 首批）

状态：verify

> 阶段：P4 表现（`docs/玩法/M1_Port/3a重写路径.md` P4 的 `13-audio` 项）
> 原作锚点：`docs/source/3a/parts/13-audio.part.js`（9 条语句，约 50 个事件，WebAudio 程序化合成）
> 范围：首批 5 个事件先让游戏有声音；其余事件与 3D 定位声留后续批次。

## 一 做什么

1. 用 Python 确定性生成 5 个原生 WAV，放进 `assets/Sounds/`（44.1kHz / 16bit / 单声道）。
2. 新增音效模块：加载、2D 声部池、pitch 抖动、环境循环、探针。
3. 接入 4 个点位：开火、空仓、换弹出、换弹入；雨声循环在模块创建时起播。
4. 自检新增「声音」按钮：打设备状态与 5 个事件，并把非循环事件各播一次。

## 二 事件表

| 事件 | 文件 | 音量 | pitch 抖动 | 循环 | 触发点 |
|---|---|---|---|---|---|
| `rifle_fire` | `Sounds/rifle_fire.wav` | 0.85 | 0.94–1.06 | 否 | `Weapon/Rifle.lua` 每次开火 |
| `rifle_dry` | `Sounds/rifle_dry.wav` | 0.60 | 0.98–1.02 | 否 | 空仓首次扣扳机 |
| `reload_out` | `Sounds/reload_out.wav` | 0.55 | 0.95–1.05 | 否 | 换弹时间轴 `reloadMagOut` |
| `reload_in` | `Sounds/reload_in.wav` | 0.60 | 0.95–1.05 | 否 | 换弹时间轴 `reloadMagIn` |
| `rain` | `Sounds/rain_loop.wav` | 0.35 | 固定 | 是 | 模块创建时（`SOUND_AMBIENT`） |

## 三 差异登记

| # | 差异 | 原因 | 代价 |
|---|---|---|---|
| 1 | 事件数 5 / 约 50 | 首批只做枪械与环境；脚步、命中分表面、受伤、中继、敌人开火留后续 | 大部分动作仍无声 |
| 2 | 音色不是原作 WAV 级复刻 | 原作是 WebAudio 实时合成（振荡器 + 滤波 + 卷积混响），本项目生成等长采样后播放 | 枪声层次与混响密度不及原作 |
| 3 | 无 HRTF / 总线混响 / 优先级 | 引擎 `SoundSource3D` 只做距离衰减；混响、HRTF 属 WebAudio 专属能力 | 敌人枪声方位感弱（本批未接 3D） |
| 4 | 敌方与命中音效未接 | 需要 Enemy / ImpactBursts 注入回调，本批只动 Rifle 与 Mode | 命中无反馈声 |
| 5 | 生成器不进构建流程，且不随仓库分发 | `tools/gen_audio.py` 是离线工具，但 `tools/` 被 `.gitignore` 忽略；只有 WAV 入库。新克隆的仓库无法重跑生成器，只能替换资源 | 资源与脚本可能不同步；换音色必须先拿到本地工具 |
| 6 | 雨声不区分室内外 | 原作按室内盒剔除雨量；本批雨声常驻 | 进仓库仍听雨 |

## 四 文件

| 文件 | 动作 | 内容 |
|---|---|---|
| `assets/Sounds/rifle_fire.wav` 等 5 个 | 新建（脚本生成） | 见事件表 |
| `scripts/modes/M1_Port/Audio/Sfx.lua` | 新建 | 加载 / 声部池 / 播放 / 环境循环 / 探针 / 释放 |
| `scripts/modes/M1_Port/Data/Audio.lua` | 新建 | 5 个事件的音量、pitch、循环标记 |
| `scripts/modes/M1_Port/Weapon/Rifle.lua` | 改 5 处 | `ctx.sfx` 注释、开火、空仓、换弹两声、`AdvanceReload` 传 ctx |
| `scripts/modes/M1_Port/Mode.lua` | 改 7 处 | 两个 require、字段、`Sfx.Create`、rifle ctx 带 `sfx`、`ProbeSfx`、自检回调、`Dispose` 释放 |
| `scripts/modes/M1_Port/SelfTest.lua` | 改 7 处 | 「声音」按钮、`onProbeSfx` 参数与断言、`probeSfx` 字段、分支 |
| `docs/玩法/M1_Port/3a复刻清单.md` | 改 1 行 | `13-audio` 待重写 → 部分 |
| `docs/交接与台账.md` | 追加 1 行 | 待真机验证 |

## 五 验收与日志期望

| 步骤 | 期望日志 | 期望值 |
|---|---|---|
| 进入 M1 | `[M1][SFX][LOAD] -> OK \| event=... file=Sounds/... hz=44100` 逐条 5 行，然后 `[M1][SFX][LOAD] -> OK \| loaded=5 missing=0` | `missing=0`；有 NONE 就写明缺哪个文件 |
| 进入 M1 | `[M1][SFX][VOICE] -> OK \| count=8`、`[M1][SFX][AMBIENT] -> OK \| event=rain gain=0.35` | 雨声循环起播 |
| 开火 | `[M1][SFX][PLAY] -> OK \| event=rifle_fire pitch=0.98 gain=0.85 n=1` | 前 3 次与每 20 次各记一次 |
| 打空弹匣 | `[M1][SFX][PLAY] -> OK \| event=rifle_dry ...` | 与既有 `[WEAPON][DRY] -> NONE` 同一帧 |
| 换弹 | `[M1][SFX][PLAY] -> OK \| event=reload_out` / `event=reload_in` | 与既有 `[WEAPON][RELOAD]` 事件对齐 |
| 点「声音」 | `[M1][SFX][PROBE] -> OK \| initialized=true mixRate=44100 loaded=5 missing=0 voices=8 ambient=true` + 5 条 `[EVENT]` | 真机应听到 4 声（雨声不重播）；`initialized=false` 表示设备没起来，按缺口处理 |

真机判据：开火、换弹、空仓、雨声四类能听到且不破音；`PROBE` 行 `initialized=true`。

本机已跑通（2026-11-24，本地 preview，第 127 帧进场景）：

```
[M1][SFX][LOAD] -> OK | loaded=5 missing=0
[M1][SFX][VOICE] -> OK | count=8
[M1][SFX][AMBIENT] -> OK | event=rain gain=0.35
[M1][SFX][PROBE] -> OK | initialized=true mixRate=44100 loaded=5 missing=0 voices=8 ambient=true
[M1][SFX][PLAY] -> OK | event=rifle_fire pitch=1.020 gain=0.85 n=1
[M1][SFX][PLAY] -> OK | event=rifle_dry pitch=1.007 gain=0.60 n=1
[M1][SFX][PLAY] -> OK | event=reload_out pitch=0.998 gain=0.55 n=1
[M1][SFX][PLAY] -> OK | event=reload_in pitch=0.956 gain=0.60 n=1
[M1][SFX][DISPOSE] -> OK | plays=5 missing=0
```

未验：真实听感（本机无输入注入，开火/换弹由临时探针代跑；听不听得见、有没有破音仍要真机确认）。

## 六 后续

- 第二批：脚步（需 Rig 步频事件）、命中分表面（ImpactBursts 回调）、受伤（PlayerHealth）、中继切断（Relay）、敌人开火（Enemy，走 `SoundSource3D`）。
- 收尾时重新生成 `docs/代码地图.md`（新增 `Audio/` 系统域）。