# m1-p1a-foundation P1-A 几何与材质地基

> 职责：验证地面几何、TextureBaker 材质与天空环境；看 [M1][FLOOR]/[MAT][GET] 日志。
> 不负责：不记录当前进度（进度在 docs/交接与台账.md 台账节）。

状态：verify（2026-11-23 真机 54602 + 本地 preview：地面材质出图 tex=1024x1024；1.35 计算队列不支持 MipDown 别名，已探测降级为仅 level 0，远处黑斑已改 512 低频贴图集 + 放大 tile（2026-11-24，待真机）；`Cylinder`/`Tube` 仍未真机调用）

范围：把灰盒地板换成带真实材质的港区地面；落位按米 UV 的几何工具与材质查表入口。
不含道具（P1-B）、四区域总装（P1-C）、天空与岸桥（P1-D）。

原作锚点：`01-geometry` 语句 1 `$e`、2 `Wi`、3 `ot`、4 `Fn`、7 `Lc`；
`05-material` 语句 4–30 的材质名与磨损语义；
`09-level` 语句 1 的地面写法。

## 改动

| 文件 | 动作 |
|---|---|
| `scripts/modes/M1_Port/Art/Geometry.lua` | 新建：`Box` / `Cylinder` / `Tube` / `PaintNoise` |
| `scripts/modes/M1_Port/Art/Materials.lua` | 新建：`Get` / `Has`，未知材质名报错并列出可选名 |
| `scripts/modes/M1_Port/Data/Materials.lua` | 新建：地面材质 `asphalt`、UV 80 m |
| `scripts/modes/M1_Port/Mode.lua` | `CreateFloor` 改用几何与材质入口；`self.world = WorldData`；碰撞盒改为真实尺寸 |

## 预期差异（按复刻规范）

1. **顶点色算法**：原作 `05` 用自定义 GLSL 按磨损度混合漆面与锈底；引擎用 `TextureBaker`
   的 `vertexColor = true` + 几何侧 `ApplyNoiseColor`。表现相近，算法不同。
2. **共享材质**：每类材质一个实例（`TextureBaker` 内部按参数缓存），色调写进顶点色；
   原作按 seed 逐个生成。省 draw call，代价是同一材质的磨损图案在各实例间一致。
3. **倒角形状**：`ChamferBoxGeometry` 平倒角，原作 `Wi` 为圆弧倒角（约 2 cm）。
4. **管缆张力**：引擎 `TubeGeometry` 无 `tension` 参数，按点表密度直接插值。
5. **混凝土边沿**：原作四区域地面各有材质（`concrete_painted` / `floor_epoxy` / `concrete_dirty`）；
   本卡只做堆场沥青一整块，分区地面留 P1-C。

## 观测点

- `[GEO][CREATE] -> OK | kind= size= uvMeters= bevel=`
- `[MAT][GET] -> OK | name= vertexColor= uvMeters=`
- `[M1][FLOOR] -> OK | size= y= material= uvMeters= tris=`
- `[MAT][ERROR]` 行首错误格式，含名字与可选清单

## 验收

1. 真机进 M1_Port，地面可见沥青纹理与颗粒，不再是纯色；
2. 地面尺寸 80×60，边界不外露，玩家不会掉下去；
3. 日志 `[M1][FLOOR] -> OK`、`[MAT][GET] -> OK` 齐全，无 ERROR；
4. 帧率不低于 55。

## 自检

本卡新增玩家可见功能（地面材质）暂未配自检按钮；用户 2026-11-21 裁定自检后置，
台账在案（`docs/交接与台账.md` 台账节）。本卡验收由人工执行。

## 不做

道具、分区地面、仓库屋顶、天空、岸桥、软阴影、雨、海面反射、自检按钮。
