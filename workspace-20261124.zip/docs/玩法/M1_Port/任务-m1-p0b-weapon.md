# m1-p0b-weapon P0-B 能射

> 职责：验证步枪射击、换弹、弹药 HUD 与命中射线；看 [WEAPON][SHOT]/[HUD][AMMO] 日志。
> 不负责：不记录当前进度（进度在 docs/交接与台账.md 台账节）。

状态：done（2026-11-23 真机 feedback 54602：开火 spread 递增、换弹 magin/done 时间与数据一致、弹药 30/150 显示正常；枪在第一人称可见 `seen=true`）

范围：进入 M1_Port 后可用触屏「开火」按住连发、「换弹」手动换弹；弹匣/备弹递减与补弹；准星与弹药 HUD；枪口光、曳光、命中火花。不含敌人伤害结算、瞄准、后坐力、音效、暂停。

原作锚点：`16-weapon` 语句 1 `mi`、语句 28 `Gv/B_/O_/H_/V_/eu/W_/G_`、语句 37 `Xe/Be/Fe` 子集；`12-effects` 语句 10 `Cf` 的 muzzleFlash/tracer/impact；`18-hud` 语句 1 的 `h-cross`/`h-ammo`；`14-input` 语句 1 的触屏按钮。

预期差异（按复刻规范，待批准）：

1. 视图模型用简化盒体（`Data/Weapon.lua` 的 `viewParts`），完整 PAC-9 建模、枪身图集与细节 shader 留 P4。
2. 开关 `damage=26`、`range=300` 只写入射线日志，不结算伤害与弱点；敌人接入时在 P2 启用（`15-player` 语句 3 的战斗结算）。
3. 曳光为单条 0.05s 盒体线段，枪口光为点光 + 小球，命中火花为 0.12s 小球；原作粒子池、弹壳、碎屑、贴花、烟留 P4。
4. 空仓换弹总时长 2.72s 与补弹时刻 1.345s 对齐，但弹栓/拍匣等中间阶段动画与日志省略，留 P4。
5. 弹药 HUD 只有数字、备弹、武器名与状态文本；原作弹药格（pips）与低弹 cue 动画留 P5。
6. 准星尺寸/颜色沿用 `UI.GameHUD` 的默认值（size 12 / gap 4 / thickness 2 / dot 2），原作 CSS 精确值待 P5 对齐。
7. 触屏只有「开火」「换弹」两键；原作另有瞄准/交互/暂停，瞄准 P4、交互与暂停 P3/P5。
8. 无开火后坐力、镜头抖与音效，留 P2/P4。
9. 鼠标/手柄不接（沿用 P0-A 裁定）。

实现要点：

- `modes/M1_Port/Data/Weapon.lua`：弹匣 30、备弹 150、720 RPM、伤害 26、射程 300、换弹 2.1/空仓 2.72、补弹 1.345s、散布 0.0125 + 移动 0.013 + Bloom 0.0065 + 空中 0.022 − 蹲下 0.002。
- `modes/M1_Port/Weapon/Rifle.lua`：冷却 `60/rpm`、每次射击 Bloom +0.17（上限 1，衰减 1.5/s）、按住连发（每帧最多补 3 发）、空仓 0.32s 后自动换弹、手动换弹拒绝分支。
- `modes/M1_Port/Art/Effects.lua`：单份枪口光/曳光/命中火花，按数据表时长回收。
- `modes/M1_Port/Weapon/WeaponMount.lua`：相机下挂点 `[0.118,-0.122,-0.275]`，枪口 `[0,0,-0.531]`。
- `modes/M1_Port/Hud/WeaponHud.lua`：独立 NanoVG 上下文画准星与 `ammo / reserve`。
- `modes/M1_Port/Hud/PlayerHud.lua`：新增按住开火与点按换弹按钮。
- `modes/M1_Port/Rig.lua`：新增水平速度供散布使用。

验收步骤（真机）：

1. 进入 M1_Port：右下出现「开火」「换弹」，屏幕中央准星，右下显示 `30 / 150`；日志 `[WEAPON][CREATE]`、`[WEAPON][MOUNT]`、`[FX][CREATE]`、`[HUD][WEAPON]` 均为 OK。
2. 站立按住开火 1 秒：约 12 发，弹匣递减；`[WEAPON][SHOT]` 的 `spread≈0.0125`、`speedFrac=0.00`；曳光/枪口光/命中火花可见。
3. 移动中开火：`speedFrac` 随实测速度上升，`spread` 落在 `0.0125 + 0.013×speedFrac` 附近；空中 `air=true` 时 `spread` 增加 0.022。
4. 打空：`[WEAPON][DRY] -> NONE`，0.32s 后 `[WEAPON][RELOAD] start`；空仓换弹总时长约 2.72s，1.345s 时 `event=magin` 补弹。
5. 手动换弹：`start → magout(0.47) → magin(1.345) → done(2.10)`；备弹同步减少。
6. 满弹按换弹或备弹为 0：`[WEAPON][RELOAD] -> NONE` 且 `reason=full|empty-reserve`。
7. 退出/关机：`[M1][MODE] stop`、`[M1][MODE] dispose`，无 `Dispose` 报错。

观测点（按观测点一节）：`[WEAPON][SHOT]` 含 origin/dir/point/spread 与输入量；`[WEAPON][RELOAD]` 含阶段、时间、弹匣与备弹；`[HUD][AMMO]` 在数值变化时记录；`[FX][FIRE]` 首次与每 10 发记录距离与命中点。

不做：敌人、伤害结算、瞄准、后坐力、音效、暂停、鼠标/手柄。

实现期补正（待复验）：

10. LSP 把数据表颜色数组判为可空，颜色字段改为定长元组 `[r,g,b]` / `[r,g,b,a]`，行为不变。
11. `Rifle.Create` 的 `PhysicsWorld` 断言逐行抑制：`.emmylua` 声明该返回非 nil，运行时仍需按资源断言中断。

自检：沿用既有裁定，暂不接入 `common/core/SelfTest`，本卡步骤由人工执行；台账在案。
