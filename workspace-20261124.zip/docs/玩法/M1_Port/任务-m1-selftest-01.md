# m1-selftest-01 自检执行器

> 职责：实现并验证自检执行器：一项操作一个按钮，只执行不判定。
> 不负责：不记录当前进度（进度在 docs/交接与台账.md 台账节）。

状态：verify（2026-11-23 真机 54602：移动/跳跃/蹲下/开火/换弹/地面 6 项全部 event=done；新增「受伤」项与生命探针待真机）

依据：`docs/参考/自检清单.md`、`docs/参考/任务-selftest-refactor-01.md`（自检只执行不判定）。

## 范围

| 文件 | 改动 |
|---|---|
| `scripts/modes/M1_Port/SelfTest.lua` | 新增执行器与界面：移动/跳跃/蹲下/开火/换弹/地面 6 键 + 全部 |
| `scripts/modes/M1_Port/Mode.lua` | 接线；地面探针拆为可重复调用 `ProbeFloor` |
| `scripts/modes/M1_Port/Hud/PlayerHud.lua` | 加 `SetFireOverride` / `QueueReload`，`IsFireHeld` 读取覆盖位 |
| `scripts/modes/M1_Port/Rig.lua` | JUMP 补 `v0`/`vy`/`kccJump`/`kccMax`；引擎垂直速度读不到时按 `v²=2gh` 补高度 |

## 原作锚点

- 15-player 语句 1：跳跃顶点 1.0、重力 21、土狼时间 0.12、跳跃缓冲 0.13。`v0 = √(2×21×1.0) = 6.48 m/s`。
- 12-effects / 16-weapon：开火与换弹沿用现有 `Rifle:Update`，不新增逻辑。

## 差异

| 项 | 原作 | 本项目 | 原因 | 代价 |
|---|---|---|---|---|
| 地面材质纹理 | 运行时 GLSL 生成三张 RT | TextureBaker 烘焙 | 引擎能力差异 | 1.35 拒收 `flow_control_prefer`，烘焙未完成，`tex=1x1` |
| 跳跃高度序列 | 自建控制器直接积分 | 先读引擎垂直速度，读不到才自积分 | 1.35 的 KCC 速度接口未证实可读 | 自积分期间节点由脚本上移，探针读数可判定 |

## 验收

真机进入 `M1_Port`，界面下方 7 个按钮，逐个点验后看日志：

1. 移动 → `[RIG][MOVE] -> OK/FAIL | mode=walk moved=...`
2. 跳跃 → `[RIG][JUMP] -> OK | event=start ... v0=6.48 vy=...` 与 `event=land ... apex=... kccJump=... kccMax=...`
3. 蹲下 → `[RIG][CROUCH] -> OK | event=settle eye≈1.05`
4. 开火 → `[WEAPON][SHOT]` 连续、`[HUD][AMMO]` 递减
5. 换弹 → `[WEAPON][RELOAD]` 出现，弹药回满
6. 地面 → `[M1][FLOOR] -> OK/NONE | event=probe ... tex=... baked=...`
7. 全部 → 6 条 `event=done` + 一条 `event=all-done`

判定：本次只求拿到 `apex`、`vy`、`kccJump` 三值。apex 若仍为 0.70 且 `kccJump=6.48`，说明引擎跳跃初速低于设定，按复刻规范登记差异后再定判定区间。
