# 玩法一 · 港区行动（M1_Port）

> 职责：玩法一的一切文档入口与状态。含定位、结构树、文档与代码对照、待建清单。
> 不负责：不放跨玩法通用规范（在 docs/参考/），不放其他玩法的内容。

## 定位

第一人称、卡通渲染、塔啦啦玩家模型（唯一豁免）；复刻关卡结构、三处中继、撤离、敌人类型、武器行为、界面信息层级；不复刻写实渲染、原作美术风格。数值与验收以 `docs/3a游戏文档.html` 为准。任务系统只保留中继→撤离。

## 状态

实现中。当前可进入「港区行动」：第一人称/第三人称切换、移动跳跃蹲伏、步枪射击与换弹、弹药 HUD、四区域场地与 165 处道具、猎犬敌人与三波刷怪、三处中继→撤离的完整闭环（目标条、交互提示、统计与评级、死亡页与结算页、电台字幕）、自检执行器与全流程自动跑者。P3-C 余世界目标标记与中继柜灯色。

## 结构树

```
M1_Port/
├── Mode.lua                     入口：装配与生命周期
├── Level.lua                    场地装配（四区域 + 仓库壳 + 围挡 + 标记）
├── Rig.lua                      角色控制器
├── SelfTest.lua                 自检执行器
├── Settings.lua                 设置权威
├── Art/                         视觉资产
│   ├── Geometry.lua             盒/柱/管几何
│   ├── Materials.lua            烘焙材质查表
│   ├── Props.lua                31 类道具构建器
│   └── Effects.lua              枪口光/曳光/火花
├── Combat/                      战斗
│   ├── PlayerHealth.lua         玩家生命权威
│   ├── Enemy.lua                猎犬占位骨架与状态机
│   ├── Waves.lua                波次生成与开火名额
│   └── AutoPilot.lua            自检 AI（自动打敌人）
├── Flow/                        关卡流程
│   ├── GameFlow.lua             intro/playing/dead/complete
│   ├── Relay.lua                三处中继按住切断
│   ├── Extract.lua              撤离判定
│   └── Stats.lua                统计与评级
├── Hud/                         界面
│   ├── PlayerHud.lua            摇杆与动作键
│   ├── WeaponHud.lua            准星与弹药
│   ├── StatusHud.lua            生命与状态
│   ├── SettingsPanel.lua        设置面板
│   ├── ObjectiveHud.lua         目标条与中继进度
│   ├── InteractPrompt.lua       交互提示
│   ├── Radio.lua                电台字幕
│   └── MenuScreens.lua          死亡页与结算页
├── Perf/                        观测
│   └── Stats.lua                帧率与场景规模
├── Test/                        测试工具
│   └── FlowRunner.lua           全流程自动跑者（瞬移走位）
├── View/                        相机视图
│   ├── FirstPersonCamera.lua    第一人称
│   └── ThirdPersonView.lua      第三人称与角色
├── Weapon/                      武器
│   ├── Rifle.lua                射速散布命中
│   ├── WeaponMount.lua          两套视图模型
│   └── WeaponPose.lua           手臂两骨 IK
├── Data/                        数值表
│   ├── Props.lua                道具尺寸与摆放
│   ├── Level.lua                区域/盒体/标记
│   ├── Enemy.lua                猎犬数值/生成点/波次
│   ├── Player.lua               移动跳跃蹲伏
│   ├── Weapon.lua               武器参数
│   ├── World.lua                场地边界
│   ├── Controls.lua             按键映射与按钮布局
│   ├── Effects.lua              特效时长
│   ├── Materials.lua            地面材质
│   ├── WeaponHud.lua            弹药显示
│   ├── StatusHud.lua            生命条
│   ├── Health.lua               生命数值
│   ├── Settings.lua             设置默认值
│   ├── Flow.lua                 流程与评级阈值
│   ├── Relay.lua                三处中继与撤离点
│   ├── Radio.lua                电台文案
│   └── AutoPilot.lua            自检 AI 参数
└── kit/                         外部积木副本
    └── TextureBaker/            PBR 烘焙（去 flow_control_prefer）
```


## 文档与代码对照

| 文档 | 对应内容 |
|---|---|
| `复刻规范.md` | 源码追溯与复刻保真要求（只适用本玩法） |
| `3a重写路径.md` | 阶段计划 P0–P5，对应 `Mode.lua` 各阶段实现顺序 |
| `3a复刻清单.md` | 22 个原作片段 → 本目录各模块的映射与状态 |
| `3a拆分产物.md` | `docs/source/3a/` 拆分产物的清单与重建脚本 |
| `任务-m1-p0a-move.md` | `Rig.lua` 移动与地面检测 |
| `任务-m1-p0b-weapon.md` | `Weapon/`、`Data/Weapon.lua` |
| `任务-m1-p1a-foundation.md` | `Art/Geometry.lua`、`Art/Materials.lua`、`kit/TextureBaker/` |
| `任务-m1-p1b-props.md` | `Art/Props.lua`、`Data/Props.lua`、四区域对齐与差异登记 |
| `任务-m1-p2a-enemy.md` | `Combat/Enemy.lua`、`Combat/Waves.lua`、`Data/Enemy.lua`、`Rifle` 命中回调 |
| `任务-m1-p3a-flow-relay.md` | `Flow/GameFlow.lua`、`Flow/Relay.lua`、`Hud/ObjectiveHud.lua`、`Hud/InteractPrompt.lua` |
| `任务-m1-p3b-extract-debrief.md` | `Flow/Extract.lua`、`Flow/Stats.lua`、`Hud/MenuScreens.lua`、`Hud/Radio.lua` |
| `任务-m1-selftest-01.md` | `SelfTest.lua` |

## 待建

- 世界目标标记、中继柜灯色（P3-C）
- 标题页、暂停页、操作说明（P5）
- 贴花与镜头路径（P4）
- 每项新增功能的按钮、探针与期望值（规则第 26 节）

## 原作来源

原作源码已拆分到 `docs/source/3a/`（22 个功能片段），导航见 `3a复刻清单.md`；拆分方法见 `docs/手册/html拆分.md`。

## 约束

- 唯一权威源是原作 `docs/source/3a/parts/`，数值以数据表与源码为准。
- 只改玩法一相关文件；展示页、基础设施与模型不要动。
- 唯一豁免是玩家模型（塔啦啦模型、材质、动画不动），世界与武器按原作。
