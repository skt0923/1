# 任务 m1-p3b 撤离、统计与结算

状态：verify

## 范围

- 撤离判定：三处中继全部切断后解锁撤离点，进入半径 3.0 米即完成（`[M1][EXTRACT][REACH]`）。
- 战斗统计：`shots`（开火数）、`hits`（命中敌人数）、`kills`（击杀数）、`retries`、`seconds`；命中率 = `hits/shots`，未开火时为 `—`。
- 评级：原作算式 `(time<270?2:time<400?1:0) + (acc>=.5?2:acc>=.3?1:0) + (retries===0?1:0)`，0–5 分对应六个评级名。
- 死亡页：`阵亡` + `生存时间 mm:ss` + `已切断中继 n/3`。
- 结算页：`行动简报` + 评级 + `用时 / 命中率 / 摧毁机械 / 重试次数`。
- 电台字幕：入场（intro 1.3 秒时）、全切断、撤离、阵亡四条。
- 自检「撤离」：先把三处中继置为已切断，再传送到撤离点，2 秒内应进 `complete`。

不做（P3-C）：世界目标标记（屏幕投影 + 边缘指示）、中继柜灯色切换、标题/暂停页、贴花。

## 原作锚点

| 内容 | 片段 | 语句 / 字段 |
|---|---|---|
| 撤离判定 | `20-flow.part.js` | `allCut` 后 `q()` 加撤离标记；触达时 `i.events.emit("extraction:reached")`、`o.show(!1)`、`o.radio(_l.done,2.2)`、`l.setDebrief(...)`、`M("complete")` |
| 统计与评级 | 同上 | `P=i.combat.stats\|\|{shots:0,hits:0,kills:0}`；`V=P.shots>0?Zn(P.hits/P.shots,0,1):null`；`Y=...`；`L=["险象环生","火力全开","稳扎稳打","干净利落","精准果断","完美突击"][Y]` |
| 死亡页 | `19-menu.part.js` | `setDead({time,relays,total})` → `dead-time` / `dead-relays` |
| 结算页 | 同上 | `setDebrief({time,accuracy,kills,retries,rating})` → `time` / `acc` / `kills` / `retries` / `rating` |
| 时间格式 | 同上 | `O(U)=mm:ss`，向下取整 |
| 电台 | `18-hud.part.js` | `radio(text, secs=4.5)`、`clearRadio()`；`comms` 元素带 `aria-live` |

## 差异登记（未批准前不实现）

| # | 参考实现 | 当前实现 | 前提差异 | 批准 |
|---|---|---|---|---|
| 1 | 结算页是完整 DOM 屏幕（标题页/暂停页/设置共用一套遮罩） | 只做两个居中文本块，无按钮、无遮罩、无重开 | 菜单体系与交互属 P5；本阶段只交付读数 | 待批准 |
| 2 | 死亡后进入 `dead` 并锁输入；重开按 `retries++` | 只锁移动，无重开入口（`retries` 恒 0） | 重开需要 Router 重进玩法，留 P5 | 待批准 |
| 3 | 命中率统计 `combat.stats.hits`（命中敌人） | `Rifle.hits` 在打中敌人时累加；打中世界不计 | 无 | — |
| 4 | 撤离触达后隐藏 HUD 并淡出 | 不隐藏 HUD（结算页叠在上层文本） | 淡出属表现层，留 P4 | 待批准 |
| 5 | 电台有语音合成与优先级队列 | 只排队 + 定时显示文本 | 无音频层（P4） | 待批准 |
| 6 | 结算页可重试/重新部署 | 无按钮；靠右上「菜单」离开 | 同上 | 待批准 |

## 自检

按钮「撤离」：

```
[M1][RELAY][FORCE] -> OK | done=3/3 reason=selftest
[M1][EXTRACT][TEST] -> OK | pos=(36.0,0.0)
[M1][EXTRACT][UNLOCK] -> OK | pos=(36.0,0.0) radius=3.0
[M1][EXTRACT][REACH] -> OK | dist=0.00 radius=3.0
[M1][STATS][PROBE] -> OK | time=00:12 shots=18 hits=6 kills=3 retries=0 acc=33% rating=稳扎稳打(2)
[M1][FLOW][STATE] -> OK | from=playing to=complete
[M1][SCREEN][COMPLETE] -> OK | rating=稳扎稳打 time=00:12 acc=33% kills=3 retries=0
```

按钮「中继」后连按三次仍应正常；「撤离」可在任意时刻单点（会自动补齐中继）。

## 文件

| 文件 | 类型 |
|---|---|
| `scripts/modes/M1_Port/Data/Radio.lua` | 新建（4 条文案） |
| `scripts/modes/M1_Port/Flow/Stats.lua` | 新建（统计 + 评级） |
| `scripts/modes/M1_Port/Flow/Extract.lua` | 新建（撤离判定） |
| `scripts/modes/M1_Port/Hud/Radio.lua` | 新建（字幕） |
| `scripts/modes/M1_Port/Hud/MenuScreens.lua` | 新建（死亡页/结算页） |
| `scripts/modes/M1_Port/Weapon/Rifle.lua` | 改（`hits` 计数） |
| `scripts/modes/M1_Port/Flow/GameFlow.lua` | 改（`complete` 状态） |
| `scripts/modes/M1_Port/Flow/Relay.lua` | 改（`ForceAllCut`，自检用） |
| `scripts/modes/M1_Port/Mode.lua` | 改（接线 10 处） |
| `scripts/modes/M1_Port/SelfTest.lua` | 改（「撤离」项） |