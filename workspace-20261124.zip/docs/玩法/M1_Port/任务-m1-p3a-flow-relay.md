# 任务 m1-p3a 流程骨架与中继交互

状态：verify

## 范围

- 六状态机的最小实现：`intro`（3.5 秒）→ `playing` → `dead`；`title`/`extract`/`complete` 留 P3-B。
- 三处中继可交互：靠近 2.2 米、朝向夹角达标、按住 2.4 秒切断；切断计数 0/3。
- HUD：任务目标文字（两行）+ 中继进度（`A● B○ C○`）；交互提示（"按住 交互 · 切断中继 A 62%"）。
- 入口：触屏「交互」按钮（右下，换弹左侧）；自检「中继」按钮（传送到最近未切断中继并自动按住到切断）。
- 死亡：`health.alive=false` 时进 `dead` 状态，停止移动输入（原作 `alive=false` 会停控制）。

P3-B 已实现（见 `任务-m1-p3b-extract-debrief.md`）：撤离判定、结算页与评级四项统计、死亡页、无线电字幕。
仍留 P3-C：世界目标标记、中继柜灯色、标题/暂停页、贴花。

## 原作锚点

| 内容 | 片段 | 语句 / 字段 |
|---|---|---|
| 流程配置 | `20-flow.part.js` | `Yi = { introSeconds: 3.5, retryIntroSeconds: 1.3, interactRange: 2.2, interactFacing: 0.45, cutSeconds: 2.4, patrol: { gull: 2, hound: 1 } }` |
| 状态机 | 同上 | `B(P)`：`title → intro → playing → paused → dead → complete`；`intro` 里 0.5s 地名卡、1.3s 无线电、`h-0.6` 显示 HUD 与 `setObjective` |
| 中继状态 | 同上 | `relays` 表项 `{o, id, short（id 末字母大写）, t, cut, cutting}`；`setRelays(done,total)` |
| 目标条 HUD | `18-hud.part.js` | `h-obj`：`任务目标` + 目标文字 + `h-relays`（`0/3` 与三格 `<i>`，`cut` 类置灰）；`setObjective(text)` 逐字打字机效果 |
| 交互提示 HUD | 同上 | `h-prompt`：`按住 {E|交互} · {label}` + 进度环 `stroke-dashoffset`（`setPrompt(text, progress 0..1)`） |

## 差异登记（未批准前不实现）

| # | 参考实现 | 当前实现 | 前提差异 | 批准 |
|---|---|---|---|---|
| 1 | 交互键 `E`（键盘）+ 手柄 `Y` + 触屏「交互」 | 只做触屏「交互」按钮；键盘 E 留 P4（项目现无键盘输入层） | 1.35 项目未接 KeyDown，`GameHUD` 已占键盘映射 | 待批准 |
| 2 | 进度环用 SVG `stroke-dashoffset` | 用文字百分比（`62%`），不画环 | `urhox-libs/UI` 无圆弧控件；raw NanoVG 自绘环留 P4 | 待批准 |
| 3 | 目标文字逐字打字机效果 | 一次显示全文 | 表现层差异，不影响判定 | 待批准 |
| 4 | 六状态含 `title`/`paused`/`extract`/`complete` | 只 `intro`/`playing`/`dead` | 菜单体系属 P3-B/P5 | 待批准 |
| 5 | 中继模型可切换 `setState("live"/"cut")`（灯色变化） | 只改状态与日志，柜体外观不变 | `Props` 的中继柜是静态几何，无灯组 | 待批准 |
| 6 | 中继坐标来自 `09-level` 的 `relays` | 沿用 `Data/Props.lua` 的三处 `relay_node` 摆放（1.5,7.5 / -4,-20 / 23,14），差异沿用 p1b 第 13 条 | 原作坐标未逐字对齐 | 待批准 |
| 7 | 切断进度按帧累积、松开归零 | 同上（`progress += dt`，松开清零） | 无 | — |

## 自检

按钮「中继」：传送到最近未切断中继旁 1.5 米并自动按住 2.4 秒，期望看到

```
[M1][FLOW][STATE] -> OK | from=intro to=playing
[M1][RELAY][PROBE] -> OK | done=0/3 nearest=A dist=1.5 facing=0.92
[M1][RELAY][CUT] -> OK | id=relay_a done=1/3
[M1][OBJ][SET] -> OK | text=切断三处中继(1/3) pips=A● B○ C○
```

连续按三次「中继」应看到 `done=3/3`；第四次应 `[M1][RELAY][PROBE] -> NONE | reason=all-cut`。

## 文件

| 文件 | 类型 |
|---|---|
| `scripts/modes/M1_Port/Data/Flow.lua` | 新建（流程与评级数值） |
| `scripts/modes/M1_Port/Data/Relay.lua` | 新建（三处中继与撤离点坐标） |
| `scripts/modes/M1_Port/Flow/GameFlow.lua` | 新建（状态机） |
| `scripts/modes/M1_Port/Flow/Relay.lua` | 新建（中继交互） |
| `scripts/modes/M1_Port/Hud/ObjectiveHud.lua` | 新建（目标条） |
| `scripts/modes/M1_Port/Hud/InteractPrompt.lua` | 新建（交互提示） |
| `scripts/modes/M1_Port/Hud/PlayerHud.lua` | 改（加「交互」按钮） |
| `scripts/modes/M1_Port/Data/Controls.lua` | 改（交互按钮位置/颜色数据） |
| `scripts/modes/M1_Port/Mode.lua` | 改（接线） |
| `scripts/modes/M1_Port/SelfTest.lua` | 改（加「中继」项） |