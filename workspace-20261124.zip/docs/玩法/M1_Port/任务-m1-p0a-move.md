# m1-p0a-move P0-A 能走

> 职责：验证角色移动、地面检测与跳跃探针；看 [RIG][MOVE]/[RIG][JUMP] 日志。
> 不负责：不记录当前进度（进度在 docs/交接与台账.md 台账节）。

状态：done（2026-11-23 真机 feedback 54602：`[RIG][MOVE]` 稳态 moved=1.89 判 OK；`[RIG][JUMP]` apex=0.90、expect=[0.80,1.20] 判 OK；起跳 start 日志已改打最后着地高度）

范围：进入 M1_Port，第一人称移动、跑步、跳跃、蹲下（眼高与速度）、鼠标/触摸视角、边界钳制与落水救援，以及承载这些操作的 HUD（摇杆、跳跃/跑步/蹲下按钮、准星）；不含武器、敌人、音效。

原作锚点：`00-config` 的 oi/Pi；`15-player` 的 Mt 与 x_ 子集；`14-input` 的 v_ 子集；`13-audio` 语句 9 的键位与灵敏度；`07-physics` 的 4.5 移动与边界；`20-flow` 的 QC 启动骨架。

预期差异（按复刻规范，已批准）：

1. 自建 AABB `moveCapsule` 改为引擎 `KinematicCharacterController` + `CharacterComponent`；地面加速 34 / 减速 26 / 空中 9 无对应字段，用 `airControlFactor = 9/34` 近似。
2. 玩家无模型、无动画；玩家模型豁免（m1）。
3. 蹲下只改眼高 1.05 与速度 1.9，胶囊高度仍 1.8；运行时改胶囊验证后再补。
4. 鼠标偏航取引擎 `mouseMoveX` 符号（与引擎示例一致），原作取反。
5. 相机近/远裁剪 0.08/900 取自 `04-postfx` 相机创建，P4 再对齐后处理。
6. 灰盒地板与光照为临时验证设施，P1 由 `09-level` 替换。

实现期补正（待复验）：

7. 出生点改为脚底 `y=0`：原作 `C.pos` 为脚底（`eye = pos.y + eye`），引擎四件套示例同约定；草案 `height*0.5` 会让胶囊悬空 0.86 m。
8. 灰盒地板扩为 80×60：草案 40×40 只覆盖 ±20，边界是 ±40/±30，未到边界就会掉出地板。
9. 模型、材质与组件加载加 `assert`（按资源断言）。
10. 落水安全点阈值取原作 `-0.5`：草案用 `groundY = 0`，贴地负误差时不再更新安全点。
11. 真机 53452 崩溃于 `Mode.lua:65`：`assert(v, msg)` 在实参位置返回两个值，`SetModel` 收到第三个 string；已改为局部变量后再传。`docs/参考/构建清单.md` 补「内联 `assert`/多返回值」一项。
12. 灰盒地板改用 `Techniques/PBR/PBRNoTexture.xml` 纯色材质：真机 53466 的 `Stone.xml` LitSolid DIFFMAP 变体链接失败（`input vTexCoord not declared`）导致画面全灰。
13. 真机 53475 确认启动成功（`[M1][MODE] -> OK`），但界面没有任何 UI，移动端无键盘鼠标不可操作；补 `modes/M1_Port/Hud/PlayerHud.lua`：`UI.GameHUD` 摇杆 + 跳跃/跑步/蹲下按钮 + 准星 + `EnableTouchLook` 触摸视角。
14. 移动控制权收归 GameHUD：删除 `PlayerRig:ReadInput` 与 `Controls.lua` 的键位表，避免 GameHUD 摇杆与键盘逐帧双写 `CTRL_*`。原作 Ctrl 蹲下改为 C 切换（GameHUD 蹲下按钮无 on_release）。
15. 触摸视角直接写 `controls.pitch`，俯仰钳制上移到 `FirstPersonCamera:Sync`（原来只在鼠标分支钳制）。
16. 真机 53484 摇杆拖动同时转视角：Android 触摸被映射成 mouseMove，鼠标视角与触摸视角叠加；`FirstPersonCamera` 在移动平台或 `input.touchEmulation` 下关闭鼠标视角，视角只由 `EnableTouchLook` 驱动。键鼠与手柄适配本轮不做。

17. 补量化探针（按观测点）：`[RIG][MOVE]` 每 0.5s 记录模式、实测速度与期望区间、方向、位置、是否着地；`[RIG][JUMP]` 记录起跳与落地顶点及期望区间；`[RIG][CROUCH]` 记录进入时的目标值与稳定后的眼高、走跑速度；`[CAMERA][LOOK]` 每 0.5s 记录来源（mouse/touch）、yaw/pitch 与俯仰钳制区间。
18. 补 `Mode:Dispose()`：真机 53495 关机时 `Router:59 attempt to call a nil value (method 'Dispose')`，M1_Port 缺实现（Showcase 已有）。
19. 键鼠与手柄适配按用户裁定暂不做，等明确要求再做。

验收：真机摇杆移动、跳跃/跑步/蹲下按钮生效（蹲下为点按切换，眼高与速度变化）、屏幕拖拽转视角、拖摇杆时视角不转动、边界不越界；日志 `[HUD][CREATE]`、`[RIG][CROUCH]`、`[RIG][MOVE]`、`[RIG][JUMP]`、`[CAMERA][LOOK]`、`[M1][MODE]` start/stop/dispose。

不做：键鼠与手柄适配、开火、换弹、弹药、敌人、武器模型、音效、暂停菜单。
