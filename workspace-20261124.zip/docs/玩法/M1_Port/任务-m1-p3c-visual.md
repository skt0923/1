# 任务卡 m1-p3c：柜体灯色 + 世界目标标记

状态：verify

> 所属阶段：P3 收尾（闭合「中继 → 撤离」闭环的可见性）。计划见 `3a重写路径.md` 的 P3。
> 原作锚点：`08-props` 语句 1 的 `B3`（relay_node 的 `setState` / `update`）、`18-hud` 语句 1 的 `h-marks`。
> 范围：两项玩家可见表现 + 一处差异登记，不改玩法逻辑、不改数值平衡。

## 一 做什么

| 项 | 原作行为 | 本项目做法 | 文件 |
|---|---|---|---|
| 中继柜灯色 | 灯罩按状态变色：live 橙 `0xFFA028`，强度 `5.5+3sin(t*2.2)`；cutting 5.5Hz 闪烁（亮 9 / 灭 0.5）；cut 立即转红 `0xFF2828`，0.3 秒内 9、2.6 秒内平方衰减并闪烁、之后熄灭 | 三段状态与数值照抄，用 `NoTextureUnlit` + `MatDiffColor` 表现亮度；状态由 `Flow/Relay` 的 entries 驱动，灯只读 | 新增 `Flow/RelayLamp.lua`、`Data/RelayLamp.lua` |
| 世界目标标记 | `h-marks` 把世界坐标投影到屏幕；relay 抬高 1.9、extract 抬高 1.2；视口外按 \|x\|>0.9、\|y\|>0.82 钳制并加边缘箭头；未切断的中继常显、全部切断后追加撤离点 | 投影自算（相机前向/右向/上向 + fov + 宽高比），贴边改用 UI 边距 28、边缘箭头用 `◀`/`▶` 字符；只在 `playing` 态显示 | 新增 `Hud/WorldMarker.lua`、`Data/WorldMarker.lua` |
| 贴花 | 06-decal 全篇无 relay / extract 命中，识别只靠柜体发光件、09-level 的 label 与 HUD 标记 | **不做**，登记差异 | — |

## 二 差异登记

| # | 差异 | 原因 | 代价 |
|---|---|---|---|
| 1 | 灯色用 Unlit 纯色近似，不发光、无 Bloom、灯体不旋转 | 1.35 无 emissive 输出通道，项目未接 Bloom；柜体为静态几何，旋转灯需单独可动节点 | 远处辨识度低于原作，真机暗环境下更明显 |
| 2 | 中继柜与撤离点不加专属贴花 | 原作 06-decal 没有这两类贴花，照做等于自编内容 | 无编号牌与地面标识，靠灯色与世界标记识别 |
| 3 | 投影自己算，不用 `Camera:WorldToScreenPoint` | 该接口的屏幕坐标系（原点、Y 方向）未在 1.35 真机确认，自算结果可复现 | 需要随相机 fov / 宽高比变化重算，已由相机组件实时读取 |
| 4 | 标记文案为短标 A/B/C 与「撤离」，不含距离 | 原作标记只给短标与 label | 无距离读数，靠目标条与探针判断远近 |
| 5 | 超过 150 米不显示标记 | 原作无裁剪；场景 190×320 米，全显无收益 | 远距离目标不提示 |

## 三 自检（真机）

| 步骤 | 期望日志 / 画面 |
|---|---|
| 1 进入 M1_Port | `[M1][LAMP][CREATE] -> OK \| lamps=3 child=lamp maxIntensity=9.0`、`[M1][WMARK][CREATE] -> OK \| relayH=1.9 extractH=1.2 maxDist=150` |
| 2 intro 结束进 playing | `[M1][WMARK][SHOW] -> OK \| count=3 ids=relay_a,relay_b,relay_c`，屏幕上三个中继短标 |
| 3 转头看向别处、走到中继背后 | 标记贴到屏幕边缘并带 `◀`/`▶` 前缀，不消失成 0 个 |
| 4 按住「交互」切断第一处 | `[M1][LAMP][STATE] -> OK \| id=relay_a from=live to=cutting`，随后 `to=cut`；该灯先闪后转红并在约 2.6 秒内熄灭 |
| 5 顶部自检点「标记」 | `[M1][WMARK][PROBE] -> OK \| shown=2 ...`、`[M1][LAMP][PROBE] -> OK \| A=cut/0.00 B=live/0.8x C=live/0.7x` |
| 6 切断三处 | 目标条 3/3，`[M1][WMARK][SHOW] -> OK \| count=1 ids=extract`，屏幕出现「撤离」标记 |
| 7 走进撤离点 | `[M1][EXTRACT][REACH] -> OK`、`[M1][WMARK][SHOW] -> NONE \| count=0`，标记与灯色随结算页消失 |

## 四 约束

- 灯色与世界标记都只读 `Flow/Relay`、`Flow/Extract`、`Flow/GameFlow` 的状态，不写任何玩法状态（第 15 节）。
- 灯罩材质按实例 Clone 一份再改，不动共享实例（第 21 节）。
- 中继柜或灯罩子节点找不到时 `assert` 报错带 id 与坐标，不静默跳过（第 20、28 节）。