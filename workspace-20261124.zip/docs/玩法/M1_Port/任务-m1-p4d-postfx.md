# 任务卡：P4-D 后处理（04-postfx）

状态：verify

> 阶段：P4 表现（`docs/玩法/M1_Port/3a重写路径.md` P4 第一项）
> 原作锚点：`docs/source/3a/parts/04-postfx.part.js`（`SALTLINE_POST`，20 段 pass，TUNE 对象 `g`）
> 范围：只接引擎 Zone 上真实存在的后处理开关；其余逐项登记差异，不摆假开关。

## 一 做什么

1. 新增后处理模块，把原作的泛光、色调映射、自动曝光、暗角四类效果接上引擎 Zone。
2. 每项写入后立刻回读，回读不一致照样记 `NONE`——只证明赋值没报错不算生效。
3. 运行时逐项探测能力，1.35 缺的属性记 `NONE` 并写明 key，不中断其余项（第 20 节）。
4. 自检新增「后处理」按钮：打生效项数 + 5 项回读值。

## 二 原作 pass → 引擎映射

| 原作 pass | 引擎等效 | 本次 |
|---|---|---|
| `depthcopy` / `depthhalf` | 延迟管线自动产出深度；前向管线由引擎内部处理 | 不适用 |
| `ao` / `blur-ao`（12 taps 螺旋） | 延迟 GTAO（`ssaoRadius`/`ssaoIntensity` 可调）；前向桌面固定 SSAO；**前向移动无** | 不做，记差异 1 |
| `vol` / `blur-vol`（HG 双瓣 + 阴影可见性 + 室内尘埃） | `engine-docs/recipes/volumetric-fog.md`，桌面前向有、移动前向无 | 不做，记差异 2 |
| `composite`（半分辨率升采样 + AO/vol 合成） | 引擎内部合成 | 不适用 |
| `motion`（上一帧矩阵运动模糊） | `zone.motionBlurEnabled`，延迟 only | 不做，记差异 3 |
| `down`×6 / `up`×5 + `uMix=0.62` | `zone.bloomMode = BLOOM_MODE_UE` 多级泛光 | **做**（强度按实测收敛到 0.15，见差异 4b） |
| `streak`（横向光条） | 无对应接口 | 不做，记差异 4 |
| `adapt`（1×1 亮度纹理 → 曝光） | `zone.autoExposure*`（plus 直方图路径） | **做** |
| `dirt`（512×288 镜头污渍） | 无对应接口 | 不做，记差异 5 |
| `grade`：AgX 25% + ACES 75% 混合、色散、太阳耀斑、分离色调、暗角、伤害/低血/ADS/闪光/淡出染色 | `tonemapMode`（ACES 或 LUT，二选一）+ `vignetteEnabled` / `vignetteIntensity` | **部分**：ACES + 暗角；其余记差异 6–8 |
| `final`（FXAA / 锐化 0.3 / 颗粒 0.02 / 抖动） | 无独立开关（前向桌面 MSAA，延迟 TAA） | 不做，记差异 9 |

## 三 差异登记

真机是 Android 前向移动管线，`.project/` 下无 `engine.json`，即默认前向；延迟管线在移动端「未经验证，不建议」（`engine-docs/recipes/deferred-rendering.md` §4）。因此下列项按「不做」登记，不是遗漏：

| # | 差异 | 原因 | 代价 |
|---|---|---|---|
| 1 | 环境光遮蔽（原作 AO pass） | 前向移动无 SSAO/GTAO；要 AO 必须切延迟，需 5 个 GBuffer，移动端未验证 | 暗部缺少接触阴影 |
| 2 | 体积光（原作 vol pass） | 前向移动无体积雾 | 缺少光柱与尘埃 |
| 3 | 运动模糊 | 延迟 only | 快速转向无拖影 |
| 4 | 横向光条 streak 未实现 | 引擎无该 pass | 强光无横向辉光 |
| 4b | 泛光强度：引擎 `bloomUEIntensity = 0.15`，原作 grade pass 的 `uBloom = 0.065` | 两者量纲不同（引擎默认 0.675）。本机 A/B：0.55 整片发白（整体 +4.79），0.15 只让亮部发柔光（整体 +1.61） | 亮部辉光幅度与原作不同，需真机再标定 |
| 5 | 镜头污渍 dirt | 引擎无该 pass | 缺镜头脏污层 |
| 6 | AgX 25% 与 ACES 75% 混合 | 引擎 tonemap 只能单选 | 高光滚降与色相偏移与原作不同；取 ACES |
| 7 | 色散 / 太阳耀斑 / 分离色调 / Look 曲线（power 1.18、sat 1.22） | 引擎无全屏染色 pass | 色调更平；后续可用 `tonemapLUT` + 自制 LUT 近似 |
| 8 | 受击 / 低血 / ADS / 枪口闪光 / 淡出的全屏染色与暗角 | 引擎只能改全局暗角强度，无逐项 uniform；受击界面反馈已由 `Combat/PlayerHealth.lua` 承担，不在后处理里重复 | 受击画面不泛红 |
| 9 | FXAA / 锐化 / 颗粒 / 抖动 | 引擎无独立开关 | 边缘与颗粒质感不同 |
| 10 | 动态分辨率与自动降档（原作 `dynres`、`scale`、质量阶） | 未实现；`Perf/Stats.lua` 已有帧率统计，降档策略留到 P5 | 掉帧不自动降分辨率 |
| 11 | HDR 开关（`renderer:SetHDRRendering`） | `Mode.lua` 内 renderer 的取用方式本轮未读，接入点待确认；先按引擎默认，泛光阈值量纲待真机回读 | 泛光亮度响应可能与预期不同 |
| 12 | 暗角强度量纲 | `vignetteIntensity = 0.3` 下边缘仅暗 0.35/255（-0.3%），视觉几乎不可见；强度语义未标定 | 暗角实际很弱 |

## 四 文件

| 文件 | 动作 | 内容 |
|---|---|---|
| `scripts/modes/M1_Port/Post/PostFx.lua` | 新建 | 探测式写入 + 回读 + 日志 + `Probe` / `Dispose` |
| `scripts/modes/M1_Port/Data/PostFx.lua` | 新建 | 15 项目标值，含换算与试调出处 |
| `scripts/modes/M1_Port/Mode.lua` | 改 6 处 | 两个 require、字段声明、`PostFx.Apply(zone, PostFxData)`、自检回调（含 `self.postfx`）、`Mode:ProbePostFx` |
| `scripts/modes/M1_Port/SelfTest.lua` | 改 9 处 | 「后处理」按钮、`onProbePost` / `postFx` 参数、字段、`probePost` 分支、`BuildPostToggles` 与 `TogglePost` |
| `docs/玩法/M1_Port/3a复刻清单.md` | 改 1 行 | `04-postfx` 状态改为「部分」并写缺口 |
| `docs/交接与台账.md` | 追加 1 行 | 待真机验证 |

调用面：`Mode:Start` 在 Zone 建好、天空接好之后调用 `PostFx.Apply`；`SelfTest` 通过回调调 `Mode:ProbePostFx`；没有其他调用方。本模块不被 `scripts/` 根引用。

## 五 数值换算

| 项 | 原作 | 引擎 | 换算 |
|---|---|---|---|
| 曝光下限 | `minExposure = 0.6`（线性倍率） | `autoExposureMinBrightness`（EV） | `log2(0.6) = -0.737` |
| 曝光上限 | `maxExposure = 2.0` | `autoExposureMaxBrightness`（EV） | `log2(2.0) = 1.0` |
| 曝光速度 | `adaptTau = 1.5` 秒 | `autoExposureSpeedUp/Down`（每秒） | `1 / 1.5 = 0.667` |
| 泛光阈值 | 无阈值（全亮度参与） | `bloomUEThreshold = -1` | `-1` 即不设阈值 |
| 泛光强度 | `bloom = 0.065`（grade pass 叠加权重） | `bloomUEIntensity`（引擎默认 0.675） | 量纲不同，取 0.55 试调，不作等价声明 |
| 暗角 | `vignette = 0.3` | `vignetteIntensity` | 量纲未标定，取 0.3 起点 |

## 六 自检与验收

按钮：自检面板「后处理」+ 第二块 **16 个属性级开关**（两行各 8 个，文字尾部「开 / 关」即当前状态）。

逐项开关：每按一次翻转一项，关时写回引擎默认值（来源 `engine-docs/recipes/post-processing.md` 默认值表与 `Zone.d.lua` 字段注释），并回读确认才改状态。日志 `[M1][POST][TOGGLE] -> OK \| key=... on=true\|false want=...`。

其中「泛光阈值」「泛光范围」的关值等于开值（都取引擎默认 `-1` / `4`），切换不改变画面，日志写 `noDelta=true note=开值与引擎默认相同`，不当成真开关。

| 开关 | Zone 属性 | 开 | 关（引擎默认） |
|---|---|---|---|
| 泛光模式 | `bloomMode` | `BLOOM_MODE_UE` | `BLOOM_MODE_LEGACY` |
| 泛光强度 | `bloomUEIntensity` | 0.15 | 0.675 |
| 泛光阈值 | `bloomUEThreshold` | -1 | -1（无差异） |
| 泛光范围 | `bloomUESizeScale` | 4 | 4（无差异） |
| 色调映射 | `tonemapMode` | `TONEMAP_MODE_ACES` | `TONEMAP_MODE_LUT` |
| 曝光开关 | `autoExposureEnabled` | true | false |
| 曝光直方图 | `autoExposurePlusEnabled` | true | false |
| 曝光下限 | `autoExposureMinBrightness` | -0.737 | -10 |
| 曝光上限 | `autoExposureMaxBrightness` | 1.0 | 20 |
| 曝光补偿 | `autoExposureBias` | 0 | 0（无差异） |
| 适应变亮 | `autoExposureSpeedUp` | 0.667 | 3 |
| 适应变暗 | `autoExposureSpeedDown` | 0.667 | 1 |
| 锁曝光 | `autoExposureForceTarget` | false | false（无差异） |
| 暗角贴图 | `vignetteTexture` | 径向贴图 | 1×1 白色占位 |
| 暗角开关 | `vignetteEnabled` | true | false |
| 暗角强度 | `vignetteIntensity` | 0.3 | 0 |

| 步骤 | 期望日志 | 期望值 |
|---|---|---|
| 进入 M1 | `[M1][POST][*] -> OK/NONE \| key=... want=... got=...` 逐项 16 条，然后 `[M1][POST][APPLY] -> OK \| applied=16 probed=16 toggles=16` | 本机 1.35 实测 `applied=16 probed=16 toggles=16`；若某版本缺项则 `applied<16`，每条 NONE 都带 key |
| 点「后处理」 | `[M1][POST][PROBE] -> OK \| applied=16 probed=16 toggles=16` + 16 条 `[M1][POST][STATE] -> OK \| key=... on=... noDelta=...` + 5 条 `[M1][POST][READ]` | `STATE` 的 `on` 与按钮文字一致；`READ` 回读值与写入值一致（误差 ≤2%） |
| 点某个开关 | `[M1][POST][TOGGLE] -> OK \| key=... on=false want=...`，随后同 key 的写入行回读新值 | 按钮文字随之变「关」；再点一次回「开」 |
| 截图判读 | 灯光、自发光、天空高光有晕；亮部有辉光，但天空与地面不应整片发白 | 若整片发白，先查 `[M1][POST][BLOOM] -> ... \| key=bloomUEThreshold`；若画面与关后处理完全一样，`[M1][POST][BLOOM]` 必为 NONE |

本机已跑通的证据（2026-11-24，本地 preview，1632×918，第 600 帧）：

| 对比 | 结果 |
|---|---|
| 关后处理 vs 交付值（泛光 0.15 + 暗角 0.3） | 整体 +1.61、中心 +1.97、边缘 +1.19 → 泛光生效且不发白 |
| 只开暗角（泛光 0） vs 关 | 边缘 -0.35、中心 +0.53 → 暗角生效但幅度很小（见差异 12） |
| 泛光强度 0.55（阈值 -1） | 整体 +4.79，天空与地面同时发白 → 弃用 |
| 泛光阈值 0.8 / 1.0（强度 0.55） | 整体变化 +0.29 / +0.42，噪声级 → 本场景几乎无像素过阈值，等于没开 |
| 开关面板 | `[M1][SELFTEST][POSTTGL] -> OK | event=create count=16 rows=2`，本机截图两行各 8 个、文字后缀「开」 |
| 单个开关的切换 | **未在本机验证**：本地预览无输入注入，点不到按钮；需真机点一次，期望 `[M1][POST][TOGGLE] -> OK | key=... on=false want=...` |

验收标准：

1. 进入 M1 不报错，`APPLY` 行出现且 `applied > 0`。
2. 点「后处理」按钮，`PROBE` 行与 5 条 `READ` 行出现，无 `read-failed`。
3. 截图能看出亮部辉光且整片不发白；看不出来就按未交付处理，先查 `[M1][POST][BLOOM]` 与 `[M1][POST][VIGNETTE]` 两行。

暗角只作「已接通」交付：`vignetteIntensity = 0.3` 下视觉几乎不可见，强度标定留到真机（差异 12）。

## 七 不做

- 不切延迟管线（移动端未验证，且 `04-postfx` 之外的水面倒影、GBuffer 特效都依赖它，应单独立任务）。
- 不加受击染色、闪光染色、淡出染色（引擎无接口，且与 `PlayerHealth` 界面脉冲重复）。
- 不做动态分辨率与自动降档（P5）。
- 不改 HDR 开关（接入点待确认，见差异 11）。

## 八 后续

- 收尾时重新生成 `docs/代码地图.md`（新增 `Post/` 系统域）。
- 若真机 `bloomMode` / `tonemapMode` 为 NONE，先查 1.35 的 Zone 是否带这两个属性，再决定是否改用 `tonemapLUT` 路线。