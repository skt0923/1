# 任务卡 m1-p4b：天气（雨 / 雨溅 / 湿地面）

状态：verify

> 所属阶段：P4 表现第二批。计划见 `3a重写路径.md` 的 P4（`11-ground` 行）。
> 原作锚点：`11-ground` 的雨（雨量 0..1 渐变、风向偏移、室内剔除、屋檐滴水）与雨溅；湿地面按
> `engine-docs/recipes/deferred-scene-weather-lighting.md` 4.3/4.4 的做法改到项目自己的着色器上。
> 范围：只做雨、雨溅、地面湿润三件；平面反射与 SSR 单列为待能力探测项。

## 一 做什么

| 项 | 原作行为 | 本项目做法 | 文件 |
|---|---|---|---|
| 雨丝 | GPU 线段 9000，风向偏移、雨量渐变、室内剔除 | `ParticleEffect` 3000 粒子 + `ParticleEmitter`（`FC_DIRECTION` 沿速度拉伸），发射盒每帧跟相机、`Image` 画 8×64 雨丝贴图，雨量按 0..1 渐变 | `Art/Weather.lua`、`Data/Weather.lua` |
| 雨溅 | 900 水花，只落在积水处 | 320 粒子发射盒贴地跟随玩家，向上散射、短寿命 | 同上 |
| 地面湿润 | 大掩码（积水/潮湿/油污/磨损）+ 湿材质 + 涟漪 + 平面反射 | `BakedSurface.shaderinc` 增加 `wetness` uniform：朝上最湿、立面半湿、世界噪声水洼处粗糙度降到 0.04；由 `Art/Weather.lua` 每帧写地面材质 | 同上 + `kit/TextureBaker/Shaders/BakedSurface.shaderinc` |
| 室内剔除 | 室内盒判据 | 用 `Data/Level.lua` 的「仓库」分区矩形判定，进仓即停雨、湿润回落 | `Mode.lua` 组矩形传给 Weather |

## 二 差异登记

| # | 差异 | 原因 | 代价 |
|---|---|---|---|
| 1 | 雨 3000 粒子（原作 9000 条 GPU 线段），无屋檐滴水 | 没验证过 1.35 上 9000 粒子发射器的帧率；屋檐滴水需要逐屋檐几何 | 雨帘密度低于原作，屋檐下没有滴水 |
| 2 | 水洼没有倒影：无平面反射、无 SSR | 平面反射需镜像相机 + 斜裁剪，SSR 需延迟管线，1.35 都未验证；单列为待能力探测项 | 水洼只有高光，看不到岸桥与集装箱的倒影 |
| 3 | 雨滴涟漪不做 | 需要地面材质的法线动画（原作在 GLSL 里做），改造成本高于本批范围 | 地面雨点打在积水里的环形波纹缺失 |
| 4 | 积水/油污/磨损用 shader 世界噪声阈值近似，不做原作大掩码贴图 | 原作掩码是 2048 双三次采样贴图，本项目的烘焙贴图链路不含掩码通道 | 水洼位置随机且不随关卡布置 |
| 5 | 只有一档雨量，无天气状态机与画质档位 | 本玩法当前没有天气切换入口 | 想停雨只能改 `Data/Weather.lua` 或自检里调 `SetRainLevel` |
| 6 | 湿润同时作用于全部地面分区（堆场/仓库/码头/大门） | 地面材质按分区共享，逐区湿度的收益低 | 室内地面也会变湿（雨本身已按仓房矩形停掉） |
| 7 | 平面反射 / SSR / 涟漪 / 屋檐滴水 | 见第 1–4 条 | **待能力探测**，下一批单独立项 |

## 三 自检（真机）

| 步骤 | 期望日志 / 画面 |
|---|---|
| 1 进图 | `[M1][WEATHER][CREATE] -> OK \| rain=3000 splash=320 ground=4 target=0.70` |
| 2 等 2–3 秒 | `[M1][WEATHER][SHOW] -> OK \| level≈0.7x particles=3000`；画面出现斜雨，地面变深、出现高光 |
| 3 走进仓房 | `[M1][WEATHER][INDOOR] -> NONE \| pos=...`，雨与雨溅同时消失，湿润度向 0 回落 |
| 4 走出仓房 | `[M1][WEATHER][INDOOR] -> OK \| pos=...`，雨恢复 |
| 5 顶部自检点「雨」 | `[M1][WEATHER][PROBE] -> OK \| level=.. target=0.70 wetness=.. indoors=false rain=true splash=true ground=4` |
| 6 对照帧率 | `[M1][PERF][PROBE] -> OK \| fps=...`，与开雨前同一位置对比，下降不超过约 15% |

## 四 约束

- 雨量、粒子数、风偏、湿润渐变全部在 `Data/Weather.lua`（第 15 节）；`Art/Weather.lua` 只做表现。
- 地面材质取自 `level.zones` 上的 `StaticModel`，按共享实例写 `wetness`，不 Clone（同一分区共享一份是预期效果，第 21 节）。
- `ParticleEmitter`、`DiffUnlitParticleAdd`、贴图生成失败一律 `assert` 带资源名（第 20 节）。