# 任务 m1-p2a 猎犬敌人与波次
状态：verify

## 范围

- 敌人占位骨架：躯干 + 头 + 尾三段盒体（内置 `Models/Box.mdl`），不做骨骼动画。
- 状态机：巡逻 / 追击 / 攻击 / 死亡；视线用静态射线遮挡判断，光束点射（telegraph → burst）。
- 波次：3 / 4 / 5 只三波，间隔 4 秒；生成点取原作 `09-level` 的 24 个地面点。
- 玩家射击命中：`Rifle` 增加 `hitscan` 回调，敌人用包围盒求交，取与静态命中更近者。
- 自检按钮「敌人」→ `[M1][WAVE][PROBE]`。

## 原作锚点

| 内容 | 片段 | 语句 / 字段 |
|---|---|---|
| 猎犬数值 | `17-enemy.part.js` | `Kv` 配置：hp 140、shotDamage 5、burst 4、burstGap .11、telegraph .5、cooldown 1.8–3、runSpeed 4.5、patrolSpeed 1.5、rangeMin 8、rangeMax 18、spreadNear .045、spreadFar .12、lungeRange 3、lungeDamage 15、lungeCooldown 3.5、lungeSpeed 9.5 |
| 通用感知 | 同上 | `sightRange` 45、`sightCone` 200 |
| 生成点 | `09-level.part.js` | 语句 4 `enemySpawns` 的 24 个 `ground` 点 |

## 差异登记（未批准前不实现）

| # | 参考实现 | 当前实现 | 前提差异 | 批准 |
|---|---|---|---|---|
| 1 | 猎犬有骨骼、四足动画、朝向与咆哮动作 | 三段盒体占位，无动画 | 项目无猎犬模型与动画资源 | 待批准 |
| 2 | 寻路网格 + 冲刺扑击（lungeSpeed 9.5 / lungeDamage 15） | 直线追击，不做扑击 | 无导航网格；扑击需要动画配合 | 待批准 |
| 3 | 命中判定用骨骼胶囊与散布锥 | 轴对齐包围盒（半宽 0.9） | 无骨骼 | 待批准 |
| 4 | 敌人子弹是弹道实体（boltSpeed 70），命中由射线对角色胶囊判定 | 散布按弧度加到方向，命中由射线对玩家球（半径 0.5）判定，即打即中 | 缺弹道飞行物表现与弹药池 | 已批准（2026-11-24） |
| 5 | 波次由 `20-flow` 的状态机推进，含简报与撤离 | 固定 3/4/5 三波，间隔 4 秒；flow 状态机已建（m1-p3a/p3b），波次仍独立推进、未由 flow 接管 | P3-C/P4 再接 | 待批准 |
| 6 | 敌人伤害按部位与护甲结算 | 每发固定 shotDamage 5 | 无部位系统 | 待批准 |
| 7 | 生成点全部来自原作 `enemySpawns` | 额外补 3 个大门区近点（-30,14 / -28,18 / -33,20），否则出生点附近无敌人可打 | 原作生成点针对完整流程的波次推进，进场首波没有近点 | 已批准（2026-11-24） |
| 8 | 原作的敌人 AI 由 17-enemy 的决策树驱动 | 自检用 `Combat/AutoPilot.lua` 反向驱动玩家：选最近敌人、限速转向、接近到 10 米、容差 2.5°内开火、空弹自动换弹、卡住偏航绕行、绕不过换目标，30 秒收工出报告 | 只用于自检，不是玩法 AI；不寻路，被墙彻底挡住的目标会放弃 | 已批准（2026-11-24） |

## 自检

按钮「敌人」。进入玩法约 1.2 秒后应出现刷怪日志；走近堆场敌人会看到状态切换。

```
[M1][WAVE][CREATE] -> OK | waves=3 spawns=24 first=3
[M1][WAVE][SPAWN] -> OK | wave=1 pending=2 total=1
[M1][ENEMY][SPAWN] -> OK | index=1 zone=yard hp=140 pos=(-19.0,0.0,-1.4)
[M1][ENEMY][SIGHT] -> OK | index=1 dist=...
[M1][ENEMY][STATE] -> OK | index=1 state=chase dist=...
[M1][WEAPON][SHOT] -> OK | ... hit=1 ... target=enemy
[M1][ENEMY][DAMAGE] -> OK | index=1 reason=rifle amount=25 hp=115
[M1][ENEMY][DEATH] -> OK | index=1 reason=rifle shots=...
[M1][WAVE][PROBE] -> OK | wave=1 pending=0 alive=0 spawned=3 nearest=-1.0
[M1][HURT][APPLY] -> OK | reason=enemy amount=5.0 health=95/100
```

站在出生点不动约 8 秒会被首波打死，HUD 显示「阵亡」（死亡后禁用移动与镜头属 P3，未做）。

2026-11-24 本地自跑（9 项连跑）实际结果：

- 移动：`OK | reason=steady moved=1.89` 之后一条 `NONE | reason=blocked`（出生点正前方 4 米是原作隔离墩，位移 0.08）；被挡住不再判 FAIL。
- 跳跃：`OK | event=land apex=0.90 expect=[0.80,1.20]`。
- 换弹：`ammo 20/30 → 30/30 reserve 140`。
- 地面：`OK | name=asphalt tex=1024x1024 size=40x40 baked=true`。
- 道具：`OK | placed=165 builders=31`。
- 敌人：`OK | wave=1 pending=0 alive=2 spawned=3 nearest=8.1 nearestHp=140`；同轮射击把 3 号敌人从 140 打到 10 后 `DEATH`。
- 受伤项被拒（`already=dead`）：连跑时机枪先被首波打死。单项点「受伤」不受影响。

2026-11-24 AI 自检（按钮「AI」，30 秒）实跑结果：

```
[M1][AI][START] -> OK | shots=0 health=60
[M1][AI][TARGET] -> OK | index=1 dist=8.4 hp=140
[M1][AI][FIRE] -> OK | dist=8.2 yawErr=2.0 los=true
[M1][ENEMY][DEATH] -> OK | index=1 reason=rifle shots=4
[M1][WAVE][NEXT] -> OK | wave=2 spawn=4
[M1][AI][STOP] -> OK | elapsed=30.0 shots=21 kills=3 alive=4 spawned=7 hp=60->100
```

已知限制：AI 不寻路。第二波敌人在仓库/围墙后面时，它靠近到 17–50 米仍无视线，会先偏航绕行、三次绕不过就 `[M1][AI][SKIP]` 换目标，因此后两波多数打不到。
