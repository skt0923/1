# 任务卡 m1-p4a：命中表现（贴花 / 碎屑 / 火花 / 弹壳）

状态：verify

> 所属阶段：P4 表现的第一批。计划见 `3a重写路径.md` 的 P4。
> 原作锚点：`12-effects` 语句 1（贴花池 `j1` cap 160、尺寸表 `ZR`、按表面分派碎屑与火花、弹壳池 60）、`06-decal`（弹痕贴图用 2D 画布生成）。
> 范围：只做「打中东西看得见反馈」，不做爆炸、烟、持续发射器与文字标签。

## 一 做什么

| 项 | 原作行为 | 本项目做法 | 文件 |
|---|---|---|---|
| 弹痕贴花 | 池 cap 160；尺寸 `bullet_metal .25 / bullet_concrete .34 / bullet_wood .24 / bullet_glass .30`；贴图用 2D 画布画 | 池 48，Lua 逐像素生成 4 张 64px 贴图，贴到命中点（`DiffUnlitAlpha` + 薄盒），池满覆盖最旧 | 新增 `Art/Decals.lua`、`Data/ImpactFx.lua` |
| 碎屑与火花 | 按表面分派数量与速度（metal 12/18、concrete 更多碎屑更少火花…） | 32 碎屑 + 24 火花固定池，自算法位移与重力，沿命中法线半球散射 | 新增 `Art/ImpactBursts.lua` |
| 弹壳 | 池 60，抛出后落地 | 12 枚薄盒，从抛壳口向右上抛出，落地停住、1.4 秒回收 | 新增 `Art/ShellPool.lua` |
| 表面判定 | 12-effects 按材质 case 分派 | 按命中节点名子串判定（`container`→metal、`shelf_rack`→metal、`guard_booth`→glass、`crate/pallet`→wood，其余 concrete） | `Data/ImpactFx.lua` 的 `nameKeys` |

## 二 接线

`Rifle:FireOne` 命中静态体时把 `{ point, normal, nodeName }` 交给 `Effects:Fire`，由 `Effects:Attach` 注入的三个模块分别生成贴花、碎屑火花与弹壳；`Effects:Update` 驱动三者。

## 三 差异登记

| # | 差异 | 原因 | 代价 |
|---|---|---|---|
| 1 | 池容量压小：贴花 48（原作 160）、碎屑 32（原作 256）、火花 24（原作加色池 3200）、弹壳 12（原作 60） | 每个都是独立 StaticModel，移动端绘制批次与节点数受限（本机 static=1031 / batches≈160） | 密集射击时旧贴花被更快覆盖 |
| 2 | 贴图 64px、无 mip（1.35 无 mip 写入接口）、无贴图集分块 | 引擎能力限制（台账「引擎版本约束」） | 极近距离能看到锯齿；四种表面各自一张图，未做同图集随机旋转 |
| 3 | 碎屑与火花是薄盒/球体，不加色、不发光、无拖尾 | 1.35 无 emissive 输出、无 Bloom | 火花观感弱于原作 |
| 4 | 弹壳不弹跳、不滚动、不发声 | 抛物线落地即静止，省物理体 | 落地动作生硬 |
| 5 | 不做爆炸池与烟 | 当前玩法没有爆炸源（无手雷、油桶不爆）；等有消费方再补 | 无爆炸表现 |
| 6 | 06-decal 只做弹痕 4 种 + 焦痕尺寸表，不做编号牌/集装箱文字/公司 logo | 那部分属 P4 材质与贴花批次，且本项目道具为几何简化版 | 箱体仍无文字 |

## 四 自检（真机）

| 步骤 | 期望日志 |
|---|---|
| 1 进图 | `[M1][DECAL][CREATE] -> OK \| cap=48 textures=4 size=64px`、`[M1][BURST][CREATE] -> OK \| debris=32 sparks=24`、`[M1][SHELL][CREATE] -> OK \| cap=12` |
| 2 朝集装箱开枪 | `[M1][DECAL][ADD] -> OK \| n=1 surface=metal size=0.25 ...`、`[M1][BURST][SPAWN] -> OK \| surface=metal debris=10 sparks=16`、`[M1][SHELL][EJECT] -> OK \| n=1` |
| 3 朝地面开枪 | 日志 `surface=concrete size=0.34`，地面出现灰黑弹孔 |
| 4 连打 12 枪 | `[M1][SHELL][EJECT] -> OK \| n=10`，弹壳池轮转不报错 |
| 5 顶部自检点「特效」 | `[M1][DECAL][PROBE] -> OK \| live=.. added=.. last=metal`、`[M1][BURST][PROBE]`、`[M1][SHELL][PROBE]` |

## 五 约束

- 贴花/碎屑/弹壳只由 `Weapon/Rifle` 的命中信息驱动，不读玩法状态；数值只在 `Data/ImpactFx.lua`（第 15 节）。
- 材质按实例新建（贴图各自持有），不 Clone 共享材质（第 21 节）。
- 模型、Technique、贴图生成失败一律 `assert` 带资源名（第 20 节）。