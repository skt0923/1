# HTML 拆分

> 职责：把单文件 HTML（库与代码打包在一个 script 里）拆成可分别查阅的文件，且必须能逐字节还原。
> 不负责：不绑定具体项目；不是日常阅读路径。

把单文件 HTML（尤其是把库和游戏代码打包进一个 `<script>` 的产物）拆成可分别查阅的文件，**且必须能逐字节还原**。还原不了一致就是方案不成立，换更保守的做法。

本文是方法论，不绑某个具体项目。末尾有可直接复用的脚本骨架。

## 两级拆分

拆成什么样，取决于你之后怎么用：

| 级别 | 目标 | 产物 | 什么时候用 |
|---|---|---|---|
| **C 阶段**（主干） | 把「库」和「业务代码」分开 | 3–4 个大块：`three-lib.part.js`、`game-code.part.js`、`ui.css`、`head.html` | 必做。先把 90% 的无用代码（第三方库）隔离出去 |
| **A 阶段**（细化） | 把业务代码按功能分块 | 每个功能一个 `.part.js`，如 `16-weapon`、`17-enemy` | 业务代码仍太大、改功能时要翻很久时做 |

**顺序固定：先 C 后 A**。C 阶段通过校验之后再做 A，A 的产物以 C 的 `game-code.part.js` 为基准校验。这样任何一级出问题都能立即定位是哪一级的错。

A 阶段是**可选**的。如果 C 之后业务代码只有几十 KB，直接看 `game-code.part.js` 就够了，不必细分。

---

## 一 先判断值不值得拆

拆之前先回答三个问题，任何一个答不上来就先别拆。

| 检查 | 命令 | 判断 |
|---|---|---|
| 代码是否被压缩成超长行 | `awk 'length($0)>2000{n++} END{print n}' 文件.html` | 超长行数占多数 → 行号完全不可用于定位 |
| 是否有可读的结构 | `grep -c '<script>' 文件.html` | 多个 `<script>` 可直接按标签切，最简单 |
| 内嵌资源有多少 | `grep -oE 'data:[a-z]+/[a-z]+;base64,' 文件.html \| wc -l` | 有大量 base64 → 资源也要拆出来，工作量翻倍 |

**关键结论**：如果只有**一个** `<script>` 且被压缩，那么：

- 按行拆**一定错**（一行里可能有几十个函数，行边界和代码边界不对齐）
- 按字符数硬切**一定错**（会切断字符串、模板字面量、括号）
- 唯一安全的切点是 **AST 语句边界**

### 不要相信文档里写的分界

如果参考文档（清单/手册）里写了「L4191 起是游戏实现」这种行号分界，**必须实测验证**。本次实测就发现清单写的 L4191 是错的：

| 说法 | 实际 |
|---|---|
| 清单 §0.2：L4191 起为游戏实现 | L3833 起已是游戏实现（天空噪声 GLSL） |
| 误判原因 | 压缩后一条语句可以跨 359 行（`L3991-L4385`），行号与语句边界完全不对齐 |

**可靠的分界依据是内容特征，不是行号**。做法：找一个只可能属于目标代码的品牌标记/字符串常量，取它所在语句的下标作为切分点，再交叉校验「切点之前不得出现该标记」。

---

## 二 原理：AST 语句边界切分

### 为什么可行

JavaScript 解析器（acorn / esprima / @babel/parser）会给每个节点输出 `start` / `end` 字节偏移。**语句级别**的偏移天然满足：

- 不重叠
- 边界落在 `;` 或 `}` 之后，不会切在字符串/括号内部
- 按偏移切片后原样拼接，**逐字节等于原文**

### 必须先探明结构

打包产物常见两种形态，处理方式不同：

```
形态 A:  <script> 顶层有多条语句        → 直接切 script.body
形态 B:  <script> 只有一条 IIFE         → 切 iife.body.body（本次就是这种）
```

探测方法：

```js
const ast = acorn.parse(code, { ecmaVersion:'latest', locations:true, ranges:true });
console.log('顶层语句数:', ast.body.length);           // 1 → 形态 B
console.log('类型:', ast.body[0].type);                 // ExpressionStatement
// 形态 B 展开：
const fn = ast.body[0].expression.callee;              // ArrowFunctionExpression
const stmts = fn.body.body;                            // 真正的语句列表
```

本次实测：顶层 1 条 IIFE，内部 **876 条语句**（591 函数声明、186 变量声明、96 表达式语句、2 for-of、1 块），这 876 条就是天然切分单位。

### 必须保留的三个东西

拆出来的片段要能还原，除了语句本身，还得存：

| 项 | 说明 | 本次实测值 |
|---|---|---|
| IIFE 外壳头 | 第一条语句之前的原文 | `"\n(()=>{"`（7 字节） |
| IIFE 外壳尾 | 最后一条语句之后的原文 | `"})();\n\n"`（7 字节） |
| 切分点间隙 | 前段最后一条语句结束 → 后段第一条语句开始之间的原文 | `""`（本次为空，但**不能假设为空**） |

切分点间隙必须单独存。本次第一版用 `join('\n')` 拼接，直接多了 876 字节（正好是语句数），被校验抓出来。

---

## 三 五个坑（都踩过，且都被校验抓到）

> **阅读约定**：本节所有标 ❌ 的代码块是**错误示范，禁止照抄**，只用来识别症状。它们故意不可执行（含 `...` 占位符），`node --check` 会报错。正确写法在每段末尾标 ✅，或见第五节完整骨架。

### 坑 1：用 `join()` 拼语句会丢空白

```text
❌ 错误写法（仅示意，勿用）
stmts.map(s => code.slice(s.start, s.end)).join('\n')
症状：原文件语句之间本来紧挨着，join 凭空插入换行 → 拼回后多出「语句数」个字节
```

✅ **正确**：切连续区间，不是逐条拼接。

```js
const text = code.slice(stmts[0].start, stmts[stmts.length - 1].end);
```

### 坑 2：拼回时硬编码 HTML 字面量

```text
❌ 错误写法（仅示意，勿用）
const out = head + '<style>' + css + '</style>\n</head>\n<body>' + dom + ...
症状：`</style>` 与 `<script>` 之间到底几个换行、有没有 <body>，手写靠猜，必然对不上
```

✅ **正确**：把每个标签和间隙都切成独立文件（`style-open.txt`、`style-close.txt` 等），拼回时纯拼接、零手写字面量。

### 坑 3：拆分脚本自己把产物删了

`rm -rf docs/source/3a` 会把 `_split.js` 和 `_rejoin.js` 一起删掉（它们就在那个目录）。要么脚本放目录外，要么清理时按文件名排除。

### 坑 4：假阴性测试

篡改后仍报 PASS，说明测试无效。本次踩过：

```text
❌ 无效的测试命令（仅示意，勿用）
sed -i '0,/var _M/s//var _N/' game-code.part.js
症状：以为改到了，实际 'var _M' 在 three-lib 里，game-code 里没有 → 没改成 → PASS 是假阴性
```

✅ **正确**：每个参与拼接的文件**单独**做一次篡改测试，四种都测：

| 篡改对象 | 预期 |
|---|---|
| `ui.css` 追加 1 字节 | FAIL |
| `three-lib.part.js` 改首字符 | FAIL |
| `game-code.part.js` 中间插换行 | FAIL |
| `stmts.json` 的 `splitGap` 加一个空格 | FAIL |

四次全 FAIL，恢复后 PASS，校验才算有效。

### 坑 5：拆完的文件各自套 IIFE 就跑不起来

去掉外壳后 `game-code` 依赖 `three-lib` 的变量。若给每个文件各套一层 IIFE，作用域隔离，`game-code` 立刻报 undefined。

两种做法，**选第一种**：

| 做法 | 后果 |
|---|---|
| 片段文件**不套外壳**，由 rejoin 拼回完整文件 | ✅ 保真，且片段不能单独运行（README 要写清） |
| 去掉 IIFE 改全局作用域 | ⚠️ 可行但污染全局（本次有 1970 个压缩短名），且加载顺序错就静默崩溃 |

若确实需要「去 IIFE 让每个文件独立」，先做三项检查（本次实测全为零，但不代表别的文件为零）：`delete 标识符`、`枚举 window 属性`、`eval`/`with`/`new Function`。

---

## 四 标准流程

### 4.1 C 阶段（必做）

```
0. 备份基线：cp 原文件 .tmp/baseline/ && sha256sum 记录
1. 探测结构：语句数 / 形态 A 或 B / 内嵌资源数
2. 定分界：找内容特征锚点，不用行号（见 4.4）
3. 切分：按 AST 语句边界，存「语句区间 + 外壳头尾 + 切分间隙 + 所有字面量标签」
4. 还原校验：纯拼接 → SHA256 与原文件比对
5. 位置校验：分段偏移 + 反错乱 + 反向抽取（见 4.3）
6. 破坏性测试：四个文件逐个篡改，确认校验有效
7. 语法自检：每个 .part.js 单独过一遍 acorn（只查语法，不执行）
8. 运行时等价：Node vm + DOM 桩，原文件与拼接体对比报错点
```

第 4 步不通过 = 方案不成立，回到第 3 步或退到更保守的切法（只切最明显的 `<style>` / `<script>` 两块）。

### 4.2 A 阶段（业务代码仍很大时做）

前置：C 阶段已通过全部校验。

```
1. 列功能清单：把业务代码按「改一处只会开一个文件」的原则列出功能块
2. 给每块找锚点：每块起始位置的那个具名声明（函数名或变量名）
3. 校验锚点单调递增：锚点必须按代码实际顺序排列，否则分组逻辑有误
4. 校验覆盖完整：各段语句数之和必须等于业务代码总语句数，不能有缺口
5. 切连续区间 + 记录段间间隙（同 C 阶段，不能 join）
6. 还原校验：22 个片段 → game-code.part.js，逐字节一致
7. 三级直连：片段 → 完整 HTML，SHA256 与原文件一致（不经过中间文件）
8. 位置校验 + 反错乱 + 反向抽取（同 C 阶段）
9. 运行时等价：原文件 / C 产物 / A 产物 / 三级直连，四路对比
```

**分组原则**：

| 原则 | 说明 |
|---|---|
| 按功能，不按体积 | `08-props` 158 条 145 KB 也比拆成三个文件好——改道具就该在一个文件里 |
| 每块必须有一个明确主题 | 能用一句话说清「这个文件管什么」 |
| 锚点必须是具名声明 | 压缩代码里只有函数名和变量名可靠，不要用行号 |
| 顺序必须与代码一致 | 片段按原顺序拼接才能还原，分组顺序不能重排 |

本次 3A 拆分的 22 个功能块见 `docs/source/3a/parts/_index.json` 的 `desc` 字段与 `docs/玩法/M1_Port/3a拆分产物.md` 的分组表。

### 4.3 为什么还需要位置校验

哈希是对整个字节流按顺序算的，顺序变了哈希必然变，所以「哈希相同但位置错乱」在数学上不可能。**但校验脚本本身可能写错**——本次就遇到过检查脚本把拼接顺序写反、误报 FAIL，以及漏算 IIFE 外壳头导致偏移差 7 字节的情况。为避免「校验器本身不可信」，多做四层独立验证：

| 层 | 做法 | 判定 |
|---|---|---|
| 分段偏移 | 按**真实拼接顺序**逐段累加偏移，核对每段内容 | 每段全匹配，偏移累加等于文件长度、剩余 0 |
| 反错乱 | 故意交换两个大段后重新拼接 | 必须 **不相等**，否则说明顺序不敏感、校验无效 |
| 反向抽取 | 从原文件按已知偏移切段，与片段文件逐个比对 | 全部相等 |
| 独立重写 | 不用还原脚本，用另一种语言（如 Python）手写拼接 | 字符串完全相等 |

最后一条专治「校验器作弊」：如果还原脚本里藏了某种自洽但错误的逻辑，换一种实现重写一遍就能暴露。

```python
# 分段偏移检查（顺序必须与 rejoin 一致，不是文件名字母序）
cursor = 0
for name, frag in segments_in_rejoin_order:
    assert original[cursor:cursor+len(frag)] == frag, name
    cursor += len(frag)
assert cursor == len(original), '未覆盖到末端'
```

**两个常见算错点**：

1. 分段表顺序写错会误报 FAIL。顺序应直接照抄 rejoin 的拼接表达式，而不是按文件名排。
2. 起点偏移漏算 IIFE 外壳头。完整起点 = `<script>` 标签之后 + 外壳头 + 库区间 + 切分间隙，四段都要加，漏一段就差几个字节。

### 4.4 定分界：内容特征优先

不要相信行号。本次 3A 拆分遇到两次边界错判：

| 错误分界 | 问题 | 正确分界 |
|---|---|---|
| 清单写的 L4191 | 该行在压缩代码中间，且 L3991 起已是游戏 shader | L3833（`oi` 游戏世界配置） |
| 天空 shader `Ug` (#353) | 漏掉 #332–#352 共 21 条游戏语句（配置/画质/事件总线/随机/数学/几何工具） | `gf=class{...WebGLRenderer}` 是库最后一站，`oi` 是游戏第一条 |

**可靠的分界依据**：找一个只可能属于目标代码的标识（如游戏品牌常量、专属配置对象），取它所在语句下标作切点，再双向交叉校验：

```js
// 切点之前必须有库的特征（证明没切晚）
if (!before.includes('WebGLRenderer')) throw new Error('切早了');
// 切点之前不能有业务的特征（证明没切晚）
if (before.includes('// SALTLINE_SKY')) throw new Error('切晚了');
// 切点之后必须有业务特征（证明没切早）
if (!after.includes('SALTLINE')) throw new Error('切早了');
```

---

## 五 可复用脚本骨架

依赖：`npm install acorn`（约 2 秒）。

完整可运行版本见 `docs/source/3a/_split.js`（C 阶段）、`_split_a.js`（A 阶段）、`_rejoin.js`、`parts/_rejoin_a.js`。下面是精简后的核心逻辑。

### 5.1 C 阶段：拆库 / 业务

```js
const fs = require('fs'), path = require('path'), crypto = require('crypto');
const acorn = require('acorn');

const SRC = '输入.html', OUT = '输出目录';
const raw = fs.readFileSync(SRC, 'utf8');

// ① 定位标签
const styleOpen = raw.indexOf('<style>');
const styleClose = raw.indexOf('</style>');
const scriptOpen = raw.indexOf('<script>');
const scriptClose = raw.lastIndexOf('</script>');

// ② 解析 script
const scriptText = raw.slice(scriptOpen + 8, scriptClose);
const ast = acorn.parse(scriptText, { ecmaVersion:'latest', sourceType:'script', locations:true, ranges:true });

// ③ 取语句列表（形态 A 用 ast.body，形态 B 用下面的展开）
let stmts = ast.body;
if (stmts.length === 1 && stmts[0].expression?.callee?.body?.body) {
  stmts = stmts[0].expression.callee.body.body;   // IIFE
}
stmts = [...stmts].sort((a, b) => a.start - b.start);

// ④ 定分界（用内容特征，不用行号）
const ANCHOR = 'GAME_START_ANCHOR';
const splitIdx = stmts.findIndex(st =>
  st.type === 'VariableDeclaration' &&
  st.declarations.some(d => d.id.type === 'Identifier' && d.id.name === ANCHOR)
);
if (splitIdx < 0) throw new Error('找不到锚点');
// 交叉校验
if (scriptText.slice(0, stmts[splitIdx].start).includes('BRAND_MARK')) throw new Error('边界不对');
if (!scriptText.slice(stmts[splitIdx].start).includes('BRAND_MARK')) throw new Error('边界不对');

// ⑤ 切连续区间 + 存间隙
const libStmts = stmts.slice(0, splitIdx), gameStmts = stmts.slice(splitIdx);
const iifeHead = scriptText.slice(0, stmts[0].start);
const iifeTail = scriptText.slice(stmts[stmts.length - 1].end);
const libText  = scriptText.slice(libStmts[0].start, libStmts[libStmts.length - 1].end);
const splitGap = scriptText.slice(libStmts[libStmts.length - 1].end, gameStmts[0].start);
const gameText = scriptText.slice(gameStmts[0].start, gameStmts[gameStmts.length - 1].end);

// ⑥ 写文件（所有字面量都切片保存，禁止手写）
fs.mkdirSync(OUT, { recursive: true });
fs.writeFileSync(path.join(OUT, 'head.html'),        raw.slice(0, styleOpen));
fs.writeFileSync(path.join(OUT, 'style-open.txt'),   raw.slice(styleOpen, styleOpen + 7));
fs.writeFileSync(path.join(OUT, 'ui.css'),           raw.slice(styleOpen + 7, styleClose));
fs.writeFileSync(path.join(OUT, 'style-close.txt'),  raw.slice(styleClose, scriptOpen));
fs.writeFileSync(path.join(OUT, 'script-open.txt'),  raw.slice(scriptOpen, scriptOpen + 8));
fs.writeFileSync(path.join(OUT, 'iife-head.txt'),    iifeHead);
fs.writeFileSync(path.join(OUT, 'lib.part.js'),      libText);
fs.writeFileSync(path.join(OUT, 'game.part.js'),     gameText);
fs.writeFileSync(path.join(OUT, 'iife-tail.txt'),    iifeTail);
fs.writeFileSync(path.join(OUT, 'script-close.txt'), raw.slice(scriptClose));
fs.writeFileSync(path.join(OUT, 'meta.json'), JSON.stringify({
  sourceSha256: crypto.createHash('sha256').update(raw, 'utf8').digest('hex'),
  splitGap, totalStmts: stmts.length, splitIndex: splitIdx,
}, null, 1));
```

### 5.2 A 阶段：业务代码按功能细分

```js
// 输入：C 阶段的 game-code.part.js；输出：parts/NN-name.part.js
const GROUPS = [
  ['00-config',   'oi',  '世界边界/太阳/玩家参数/画质/事件总线'],
  ['01-geometry', '$e',  '盒体UV/圆角盒/圆柱UV/管缆/合并'],
  // ... 每个功能一个条目，顺序必须与代码一致
];

// ① 收集所有具名声明 -> 语句下标
const nameToStmt = new Map();
allStmts.forEach((st, i) => {
  if (st.type === 'FunctionDeclaration' && st.id && !nameToStmt.has(st.id.name)) nameToStmt.set(st.id.name, i);
  if (st.type === 'VariableDeclaration') for (const d of st.declarations) {
    if (d.id.type === 'Identifier' && !nameToStmt.has(d.id.name)) nameToStmt.set(d.id.name, i);
  }
});

// ② 解析每个锚点，校验存在 + 单调递增
const resolved = GROUPS.map(([name, anchor, desc]) => {
  const idx = nameToStmt.get(anchor);
  if (idx === undefined) throw new Error('找不到锚点 ' + anchor);
  return { name, anchor, desc, start: idx };
});
for (let i = 1; i < resolved.length; i++) {
  if (resolved[i].start <= resolved[i - 1].start) throw new Error('分组顺序与代码不符：' + resolved[i].name);
}

// ③ 段区间 + 覆盖校验
const segments = resolved.map((r, i) => ({ ...r, end: i + 1 < resolved.length ? resolved[i + 1].start : allStmts.length }));
const covered = segments.reduce((a, sg) => a + (sg.end - sg.start), 0);
if (covered !== allStmts.length - gameStart) throw new Error('有语句没被分到任何文件');

// ④ 切连续区间 + 存段间间隙（不能 join，会丢空白）
for (const seg of segments) {
  const text = scriptText.slice(allStmts[seg.start].start, allStmts[seg.end - 1].end);
  fs.writeFileSync(path.join(PARTS_DIR, seg.name + '.part.js'), text, 'utf8');
}
```

**A 阶段的两个特有坑**：

| 坑 | 现象 | 修法 |
|---|---|---|
| `tailGap` 取成整个 script 的结尾 | 拼回多出 IIFE 尾 `"})();\n\n"`（7 字节） | 尾部间隙应到「最后一条语句结束」为止，不含外壳 |
| 锚点在某处「首次出现」但实际属于后段 | 分组顺序校验会报错 | 以**声明位置**为准，不是引用位置 |

### 5.3 还原 + 校验

```js
const fs = require('fs'), path = require('path'), crypto = require('crypto');
const read = f => fs.readFileSync(path.join(__dirname, f), 'utf8');
const meta = JSON.parse(read('meta.json'));

const scriptText = read('iife-head.txt') + read('lib.part.js')
                 + meta.splitGap
                 + read('game.part.js') + read('iife-tail.txt');
const out = read('head.html')
          + read('style-open.txt') + read('ui.css') + read('style-close.txt')
          + read('script-open.txt') + scriptText + read('script-close.txt');

const sha = t => crypto.createHash('sha256').update(t, 'utf8').digest('hex');
const original = fs.readFileSync(process.argv[2] || '输入.html', 'utf8');

if (sha(out) === sha(original)) { console.log('[PASS] 逐字节完全一致'); process.exit(0); }
console.error('[FAIL] 长度 ' + Buffer.byteLength(original) + ' vs ' + Buffer.byteLength(out));
process.exit(1);
```

### 5.4 三级直连（A 阶段必做）

不经过 `game-code.part.js` 中间文件，直接从所有功能片段拼到完整 HTML，校验 SHA256。这一层能证明「片段顺序 + 段间间隙 + C 阶段外壳」三者组合正确，而不只是中间文件正确。

```js
let gameCode = idx.headGap;
for (let i = 0; i < idx.parts.length; i++) {
  gameCode += readParts(idx.parts[i].file);
  if (i < idx.gaps.length) gameCode += idx.gaps[i].gap;
}
gameCode += idx.tailGap;

const html = readRoot('head.html')
  + readRoot('style-open.txt') + readRoot('ui.css') + readRoot('style-close.txt')
  + readRoot('script-open.txt')
  + readRoot('iife-head.txt') + readRoot('three-lib.part.js') + meta.splitGap + gameCode + readRoot('iife-tail.txt')
  + readRoot('script-close.txt');
```

---

## 六 本次实测数据（可作量级参考）

| 指标 | 值 |
|---|---|
| 原文件 | 1,425,707 字节 / 6,215 行 / SHA256 `9e55b520…` |
| 压缩程度 | 22 个超长行占 1.1 MB；最长单行 238,667 字符 |
| Script 结构 | 单 IIFE，内部 876 条语句 |
| **C 阶段** | 库 332 条（702 KB）/ 游戏 544 条（676 KB） |
| **A 阶段** | 22 个功能片段，8 KB ~ 145 KB |
| 拆分耗时 | acorn 解析约 2.3 秒 |
| 还原校验 | C / A / 三级直连，三路 SHA256 全部等于原文件 |
| 运行时等价 | 原文件 / C 产物 / A 产物 / 三级直连，四路执行路径一致 |

参考实例：`docs/source/3a/`（`_split.js`、`_split_a.js`、`_rejoin.js`、`parts/_rejoin_a.js`、`stmts.json`、`parts/_index.json`）。

---

## 七 一句话验收

> 拆完能还原，还原后 SHA256 等于拆分前；篡改任何一个参与拼接的文件都会被校验报 FAIL。

两条同时成立才算拆分成功，否则方案不成立，退回更保守的切法。

做了 A 阶段时再加一条：

> 三级直连（所有功能片段 → 完整 HTML，不经中间文件）的 SHA256 也必须等于原文件。

---

## 八 拆完之后怎么用

拆分只是手段，目的是**改功能时只开一个文件**。建立索引时按这个格式：

| 想看什么 | 去哪里 |
|---|---|
| 某个功能怎么实现 | `parts/NN-name.part.js`，文件名即功能名 |
| 某个压缩标识（如 `Gg`、`4.5`）是什么 | `parts/_index.json` 的 `desc` + `startLine` |
| 这个功能的原作行号 | `stmts.json` 里按 `label` 搜，取 `line` |
| 一段代码属于哪个功能 | 在 `parts/` 里 `grep` 该标识，命中的文件即归属 |

A 阶段的分组表就是索引本身，把它写进项目文档（如 `docs/玩法/M1_Port/3a复刻清单.md`「一 功能索引」），改功能前先查表定位文件。
