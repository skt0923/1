/**
 * 校验 docs/3A复刻实现清单.md 里声明的路径与行号是否真实存在
 */
const fs = require('fs');
const path = require('path');

const ROOT = '/workspace';
const md = fs.readFileSync(path.join(ROOT, 'docs/3A复刻实现清单.md'), 'utf8');

let fail = 0;
let pass = 0;

// 1) 校验所有 `scripts/xxx.lua` 路径存在，以及 `:行号` 在该文件范围内
const re = /`((?:scripts|docs|assets)\/[^`\s]+?\.(?:lua|md|mp3|js|json|css|html))(?::(\d+)(?:-(\d+))?)?`/g;
let m;
const seen = new Set();
while ((m = re.exec(md)) !== null) {
  const rel = m[1];
  const line = m[2] ? parseInt(m[2], 10) : null;
  const line2 = m[3] ? parseInt(m[3], 10) : null;
  const abs = path.join(ROOT, rel);
  const key = rel + ':' + line;
  if (seen.has(key)) continue;
  seen.add(key);

  // 通配符路径（如 assets/audio/sfx/*.mp3）按目录存在性判断
  if (rel.includes('*')) {
    const dir = path.dirname(abs);
    if (!fs.existsSync(dir)) {
      console.log(`[FAIL] 通配符目录不存在: ${dir}`);
      fail++;
    } else {
      pass++;
    }
    continue;
  }

  if (!fs.existsSync(abs)) {
    console.log(`[FAIL] 路径不存在: ${rel}`);
    fail++;
    continue;
  }
  if (line !== null) {
    const total = fs.readFileSync(abs, 'utf8').split('\n').length;
    const max = line2 || line;
    if (max > total) {
      console.log(`[FAIL] ${rel}:${line}${line2 ? '-' + line2 : ''} 超出文件行数 ${total}`);
      fail++;
    } else {
      pass++;
    }
  } else {
    pass++;
  }
}

console.log('');
console.log(`路径与行号校验: 通过 ${pass}，失败 ${fail}`);

// 2) 校验 22 个 parts 文件都被提及
console.log('');
const idx = JSON.parse(fs.readFileSync(path.join(ROOT, 'docs/source/3a/parts/_index.json'), 'utf8'));
let missing = [];
for (const p of idx.parts) {
  if (!md.includes(p.file)) missing.push(p.file);
}
console.log('22 个功能片段是否都在清单中提及:', missing.length === 0 ? '是' : '缺 ' + missing.join(', '));
if (missing.length) fail++;

// 3) 校验清单里的锚点在 parts 文件里真的存在
console.log('');
let anchorFail = 0;
for (const p of idx.parts) {
  const text = fs.readFileSync(path.join(ROOT, 'docs/source/3a/parts', p.file), 'utf8');
  const anchor = p.anchor;
  // 锚点应作为声明出现在该文件中
  const pat = new RegExp('(?:function\\s+' + anchor.replace(/[$]/g, '\\$') + '\\s*\\(|var\\s+[^;]*\\b' + anchor.replace(/[$]/g, '\\$') + '\\s*=|,\\s*' + anchor.replace(/[$]/g, '\\$') + '\\s*=)');
  if (!pat.test(text)) {
    // 宽松回退：至少出现过
    if (!text.includes(anchor)) {
      console.log(`[FAIL] 锚点 ${anchor} 不在 ${p.file}`);
      anchorFail++;
    }
  }
}
console.log('锚点存在性:', anchorFail === 0 ? '全部存在' : anchorFail + ' 个缺失');
fail += anchorFail;

console.log('');
console.log(fail === 0 ? '[PASS] 清单校验全部通过' : '[FAIL] 共 ' + fail + ' 处问题');
process.exit(fail === 0 ? 0 : 1);
