/**
 * 3A 参考原型还原与保真校验脚本
 *
 * 把 docs/source/3a/ 下的片段按原顺序纯拼接，还原成完整单文件 HTML，
 * 并与 docs/3a游戏文档.html 做 SHA256 比对。
 *
 * 用法:
 *   node docs/source/3a/_rejoin.js             # 还原并校验（不写文件，只比对）
 *   node docs/source/3a/_rejoin.js --write     # 同时写出 rejoined.html 供人工查看
 *   node docs/source/3a/_rejoin.js <输出路径>   # 写出到指定路径并校验
 *
 * 退出码: 0 = 逐字节完全一致, 1 = 不一致（打印首个差异位置）
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DIR = __dirname;
const ORIGINAL = path.resolve(DIR, '../../3a游戏文档.html');
const read = (f) => fs.readFileSync(path.join(DIR, f), 'utf8');

const meta = JSON.parse(read('stmts.json'));
const scriptText =
  read('iife-head.txt') + read('three-lib.part.js') + meta.splitGap + read('game-code.part.js') + read('iife-tail.txt');

// 纯拼接：不写任何字面量，全部来自切片文件
const out =
  read('head.html') +
  read('style-open.txt') + read('ui.css') + read('style-close.txt') +
  read('script-open.txt') + scriptText + read('script-close.txt');

const sha = (t) => crypto.createHash('sha256').update(t, 'utf8').digest('hex');

if (!fs.existsSync(ORIGINAL)) {
  console.error('[FAIL] 找不到原文件: ' + ORIGINAL);
  process.exit(1);
}
const original = fs.readFileSync(ORIGINAL, 'utf8');
const origSha = sha(original);
const outSha = sha(out);

const arg = process.argv[2];
if (arg === '--write' || (arg && arg !== '--check')) {
  const outPath = arg === '--write' ? path.join(DIR, 'rejoined.html') : path.resolve(arg);
  fs.writeFileSync(outPath, out, 'utf8');
  console.log('已写出: ' + outPath);
}

console.log('原文件   : ' + ORIGINAL + ' (' + Buffer.byteLength(original, 'utf8') + ' 字节)');
console.log('原 SHA256: ' + origSha);
console.log('拼回 SHA : ' + outSha);
console.log('');

if (outSha === origSha) {
  console.log('[PASS] 逐字节完全一致');
  process.exit(0);
}

console.error('[FAIL] 字节不一致');
const a = Buffer.from(original, 'utf8');
const b = Buffer.from(out, 'utf8');
console.error('长度: 原 ' + a.length + ' vs 拼回 ' + b.length + ' (差 ' + (b.length - a.length) + ')');
for (let i = 0; i < Math.min(a.length, b.length); i++) {
  if (a[i] !== b[i]) {
    const from = Math.max(0, i - 80);
    console.error('首个差异在字节 ' + i + ':');
    console.error('  原    : ' + JSON.stringify(a.subarray(from, i + 80).toString('utf8')));
    console.error('  拼回  : ' + JSON.stringify(b.subarray(from, i + 80).toString('utf8')));
    break;
  }
}
process.exit(1);
