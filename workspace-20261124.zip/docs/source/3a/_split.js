/**
 * 3A 参考原型拆分脚本（方案 C：三大块）
 *
 * 输入: docs/3a游戏文档.html  (只读, 永不修改)
 * 输出: docs/source/3a/
 *   head.html            doctype + meta + title（style 标签之前）
 *   style-open.txt       "<style>" 字面量
 *   ui.css               全部 CSS
 *   style-close.txt      "</style>...<body>...<script>" 之间的全部字面量
 *   script-open.txt      "<script>" 字面量
 *   iife-head.txt        "(()=>{" 外壳头
 *   three-lib.part.js    Three.js 库区间（365 条顶层语句，无外壳）
 *   game-code.part.js    游戏实现区间（511 条顶层语句，无外壳）
 *   iife-tail.txt        "})();" 外壳尾
 *   script-close.txt     "</script>...</html>" 及之后全部字面量
 *   stmts.json           顶层语句精确索引 + 切分间隙
 *   _rejoin.js           （本脚本旁边，需手动保留）
 *
 * 保真策略:
 *   1. 用 acorn 解析，按 AST 语句边界切分，绝不截断括号/字符串
 *   2. 每个片段保留原始字节，不做任何格式化
 *   3. _rejoin.js 纯拼接后 SHA256 必须等于原文件
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const acorn = require('acorn');

const SRC = '/workspace/docs/3a游戏文档.html';
const OUT = '/workspace/docs/source/3a';

/**
 * 游戏实现起点锚点：`oi`（世界边界配置 `{min:new W(-40,0,-30),...}`）。
 *
 * 不用清单 0.2 的「L4191」行号分界——那是错的。
 * 实测边界证据：
 *   #331 gf     = class{...WebGLRenderer...}    Three.js 渲染器，库的最后一站
 *   #332 oi     = {min:new W(-40,0,-30),...}    游戏世界边界配置 ← 真正的分界
 *   #333 zy     自动画质
 *   #334 Dy     事件总线
 *   #335 il     随机数
 *   #341 $e     盒体 UV 重算（清单 §6 几何工具）
 *   #353 Ug     天空噪声 GLSL，被 #355 以 ${Ug}${Ng} 引用
 *   #355 H6/V6  "// SALTLINE_SKY" 天空 shader
 *   #359 Wy/xf  "// SALTLINE_SHADOW" 软阴影
 *   #364 Bg     "// SALTLINE_POST" 后处理 shader 集
 *
 * 之前的 #353 分界是错的：会把 #332-#352 共 21 条游戏语句（配置、画质、
 * 事件总线、随机数、数学工具、桩对象、几何工具）错划进库。
 */
const GAME_START_ANCHOR = 'oi';

const raw = fs.readFileSync(SRC, 'utf8');
const origSha = crypto.createHash('sha256').update(raw, 'utf8').digest('hex');

const styleOpen = raw.indexOf('<style>');
const styleClose = raw.indexOf('</style>');
const scriptOpen = raw.indexOf('<script>');
const scriptClose = raw.lastIndexOf('</script>');
if ([styleOpen, styleClose, scriptOpen, scriptClose].some((v) => v < 0)) {
  throw new Error('标签定位失败');
}

const cssText = raw.slice(styleOpen + 7, styleClose);
const scriptText = raw.slice(scriptOpen + 8, scriptClose);

const ast = acorn.parse(scriptText, {
  ecmaVersion: 'latest',
  sourceType: 'script',
  locations: true,
  ranges: true,
});

const iife = ast.body[0].expression;
if (iife.type !== 'CallExpression' || iife.callee.type !== 'ArrowFunctionExpression') {
  throw new Error('预期单一 IIFE，实际为 ' + (ast.body[0] && ast.body[0].type));
}

const stmts = [...iife.callee.body.body].sort((a, b) => a.start - b.start);

// 按锚点名定位游戏实现起点
const splitIdx = stmts.findIndex((st) => {
  if (st.type !== 'VariableDeclaration') return false;
  return st.declarations.some((d) => d.id.type === 'Identifier' && d.id.name === GAME_START_ANCHOR);
});
if (splitIdx < 0) throw new Error('找不到游戏实现起点锚点: ' + GAME_START_ANCHOR);

// 交叉校验：锚点语句之前不得出现 WebGLRenderer（库特征），之后必须是游戏配置
const beforeText = scriptText.slice(0, stmts[splitIdx].start);
const afterText = scriptText.slice(stmts[splitIdx].start);
if (!beforeText.includes('WebGLRenderer') && !beforeText.includes('var gf=class')) {
  throw new Error('分界校验失败：锚点之前没有 Three.js 渲染器特征，边界可能偏早');
}
if (beforeText.includes('"SALTLINE"') || beforeText.includes('// SALTLINE_SKY')) {
  throw new Error('分界校验失败：锚点之前已出现游戏 shader 标记，边界偏晚');
}
if (!afterText.includes('SALTLINE')) {
  throw new Error('分界校验失败：锚点之后无 SALTLINE，边界不对');
}
console.log('[OK] 分界校验通过：锚点 #' + splitIdx + ' L' + stmts[splitIdx].loc.start.line + '（' + stmts[splitIdx].type + '）');
console.log('     锚点前有 Three.js 渲染器、无游戏 shader；锚点后有 SALTLINE');


// 外壳首尾
const iifeHead = scriptText.slice(0, stmts[0].start);
const iifeTail = scriptText.slice(stmts[stmts.length - 1].end);

// 按连续区间切片：保留语句之间的原始空白，切分点间隙单独存放
const libStmts = stmts.slice(0, splitIdx);
const gameStmts = stmts.slice(splitIdx);
const libText = scriptText.slice(libStmts[0].start, libStmts[libStmts.length - 1].end);
const splitGap = scriptText.slice(libStmts[libStmts.length - 1].end, gameStmts[0].start);
const gameText = scriptText.slice(gameStmts[0].start, gameStmts[gameStmts.length - 1].end);

fs.mkdirSync(OUT, { recursive: true });

// 语句索引
const index = stmts.map((st, i) => {
  let label = '';
  if (st.type === 'FunctionDeclaration') label = st.id ? st.id.name : '[anon]';
  else if (st.type === 'VariableDeclaration') {
    label = st.declarations.map((d) => (d.id.type === 'Identifier' ? d.id.name : '<pattern>')).join(',');
  }
  return {
    i,
    part: i < splitIdx ? 'three-lib' : 'game-code',
    type: st.type,
    line: st.loc.start.line,
    endLine: st.loc.end.line,
    label: label.slice(0, 200),
  };
});

fs.writeFileSync(
  path.join(OUT, 'stmts.json'),
  JSON.stringify(
    {
      source: 'docs/3a游戏文档.html',
      sourceSha256: origSha,
      sourceBytes: Buffer.byteLength(raw, 'utf8'),
      splitIndex: splitIdx,
      totalStmts: stmts.length,
      splitGap: splitGap,
      stmts: index,
    },
    null,
    1
  ),
  'utf8'
);

// 文本块：全部按原始切片边界保存，rejoin 只做纯拼接
fs.writeFileSync(path.join(OUT, 'head.html'), raw.slice(0, styleOpen), 'utf8');
fs.writeFileSync(path.join(OUT, 'style-open.txt'), raw.slice(styleOpen, styleOpen + 7), 'utf8');
fs.writeFileSync(path.join(OUT, 'ui.css'), cssText, 'utf8');
fs.writeFileSync(path.join(OUT, 'style-close.txt'), raw.slice(styleClose, scriptOpen), 'utf8');
fs.writeFileSync(path.join(OUT, 'script-open.txt'), raw.slice(scriptOpen, scriptOpen + 8), 'utf8');
fs.writeFileSync(path.join(OUT, 'iife-head.txt'), iifeHead, 'utf8');
fs.writeFileSync(path.join(OUT, 'iife-tail.txt'), iifeTail, 'utf8');
fs.writeFileSync(path.join(OUT, 'script-close.txt'), raw.slice(scriptClose), 'utf8');

// JS 片段（无外壳，纯连续区间）
fs.writeFileSync(path.join(OUT, 'three-lib.part.js'), libText, 'utf8');
fs.writeFileSync(path.join(OUT, 'game-code.part.js'), gameText, 'utf8');

// 语法自检
function checkParse(name, code) {
  try {
    acorn.parse(code, { ecmaVersion: 'latest', sourceType: 'script' });
    console.log('[OK] ' + name + ' 语法解析通过');
  } catch (err) {
    console.error('[FAIL] ' + name + ' 语法错误: ' + err.message);
    process.exitCode = 1;
  }
}
checkParse('three-lib.part.js', fs.readFileSync(path.join(OUT, 'three-lib.part.js'), 'utf8'));
checkParse('game-code.part.js', fs.readFileSync(path.join(OUT, 'game-code.part.js'), 'utf8'));

console.log('\n=== 拆分完成 ===');
console.log('原 SHA256:', origSha);
console.log('语句: 总 ' + stmts.length + ' | three-lib ' + splitIdx + ' | game-code ' + (stmts.length - splitIdx));
const files = [
  'head.html', 'style-open.txt', 'ui.css', 'style-close.txt', 'script-open.txt',
  'iife-head.txt', 'three-lib.part.js', 'game-code.part.js', 'iife-tail.txt', 'script-close.txt',
];
for (const f of files) {
  console.log('  ' + f.padEnd(22) + fs.statSync(path.join(OUT, f)).size + ' 字节');
}
