/**
 * A 阶段还原脚本：parts/*.part.js -> game-code.part.js
 *
 * 用法:
 *   node docs/source/3a/parts/_rejoin_a.js             # 还原并校验（不写文件）
 *   node docs/source/3a/parts/_rejoin_a.js --write     # 写出 game-code.rebuilt.js
 *
 * 退出码: 0 = 与 game-code.part.js 逐字节一致, 1 = 不一致
 */
const fs = require('fs');
const path = require('path');

const DIR = __dirname;
const GAME_CODE = path.resolve(DIR, '../game-code.part.js');
const read = (f) => fs.readFileSync(path.join(DIR, f), 'utf8');

const idx = JSON.parse(read('_index.json'));

let out = idx.headGap;
for (let i = 0; i < idx.parts.length; i++) {
  out += read(idx.parts[i].file);
  if (i < idx.gaps.length) out += idx.gaps[i].gap;
}
out += idx.tailGap;

const target = fs.readFileSync(GAME_CODE, 'utf8');

if (process.argv.includes('--write')) {
  const p = path.join(DIR, 'game-code.rebuilt.js');
  fs.writeFileSync(p, out, 'utf8');
  console.log('已写出:', p);
}

console.log('片段数:', idx.parts.length, ' 间隙数:', idx.gaps.length);
console.log('拼回长度:', out.length, ' game-code.part.js:', target.length);

if (out === target) {
  console.log('[PASS] A 阶段还原：与 game-code.part.js 逐字节完全一致');
  process.exit(0);
}

console.error('[FAIL] 不一致');
for (let i = 0; i < Math.min(out.length, target.length); i++) {
  if (out[i] !== target[i]) {
    console.error('首个差异在字符', i);
    console.error('  拼回:', JSON.stringify(out.slice(Math.max(0, i - 60), i + 60)));
    console.error('  目标:', JSON.stringify(target.slice(Math.max(0, i - 60), i + 60)));
    break;
  }
}
process.exit(1);
