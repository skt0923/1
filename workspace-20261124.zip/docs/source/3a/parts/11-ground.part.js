function Ib(i,e){let t={uTime:{value:0},uRain:{value:.6},uWetG:i.mats&&i.mats.uniforms&&i.mats.uniforms.wet||{value:1},uReflOn:{value:0},uReflLod:{value:0},uMarkRes:{value:e.marks.image.width},uMaskRes:{value:e.mask.image.width},uMask:{value:e.mask},uMarks:{value:e.marks},uDetail:{value:e.detail},uDetailN:{value:e.detailN},uRefl:{value:e.black},uMaskRect:{value:new W(Li.x0,Li.z0,1/Li.size)},uMarkRect:{value:new Dt(fa.x0,fa.z0,1/fa.w,1/fa.h)},uReflMatrix:{value:new Ye},uReflScale:{value:new Ae(.5,.5)}},n=new Qt({color:16777215,roughness:1,metalness:0});n.name="apron_wet",n.onBeforeCompile=r=>{Object.assign(r.uniforms,t),r.vertexShader=`varying vec3 vGWorld;
`+r.vertexShader.replace("#include <begin_vertex>",`#include <begin_vertex>
  vGWorld = (modelMatrix * vec4(transformed, 1.0)).xyz;`),r.fragmentShader=r.fragmentShader.replace("#include <common>",`#include <common>
`+TR).replace("#include <map_fragment>",AR).replace("#include <roughnessmap_fragment>","float roughnessFactor = gRough;").replace("#include <normal_fragment_maps>",`#include <normal_fragment_maps>
  normal = normalize(mat3(viewMatrix) * normalize(vec3(-gNxz.x, 1.0, -gNxz.y)));`).replace("#include <lights_physical_fragment>",`#include <lights_physical_fragment>
  material.specularColor = mix(material.specularColor, vec3(0.075), max(gPuddle, gSoak * 0.5));`).replace("#include <lights_fragment_maps>",`#include <lights_fragment_maps>
`+RR).replace("#include <lights_fragment_end>",`#include <lights_fragment_end>
  reflectedLight.directSpecular = min(reflectedLight.directSpecular, vec3(40.0));`)},n.customProgramCacheKey=()=>"saltline-apron-3";let s=new rn(190,320,1,1).rotateX(-Math.PI/2).translate(-65,0,0),o=new Qe(s,n);return o.receiveShadow=!0,o.castShadow=!1,o.name="apron",o.matrixAutoUpdate=!1,o.updateMatrix(),{mesh:o,material:n,uniforms:t}}function zb(i,e,t){let n=new Wn;n.layers.set(0),n.matrixAutoUpdate=!0;let s=new si(16,16,{type:js,format:_n,colorSpace:Er,minFilter:Ln,magFilter:Zt,generateMipmaps:!0,depthBuffer:!0,stencilBuffer:!1,samples:0});s.texture.name="planarReflection";let o=new W,r=new W,a=new Ye,l=new Ae,c=new go,u=new Dt,h=new Dt,f=new Ye().set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),p=[],d={target:s,camera:n,enabled:!0,active:!1};function v(g,x,y){let b=i.quality.planar||0;if(!d.enabled||b<=0){e.uReflOn.value=0,d.active=!1;return}if(o.setFromMatrixPosition(y.matrixWorld),o.y<.03){e.uReflOn.value=0,d.active=!1;return}let m=i.render&&i.render.resolution;m&&m.x>8?l.copy(m):g.getDrawingBufferSize(l);let A=Math.max(64,Math.round(l.x*b/16)*16),_=Math.max(32,Math.round(l.y*b/8)*8);(s.width!==A||s.height!==_)&&s.setSize(A,_),a.extractRotation(y.matrixWorld),r.set(0,0,-1).applyMatrix4(a).add(o),n.position.set(o.x,-o.y,o.z),n.up.set(0,1,0).applyMatrix4(a),n.up.y=-n.up.y,r.y=-r.y,n.lookAt(r),n.near=y.near,n.far=y.far,n.updateMatrixWorld(!0),n.matrixWorldInverse.copy(n.matrixWorld).invert(),n.projectionMatrix.copy(y.projectionMatrix),e.uReflMatrix.value.copy(f).multiply(n.projectionMatrix).multiply(n.matrixWorldInverse),c.normal.set(0,1,0),c.constant=.01,c.applyMatrix4(n.matrixWorldInverse),u.set(c.normal.x,c.normal.y,c.normal.z,c.constant);let M=n.projectionMatrix.elements;h.x=(Math.sign(u.x)+M[8])/M[0],h.y=(Math.sign(u.y)+M[9])/M[5],h.z=-1,h.w=(1+M[10])/M[14],u.multiplyScalar(2/u.dot(h)),M[2]=u.x,M[6]=u.y,M[10]=u.z+1,M[14]=u.w,n.projectionMatrixInverse.copy(n.projectionMatrix).invert();let E=y.projectionMatrix.elements;e.uReflScale.value.set(E[0]*.5,E[5]*.5),e.uReflLod.value=Math.log2(Math.max(_,1)/270);for(let w=0;w<t.length;w++)p[w]=t[w].visible,t[w].visible=!1;try{i.render.renderWorld(n,s)}finally{for(let w=0;w<t.length;w++)t[w].visible=p[w]}e.uRefl.value=s.texture,e.uReflOn.value=1,d.active=!0}return d.pass=v,d}var B1=[[-.92,.39,9.5,.06],[-.75,-.66,5.7,.04],[-.99,.12,3.3,.026],[-.5,.87,2,.016]],Db=[[-.8,.6,1.31,.02],[-.95,-.31,.83,.014],[-.35,-.94,.57,.01],[-.6,.8,.39,.007],[-1,.05,.27,.005],[.3,.95,.47,.006],[-.86,-.51,.21,.0035]];for(let i of B1.concat(Db)){let e=Math.hypot(i[0],i[1]);i[0]/=e,i[1]/=e,i[4]=2*Math.PI/i[2],i[5]=Math.sqrt(9.81*i[4])}var fi=i=>Number.isInteger(i)?i.toFixed(1):i.toFixed(5);function Lb(i,e,t){let n=1-bs.smoothstep(Math.hypot(i-30,e),50,220),s=0;for(let o of B1)s+=o[3]*Math.sin(o[4]*(o[0]*i+o[1]*e)-o[5]*t);return oi.seaY+s*n}var CR=B1.map(i=>`  { float ph = ${fi(i[4])} * dot(vec2(${fi(i[0])}, ${fi(i[1])}), swp.xz) - ${fi(i[5])} * uTime; sdisp.y += ${fi(i[3])} * sin(ph); sdisp.xz += vec2(${fi(i[0])}, ${fi(i[1])}) * (${fi(i[3]*.6)} * cos(ph)); }`).join(`
`),PR=B1.map(i=>`  slopeA += vec2(${fi(i[0])}, ${fi(i[1])}) * (${fi(i[3]*i[4])} * cos(${fi(i[4])} * dot(vec2(${fi(i[0])}, ${fi(i[1])}), sxz) - ${fi(i[5])} * uTime));`).join(`
`),IR=Db.map(i=>`  slopeB += vec2(${fi(i[0])}, ${fi(i[1])}) * (${fi(i[3]*i[4])} * cos(${fi(i[4])} * dot(vec2(${fi(i[0])}, ${fi(i[1])}), sxz) - ${fi(i[5])} * uTime));`).join(`
`),zR=`
uniform float uTime; uniform sampler2D uDetail, uDetailN; uniform vec3 uHazeA, uHazeB, uSunDirW;
varying vec3 vGWorld; varying float vSAmp;
float gRough; vec2 gNxz; float gOcc; float gSDist; float gSpark;
`,DR=`
{
  vec2 sxz = vGWorld.xz;
  float sd = length(cameraPosition - vGWorld); gSDist = sd;
  vec2 slopeA = vec2(0.0), slopeB = vec2(0.0);
${PR}
${IR}
  float nearB = 1.0 - smoothstep(25.0, 110.0, sd);
  vec2 t1 = texture2D(uDetailN, sxz * 0.113 + uTime * vec2(-0.021, 0.009)).ba - 0.5;
  vec2 t2 = texture2D(uDetailN, sxz * 0.031 + uTime * vec2(-0.007, -0.004)).ba - 0.5;
  vec2 t3 = texture2D(uDetailN, sxz.yx * 0.39 + uTime * vec2(0.031, -0.027)).ba - 0.5;
  gNxz = slopeA * vSAmp + slopeB * nearB + t1 * 0.2 + t2 * 0.24 + t3 * 0.1 * nearB;
  // foam / scum along the quay wall (x = 30) and around the moored hull x[33,49] z[-60,-9]
  float dq = sxz.x - 30.0;
  vec2 hq = abs(sxz - vec2(41.0, -34.5)) - vec2(4.0, 21.5);
  float dh = length(max(hq, 0.0)) + min(max(hq.x, hq.y), 0.0) - 4.0;
  float de = min(dq, dh);
  vec4 fn = texture2D(uDetail, sxz * 0.41 + uTime * vec2(-0.012, 0.007));
  vec4 fn2 = texture2D(uDetail, sxz * 0.093 + uTime * vec2(0.004, 0.003));
  float band = 1.0 - smoothstep(0.0, 0.2 + fn2.g * fn2.g * 2.2, de);
  float foam = clamp(band * smoothstep(0.5, 0.68, fn.a * 0.55 + fn.r * 0.25 + fn2.g * 0.3 + band * 0.2), 0.0, 1.0) * step(-0.3, de);
  float scum = (1.0 - smoothstep(0.0, 5.0, de)) * smoothstep(0.4, 0.7, fn2.g);
  vec3 alb = vec3(0.0045, 0.013, 0.017);
  alb = mix(alb, vec3(0.03, 0.04, 0.034), scum * 0.6);
  alb = mix(alb, vec3(0.3, 0.32, 0.3), foam * 0.7);
  diffuseColor.rgb *= alb;
  // wind structure: broad cat's-paw patches (ruffled, darker, duller) between calmer slicks, plus long swell shading
  vec4 fn3 = texture2D(uDetail, sxz * 0.0123 + uTime * vec2(0.0016, 0.0011));
  float gust = smoothstep(0.38, 0.62, fn2.g * 0.45 + fn3.g * 0.75 - 0.1);
  float swell = sin(dot(sxz, vec2(-0.118, 0.05)) - uTime * 0.55 + fn3.a * 5.0) * 0.5 + 0.5;
  gNxz = gNxz * mix(0.4, 1.35, gust) + vec2(-0.92, 0.39) * (swell - 0.5) * 0.07;
  gSpark = mix(0.55, 1.0, swell) * mix(1.0, 0.6, gust);
  diffuseColor.rgb *= mix(1.0, 0.6, gust);
  gRough = mix(mix(0.1, 0.32, smoothstep(12.0, 380.0, sd)) * mix(0.62, 1.5, gust), 0.65, max(foam, scum * 0.3));
  gNxz *= 1.0 - foam * 0.6;
  gOcc = mix(0.3, 1.0, smoothstep(0.0, 8.0, de)) * mix(0.8, 1.05, swell);
}
`,LR=`
{
  vec3 sdir = normalize(vGWorld - cameraPosition);
  float toSun = pow(max(dot(normalize(sdir.xz + vec2(1e-5)), normalize(uSunDirW.xz)), 0.0), 3.0);
  vec3 hz = mix(uHazeA, uHazeB, toSun);
  outgoingLight = mix(outgoingLight, hz, smoothstep(220.0, 860.0, gSDist) * 0.8);
}
`;function gv(i,e,t,n,s){let o=[i],r=i,a=t;for(;r<e-.001;)r=Math.min(e,r+a),o.push(r),a=Math.min(s,a*n);return o}function kb(i,e){let t=oi.seaY,n=gv(27.5,880,.75,1.075,120),s=gv(48,880,.9,1.085,120),r=s.map(M=>-M).reverse().concat(gv(-48+.9,48-.9,.9,1,.9),s.slice(0)),a=n.length,l=r.length,c=12,u=new Float32Array((a*l+c)*3),h=[],f=0;for(let M=0;M<l;M++)for(let E=0;E<a;E++)u[f++]=n[E],u[f++]=t,u[f++]=r[M];for(let M=0;M<l-1;M++)for(let E=0;E<a-1;E++){let w=M*a+E,S=w+1,z=w+a,H=z+1;h.push(w,z,S,S,z,H)}let p=(M,E,w,S)=>{let z=f/3;for(let[H,O]of[[M,E],[w,E],[M,S],[w,S]])u[f++]=H,u[f++]=t,u[f++]=O;h.push(z,z+2,z+1,z+1,z+2,z+3)};p(-880,-880,27.5,-158),p(-880,158,27.5,880),p(-880,-158,-158,158);let d=new nt;d.setAttribute("position",new et(u,3));let v=new Float32Array(u.length);for(let M=1;M<v.length;M+=3)v[M]=1;d.setAttribute("normal",new et(v,3)),d.setIndex(h),d.boundingSphere=new Dn(new W(0,t,0),1300);let g=en.horizonAway.clone().multiplyScalar(.85),x=en.horizon.clone().multiplyScalar(.8),y={uTime:{value:0},uDetail:{value:e.detail},uDetailN:{value:e.detailN},uHazeA:{value:g},uHazeB:{value:x},uSunDirW:{value:Mn.dir.clone()}},b=new Qt({color:16777215,roughness:.1,metalness:0});b.name="sea",b.onBeforeCompile=M=>{Object.assign(M.uniforms,y),M.vertexShader=`uniform float uTime; varying vec3 vGWorld; varying float vSAmp;
`+M.vertexShader.replace("#include <begin_vertex>",`#include <begin_vertex>
  vec3 swp = (modelMatrix * vec4(transformed, 1.0)).xyz;
  vSAmp = 1.0 - smoothstep(50.0, 220.0, distance(swp.xz, vec2(30.0, 0.0)));
  vec3 sdisp = vec3(0.0);
${CR}
  transformed += sdisp * vSAmp;
  vGWorld = swp;`),M.fragmentShader=M.fragmentShader.replace("#include <common>",`#include <common>
`+zR).replace("#include <map_fragment>",DR).replace("#include <roughnessmap_fragment>","float roughnessFactor = gRough;").replace("#include <normal_fragment_maps>",`#include <normal_fragment_maps>
  normal = normalize(mat3(viewMatrix) * normalize(vec3(-gNxz.x, 1.0, -gNxz.y)));`).replace("#include <lights_fragment_maps>",`#include <lights_fragment_maps>
  radiance *= gOcc; iblIrradiance *= gOcc;`).replace("#include <lights_fragment_end>",`#include <lights_fragment_end>
  { // sun glitter: strongest along the sun's azimuth, calmer to the sides; broken by swell and cat's paws
    vec3 sv = normalize(vGWorld - cameraPosition);
    float az = max(dot(normalize(sv.xz + vec2(1e-5)), normalize(uSunDirW.xz)), 0.0);
    reflectedLight.directSpecular = min(reflectedLight.directSpecular, vec3(40.0)) * gSpark * mix(0.3, 1.0, az * az * az);
  }`).replace("#include <opaque_fragment>",LR+`
#include <opaque_fragment>`)},b.customProgramCacheKey=()=>"saltline-sea-1";let m=new Qe(d,b);m.name="sea",m.receiveShadow=!0,m.castShadow=!1,m.frustumCulled=!1,m.matrixAutoUpdate=!1;let A=new Qt({color:724238,roughness:.55,metalness:0}),_=new Qe(new rn(320,4.4).rotateY(Math.PI/2).translate(29.88,-2.18,0),A);return _.name="quaySkirt",_.receiveShadow=!0,_.matrixAutoUpdate=!1,{mesh:m,skirt:_,uniforms:y,material:b}}var Ub=`
uniform vec3 uBoxMin[4]; uniform vec3 uBoxMax[4];
bool wInside(vec3 p){
  for (int i = 0; i < 4; i++) { if (all(greaterThan(p, uBoxMin[i])) && all(lessThan(p, uBoxMax[i]))) return true; }
  return false;
}
float wPhase(float c){ float g = 0.72; return (1.0 - g * g) / (12.566 * pow(1.0 + g * g - 2.0 * g * c, 1.5)); }
`,kR=`
uniform float uTime, uRain, uPix, uDrip; uniform vec3 uVel, uBox, uSunDir, uSunCol, uAmb;
attribute vec4 aSeed;
varying vec3 vCol; varying float vA; varying vec2 vUv;
${Ub}
uniform vec4 uSky[8];   // roof openings (x, z, half w, half d): rain falls through these into the shed
bool wSky(vec3 p){
  for (int i = 0; i < 8; i++) { if (abs(p.x - uSky[i].x) < uSky[i].z && abs(p.z - uSky[i].y) < uSky[i].w) return true; }
  return false;
}
void main(){
  vUv = position.xy;
  float sp = 0.82 + 0.36 * aSeed.w;
  vec3 vel = uVel * sp;
  vec3 p; float len; float kill = 0.0;
  if (aSeed.w < 0.0) {                       // eave drip line (shed south eave), free-fall from 7 m
    float T = 1.19; float t = fract(uTime / T * (0.9 + 0.2 * aSeed.y) + aSeed.z) * T;
    p = vec3(mix(-16.0, 12.0, aSeed.x), 7.0 - 4.9 * t * t, -10.72 + 0.05 * sin(aSeed.x * 911.0));
    vel = vec3(0.0, -9.81 * t - 0.3, 0.0); len = 0.022 * length(vel) + 0.03;
    kill = 1.0 - uDrip;
    if (fract(aSeed.x * 37.7) > 0.55 + 0.45 * uRain) kill = 1.0;
  } else {
    p = aSeed.xyz * uBox + vel * uTime;
    p = mod(p - cameraPosition + 0.5 * uBox, uBox) - 0.5 * uBox + cameraPosition;
    len = 0.03 * length(vel);
    if (fract(aSeed.w * 7.13 + aSeed.x) > uRain) kill = 1.0;
    if (wInside(p) && !wSky(p)) kill = 1.0;
  }
  if (p.y < (p.x > 30.0 ? -1.6 : 0.0)) kill = 1.0;
  vec3 dir = normalize(vel);
  vec3 toP = p - cameraPosition; float dist = length(toP);
  vec3 side = normalize(cross(dir, toP));
  float w0 = 0.005 + 0.004 * fract(aSeed.w * 3.7);
  float w = max(w0, dist * uPix * 0.75);
  vec3 wp = p + dir * (len * (position.y - 0.5)) + side * (w * position.x);
  float a = (w0 / w) * smoothstep(0.7, 2.6, dist) * (1.0 - smoothstep(0.38, 0.5, dist / uBox.x));
  float c = dot(toP / max(dist, 1e-3), uSunDir);
  vCol = uAmb + uSunCol * wPhase(c);
  vA = a * (0.55 + 0.45 * fract(aSeed.w * 13.3));
  gl_Position = kill > 0.5 ? vec4(2.0, 2.0, 2.0, 1.0) : projectionMatrix * viewMatrix * vec4(wp, 1.0);
}`,FR=`
varying vec3 vCol; varying float vA; varying vec2 vUv;
void main(){
  float x = 1.0 - abs(vUv.x) * 2.0;
  float e = smoothstep(0.0, 0.12, vUv.y) * smoothstep(1.0, 0.55, vUv.y);
  gl_FragColor = vec4(vCol, vA * x * e);
}`,UR=`
uniform float uTime, uRain; uniform vec3 uSunDir, uSunCol, uAmb, uMaskRect; uniform sampler2D uMask;
attribute vec4 aSeed;
varying vec3 vCol; varying float vA; varying vec2 vUv; varying float vLife;
${Ub}
vec2 sHash(vec2 p){ vec3 q = fract(vec3(p.xyx) * vec3(.1031, .1030, .0973)); q += dot(q, q.yzx + 33.33); return fract((q.xx + q.yz) * q.zy); }
void main(){
  vUv = position.xy;
  float period = 0.26 + 0.14 * aSeed.z;
  float tt = uTime / period + aSeed.w * 10.0; float cyc = floor(tt); float life = fract(tt);
  vec2 r = sHash(aSeed.xy * 91.7 + cyc * 0.371);
  vec2 rr = r - 0.5; rr *= 0.35 + 1.3 * abs(rr);                    // denser near the player
  vec2 snap = floor(cameraPosition.xz / 4.0) * 4.0;
  vec3 p = vec3(snap.x + rr.x * 30.0, 0.0, snap.y + rr.y * 30.0);
  float kill = 0.0;
  vec2 muv = (p.xz - uMaskRect.xy) * uMaskRect.z;
  float inM = step(0.0, muv.x) * step(muv.x, 1.0) * step(0.0, muv.y) * step(muv.y, 1.0);
  float pud = step(textureLod(uMask, muv, 0.0).r, 0.49) * inM;
  float k = fract(aSeed.w * 5.3 + cyc * 0.17);
  if (pud < 0.5 && k > 0.3) kill = 1.0;
  if (k > 0.2 + 0.8 * uRain) kill = 1.0;
  if (p.x > 29.7 || wInside(p + vec3(0.0, 0.2, 0.0))) kill = 1.0;
  float sz = mix(0.04, 0.08, aSeed.z) * mix(0.65, 1.0, pud);
  float wd = sz * (0.7 + 1.5 * life), ht = sz * (0.4 + 1.3 * sin(life * 3.14159));
  vec3 toP = p - cameraPosition; float dist = length(toP);
  vec3 side = normalize(vec3(toP.z, 0.0, -toP.x));
  vec3 wp = p + side * (wd * position.x * 2.0) + vec3(0.0, ht * position.y + 0.004, 0.0);
  float c = dot(toP / max(dist, 1e-3), uSunDir);
  vCol = uAmb * 1.4 + uSunCol * wPhase(c) * 0.8;
  vA = (1.0 - life) * (1.0 - smoothstep(11.0, 15.0, dist)) * mix(0.5, 1.0, pud);
  vLife = life;
  gl_Position = kill > 0.5 ? vec4(2.0, 2.0, 2.0, 1.0) : projectionMatrix * viewMatrix * vec4(wp, 1.0);
}`,NR=`
varying vec3 vCol; varying float vA; varying vec2 vUv; varying float vLife;
void main(){
  float x = vUv.x * 2.0, y = vUv.y;
  // little crown: a rim arc that opens outward, plus a few thrown droplets
  float dome = smoothstep(1.0, 0.25, length(vec2(x * 1.15, y * 1.5)));
  float crown = dome * (0.35 + 0.65 * smoothstep(0.25, 0.75, length(vec2(x, y * 1.4))));
  float core = smoothstep(0.5, 0.0, length(vec2(x * 1.6, (y - 0.25) * 1.6))) * (1.0 - vLife);
  float dots = smoothstep(0.16, 0.05, length(vec2(abs(x) - 0.75, y - 0.82))) + smoothstep(0.14, 0.04, length(vec2(x - 0.2, y - 0.93)));
  float a = clamp(crown * 0.5 + core * 0.8 + dots * 0.0, 0.0, 1.0) * vA * 0.6;
  if (a < 0.003) discard;
  gl_FragColor = vec4(vCol, a);
}`;function Fb(i,e,t){let n=new ea;n.setAttribute("position",new et(new Float32Array([-.5,0,0,.5,0,0,-.5,1,0,.5,1,0]),3)),n.setIndex([0,1,2,2,1,3]);let s=new Float32Array((i+e)*4);for(let o=0;o<(i+e)*4;o++)s[o]=t();for(let o=i;o<i+e;o++)s[o*4+3]=-1;return n.setAttribute("aSeed",new zs(s,4)),n.instanceCount=i+e,n.boundingSphere=new Dn(new W,1e5),n}function Nb(i,e){let t=i.rng&&i.rng.fork?i.rng.fork():Math.random,n=Math.max(.15,i.quality.rain||.5),s=Math.round(9e3*n),o=260,r=Math.round(900*n),a=[0,1,2,3].map(()=>new W),l=[0,1,2,3].map(()=>new W),c=Mn.color.clone().multiplyScalar(1.9),u=en.fog.clone().multiplyScalar(.15),h={uTime:{value:0},uRain:{value:.6},uBoxMin:{value:a},uBoxMax:{value:l},uSunDir:{value:Mn.dir.clone()},uSunCol:{value:c},uAmb:{value:u}},f=[0,1,2,3,4,5,6,7].map(()=>new Dt(0,0,-1,-1)),p={...h,uSky:{value:f},uPix:{value:.002},uDrip:{value:0},uVel:{value:new W(-2.6,-9.4,1.1)},uBox:{value:new W(26,15,26)}},d=new zn({uniforms:p,vertexShader:kR,fragmentShader:FR,transparent:!0,depthWrite:!1,blending:hr,side:Sn,fog:!1}),v=new Qe(Fb(s,o,t),d);v.frustumCulled=!1,v.renderOrder=900,v.name="rain",v.matrixAutoUpdate=!1,v.castShadow=v.receiveShadow=!1;let g={...h,uMask:{value:e.mask},uMaskRect:{value:new W(Li.x0,Li.z0,1/Li.size)}},x=new zn({uniforms:g,vertexShader:UR,fragmentShader:NR,transparent:!0,depthWrite:!1,blending:hr,side:Sn,fog:!1}),y=new Qe(Fb(r,0,t),x);y.frustumCulled=!1,y.renderOrder=890,y.name="rainSplash",y.matrixAutoUpdate=!1;let b=.6,m=.6,A=22+t()*25,_=0,M=new Ae;return{rain:v,splash:y,wind:p.uVel.value,setRain(w){m=Math.min(1,Math.max(0,w))},get rainLevel(){return b},update(w){_+=w,b+=(m-b)*Math.min(1,w*.8),h.uTime.value=_,h.uRain.value=b,v.visible=y.visible=b>.01;let S=i.camera;if(S){let O=i.render&&i.render.resolution;O&&O.x>8?M.copy(O):i.renderer.getDrawingBufferSize(M),p.uPix.value=2*Math.tan(S.fov*Math.PI/360)/Math.max(1,M.y)}let z=i.level&&i.level.interiorBoxes||[];for(let O=0;O<4;O++){let q=z[O];q&&q.min&&q.max?(a[O].set(q.min.x-.15,q.min.y-1,q.min.z-.15),l[O].set(q.max.x+.15,q.max.y+.3,q.max.z+.15)):(a[O].set(0,0,0),l[O].set(0,0,0))}p.uDrip.value=z.length?1:0;let H=i.level&&i.level.skylights||[];for(let O=0;O<8;O++){let q=H[O];q&&q.w>0?f[O].set(q.x,q.z,q.w*.5,(q.d||q.w)*.5):f[O].set(0,0,-1,-1)}A-=w,A<=0&&(A=30+t()*30,i.events.emit("thunder",{intensity:.3+.7*t()}))}}}async function O1(i){let e=(i.quality.tex||512)>=1024,t=Math.min(8,i.renderer.capabilities.getMaxAnisotropy?i.renderer.capabilities.getMaxAnisotropy():1),n=e?1024:512,s=Rb(n),o=N1(s,n,{repeat:!1,aniso:2}),r=e?512:256,{det:a,nrm:l}=Cb(r),c=N1(a,r,{aniso:t}),u=N1(l,r,{aniso:t});try{document.fonts&&document.fonts.load&&await Promise.race([document.fonts.load('900 40px "PingFang SC"'),new Promise(M=>setTimeout(M,350))])}catch{}let h=Pb(e?2048:1024,t),f=new ui(new Uint8Array([0,0,0,255]),1,1);f.needsUpdate=!0;let p={mask:o,detail:c,detailN:u,marks:h,black:f},d=new wt;d.name="ground";let v=Ib(i,p),g=kb(i,p),x=Nb(i,p);d.add(v.mesh,g.mesh,g.skirt,x.rain,x.splash),i.scene.add(d);let y=zb(i,v.uniforms,[v.mesh,g.mesh,x.rain,x.splash]);i.render&&i.render.addPrePass&&i.render.addPrePass(y.pass);let b=(M,E)=>{let w=i.level&&i.level.interiorBoxes;if(!w)return!1;for(let S=0;S<w.length;S++){let z=w[S];if(z&&z.min&&M>z.min.x&&M<z.max.x&&E>z.min.z&&E<z.max.z)return!0}return!1},m=(M,E)=>M>Li.x0&&M<Li.x0+Li.size&&E>Li.z0&&E<Li.z0+Li.size,A=0,_={root:d,apron:v.mesh,sea:g.mesh,rain:x.rain,planar:y,reflectionTarget:y.target,reflectionCamera:y.camera,maskTexture:o,uniforms:v.uniforms,puddleDepth(M,E){return M>oi.quayX||!m(M,E)||b(M,E)?-.2:.5-U1(s,n,M,E,0)},isPuddle(M,E){return _.puddleDepth(M,E)>.015},wetnessAt(M,E){if(M>oi.quayX)return 1;if(b(M,E))return .12;if(!m(M,E))return .6;let w=.5-U1(s,n,M,E,0);if(w>.015)return 1;let S=bs.smoothstep,z=S(w,-.11,0),H=S(w,-.65,-.02),O=1-S(U1(s,n,M,E,1)+H*.55,.2,.42);return Math.min(.95,.25+(1-O)*.4+z*.3)},seaHeight(M,E){return Lb(M,E,A)},setRain(M){x.setRain(M)},get rainLevel(){return x.rainLevel},setReflections(M){y.enabled=!!M},update(M){A+=M,x.update(M),v.uniforms.uTime.value=A,v.uniforms.uRain.value=x.rainLevel,g.uniforms.uTime.value=A}};return _}async function BR(i){let e=i.scene.children.find(o=>o.isMesh&&o.geometry&&o.geometry.type==="PlaneGeometry"&&o.geometry.parameters&&o.geometry.parameters.width===80);e&&i.scene.remove(e),i.ground=await O1(i);let t=new wt,n=(o,r,a,l,c,u=0)=>{let h=new Qe(o,r);return h.position.set(a,l,c),h.rotation.y=u,h.castShadow=h.receiveShadow=!0,t.add(h),h},s=o=>i.mats.get(o);return n(new un(6.06,2.59,2.44),s("paint_red"),3,1.295,-.2),n(new un(6.06,2.59,2.44),s("paint_blue"),9.4,1.295,-.2),n(new un(6.06,2.59,2.44),s("paint_teal"),9.4,3.885,-.2),n(new un(12.19,2.59,2.44),s("paint_yellow"),3,1.295,11.2),n(new un(6.06,2.59,2.44),s("paint_white"),12.4,1.295,11.2),n(new un(1.1,1.1,1.1),s("paint_orange"),5.6,.55,4.7,.4),n(new Ys(.29,.29,.88,20),s("plastic_blue"),3.9,.44,6.3),n(new Ys(.29,.29,.88,20),s("steel_rust"),4.6,.44,6.6),n(new Ys(.06,.06,5,10),s("steel_galv"),12.5,2.5,6.2),n(new un(.08,1.6,.08),i.mats.emissive(16726556,6),6.6,.82,2.6),n(new un(.08,1.6,.08),i.mats.emissive(3524863,5),2.2,.82,3.2),n(new un(2.4,.08,.06),i.mats.emissive(16773328,6),9.4,2.2,1.06),n(new un(.3,.12,.3),i.mats.emissive(16760944,12),12.5,5,6.2),n(new un(.06,1.2,.06),i.mats.emissive(5832570,5),23,.62,8.2),n(new un(1.2,1.2,1.2),s("steel_dark"),22.4,.6,9.6,.3),i.scene.add(t),{cam:[-9,1.65,5.6],target:[14,.4,5]}}var Sv={};br(Sv,{create:()=>Cf,showcase:()=>JR});function yv(i){let n=new Float32Array(4096),s=i>>>0,o=()=>{s|=0,s=s+1831565813|0;let l=Math.imul(s^s>>>15,1|s);return l=l+Math.imul(l^l>>>7,61|l)^l,((l^l>>>14)>>>0)/4294967296};for(let l=0;l<4096;l++)n[l]=o();let r=(l,c)=>{let u=Math.floor(l),h=Math.floor(c),f=l-u,p=c-h;f=f*f*(3-2*f),p=p*p*(3-2*p);let d=u&63,v=u+1&63,g=(h&63)*64,x=(h+1&63)*64,y=n[g+d],b=n[g+v],m=n[x+d],A=n[x+v];return y+(b-y)*f+(m-y+(y-b-m+A)*f)*p};return{noise:r,fbm:(l,c,u=4)=>{let h=0,f=.5,p=0;for(let d=0;d<u;d++)h+=r(l,c)*f,p+=f,l=l*2.03+17.1,c=c*2.03+9.7,f*=.5;return h/p},rnd:o}}var To=(i,e,t)=>{let n=(t-i)/(e-i);return n=n<0?0:n>1?1:n,n*n*(3-2*n)},Wc=4,H1=2;function Bb(i=128){let e=i*Wc,t=i*H1,n=new Uint8Array(e*t*4),s=yv(9173),o=new Float32Array(i*i),r=new Float32Array(i*i),a=new Float32Array(i*i);for(let c=0;c<Wc*H1;c++){let u=c%Wc,h=Math.floor(c/Wc),f=c*13.37+3.1,p=c*7.77+1.3;for(let d=0;d<i;d++)for(let v=0;v<i;v++){let g=(v+.5)/i*2-1,x=(d+.5)/i*2-1,y=1-To(.78,.98,Math.max(Math.abs(g),Math.abs(x))),b,m,A;if(c===6){let M=x*.5+.5,E=.16+.5*M*M,w=(s.fbm(g*2+f,M*2+p,3)-.5)*.25,S=1-To(E*.3,E,Math.abs(g+w*M)),z=s.fbm(g*9+f,M*2.2+p,4),H=1-To(.55,.95,M-(s.noise(g*6+f,3.3)-.5)*.35),O=To(0,.12,M);b=S*H*O*To(.22,.7,z+.25*(1-M)),m=S*H,A=b*.5}else{let M=c===7,E=M?.3:.6,w=(s.fbm(g*1.4+f,x*1.4+p,3)-.5)*E,S=(s.fbm(g*1.4+p+5.2,x*1.4+f+1.7,3)-.5)*E,z=g+w,H=x+S,O=Math.sqrt(z*z+H*H),q=(s.fbm(z*2.2+f,H*2.2+p,3)-.5)*.6,U=1-To(0,M?.84:.8,O+q),T=s.fbm(z*4.2+f*2,H*4.2+p*2,5),D=U*(M?.8+.7*T:.25+1.5*T);b=To(M?.02:.06,M?.7:.95,D),m=U,A=U*.55+U*s.fbm(z*3.1+f*3,H*3.1+p*3,3)*.9}let _=d*i+v;r[_]=b*y,a[_]=m,o[_]=A*y}for(let d=0;d<i;d++)for(let v=0;v<i;v++){let g=Math.max(0,v-2),x=Math.min(i-1,v+2),y=Math.max(0,d-2),b=Math.min(i-1,d+2),m=(o[d*i+x]-o[d*i+g])*i/8,A=(o[b*i+v]-o[y*i+v])*i/8,_=.55,M=-m*_,E=-A*_,w=1/Math.sqrt(M*M+E*E+1);M*=w,E*=w;let S=((h*i+d)*e+u*i+v)*4,z=d*i+v;n[S]=Math.round((M*.5+.5)*255),n[S+1]=Math.round((E*.5+.5)*255),n[S+2]=Math.min(255,a[z]*255),n[S+3]=Math.min(255,r[z]*255)}}let l=new ui(n,e,t,_n,yi);return l.magFilter=Zt,l.minFilter=Ln,l.generateMipmaps=!0,l.wrapS=l.wrapT=Bi,l.colorSpace=hi,l.needsUpdate=!0,l}var Af=4,bv=2,oo=0,_v=1,n0=2,OR=3,Mv=4,V1=5,Gc=6,W1=7;function Ob(i=128){let e=i*Af,t=i*bv,n=new Uint8Array(e*t*4),s=yv(4441),o=[0,1].map(()=>{let a=7+Math.floor(s.rnd()*4),l=[];for(let c=0;c<a;c++)l.push({a:(c/a+(s.rnd()-.5)*.12)*Math.PI*2,l:.35+s.rnd()*.6,w:.018+s.rnd()*.05,g:.5+s.rnd()*.5});return l});for(let a=0;a<8;a++){let l=a%Af,c=Math.floor(a/Af);for(let u=0;u<i;u++)for(let h=0;h<i;h++){let f=(h+.5)/i*2-1,p=(u+.5)/i*2-1,d=Math.sqrt(f*f+p*p),v=1-To(.86,.99,Math.max(Math.abs(f),Math.abs(p))),g=0;if(a===oo){let b=Math.max(0,1-d);g=b*b*b*.75+Math.exp(-d*d*22)*.5}else if(a===_v){let b=Math.pow(Math.max(0,1-f*f),1.5);g=Math.exp(-(p*p)/(.42*.42))*b}else if(a===n0||a===OR){let b=o[a-n0],m=Math.atan2(p,f);for(let A of b){let _=Math.abs(m-A.a)%(Math.PI*2);_>Math.PI&&(_=Math.PI*2-_);let M=Math.sin(Math.min(_,1.5))*d;_<1.5&&(g+=A.g*Math.exp(-(M*M)/(A.w*A.w*(.4+d)))*Math.pow(Math.max(0,1-d/A.l),1.4))}g=g*(.7+.6*s.fbm(f*5+a*9,p*5,3))+Math.exp(-d*d*70)*1.2+Math.max(0,1-d*2.2)*.06}else if(a===Mv){let b=Math.atan2(p,f),m=.78+(s.noise(Math.cos(b)*2+5,Math.sin(b)*2+5)-.5)*.04;g=Math.exp(-((d-m)*(d-m))/(.03*.03))*(.6+.4*s.noise(Math.cos(b)*5+9,Math.sin(b)*5+9))+.05*To(.2,.78,d)*(1-To(.78,.8,d))}else if(a===V1){let b=(s.fbm(f*1.6+3.3,p*1.6+8.1,3)-.5)*.5,m=(s.fbm(f*1.6+7.7,p*1.6+2.2,3)-.5)*.5,A=f+b,_=p+m,M=Math.sqrt(A*A+_*_),E=1-To(0,.84,M),w=s.fbm(A*4+1.1,_*4+6.6,5);g=To(.04,.9,E*(.3+1.4*w))*(.45+.75*E)}else if(a===Gc)g=1-To(.3,.62,d);else if(a===W1){let b=f*.5+.5,m=.22+.3*b,A=Math.exp(-(p*p)/(m*m))*Math.pow(b,1.8),_=(f-.8)/.16;f>.8&&(A*=Math.max(0,1-_*_)),g=A*1.15}g*=v;let x=Math.max(0,Math.min(255,g*255)),y=((c*i+u)*e+l*i+h)*4;n[y]=n[y+1]=n[y+2]=x,n[y+3]=255}}let r=new ui(n,e,t,_n,yi);return r.magFilter=Zt,r.minFilter=Ln,r.generateMipmaps=!0,r.wrapS=r.wrapT=Bi,r.colorSpace=hi,r.needsUpdate=!0,r}var dl=4,xv=2,da={bullet_metal:[0,1],bullet_concrete:[2,3],bullet_wood:[4],scorch:[5],soot:[6],bullet_glass:[7]};function Hb(i=256){let e=i*dl,t=i*xv,n=document.createElement("canvas");n.width=e,n.height=t;let s=document.createElement("canvas");s.width=e,s.height=t;let o=document.createElement("canvas");o.width=e,o.height=t;let r=n.getContext("2d"),a=s.getContext("2d"),l=o.getContext("2d",{willReadFrequently:!0});l.fillStyle="rgb(128,128,128)",l.fillRect(0,0,e,t);let c=(_,M)=>{let E=l.createRadialGradient(0,0,0,0,0,M);for(let[w,S]of _)E.addColorStop(w,`rgb(${S},${S},${S})`);l.fillStyle=E,l.beginPath(),l.arc(0,0,M,0,Math.PI*2),l.fill()},h=yv(77123).rnd;a.fillStyle="rgb(0,235,0)",a.fillRect(0,0,e,t);let f=Math.PI*2,p=(_,M,E,w=22,S=1)=>{_.beginPath();for(let z=0;z<w;z++){let H=z/w*f,O=M*(1+(h()-.5)*E),q=Math.cos(H)*O,U=Math.sin(H)*O*S;z?_.lineTo(q,U):_.moveTo(q,U)}_.closePath()},d=(_,M,E,w,S,z,H)=>{_.beginPath();let O=E,q=M;_.moveTo(Math.cos(q)*O,Math.sin(q)*O);let U=5+Math.floor(h()*4);for(let T=1;T<=U;T++)O=E+(w-E)*T/U,q+=(h()-.5)*S,_.lineTo(Math.cos(q)*O,Math.sin(q)*O);_.strokeStyle=H,_.lineWidth=z,_.lineCap="round",_.lineJoin="round",_.stroke()},v=(_,M)=>{let E=(_%dl+.5)*i,w=(Math.floor(_/dl)+.5)*i,S=i/2;for(let z of[r,a,l])z.save(),z.beginPath(),z.rect(E-S,w-S,i,i),z.clip(),z.translate(E,w);M(S),r.restore(),a.restore(),l.restore()},g=(_,M,E,w)=>{let S=_.createRadialGradient(0,0,M,0,0,E);for(let[z,H]of w)S.addColorStop(z,H);return S};for(let _ of da.bullet_metal)v(_,M=>{r.fillStyle=g(r,M*.1,M*.6,[[0,"rgba(14,13,12,0.4)"],[.5,"rgba(18,17,16,0.14)"],[1,"rgba(20,20,20,0)"]]),r.fillRect(-M,-M,2*M,2*M);let E=6+Math.floor(h()*5);for(let T=0;T<E;T++){let D=h()*f;d(r,D,M*.2,M*(.38+h()*.45),.3,.8+h()*1,"rgba(8,8,8,0.55)")}let w=M*(.24+h()*.08),S=.7+h()*.5,z=h()*f,H=(T,D,C,G,j,N)=>{for(let F of[r,a])F.save(),F.translate(T,D),F.rotate(G);let Q=[];for(let F=0;F<N;F++)Q.push(1+(h()-.5)*j);let K=(F,X)=>{F.beginPath();for(let ne=0;ne<N;ne++){let re=ne/N*f,$=C*Q[ne]*X,ue=Math.cos(re)*$,me=Math.sin(re)*$*S;ne?F.lineTo(ue,me):F.moveTo(ue,me)}F.closePath()};K(r,1),r.lineJoin="miter",r.strokeStyle="rgba(92,54,36,0.95)",r.lineWidth=Math.max(1.5,C*.14),r.stroke();let ie=150+Math.floor(h()*50);K(r,1),r.fillStyle=g(r,0,C*1.2,[[0,`rgb(${ie-30},${ie-26},${ie-20})`],[.7,`rgb(${ie+30},${ie+33},${ie+36})`],[1,`rgb(${ie},${ie+3},${ie+6})`]]),r.fill(),K(a,1),a.fillStyle="rgb(0,85,255)",a.fill(),r.restore(),a.restore()};H(0,0,w,z,.75,11);let O=2+Math.floor(h()*4);for(let T=0;T<O;T++){let D=h()*f,C=w*(1+h()*.7);H(Math.cos(D)*C,Math.sin(D)*C,w*(.15+h()*.3),h()*f,.8,7)}for(let T=0;T<9;T++){let D=h()*f,C=w*.3,G=w*(.6+h()*.3);r.beginPath(),r.moveTo(Math.cos(D)*C,Math.sin(D)*C),r.lineTo(Math.cos(D+.1)*G,Math.sin(D+.1)*G),r.strokeStyle=h()<.5?"rgba(245,246,248,0.7)":"rgba(70,72,76,0.5)",r.lineWidth=.8,r.stroke()}let q=M*(.1+h()*.025),U=8+Math.floor(h()*5);for(let T=0;T<U;T++){if(h()<.15)continue;let D=(T+(h()-.5)*.6)/U*f,C=q*(1.25+h()*.9),G=.16+h()*.16,j=205+Math.floor(h()*50);r.beginPath(),r.moveTo(Math.cos(D-G)*q*.9,Math.sin(D-G)*q*.9),r.lineTo(Math.cos(D)*C,Math.sin(D)*C),r.lineTo(Math.cos(D+G)*q*.9,Math.sin(D+G)*q*.9),r.closePath(),r.fillStyle=`rgb(${j},${j},${Math.min(255,j+4)})`,r.fill(),r.strokeStyle="rgba(40,40,42,0.6)",r.lineWidth=.7,r.stroke()}a.beginPath(),a.arc(0,0,q*1.8,0,f),a.fillStyle="rgb(0,60,255)",a.fill(),p(r,q,.3,11),r.fillStyle=g(r,0,q,[[0,"#000000"],[.8,"#040404"],[1,"#141414"]]),r.fill(),c([[0,0],[.26,10],[.36,240],[.5,200],[.62,100],[1,128]],q*3.4),p(a,q,.1,11),a.fillStyle="rgb(0,250,0)",a.fill()});for(let _ of da.bullet_concrete)v(_,M=>{r.fillStyle=g(r,M*.2,M*.9,[[0,"rgba(186,180,168,0.22)"],[.6,"rgba(180,175,165,0.07)"],[1,"rgba(170,165,155,0)"]]),r.fillRect(-M,-M,2*M,2*M);let E=4+Math.floor(h()*4);for(let O=0;O<E;O++){let q=h()*f,U=M*(.5+h()*.42);d(r,q,M*.25,U,.35,1.3+h()*1.3,"rgba(20,19,18,0.75)"),h()<.5&&d(r,q+(h()-.5)*.6,U*.7,U*1.05,.6,.9,"rgba(20,19,18,0.5)")}let w=M*(.33+h()*.09),S=12,z=[];for(let O=0;O<S;O++)z.push(1+(h()-.5)*.6);let H=(O,q,U,T)=>{O.beginPath();for(let D=0;D<S;D++){let C=D/S*f,G=w*z[D]*q;D?O.lineTo(Math.cos(C)*G+U,Math.sin(C)*G+T):O.moveTo(Math.cos(C)*G+U,Math.sin(C)*G+T)}O.closePath()};H(r,1.05,1.5,1.5),r.fillStyle="rgba(22,21,20,0.8)",r.fill(),H(r,1,0,0),r.fillStyle=g(r,w*.1,w*1.1,[[0,"#35332f"],[.4,"#6f6b63"],[.8,"#8f8b82"],[1,"#9a968c"]]),r.fill(),H(r,.97,-1,-1),r.strokeStyle="rgba(206,201,190,0.55)",r.lineWidth=1.2,r.stroke();for(let O=0;O<6;O++){let q=h()*f;d(r,q,w*.2,w*.9,.5,1,"rgba(28,27,25,0.5)")}for(let O=0;O<60;O++){let q=h()*f,U=Math.sqrt(h())*w*.85;r.fillStyle=h()<.55?"rgba(36,34,32,0.6)":"rgba(196,191,180,0.6)",r.beginPath(),r.arc(Math.cos(q)*U,Math.sin(q)*U,.7+h()*2,0,f),r.fill()}p(r,w*.3,.45,9),r.fillStyle=g(r,0,w*.33,[[0,"#060606"],[.7,"#161514"],[1,"#2c2a27"]]),r.fill(),c([[0,0],[.24,20],[.3,70],[.8,112],[.88,150],[1,128]],w*1.15);for(let O=0;O<22;O++){let q=h()*f,U=w*(1.15+h()*1.3);r.fillStyle=h()<.5?"rgba(190,185,175,0.45)":"rgba(30,29,27,0.45)",r.beginPath(),r.arc(Math.cos(q)*U,Math.sin(q)*U,.6+h()*1.6,0,f),r.fill()}});for(let _ of da.bullet_wood)v(_,M=>{p(r,M*.27,.7,11,1.45),r.fillStyle="rgba(206,182,140,0.85)",r.fill();for(let E=0;E<46;E++){let w=(h()-.5)*M*.62,S=M*(.25+h()*.6)*(1-Math.abs(w)/(M*.4)),z=(h()-.5)*M*.2;r.beginPath(),r.moveTo(w,z-S),r.lineTo(w+(h()-.5)*5,z+S),r.strokeStyle=h()<.5?"rgba(236,216,172,0.85)":"rgba(88,62,38,0.7)",r.lineWidth=.8+h()*2.2,r.stroke()}p(r,M*.1,.5,9,1.1),r.fillStyle=g(r,0,M*.12,[[0,"#050403"],[.8,"#140f0a"],[1,"#3a2a1a"]]),r.fill(),c([[0,0],[.5,30],[.8,140],[1,128]],M*.17)});for(let _ of da.scorch)v(_,M=>{r.fillStyle=g(r,0,M*.98,[[0,"rgba(6,5,5,0.92)"],[.3,"rgba(10,9,8,0.85)"],[.55,"rgba(22,18,15,0.5)"],[.8,"rgba(30,24,20,0.16)"],[1,"rgba(30,24,20,0)"]]),r.fillRect(-M,-M,2*M,2*M);for(let E=0;E<90;E++){let w=h()*f,S=M*(.1+h()*.3),z=M*(.5+h()*.46);r.beginPath(),r.moveTo(Math.cos(w-.03)*S,Math.sin(w-.03)*S),r.lineTo(Math.cos(w)*z,Math.sin(w)*z),r.lineTo(Math.cos(w+.03)*S,Math.sin(w+.03)*S),r.closePath(),r.fillStyle=`rgba(8,7,6,${.12+h()*.3})`,r.fill()}for(let E=0;E<60;E++){let w=h()*f,S=M*(.15+h()*.6);r.fillStyle=h()<.3?"rgba(150,140,128,0.25)":"rgba(0,0,0,0.4)",r.beginPath(),r.arc(Math.cos(w)*S,Math.sin(w)*S,1+h()*4,0,f),r.fill()}});for(let _ of da.soot)v(_,M=>{for(let E=0;E<14;E++){let w=h()*f,S=h()*M*.3,z=M*(.15+h()*.3),H=Math.cos(w)*S,O=Math.sin(w)*S,q=r.createRadialGradient(H,O,0,H,O,z);q.addColorStop(0,"rgba(8,8,8,0.4)"),q.addColorStop(1,"rgba(8,8,8,0)"),r.fillStyle=q,r.fillRect(-M,-M,2*M,2*M)}p(r,M*.1,.4,12),r.fillStyle="rgba(0,0,0,0.9)",r.fill()});for(let _ of da.bullet_glass)v(_,M=>{r.fillStyle=g(r,0,M*.5,[[0,"rgba(235,240,242,0.55)"],[1,"rgba(235,240,242,0)"]]),r.fillRect(-M,-M,2*M,2*M);for(let E=0;E<13;E++){let w=(E+h()*.6)/13*f;d(r,w,M*.07,M*(.5+h()*.45),.12,.9+h(),"rgba(240,246,248,0.85)")}for(let E=0;E<3;E++){let w=M*(.2+E*.17+h()*.05);for(let S=0;S<9;S++){if(h()<.45)continue;let z=S/9*f;r.beginPath(),r.arc(0,0,w,z,z+.5),r.strokeStyle="rgba(240,246,248,0.6)",r.lineWidth=1,r.stroke()}}p(r,M*.07,.3,10),r.fillStyle="#060606",r.fill()});let x=new xs(n);x.colorSpace=Vn,x.anisotropy=4;let y=new xs(s);y.colorSpace=hi;let b=2/i,m=_=>{let M=_%dl,E=Math.floor(_/dl);return[(M+b)/dl,1-(E+1-b)/xv,(M+1-b)/dl,1-(E+b)/xv]},A=null;try{let _=l.getImageData(0,0,e,t),M=_.data;if(M&&M.length===e*t*4){let E=l.createImageData(e,t),w=E.data,S=5/255;for(let z=0;z<t;z++){let H=Math.max(0,z-1)*e,O=Math.min(t-1,z+1)*e;for(let q=0;q<e;q++){let U=Math.max(0,q-1),T=Math.min(e-1,q+1),D=(M[(z*e+T)*4]-M[(z*e+U)*4])*S,C=(M[(O+q)*4]-M[(H+q)*4])*S,G=1/Math.sqrt(D*D+C*C+1),j=(z*e+q)*4;w[j]=(-D*G*.5+.5)*255,w[j+1]=(C*G*.5+.5)*255,w[j+2]=(G*.5+.5)*255,w[j+3]=255}}l.putImageData(E,0,0),A=new xs(o),A.colorSpace=hi}}catch{A=null}return{map:x,orm:y,nrm:A,uv:m}}var HR=`
attribute vec4 aPos;    // xyz centre, w size (m)
attribute vec4 aAxis;   // mode 1: stretch axis (length = streak length); mode 2: plane normal; w = roll (rad)
attribute vec4 aCol;    // rgb (HDR), a
attribute vec4 aMisc;   // x atlas frame, y mode (0 billboard, 1 velocity-stretched, 2 surface-aligned), z age 0..1, w sun visibility
uniform vec2 uAtlas;
uniform float uPx;      // world size of one pixel at distance 1
varying vec2 vUv;
varying vec4 vCol;
varying vec3 vOff;
varying vec3 vToCam;
varying vec3 vInfo;     // view z, age, shade
varying float vSoftD;
varying vec3 vT;
varying vec3 vB;
void main() {
  vec2 c = position.xy;
  vec3 center = aPos.xyz; float size = aPos.w; float mode = aMisc.y;
  vec3 camR = vec3(viewMatrix[0][0], viewMatrix[1][0], viewMatrix[2][0]);
  vec3 camU = vec3(viewMatrix[0][1], viewMatrix[1][1], viewMatrix[2][1]);
  vec3 toCam = cameraPosition - center; float dist = length(toCam); toCam /= max(dist, 1e-4);
  float sn = sin(aAxis.w), cs = cos(aAxis.w);
  vec2 rc = vec2(c.x * cs - c.y * sn, c.x * sn + c.y * cs);
  vec3 off; float comp = 1.0;
  if (mode < 0.5) {
    off = (camR * rc.x + camU * rc.y) * size;
    vT = camR * cs + camU * sn; vB = camU * cs - camR * sn;
  } else if (mode < 1.5) {
    float len = length(aAxis.xyz); vec3 d = aAxis.xyz / max(len, 1e-5);
    vec3 side = cross(d, toCam); float sl = length(side); side = sl > 1e-3 ? side / sl : camR;
    float w = max(size, dist * uPx * 1.4); comp = size / w;
    if (aMisc.w > 1.5) w = min(w, dist * uPx * aMisc.w);       // additive only: cap on-screen width (tracers near the lens)
    off = d * (c.x * max(len, w)) + side * (c.y * w);
    vT = d; vB = side;
  } else {
    vec3 n = normalize(aAxis.xyz);
    vec3 t = normalize(abs(n.y) > 0.9 ? cross(n, vec3(1.0, 0.0, 0.0)) : cross(vec3(0.0, 1.0, 0.0), n));
    vec3 b = cross(n, t);
    off = (t * rc.x + b * rc.y) * size;
    vT = t * cs + b * sn; vB = b * cs - t * sn;
  }
  vec4 mv = viewMatrix * vec4(center + off, 1.0);
  gl_Position = projectionMatrix * mv;
  float f = floor(aMisc.x + 0.5);
  float col = mod(f, uAtlas.x), row = floor(f / uAtlas.x);
  vUv = (vec2(col, row) + c + 0.5) / uAtlas;
  vCol = vec4(aCol.rgb * comp, aCol.a);
  vOff = off / max(size, 1e-4);
  vToCam = toCam;
  vInfo = vec3(mv.z, aMisc.z, aMisc.w);
  vSoftD = clamp(size * 0.4, 0.04, 0.7);
}`,Xb=`
uniform sampler2D uTex;
uniform sampler2D uDepth;
uniform vec2 uRes;
uniform vec2 uNearFar;
uniform float uSoft;
varying vec2 vUv;
varying vec4 vCol;
varying vec3 vOff;
varying vec3 vToCam;
varying vec3 vInfo;
varying float vSoftD;
varying vec3 vT;
varying vec3 vB;
float softFade() {
  float s = 1.0;
  if (uSoft > 0.5) {
    float d = texture2D(uDepth, gl_FragCoord.xy / uRes).x;
    float zs = (uNearFar.x * uNearFar.y) / ((uNearFar.y - uNearFar.x) * d - uNearFar.y);
    s = clamp((vInfo.x - zs) / vSoftD, 0.0, 1.0);
  }
  return s;
}`,VR=Xb+`
uniform vec3 uSun, uSunDir, uAmbLo, uAmbHi;
void main() {
  vec4 t = texture2D(uTex, vUv);
  float er = vInfo.y * 0.45;                                  // wisps erode as the puff ages
  float a = smoothstep(er, er + (vInfo.z > 1.5 ? 0.38 : 0.6), t.a) * vCol.a;   // fire lobes: denser body, crisper edge
  a *= softFade() * smoothstep(0.2, 0.9, -vInfo.x);           // soft intersection + fade right at the lens
  if (a < 0.004) discard;
  vec3 V = normalize(vToCam);
  vec3 q = vOff * 2.0; float r2 = min(dot(q, q), 1.0);
  vec3 Ns = q + V * (sqrt(1.0 - r2) * 0.9 + 0.05);            // overall sphere normal
  vec2 tn = t.rg * 2.0 - 1.0;                                 // billow normal from the flipbook
  vec3 Nb = vT * tn.x + vB * tn.y + V * sqrt(max(1.0 - dot(tn, tn), 0.0));
  vec3 N = normalize(Ns * 0.55 + Nb);
  float wrap = clamp((dot(N, uSunDir) + 0.45) / 1.45, 0.0, 1.0);
  float back = pow(clamp(dot(-V, uSunDir), 0.0, 1.0), 5.0);   // looking into the sun: forward scatter through thin edges
  float thin = 1.0 - t.b * smoothstep(0.0, 0.5, a);
  float hot = step(1.5, vInfo.z), shade = vInfo.z - 2.0 * hot;      // aMisc.w >= 2: emissive fire lobe (colour = emission)
  vec3 sun = uSun * (wrap * wrap * 0.85 + back * (0.15 + 1.3 * thin)) * shade;
  vec3 amb = mix(uAmbLo, uAmbHi, N.y * 0.5 + 0.5) * (1.0 - 0.35 * t.b);
  vec3 col = vCol.rgb * (amb + sun);
  if (hot > 0.5) {
    // alpha-blended fire: hot dense cores, dim orange skin, soot underneath. Because it is NOT additive, overlapping lobes
    // keep their shape and smoke in front can occlude them.
    float lump = clamp(dot(tn, vec2(0.6, 0.8)) * 0.6 + 0.5, 0.0, 1.0);
    float core = t.b * t.b * smoothstep(0.15, 0.9, t.a);
    vec3 fire = vCol.rgb * (0.10 + 1.7 * core) * (0.45 + 1.1 * lump);
    col = vec3(0.045, 0.042, 0.04) * (amb + sun) + fire;
  }
  gl_FragColor = vec4(col, a);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
  gl_FragColor.rgb *= gl_FragColor.a;                         // premultiply after the (possibly no-op) output transform
}`,WR=Xb+`
void main() {
  float t = texture2D(uTex, vUv).r;
  float k = t * vCol.a * softFade();
  if (k < 0.002) discard;
  gl_FragColor = vec4(vCol.rgb * k, 1.0);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}`,Vb=new Ae;function Ev(i,e,{lit:t,tex:n,cols:s,rows:o,renderOrder:r,sun:a,sunDir:l,ambLo:c,ambHi:u}){let h=new ea;h.setAttribute("position",new et(new Float32Array([-.5,-.5,0,.5,-.5,0,.5,.5,0,-.5,.5,0]),3)),h.setIndex([0,1,2,0,2,3]);let f=S=>{let z=new zs(new Float32Array(e*4),4);return z.setUsage(bo),h.setAttribute(S,z),z},p=f("aPos"),d=f("aAxis"),v=f("aCol"),g=f("aMisc");h.instanceCount=0;let x={uTex:{value:n},uAtlas:{value:new Ae(s,o)},uPx:{value:.001},uDepth:{value:null},uRes:{value:new Ae(1,1)},uNearFar:{value:new Ae(.08,900)},uSoft:{value:0}};t&&Object.assign(x,{uSun:{value:a},uSunDir:{value:l},uAmbLo:{value:c},uAmbHi:{value:u}});let y=new zn({uniforms:x,vertexShader:HR,fragmentShader:t?VR:WR,transparent:!0,depthWrite:!1,depthTest:!0,side:Sn,fog:!1,blending:Sh,blendEquation:nr,blendSrc:G0,blendDst:t?w0:G0,blendSrcAlpha:Th,blendDstAlpha:G0});y.name=t?"fx_lit":"fx_add";let b=new Qe(h,y);b.frustumCulled=!1,b.renderOrder=r,b.castShadow=!1,b.receiveShadow=!1,b.matrixAutoUpdate=!1,b.name=y.name,b.onBeforeRender=(S,z,H)=>{let O=S.getRenderTarget(),q;O?q=O.height:(S.getDrawingBufferSize(Vb),q=Vb.y);let U=H.projectionMatrix.elements;x.uPx.value=2/(Math.max(U[5],.001)*Math.max(q,1));let T=i.render,D=T&&T.depthTexture;D&&D.image&&H===i.camera&&T.depthTextureIsLive!==!0&&i.params.fxsoft!=="0"?(x.uDepth.value=D,x.uSoft.value=1,T.resolution&&T.resolution.x>0?x.uRes.value.set(T.resolution.x,T.resolution.y):x.uRes.value.set(D.image.width||1,D.image.height||1),x.uNearFar.value.set(H.near,H.far)):(x.uDepth.value=null,x.uSoft.value=0)};let m=p.array,A=d.array,_=v.array,M=g.array,E={mesh:b,cap:e,n:0,P:m,A,C:_,M,begin(){E.n=0},push(S,z,H,O,q,U,T,D,C,G,j,N,Q,K,ie,F){let X=E.n;if(X>=e)return!1;let ne=X*4;return m[ne]=S,m[ne+1]=z,m[ne+2]=H,m[ne+3]=O,A[ne]=q,A[ne+1]=U,A[ne+2]=T,A[ne+3]=D,_[ne]=C,_[ne+1]=G,_[ne+2]=j,_[ne+3]=N,M[ne]=Q,M[ne+1]=K,M[ne+2]=ie,M[ne+3]=F,E.n=X+1,!0},end:null},w=[p,d,v,g];return E.end=()=>{let S=E.n;if(h.instanceCount=S,b.visible=S>0,!!S)for(let z=0;z<4;z++){let H=w[z];H.clearUpdateRanges(),H.addUpdateRange(0,S*4),H.needsUpdate=!0}},E}