/**
 * A 阶段：把 game-code 按功能细分为多个文件
 *
 * 输入：docs/3a游戏文档.html（只读）+ C 阶段的 game-code.part.js
 * 输出：docs/source/3a/parts/NN-name.part.js（按功能切分，仍无 IIFE 外壳）
 *       docs/source/3a/parts/_index.json（每段起止语句 + 段间间隙）
 *
 * 保真：所有片段按 _index.json 顺序纯拼接后必须等于 game-code.part.js
 *       （再由 C 阶段 _rejoin.js 保证等于原文件）
 */
const fs = require('fs');
const path = require('path');
const acorn = require('acorn');

const SRC_HTML = '/workspace/docs/3a游戏文档.html';
const OUT = '/workspace/docs/source/3a';
const PARTS_DIR = path.join(OUT, 'parts');

const raw = fs.readFileSync(SRC_HTML, 'utf8');
const sOff = raw.indexOf('<script>') + 8, eOff = raw.lastIndexOf('</script>');
const scriptText = raw.slice(sOff, eOff);
const ast = acorn.parse(scriptText, { ecmaVersion: 'latest', sourceType: 'script', locations: true, ranges: true });
const allStmts = [...ast.body[0].expression.callee.body.body].sort((a, b) => a.start - b.start);

const GAME_START_ANCHOR = 'oi';
const gameStart = allStmts.findIndex((st) =>
  st.type === 'VariableDeclaration' &&
  st.declarations.some((d) => d.id.type === 'Identifier' && d.id.name === GAME_START_ANCHOR)
);
if (gameStart < 0) throw new Error('找不到游戏起点 oi');

const GROUPS = [
  ['00-config',     'oi',  '世界边界/太阳/天空色/玩家参数/画质/事件总线/随机/数学'],
  ['01-geometry',   '$e',  '盒体UV/圆角盒/圆柱UV/管缆/合并/顶点色'],
  ['02-sky',        'Ug',  '天空噪声GLSL/SALTLINE_SKY/天空网格/环境捕获'],
  ['03-shadow',     'Wy',  'SALTLINE_SHADOW 软阴影/阴影相机拟合'],
  ['04-postfx',     'Bg',  'SALTLINE_POST 后处理shader集/后处理总控/渲染器'],
  ['05-material',   'Qy',  '材质GLSL(Tn)/材质创建(Gg)/参数(c3,l1)'],
  ['06-decal',      'l3',  '贴花/标签/编号/集装箱文字工厂'],
  ['07-physics',    'd3',  'AABB物理世界/射线/视线/地面/胶囊/导航网格'],
  ['08-props',      'Gi',  '道具尺寸表/道具构建器(36类)'],
  ['09-level',      'hR',  '堆场/大门/仓库/码头/关卡总装'],
  ['10-background', 'z1',  '岸桥/货轮/拖船/远景/背景总装'],
  ['11-ground',     'Ib',  '地面/海面/雨/雨溅/平面反射'],
  ['12-effects',    'Rf',  '受光粒子/曳光/碎屑/弹壳/贴花池/特效总控'],
  ['13-audio',      'Go',  '音频事件表/AudioContext 合成'],
  ['14-input',      'v_',  '键位表/输入'],
  ['15-player',     'Mt',  '玩家控制器/战斗与伤害'],
  ['16-weapon',     'mi',  '武器尺寸/建模/手套/枪身图集/细节shader/总控'],
  ['17-enemy',      'Z_',  '猎犬骨架/飞鸥骨架/配置/AI总控/令牌/波次'],
  ['18-hud',        'hM',  'HUD 构建与更新/设置持久化'],
  ['19-menu',       'pM',  '标题/暂停/死亡/结算/设置/操作/介绍/地名卡'],
  ['20-flow',       'Yi',  '流程配置/语音/状态机/启动总控'],
  ['21-bench',      'eP',  '性能测试/无输入桩/无玩家桩'],
];

const nameToStmt = new Map();
for (let i = 0; i < allStmts.length; i++) {
  const st = allStmts[i];
  if (st.type === 'FunctionDeclaration' && st.id && !nameToStmt.has(st.id.name)) nameToStmt.set(st.id.name, i);
  if (st.type === 'VariableDeclaration') {
    for (const d of st.declarations) {
      if (d.id.type === 'Identifier' && !nameToStmt.has(d.id.name)) nameToStmt.set(d.id.name, i);
    }
  }
}

const resolved = GROUPS.map(([name, anchor, desc]) => {
  const idx = nameToStmt.get(anchor);
  if (idx === undefined) throw new Error('找不到锚点 ' + anchor + '（' + name + '）');
  if (idx < gameStart) throw new Error('锚点 ' + anchor + ' 落在游戏区之前');
  return { name, anchor, desc, start: idx };
});

for (let i = 1; i < resolved.length; i++) {
  if (resolved[i].start <= resolved[i - 1].start) {
    throw new Error('分组顺序错误：' + resolved[i].name + '(' + resolved[i].start + ') 未晚于 ' + resolved[i - 1].name + '(' + resolved[i - 1].start + ')');
  }
}

const endOf = allStmts.length;
const segments = resolved.map((r, i) => ({ ...r, end: i + 1 < resolved.length ? resolved[i + 1].start : endOf }));

const totalCovered = segments.reduce((a, sg) => a + (sg.end - sg.start), 0);
const expectCovered = endOf - gameStart;
if (totalCovered !== expectCovered) {
  throw new Error('覆盖不完整：' + totalCovered + ' != ' + expectCovered);
}

fs.mkdirSync(PARTS_DIR, { recursive: true });

const index = { sOff, gameStartStmt: gameStart, totalStmts: allStmts.length, parts: [], gaps: [] };

console.log('=== A 阶段分组 ===');
console.log('游戏区: stmt#' + gameStart + ' -> #' + (endOf - 1) + '（共 ' + expectCovered + ' 条）');
console.log('');

for (const seg of segments) {
  const text = scriptText.slice(allStmts[seg.start].start, allStmts[seg.end - 1].end);
  const file = seg.name + '.part.js';
  fs.writeFileSync(path.join(PARTS_DIR, file), text, 'utf8');
  index.parts.push({
    file, desc: seg.desc, anchor: seg.anchor,
    startStmt: seg.start, endStmt: seg.end,
    startLine: allStmts[seg.start].loc.start.line,
    endLine: allStmts[seg.end - 1].loc.end.line,
    bytes: Buffer.byteLength(text, 'utf8'),
    stmtCount: seg.end - seg.start,
  });
  console.log(
    String(seg.start).padStart(3) + '-' + String(seg.end - 1).padStart(3) +
    '  ' + file.padEnd(30) +
    String(seg.end - seg.start).padStart(3) + ' 条  ' +
    String(Buffer.byteLength(text, 'utf8')).padStart(7) + ' B  ' +
    'L' + String(allStmts[seg.start].loc.start.line).padEnd(6) + ' ' + seg.desc
  );
}

for (let i = 0; i < segments.length - 1; i++) {
  const gap = scriptText.slice(allStmts[segments[i].end - 1].end, allStmts[segments[i + 1].start].start);
  index.gaps.push({ after: segments[i].name, gap });
}
index.headGap = scriptText.slice(allStmts[gameStart - 1].end, allStmts[gameStart].start);
// 尾部间隙：game-code.part.js 不含 IIFE 外壳，所以到「最后一条语句结束」为止
index.tailGap = scriptText.slice(allStmts[endOf - 1].end, allStmts[endOf - 1].end);

fs.writeFileSync(path.join(PARTS_DIR, '_index.json'), JSON.stringify(index, null, 1), 'utf8');

const gameCode = fs.readFileSync(path.join(OUT, 'game-code.part.js'), 'utf8');
let rebuilt = index.headGap;
for (let i = 0; i < index.parts.length; i++) {
  rebuilt += fs.readFileSync(path.join(PARTS_DIR, index.parts[i].file), 'utf8');
  if (i < index.gaps.length) rebuilt += index.gaps[i].gap;
}
rebuilt += index.tailGap;

console.log('');
console.log('=== A 阶段自校验 ===');
console.log('拼回长度:', rebuilt.length, '  game-code.part.js 长度:', gameCode.length);
const same = rebuilt === gameCode;
console.log('拼回 == game-code.part.js:', same);
if (!same) {
  for (let i = 0; i < Math.min(rebuilt.length, gameCode.length); i++) {
    if (rebuilt[i] !== gameCode[i]) {
      console.log('首个差异在', i);
      console.log('  拼回:', JSON.stringify(rebuilt.slice(Math.max(0, i - 40), i + 40)));
      console.log('  原文:', JSON.stringify(gameCode.slice(Math.max(0, i - 40), i + 40)));
      break;
    }
  }
  process.exitCode = 1;
}
