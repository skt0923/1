---@meta

--- Auto-generated from Math/RandomGenerator

---@class RandomGenerator
---@overload fun(seed?: integer): RandomGenerator
---@overload fun(): RandomGenerator
RandomGenerator = {}

---@overload fun(self: RandomGenerator, seed?: integer): RandomGenerator
---@overload fun(seed?: integer): RandomGenerator
---@return RandomGenerator
function RandomGenerator.new() end

--- Restart the sequence from an integer seed.
---@param seed integer
---@return nil
function RandomGenerator:SetSeed(seed) end

--- Return the internal state as an integer. SetState() with it continues the sequence exactly (save, replay,
--- network sync).
---@return integer
function RandomGenerator:GetState() end

--- Restore a state returned by GetState().
---@param state integer
---@return nil
function RandomGenerator:SetState(state) end

--- Return the next 32-bit value as an integer (0 to 4294967295).
---@return integer
function RandomGenerator:NextUInt() end

--- Return a number in [0, 1).
---@return number
function RandomGenerator:Next() end

--- Return a number from min (inclusive) towards max (exclusive).
---@param min number
---@param max number
---@return number
function RandomGenerator:Range(min, max) end

--- Return an integer in [min, max], both inclusive and within the 32-bit signed range, without bias.
---@param min integer
---@param max integer
---@return integer
function RandomGenerator:RangeInt(min, max) end

--- Return a normally distributed number with the given mean and standard deviation.
---@param mean? number
---@param stddev? number
---@return number
function RandomGenerator:Normal(mean, stddev) end

--- Return the 32-bit FNV-1a hash of a string's bytes as an integer, for turning names into seeds.
---@param text string
---@return integer
function RandomGenerator:Hash(text) end

