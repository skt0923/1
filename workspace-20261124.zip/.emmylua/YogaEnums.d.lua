---@meta

--- Auto-generated from UI/YogaEnums

--- YGAlign enum values
---@alias YGAlign integer

---@type YGAlign
YGAlignAuto = 0
---@type YGAlign
YGAlignFlexStart = 1
---@type YGAlign
YGAlignCenter = 2
---@type YGAlign
YGAlignFlexEnd = 3
---@type YGAlign
YGAlignStretch = 4
---@type YGAlign
YGAlignBaseline = 5
---@type YGAlign
YGAlignSpaceBetween = 6
---@type YGAlign
YGAlignSpaceAround = 7
---@type YGAlign
YGAlignSpaceEvenly = 8

--- YGBoxSizing enum values
---@alias YGBoxSizing integer

---@type YGBoxSizing
YGBoxSizingBorderBox = 0
---@type YGBoxSizing
YGBoxSizingContentBox = 1

--- YGDimension enum values
---@alias YGDimension integer

---@type YGDimension
YGDimensionWidth = 0
---@type YGDimension
YGDimensionHeight = 1

--- YGDirection enum values
---@alias YGDirection integer

---@type YGDirection
YGDirectionInherit = 0
---@type YGDirection
YGDirectionLTR = 1
---@type YGDirection
YGDirectionRTL = 2

--- YGDisplay enum values
---@alias YGDisplay integer

---@type YGDisplay
YGDisplayFlex = 0
---@type YGDisplay
YGDisplayNone = 1
---@type YGDisplay
YGDisplayContents = 2

--- YGEdge enum values
---@alias YGEdge integer

---@type YGEdge
YGEdgeLeft = 0
---@type YGEdge
YGEdgeTop = 1
---@type YGEdge
YGEdgeRight = 2
---@type YGEdge
YGEdgeBottom = 3
---@type YGEdge
YGEdgeStart = 4
---@type YGEdge
YGEdgeEnd = 5
---@type YGEdge
YGEdgeHorizontal = 6
---@type YGEdge
YGEdgeVertical = 7
---@type YGEdge
YGEdgeAll = 8

--- YGFlexDirection enum values
---@alias YGFlexDirection integer

---@type YGFlexDirection
YGFlexDirectionColumn = 0
---@type YGFlexDirection
YGFlexDirectionColumnReverse = 1
---@type YGFlexDirection
YGFlexDirectionRow = 2
---@type YGFlexDirection
YGFlexDirectionRowReverse = 3

--- YGGutter enum values
---@alias YGGutter integer

---@type YGGutter
YGGutterColumn = 0
---@type YGGutter
YGGutterRow = 1
---@type YGGutter
YGGutterAll = 2

--- YGJustify enum values
---@alias YGJustify integer

---@type YGJustify
YGJustifyFlexStart = 0
---@type YGJustify
YGJustifyCenter = 1
---@type YGJustify
YGJustifyFlexEnd = 2
---@type YGJustify
YGJustifySpaceBetween = 3
---@type YGJustify
YGJustifySpaceAround = 4
---@type YGJustify
YGJustifySpaceEvenly = 5

--- YGMeasureMode enum values
---@alias YGMeasureMode integer

---@type YGMeasureMode
YGMeasureModeUndefined = 0
---@type YGMeasureMode
YGMeasureModeExactly = 1
---@type YGMeasureMode
YGMeasureModeAtMost = 2

--- YGNodeType enum values
---@alias YGNodeType integer

---@type YGNodeType
YGNodeTypeDefault = 0
---@type YGNodeType
YGNodeTypeText = 1

--- YGOverflow enum values
---@alias YGOverflow integer

---@type YGOverflow
YGOverflowVisible = 0
---@type YGOverflow
YGOverflowHidden = 1
---@type YGOverflow
YGOverflowScroll = 2

--- YGPositionType enum values
---@alias YGPositionType integer

---@type YGPositionType
YGPositionTypeStatic = 0
---@type YGPositionType
YGPositionTypeRelative = 1
---@type YGPositionType
YGPositionTypeAbsolute = 2

--- YGUnit enum values
---@alias YGUnit integer

---@type YGUnit
YGUnitUndefined = 0
---@type YGUnit
YGUnitPoint = 1
---@type YGUnit
YGUnitPercent = 2
---@type YGUnit
YGUnitAuto = 3
---@type YGUnit
YGUnitMaxContent = 4
---@type YGUnit
YGUnitFitContent = 5
---@type YGUnit
YGUnitStretch = 6

--- YGWrap enum values
---@alias YGWrap integer

---@type YGWrap
YGWrapNoWrap = 0
---@type YGWrap
YGWrapWrap = 1
---@type YGWrap
YGWrapWrapReverse = 2
