---@meta

--- Auto-generated from Network/Transport

--- TransportProtocol enum values
---@alias TransportProtocol integer

---@type TransportProtocol
TRANSPORT_SLIKENET = TRANSPORT_SLIKENET
---@type TransportProtocol
TRANSPORT_WEBSOCKET = TRANSPORT_WEBSOCKET
---@type TransportProtocol
TRANSPORT_KCP = TRANSPORT_KCP

-- Global functions
---@param protocol TransportProtocol
---@return boolean
function TransportIsSupported(protocol) end
