---@meta

--- Auto-generated from Scene/PrefabReference

---@class PrefabReference : Component
---@field prefab PrefabResource Loaded prefab resource; change the reference with SetPrefab.
---@field prefabPath string Assigned resource name (path or uuid:// reference); change it with SetPrefab.
---@field instanceNode Node Temporary instance root; query again after replacing or clearing the prefab.
PrefabReference = {}

--- Load and instantiate a prefab by ResourceCache name (relative resource path or uuid:// reference).
--- An empty name clears the reference and instance. A failed load clears both but preserves the requested name.
--- Setting the same name again has no effect, including after a failed load.
---@param resourceName string
---@return nil
function PrefabReference:SetPrefab(resourceName) end

--- Return the loaded resource, or nil if none is loaded.
---@return PrefabResource
function PrefabReference:GetPrefab() end

--- Return the assigned resource name (path or uuid:// reference), including a name that failed to load.
---@return string
function PrefabReference:GetPrefabPath() end

--- Return the temporary instance root, or nil if none exists. Query again after replacing or clearing the prefab.
---@return Node
function PrefabReference:GetInstanceNode() end

--- Make the instance persistent and remove this component. Nested prefab references remain linked.
---@return nil
function PrefabReference:Inline() end

