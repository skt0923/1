---@meta

-- 手动维护的签名：生成器不支持命名空间建模，也无法表达多返回值。

---@class CascadeParticle
CascadeParticle = {}

--- 在场景中按世界坐标创建粒子实例（UE UGameplayStatics::SpawnEmitterAtLocation）。
---@param scene Scene
---@param template CascadeParticleSystem 由 cache:GetResource("CascadeParticleSystem", ref) 加载
---@param location Vector3
---@param rotation Quaternion
---@param scale Vector3
---@param autoDestroy? boolean 播放完成后移除实例节点，默认 true；池化生成时忽略
---@param poolMethod? CascadePoolMethod 对象池方式，默认 CASCADE_POOL_NONE；CASCADE_POOL_AUTO_RELEASE 播放完成后自动归还，CASCADE_POOL_MANUAL_RELEASE 由 ReleaseToPool 归还
---@param autoActivate? boolean 创建后立即播放，默认 true
---@return CascadeParticleSystemInstance|nil
function CascadeParticle.SpawnEmitterAtLocation(scene, template, location, rotation, scale, autoDestroy, poolMethod, autoActivate) end

--- 在父节点下按局部坐标创建粒子实例，跟随父节点移动（UE UGameplayStatics::SpawnEmitterAttached）。
---@param template CascadeParticleSystem
---@param parent Node
---@param location Vector3
---@param rotation Quaternion
---@param scale Vector3
---@param autoDestroy? boolean 播放完成后移除实例节点，默认 true；池化生成时忽略
---@param poolMethod? CascadePoolMethod 对象池方式，默认 CASCADE_POOL_NONE；池化生成要求父节点属于场景
---@param autoActivate? boolean 创建后立即播放，默认 true
---@return CascadeParticleSystemInstance|nil
function CascadeParticle.SpawnEmitterAttached(template, parent, location, rotation, scale, autoDestroy, poolMethod, autoActivate) end

--- 读取终点（第 0 个目标点）；未设置时返回 false, nil。
---@param emitterIndex integer
---@return boolean ok
---@return Vector3|nil point
function CascadeParticleSystemInstance:GetBeamEndPoint(emitterIndex) end

--- 读取第 sourceIndex 个源点；未设置时返回 false, nil。
---@param emitterIndex integer
---@param sourceIndex integer
---@return boolean ok
---@return Vector3|nil point
function CascadeParticleSystemInstance:GetBeamSourcePoint(emitterIndex, sourceIndex) end

--- 读取第 sourceIndex 个源点切线；未设置时返回 false, nil。
---@param emitterIndex integer
---@param sourceIndex integer
---@return boolean ok
---@return Vector3|nil tangent
function CascadeParticleSystemInstance:GetBeamSourceTangent(emitterIndex, sourceIndex) end

--- 读取第 sourceIndex 个源点强度；未设置时返回 false, nil。
---@param emitterIndex integer
---@param sourceIndex integer
---@return boolean ok
---@return number|nil strength
function CascadeParticleSystemInstance:GetBeamSourceStrength(emitterIndex, sourceIndex) end

--- 读取第 targetIndex 个目标点；未设置时返回 false, nil。
---@param emitterIndex integer
---@param targetIndex integer
---@return boolean ok
---@return Vector3|nil point
function CascadeParticleSystemInstance:GetBeamTargetPoint(emitterIndex, targetIndex) end

--- 读取第 targetIndex 个目标点切线；未设置时返回 false, nil。
---@param emitterIndex integer
---@param targetIndex integer
---@return boolean ok
---@return Vector3|nil tangent
function CascadeParticleSystemInstance:GetBeamTargetTangent(emitterIndex, targetIndex) end

--- 读取第 targetIndex 个目标点强度；未设置时返回 false, nil。
---@param emitterIndex integer
---@param targetIndex integer
---@return boolean ok
---@return number|nil strength
function CascadeParticleSystemInstance:GetBeamTargetStrength(emitterIndex, targetIndex) end
