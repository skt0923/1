---@meta

--- Auto-generated from CascadeParticleLuaAPI
