---@meta

--- Auto-generated from Scene/PrefabResource

---@class PrefabResource : Resource
PrefabResource = {}

--- Return the prefab's root node element.
---@return XMLElement
function PrefabResource:GetRootElement() end

--- Return the XML resource that owns the prefab definition.
---@return XMLFile
function PrefabResource:GetXMLFile() end

