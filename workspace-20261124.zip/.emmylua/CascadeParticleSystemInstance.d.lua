---@meta

--- Auto-generated from CascadeParticle/CascadeParticleSystemInstance

--- CascadeTrailWidthMode enum values
---@alias CascadeTrailWidthMode integer

---@type CascadeTrailWidthMode
--- 两挂点的中点不动，向两侧缩放。
CASCADE_TRAIL_WIDTH_FROM_CENTRE = 0
---@type CascadeTrailWidthMode
--- 第一挂点一侧不动。
CASCADE_TRAIL_WIDTH_FROM_FIRST = 1
---@type CascadeTrailWidthMode
--- 第二挂点一侧不动。
CASCADE_TRAIL_WIDTH_FROM_SECOND = 2

---@class CascadeParticleSystemInstance : Component
CascadeParticleSystemInstance = {}

---@param reset? boolean
---@return nil
function CascadeParticleSystemInstance:Activate(reset) end

---@return nil
function CascadeParticleSystemInstance:Deactivate() end

---@param active boolean
---@param reset? boolean
---@return nil
function CascadeParticleSystemInstance:SetActive(active, reset) end

---@return nil
function CascadeParticleSystemInstance:ToggleActive() end

---@return boolean
function CascadeParticleSystemInstance:IsActive() end

---@param autoDestroy boolean
---@return nil
function CascadeParticleSystemInstance:SetAutoDestroy(autoDestroy) end

---@return boolean
function CascadeParticleSystemInstance:GetAutoDestroy() end

---@return boolean
function CascadeParticleSystemInstance:GetAutoActivate() end

---@return nil
function CascadeParticleSystemInstance:ReleaseToPool() end

---@return CascadePoolMethod
function CascadeParticleSystemInstance:GetPoolMethod() end

---@param system CascadeParticleSystem
---@return nil
function CascadeParticleSystemInstance:SetTemplate(system) end

---@return CascadeParticleSystem
function CascadeParticleSystemInstance:GetTemplate() end

---@param emitterName string
---@param enable boolean
---@return nil
function CascadeParticleSystemInstance:SetEmitterEnable(emitterName, enable) end

---@return integer
function CascadeParticleSystemInstance:GetNumActiveParticles() end

---@param bias number
---@return nil
function CascadeParticleSystemInstance:SetAnimationLodBias(bias) end

---@return number
function CascadeParticleSystemInstance:GetAnimationLodBias() end

---@param name string
---@param value number
---@return nil
function CascadeParticleSystemInstance:SetFloatParameter(name, value) end

---@param name string
---@param value integer
---@return nil
function CascadeParticleSystemInstance:SetIntParameter(name, value) end

---@param name string
---@param value boolean
---@return nil
function CascadeParticleSystemInstance:SetBoolParameter(name, value) end

---@param name string
---@param value Vector3
---@return nil
function CascadeParticleSystemInstance:SetVectorParameter(name, value) end

---@param name string
---@param value Color
---@return nil
function CascadeParticleSystemInstance:SetColorParameter(name, value) end

---@param emitterIndex integer
---@param point Vector3
---@return nil
function CascadeParticleSystemInstance:SetBeamEndPoint(emitterIndex, point) end

---@param emitterIndex integer
---@param point Vector3
---@param sourceIndex integer
---@return nil
function CascadeParticleSystemInstance:SetBeamSourcePoint(emitterIndex, point, sourceIndex) end

---@param emitterIndex integer
---@param tangent Vector3
---@param sourceIndex integer
---@return nil
function CascadeParticleSystemInstance:SetBeamSourceTangent(emitterIndex, tangent, sourceIndex) end

---@param emitterIndex integer
---@param strength number
---@param sourceIndex integer
---@return nil
function CascadeParticleSystemInstance:SetBeamSourceStrength(emitterIndex, strength, sourceIndex) end

---@param emitterIndex integer
---@param point Vector3
---@param targetIndex integer
---@return nil
function CascadeParticleSystemInstance:SetBeamTargetPoint(emitterIndex, point, targetIndex) end

---@param emitterIndex integer
---@param tangent Vector3
---@param targetIndex integer
---@return nil
function CascadeParticleSystemInstance:SetBeamTargetTangent(emitterIndex, tangent, targetIndex) end

---@param emitterIndex integer
---@param strength number
---@param targetIndex integer
---@return nil
function CascadeParticleSystemInstance:SetBeamTargetStrength(emitterIndex, strength, targetIndex) end

---@param firstSocketName string
---@param secondSocketName string
---@param widthMode CascadeTrailWidthMode
---@param width number
---@return nil
function CascadeParticleSystemInstance:BeginTrails(firstSocketName, secondSocketName, widthMode, width) end

---@return nil
function CascadeParticleSystemInstance:EndTrails() end

---@param firstSocketName string
---@param secondSocketName string
---@param widthMode CascadeTrailWidthMode
---@param width number
---@return nil
function CascadeParticleSystemInstance:SetTrailSourceData(firstSocketName, secondSocketName, widthMode, width) end

