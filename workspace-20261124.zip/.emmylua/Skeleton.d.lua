---@meta

--- Auto-generated from Graphics/Skeleton

---@class Bone
---@overload fun(): Bone
---@field name string
---@field nameHash StringHash|string
---@field parentIndex integer
---@field initialPosition Vector3
---@field initialRotation Quaternion
---@field initialScale Vector3
---@field offsetMatrix Matrix3x4
---@field animated boolean
---@field collisionMask number -- unsigned char
---@field radius number
---@field boundingBox BoundingBox
---@field node Node
Bone = {}

---@return Bone
function Bone.new() end

---@return Matrix3x4
function Bone:GetFinalWorldTransform() end


---@class Skeleton
---@overload fun(): Skeleton
---@field numBones integer
---@field rootBone Bone
Skeleton = {}

---@return Skeleton
function Skeleton.new() end

--- Build a skeleton in one call, for example to pass to ProceduralGeometry:ToModel(): one entry per bone, parents
--- before their children, each { name, parent = name of an earlier entry (none for a root bone), position,
--- rotation, scale } with the initial transform relative to the parent (defaults: origin, no rotation, scale 1).
--- Bone indices follow the list from 0. Names must be non-empty and unique; a bad entry or an unknown key raises
--- an error naming the entry. Lua cannot add bones to a skeleton afterwards.
---@param bones { name: string, parent?: string, position?: Vector3, rotation?: Quaternion, scale?: Vector3 }[]
---@return Skeleton
function Skeleton:FromBones(bones) end

---@return integer
function Skeleton:GetNumBones() end

---@return Bone
function Skeleton:GetRootBone() end

---@param name string
---@return Bone
function Skeleton:GetBone(name) end

---@param index integer
---@return Bone
function Skeleton:GetBone(index) end

---@param boneName string
---@return integer
function Skeleton:GetBoneIndex(boneName) end

---@param bone Bone
---@return integer
function Skeleton:GetBoneIndex(bone) end

---@param bone Bone
---@return Bone
function Skeleton:GetBoneParent(bone) end

