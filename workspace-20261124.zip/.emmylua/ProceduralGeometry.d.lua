---@meta

--- Auto-generated from Graphics/ProceduralGeometry

---@class ProceduralGeometry : RefCounted
ProceduralGeometry = {}

---@param enable boolean
---@return nil
function ProceduralGeometry:SetConvertHandedness(enable) end

---@param enable boolean
---@return nil
function ProceduralGeometry:SetDynamic(enable) end

---@param enable boolean
---@return nil
function ProceduralGeometry:SetShadowed(enable) end

---@param enable boolean
---@return nil
function ProceduralGeometry:SetGenerateTangents(enable) end

--- Transform by an affine matrix in the geometry's own coordinates (engine axes). Normals stay perpendicular to
--- the surface, and a mirroring matrix (negative determinant) also reverses winding so faces keep facing outward.
---@param matrix Matrix3x4
---@return ProceduralGeometry
function ProceduralGeometry:ApplyMatrix4(matrix) end

--- Rotate in the geometry's own coordinates (engine axes).
---@param rotation Quaternion
---@return ProceduralGeometry
function ProceduralGeometry:ApplyQuaternion(rotation) end

--- Translate in the geometry's own coordinates (engine axes).
---@param x number
---@param y number
---@param z number
---@return ProceduralGeometry
function ProceduralGeometry:Translate(x, y, z) end

--- Scale per axis in the geometry's own coordinates (engine axes).
---@param x number
---@param y number
---@param z number
---@return ProceduralGeometry
function ProceduralGeometry:Scale(x, y, z) end

--- Recompute smooth normals from the triangles. By default only vertices shared through the index buffer are
--- smoothed, so a box keeps its hard edges. With weldPositions, all vertices at the same position share one
--- normal: seams close, but hard edges such as box corners get rounded too (ToCreasedNormals() keeps them).
---@param weldPositions? boolean
---@return ProceduralGeometry
function ProceduralGeometry:ComputeVertexNormals(weldPositions) end

--- Scale the UVs so one UV unit spans `meters` on the surface (default 1), for textures that tile by real size.
--- Each UV island scales u and v separately by its average length per UV unit: box faces, cylinder sides and
--- caps, lathe and tube surfaces get UVs in metres; spheres and cones, whose scale varies, get the average. UV
--- seams and hard edges keep their islands apart. Uses the current positions, so call it after scaling.
--- Tangents are refreshed. `meters` must be greater than 0.
---@param meters? number
---@return ProceduralGeometry
function ProceduralGeometry:ScaleUVToMeters(meters) end

--- Map every UV to uv * scale + offset, component-wise: for example to place a 0..1 mapping inside a rectangle of
--- an atlas texture, or to repeat a texture. Tangents are refreshed; a negative scale component mirrors the
--- mapping. No-op without UVs. Every component must be a finite number.
---@param scale Vector2
---@param offset? Vector2
---@return ProceduralGeometry
function ProceduralGeometry:TransformUV(scale, offset) end

--- Return a deep copy.
---@return ProceduralGeometry
function ProceduralGeometry:Clone() end

--- Replace every vertex color.
---@param color Color
---@return ProceduralGeometry
function ProceduralGeometry:SetVertexColor(color) end

--- Multiply every vertex color by color (missing colors start as white), on top of earlier color operations.
---@param color Color
---@return ProceduralGeometry
function ProceduralGeometry:MultiplyVertexColor(color) end

--- Bind every vertex rigidly to skeleton bone boneIndex (0-based, at most 255) with full weight, replacing an
--- earlier binding. Only ToModel(skeleton) uses the binding. MergeGeometries() keeps it and binds the inputs that
--- have none to bone 0.
---@param boneIndex integer
---@return ProceduralGeometry
function ProceduralGeometry:SetBone(boneIndex) end

--- Multiply vertex RGB by base + range * noise, with noise in [0, 1) sampled at the current vertex positions.
--- Fields (default): scale (1) noise frequency, a number or a per-axis Vector3 (a zero component ignores that
--- axis: Vector3(4, 0, 4) varies only across X and Z); base (0.8) factor where the noise is 0; range (0.2) added
--- where the noise is 1; seed (0) integer in [0, 4294967295], the same seed always gives the same pattern.
---@param params? {scale?: number|Vector3, base?: number, range?: number, seed?: integer}
---@return ProceduralGeometry
function ProceduralGeometry:ApplyNoiseColor(params) end

--- Multiply vertex colors by a linear blend from colorFrom to colorTo along axis, at the current vertex positions.
--- Fields (default): axis (Vector3.UP, normalized); from (0) and to (1) are positions along the axis, that is
--- dot(position, axis): at or below from the factor is colorFrom, at or above to it is colorTo; colorFrom and
--- colorTo (both Color.WHITE, so pass at least one of them or nothing changes).
---@param params? {axis?: Vector3, from?: number, to?: number, colorFrom?: Color, colorTo?: Color}
---@return ProceduralGeometry
function ProceduralGeometry:ApplyGradientColor(params) end

--- Multiply vertex RGB by a grime pattern computed from the current vertex positions and normals: call it on the
--- assembled prop in its own coordinates, with the ground at y = 0. Fields (default): strength (1) 0 = no effect,
--- 1 = full effect; seed (0) integer pattern seed; largeScale (1.9) and largeAmount (0.18) frequency and darkening
--- of the large blotches; smallScale (9) and smallAmount (0.08) the same for fine speckles; upFacingAmount (0.24)
--- extra darkening that grows from up-facing to down-facing faces; groundHeight (0.2) height of the dirt band above
--- y = 0 (<= 0 disables it); groundDarken (0.42) darkening at y = 0; groundTint (Color(1, 0.95, 0.88)) color
--- multiplier reached at y = 0, which warms the band.
---@param params? {strength?: number, seed?: integer, largeScale?: number, largeAmount?: number, smallScale?: number, smallAmount?: number, upFacingAmount?: number, groundHeight?: number, groundDarken?: number, groundTint?: Color}
---@return ProceduralGeometry
function ProceduralGeometry:ApplyGrime(params) end

--- Move every vertex through fn(x, y, z), which returns the new position as x, y, z or as a Vector3. Positions are
--- in the geometry's own coordinates (engine axes). One Lua call per vertex: keep it to parts with a few hundred
--- vertices, and do not edit or delete this geometry inside fn. Tangents and the bounding box are refreshed
--- afterwards; normals are not, so call ComputeVertexNormals() when the shape changes noticeably.
---@param fn fun(x: number, y: number, z: number): number|Vector3, number?, number?
---@return ProceduralGeometry
function ProceduralGeometry:Deform(fn) end

--- Build a Model. With a skeleton the model is skinned for an AnimatedModel: it carries the bone bindings (see
--- SetBone(); unbound vertices use bone 0) and a copy of the skeleton whose bones get bounding boxes around their
--- vertices, which AnimatedModel culls with. Returns nil, logging an error, when the skeleton is empty or has
--- more than 256 bones, or a bound bone index is out of its range.
---@param skeleton? Skeleton
---@return Model
function ProceduralGeometry:ToModel(skeleton) end

---@param geometry CustomGeometry
---@return boolean
function ProceduralGeometry:FillCustomGeometry(geometry) end

---@return integer
function ProceduralGeometry:GetVertexCount() end

---@return integer
function ProceduralGeometry:GetIndexCount() end

---@return integer
function ProceduralGeometry:GetGroupCount() end

--- Bounding box in engine space (matches the Model produced by ToModel()).
---@return BoundingBox
function ProceduralGeometry:GetBoundingBox() end

--- Whether the data has been baked into engine space by an edit or merge.
---@return boolean
function ProceduralGeometry:IsBaked() end


-- Global functions
---@param width? number
---@param height? number
---@param widthSegments? integer
---@param heightSegments? integer
---@return ProceduralGeometry
function PlaneGeometry(width, height, widthSegments, heightSegments) end

---@param width? number
---@param height? number
---@param depth? number
---@param widthSegments? integer
---@param heightSegments? integer
---@param depthSegments? integer
---@return ProceduralGeometry
function BoxGeometry(width, height, depth, widthSegments, heightSegments, depthSegments) end

---@param radius? number
---@param widthSegments? integer
---@param heightSegments? integer
---@param phiStart? number
---@param phiLength? number
---@param thetaStart? number
---@param thetaLength? number
---@return ProceduralGeometry
function SphereGeometry(radius, widthSegments, heightSegments, phiStart, phiLength, thetaStart, thetaLength) end

---@param radiusTop? number
---@param radiusBottom? number
---@param height? number
---@param radialSegments? integer
---@param heightSegments? integer
---@param openEnded? boolean
---@param thetaStart? number
---@param thetaLength? number
---@return ProceduralGeometry
function CylinderGeometry(radiusTop, radiusBottom, height, radialSegments, heightSegments, openEnded, thetaStart, thetaLength) end

---@param radius? number
---@param height? number
---@param radialSegments? integer
---@param heightSegments? integer
---@param openEnded? boolean
---@param thetaStart? number
---@param thetaLength? number
---@return ProceduralGeometry
function ConeGeometry(radius, height, radialSegments, heightSegments, openEnded, thetaStart, thetaLength) end

---@param radius? number
---@param segments? integer
---@param thetaStart? number
---@param thetaLength? number
---@return ProceduralGeometry
function CircleGeometry(radius, segments, thetaStart, thetaLength) end

---@param innerRadius? number
---@param outerRadius? number
---@param thetaSegments? integer
---@param phiSegments? integer
---@param thetaStart? number
---@param thetaLength? number
---@return ProceduralGeometry
function RingGeometry(innerRadius, outerRadius, thetaSegments, phiSegments, thetaStart, thetaLength) end

---@param radius? number
---@param tube? number
---@param radialSegments? integer
---@param tubularSegments? integer
---@param arc? number
---@return ProceduralGeometry
function TorusGeometry(radius, tube, radialSegments, tubularSegments, arc) end

---@param radius? number
---@param detail? integer
---@return ProceduralGeometry
function TetrahedronGeometry(radius, detail) end

---@param radius? number
---@param detail? integer
---@return ProceduralGeometry
function OctahedronGeometry(radius, detail) end

---@param radius? number
---@param detail? integer
---@return ProceduralGeometry
function IcosahedronGeometry(radius, detail) end

---@param radius? number
---@param detail? integer
---@return ProceduralGeometry
function DodecahedronGeometry(radius, detail) end

---@param vertices number[]
---@param indices integer[]
---@param radius? number
---@param detail? integer
---@return ProceduralGeometry
function PolyhedronGeometry(vertices, indices, radius, detail) end

---@param func integer|string Built-in surface: enum index (0=Klein 1=Plane 2=Mobius 3=Mobius3D) or a case-insensitive name
---@param slices? integer
---@param stacks? integer
---@return ProceduralGeometry
function ParametricGeometry(func, slices, stacks) end

---@param geometry ProceduralGeometry
---@return ProceduralGeometry
function WireframeGeometry(geometry) end

---@param geometry ProceduralGeometry
---@param thresholdAngle? number
---@return ProceduralGeometry
function EdgesGeometry(geometry, thresholdAngle) end

---@param width? number
---@param height? number
---@param depth? number
---@param widthSegments? integer
---@param heightSegments? integer
---@param depthSegments? integer
---@return ProceduralGeometry
function BoxLineGeometry(width, height, depth, widthSegments, heightSegments, depthSegments) end

---@param radius? number
---@param tube? number
---@param tubularSegments? integer
---@param radialSegments? integer
---@param p? integer
---@param q? integer
---@return ProceduralGeometry
function TorusKnotGeometry(radius, tube, tubularSegments, radialSegments, p, q) end

---@param points Vector2[]
---@param segments? integer
---@param phiStart? number
---@param phiLength? number
---@return ProceduralGeometry
function LatheGeometry(points, segments, phiStart, phiLength) end

---@param points Vector3[]
---@param tubularSegments? integer
---@param radius? number
---@param radialSegments? integer
---@param closed? boolean
---@return ProceduralGeometry
function TubeGeometry(points, tubularSegments, radius, radialSegments, closed) end

---@param radius? number
---@param height? number
---@param capSegments? integer
---@param radialSegments? integer
---@param heightSegments? integer
---@return ProceduralGeometry
function CapsuleGeometry(radius, height, capSegments, radialSegments, heightSegments) end

---@param width? number
---@param height? number
---@param depth? number
---@param segments? integer
---@param radius? number
---@return ProceduralGeometry
function RoundedBoxGeometry(width, height, depth, segments, radius) end

---@param points Vector3[]
---@return ProceduralGeometry
function ConvexGeometry(points) end

---@param sections Vector3[][] Array of cross-sections, each a Lua array of Vector3 (uniform length)
---@param closedSections? boolean
---@return ProceduralGeometry
function LoftGeometry(sections, closedSections) end

---@param contour Vector2[]
---@return ProceduralGeometry
function ShapeGeometry(contour) end

---@param contour Vector2[]
---@param depth? number
---@return ProceduralGeometry
function ExtrudeGeometry(contour, depth) end

---@param mesh ProceduralGeometry
---@param position Vector3
---@param orientation Quaternion
---@param size Vector3
---@return ProceduralGeometry
function DecalGeometry(mesh, position, orientation, size) end

---@param size? number
---@param segments? integer
---@param bottom? boolean
---@param lid? boolean
---@param body? boolean
---@param fitLid? boolean
---@param blinn? boolean
---@return ProceduralGeometry
function TeapotGeometry(size, segments, bottom, lid, body, fitLid, blinn) end

--- Box with narrow flat chamfers on every edge and corner (chamfer defaults to 0.008 and is clamped to 90% of the
--- smallest half extent), which gives soft highlights along the edges. UVs are in length units (one UV unit per
--- meter), so a tiling texture keeps one density on every face; textures meant to cover a whole face once do not
--- fit. 96 vertices, 44 triangles.
---@param width? number
---@param height? number
---@param depth? number
---@param chamfer? number
---@return ProceduralGeometry
function ChamferBoxGeometry(width, height, depth, chamfer) end

--- Concatenate geometries into a new one (three.js mergeGeometries); the inputs are not modified. With useGroups,
--- entry i becomes material group i - 1, which is sub-geometry i - 1 of ToModel(). Unlike three.js, the inputs may
--- have different attributes: when any input has vertex colors the others get white ones, and missing UVs become
--- zero. Returns nil (and logs an error) when triangle and line geometries are mixed.
---@param geometries ProceduralGeometry[]
---@param useGroups? boolean
---@return ProceduralGeometry|nil
function MergeGeometries(geometries, useGroups) end

--- Return a copy in which vertices whose position, normal, UV and color all match within tolerance (default 1e-4)
--- are merged (three.js mergeVertices). Vertices on hard edges differ in normal and stay separate.
---@param geometry ProceduralGeometry
---@param tolerance? number
---@return ProceduralGeometry
function MergeVertices(geometry, tolerance) end

--- Return a copy whose normals are smoothed across faces meeting at less than creaseAngle radians (default pi / 3)
--- and stay hard above it (three.js toCreasedNormals). The result is non-indexed: three vertices per triangle.
---@param geometry ProceduralGeometry
---@param creaseAngle? number
---@return ProceduralGeometry
function ToCreasedNormals(geometry, creaseAngle) end
