---@meta

--- Auto-generated from CascadeParticle/CascadeParticleSystem

---@class CascadeParticleSystem : Resource
CascadeParticleSystem = {}

---@return integer
function CascadeParticleSystem:GetNumEmitters() end

