---@meta

--- Auto-generated from Audio/AudioBuffer

--- BiquadType enum values
---@alias BiquadType integer

---@type BiquadType
BIQUAD_LOWPASS = BIQUAD_LOWPASS
---@type BiquadType
BIQUAD_HIGHPASS = BIQUAD_HIGHPASS
---@type BiquadType
BIQUAD_BANDPASS = BIQUAD_BANDPASS

--- OscillatorWave enum values
---@alias OscillatorWave integer

---@type OscillatorWave
WAVE_SINE = WAVE_SINE
---@type OscillatorWave
WAVE_SAW = WAVE_SAW
---@type OscillatorWave
WAVE_SQUARE = WAVE_SQUARE
---@type OscillatorWave
WAVE_TRIANGLE = WAVE_TRIANGLE

---@class AudioBuffer : RefCounted
---@overload fun(sampleRate: integer, seconds: number): AudioBuffer
---@overload fun(): AudioBuffer
---@field sampleRate integer Sample rate in Hz.
---@field frames integer Number of frames (0 after Release()).
---@field duration number Duration in seconds.
---@field released boolean Whether Release() freed the samples.
AudioBuffer = {}

---@overload fun(self: AudioBuffer, sampleRate: integer, seconds: number): AudioBuffer
---@overload fun(sampleRate: integer, seconds: number): AudioBuffer
---@return AudioBuffer
function AudioBuffer.new() end

--- Return one channel (0 left, 1 right) of an uncompressed Sound (8 or 16 bits) as a new buffer.
---@param sound Sound
---@param channel? integer
---@return AudioBuffer
function AudioBuffer:FromSound(sound, channel) end

--- Return the sample rate in Hz.
---@return integer
function AudioBuffer:GetSampleRate() end

--- Return the number of frames (0 after Release()).
---@return integer
function AudioBuffer:GetFrames() end

--- Return the duration in seconds.
---@return number
function AudioBuffer:GetDuration() end

--- Return whether Release() freed the samples.
---@return boolean
function AudioBuffer:IsReleased() end

--- Return the largest absolute sample.
---@return number
function AudioBuffer:GetPeak() end

--- Return a deep copy.
---@return AudioBuffer
function AudioBuffer:Clone() end

--- Change the number of frames (at least 1, at most 120 seconds); new frames are silent.
---@param frames integer
---@return AudioBuffer
function AudioBuffer:Resize(frames) end

--- Return the sample at a frame index (0 to frames - 1).
---@param frame integer
---@return number
function AudioBuffer:GetSample(frame) end

--- Set the sample at a frame index (0 to frames - 1).
---@param frame integer
---@param value number
---@return nil
function AudioBuffer:SetSample(frame, value) end

--- Free the samples now instead of waiting for the garbage collector; other operations raise errors afterwards.
---@return nil
function AudioBuffer:Release() end

--- Set every sample to a value.
---@param value number
---@return AudioBuffer
function AudioBuffer:Fill(value) end

--- Set every sample to its time in seconds.
---@return AudioBuffer
function AudioBuffer:Time() end

--- Set every sample to its position in the buffer, frame / frames (0 to just below 1).
---@return AudioBuffer
function AudioBuffer:Position() end

--- Add a constant or a buffer.
---@param value number|AudioBuffer
---@return AudioBuffer
function AudioBuffer:Add(value) end

--- Multiply by a constant or a buffer.
---@param value number|AudioBuffer
---@return AudioBuffer
function AudioBuffer:Multiply(value) end

--- Add source * gain starting at atSeconds; samples beyond the end are dropped, or with wrap continue from the
--- beginning (for loops). The source needs the same sample rate and may have any length.
---@param source AudioBuffer
---@param atSeconds? number
---@param gain? number
---@param wrap? boolean
---@return AudioBuffer
function AudioBuffer:Mix(source, atSeconds, gain, wrap) end

--- Replace every sample by its sine.
---@return AudioBuffer
function AudioBuffer:Sin() end

--- Replace every sample by its exponential.
---@return AudioBuffer
function AudioBuffer:Exp() end

--- Raise every sample to a power.
---@param exponent number
---@return AudioBuffer
function AudioBuffer:Pow(exponent) end

--- Replace every sample by its absolute value.
---@return AudioBuffer
function AudioBuffer:Abs() end

--- Replace every sample by its hyperbolic tangent.
---@return AudioBuffer
function AudioBuffer:Tanh() end

--- Replace every sample by its fractional part, x - floor(x): wraps phases and times into periods.
---@return AudioBuffer
function AudioBuffer:Fract() end

--- Clamp every sample to [min, max].
---@param min number
---@param max number
---@return AudioBuffer
function AudioBuffer:Clamp(min, max) end

--- Add gain * sin(multiplier * phase + offset), with the phase read per sample from a buffer: harmonics of one
--- phase without temporary buffers.
---@param gain? number|AudioBuffer
---@param phase AudioBuffer
---@param multiplier? number
---@param offset? number
---@return AudioBuffer
function AudioBuffer:AddSin(phase, multiplier, offset, gain) end

--- Add white noise in [-gain, gain).
---@param gain? number|AudioBuffer
---@param random RandomGenerator
---@return AudioBuffer
function AudioBuffer:AddNoise(random, gain) end

--- Add random steps: a value drawn from [min, max) at the first frame and every interval seconds, held until the
--- next step.
---@param random RandomGenerator
---@param interval number
---@param min number
---@param max number
---@return AudioBuffer
function AudioBuffer:AddSteps(random, interval, min, max) end

--- Add an oscillator (WAVE_SINE, WAVE_SAW, WAVE_SQUARE or WAVE_TRIANGLE, not band-limited). The phase is in
--- cycles and advances by frequency / sampleRate before each sample.
---@param frequency number|AudioBuffer
---@param gain? number|AudioBuffer
---@param wave OscillatorWave
---@param phase? number
---@return AudioBuffer
function AudioBuffer:AddOscillator(wave, frequency, phase, gain) end

--- Add decaying sines, one per mode { frequency (Hz), decay (time constant in seconds), amplitude }, each with a
--- random phase (zero without a generator); modes above 0.46 times the sample rate are skipped. The sum fades in
--- over attack seconds. For struck metal, glass and bells.
---@param modes number[][]
---@param random? RandomGenerator
---@param attack? number
---@return AudioBuffer
function AudioBuffer:AddModes(modes, random, attack) end

--- Add count grains of noise, each decaying as e^(-decay t / length). Options (default): from (0) and to (the
--- buffer's duration) bound the start times; fall (1) is the exponent of the start distribution, above 1 crowding
--- grains towards from; minLength (0.001) and maxLength (0.004, at most 120) in seconds; minGain (0.2) and maxGain
--- (1) with gainCurve (1) as the exponent of the amplitude distribution, above 1 making loud grains rarer;
--- gainDecay (0, off) is a time constant over which amplitudes fall with the start time; decay (4); wrap (false)
--- continues grains past the end from the beginning, for loops. For debris, sparks, droplets and rain.
---@param options? { from?: number, to?: number, fall?: number, minLength?: number, maxLength?: number, minGain?: number, maxGain?: number, gainCurve?: number, gainDecay?: number, decay?: number, wrap?: boolean }
---@param random RandomGenerator
---@param count integer
---@return AudioBuffer
function AudioBuffer:AddGrains(random, count, options) end

--- Filter with a biquad: BIQUAD_LOWPASS, BIQUAD_HIGHPASS or BIQUAD_BANDPASS (0 dB peak). The frequency is clamped
--- to [10, 0.47 * sampleRate]; q defaults to 0.7071. With a per-sample frequency or q, the coefficients are
--- recomputed every options.interval frames (default 32). With options.passes above 1 (default 1), the earlier
--- passes only warm the filter state up, so a looping buffer starts with the state its end leaves.
---@param frequency number|AudioBuffer
---@param q? number|AudioBuffer
---@param options? { interval?: integer, passes?: integer }
---@param type BiquadType
---@return AudioBuffer
function AudioBuffer:Biquad(type, frequency, q, options) end

--- Filter with a one-pole lowpass, y += (x - y) * (1 - e^(-2 pi frequency / sampleRate)), starting from
--- options.initial (default 0). With a per-sample frequency the coefficient is recomputed every options.interval
--- frames (default 32).
---@param frequency number|AudioBuffer
---@param options? { interval?: integer, initial?: number }
---@return AudioBuffer
function AudioBuffer:OnePole(frequency, options) end

--- Multiply by e^(-t / tau), and by 1 - e^(-t / attack) when attack is above 0.
---@param tau number
---@param attack? number
---@return AudioBuffer
function AudioBuffer:Decay(tau, attack) end

--- Fade in linearly over inSeconds and out quadratically over outSeconds, each limited to half the buffer.
---@param inSeconds number
---@param outSeconds number
---@return AudioBuffer
function AudioBuffer:Fade(inSeconds, outSeconds) end

--- Replace x by tanh(x * drive) / tanh(drive).
---@param drive number
---@return AudioBuffer
function AudioBuffer:SoftClip(drive) end

--- Scale so the largest absolute sample becomes peak; a silent buffer stays silent.
---@param peak? number
---@return AudioBuffer
function AudioBuffer:Normalize(peak) end

--- Make a seamless loop seconds long: the samples beyond it are crossfaded into the beginning (equal power, or
--- linear when equalPower is false) and the buffer is cut to that length.
---@param seconds number
---@param equalPower? boolean
---@return AudioBuffer
function AudioBuffer:LoopCrossfade(seconds, equalPower) end

--- Create a 16-bit Sound, stereo with right (same frames and sample rate); samples beyond [-1, 1] are clamped and
--- non-finite samples raise an error.
---@param right? AudioBuffer
---@param looped? boolean
---@return Sound
function AudioBuffer:ToSound(right, looped) end

