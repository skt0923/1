---@meta

--- Auto-generated from Audio/AudioEffect

---@class AudioEffect : RefCounted
---@field enabled boolean Whether the effect processes its bus.
---@field attached boolean Whether the effect is on a bus.
AudioEffect = {}

--- Set whether the effect processes its bus. A disabled effect passes the signal through unchanged; enabling it
--- again starts from a cleared state.
---@param enable boolean
---@return nil
function AudioEffect:SetEnabled(enable) end

--- Return whether the effect processes its bus.
---@return boolean
function AudioEffect:IsEnabled() end

--- Return whether the effect is on a bus.
---@return boolean
function AudioEffect:IsAttached() end


---@class AudioGainEffect : AudioEffect
---@overload fun(gain?: number): AudioGainEffect
---@overload fun(): AudioGainEffect
---@field gain number Gain, 0 or more.
AudioGainEffect = {}

---@overload fun(self: AudioGainEffect, gain?: number): AudioGainEffect
---@overload fun(gain?: number): AudioGainEffect
---@return AudioGainEffect
function AudioGainEffect.new() end

--- Set the gain (0 or more; other values are ignored).
---@param gain number
---@return nil
function AudioGainEffect:SetGain(gain) end

--- Return the gain.
---@return number
function AudioGainEffect:GetGain() end


---@class AudioBiquadEffect : AudioEffect
---@overload fun(): AudioBiquadEffect
---@field type BiquadType Response: BIQUAD_LOWPASS, BIQUAD_HIGHPASS or BIQUAD_BANDPASS.
---@field frequency number Cutoff or centre frequency in Hz.
---@field q number Linear q.
AudioBiquadEffect = {}

---@return AudioBiquadEffect
function AudioBiquadEffect.new() end

--- Set the response.
---@param type BiquadType
---@return nil
function AudioBiquadEffect:SetType(type) end

--- Return the response.
---@return BiquadType
function AudioBiquadEffect:GetType() end

--- Set the cutoff or centre frequency in Hz (above 0; other values are ignored).
---@param frequency number
---@return nil
function AudioBiquadEffect:SetFrequency(frequency) end

--- Return the cutoff or centre frequency in Hz.
---@return number
function AudioBiquadEffect:GetFrequency() end

--- Set the linear q (above 0; other values are ignored). For WebAudio's lowpass or highpass Q in dB, pass 10^(Q / 20).
---@param q number
---@return nil
function AudioBiquadEffect:SetQ(q) end

--- Return the linear q.
---@return number
function AudioBiquadEffect:GetQ() end


---@class AudioCompressorEffect : AudioEffect
---@overload fun(): AudioCompressorEffect
---@field threshold number Threshold in dB, -100 to 0.
---@field knee number Knee width in dB, 0 to 40.
---@field ratio number Ratio, 1 to 20.
---@field attack number Attack time in seconds, 0 to 1.
---@field release number Release time in seconds, 0 to 1.
AudioCompressorEffect = {}

---@return AudioCompressorEffect
function AudioCompressorEffect.new() end

--- Set the threshold in dB, -100 to 0.
---@param db number
---@return nil
function AudioCompressorEffect:SetThreshold(db) end

--- Return the threshold in dB.
---@return number
function AudioCompressorEffect:GetThreshold() end

--- Set the knee width in dB, 0 to 40.
---@param db number
---@return nil
function AudioCompressorEffect:SetKnee(db) end

--- Return the knee width in dB.
---@return number
function AudioCompressorEffect:GetKnee() end

--- Set the ratio, 1 to 20.
---@param ratio number
---@return nil
function AudioCompressorEffect:SetRatio(ratio) end

--- Return the ratio.
---@return number
function AudioCompressorEffect:GetRatio() end

--- Set the attack time in seconds, 0 to 1.
---@param seconds number
---@return nil
function AudioCompressorEffect:SetAttack(seconds) end

--- Return the attack time in seconds.
---@return number
function AudioCompressorEffect:GetAttack() end

--- Set the release time in seconds, 0 to 1.
---@param seconds number
---@return nil
function AudioCompressorEffect:SetRelease(seconds) end

--- Return the release time in seconds.
---@return number
function AudioCompressorEffect:GetRelease() end


---@class AudioSoftClipEffect : AudioEffect
---@overload fun(threshold?: number): AudioSoftClipEffect
---@overload fun(): AudioSoftClipEffect
---@field threshold number Threshold in [0, 1).
AudioSoftClipEffect = {}

---@overload fun(self: AudioSoftClipEffect, threshold?: number): AudioSoftClipEffect
---@overload fun(threshold?: number): AudioSoftClipEffect
---@return AudioSoftClipEffect
function AudioSoftClipEffect.new() end

--- Set the threshold in [0, 1) (other values are ignored).
---@param threshold number
---@return nil
function AudioSoftClipEffect:SetThreshold(threshold) end

--- Return the threshold.
---@return number
function AudioSoftClipEffect:GetThreshold() end


---@class AudioReverbEffect : AudioEffect
---@overload fun(): AudioReverbEffect
---@field preDelay number Delay before the late reverb in seconds.
---@field decayTime number Decay time (T60) in seconds.
---@field damping number High-frequency damping, 0 to 0.95.
---@field roomSize number Room size, 0.1 to 3.
---@field width number Stereo width, 0 to 1.
---@field lateGain number Gain of the late reverb.
AudioReverbEffect = {}

---@return AudioReverbEffect
function AudioReverbEffect.new() end

--- Set the delay before the late reverb, 0 to 0.5 seconds.
---@param seconds number
---@return nil
function AudioReverbEffect:SetPreDelay(seconds) end

--- Return the pre-delay in seconds.
---@return number
function AudioReverbEffect:GetPreDelay() end

--- Set the decay time (T60, the time to fall by 60 dB) of low frequencies, 0.1 to 30 seconds.
---@param seconds number
---@return nil
function AudioReverbEffect:SetDecayTime(seconds) end

--- Return the decay time in seconds.
---@return number
function AudioReverbEffect:GetDecayTime() end

--- Set how much faster high frequencies decay, 0 to 0.95: their decay time is decayTime * (1 - damping).
---@param damping number
---@return nil
function AudioReverbEffect:SetDamping(damping) end

--- Return the damping.
---@return number
function AudioReverbEffect:GetDamping() end

--- Set the room size, 0.1 to 3: scales the delays (larger rooms have sparser, slower echoes); the decay time stays.
---@param size number
---@return nil
function AudioReverbEffect:SetRoomSize(size) end

--- Return the room size.
---@return number
function AudioReverbEffect:GetRoomSize() end

--- Set the stereo width of the reverb, 0 (mono) to 1.
---@param width number
---@return nil
function AudioReverbEffect:SetWidth(width) end

--- Return the width.
---@return number
function AudioReverbEffect:GetWidth() end

--- Set the gain of the late reverb (0 or more); the early reflections have their own gains.
---@param gain number
---@return nil
function AudioReverbEffect:SetLateGain(gain) end

--- Return the gain of the late reverb.
---@return number
function AudioReverbEffect:GetLateGain() end

--- Replace the early reflections with a list of { time (s, 0 to 1), gain, pan (-1 left to 1 right) }, at most 32.
--- Each is a copy of the input after its time, panned with equal power. An empty list removes them.
---@param reflections number[][]
---@return nil
function AudioReverbEffect:SetReflections(reflections) end

--- Return the early reflections as { time, gain, pan } lists.
---@return number[][]
function AudioReverbEffect:GetReflections() end

--- Remove the early reflections.
---@return nil
function AudioReverbEffect:ClearReflections() end

