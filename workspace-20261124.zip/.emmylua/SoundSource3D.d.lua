---@meta

--- Auto-generated from Audio/SoundSource3D

--- SoundDistanceModel enum values
---@alias SoundDistanceModel integer

---@type SoundDistanceModel
DISTANCE_LINEAR = DISTANCE_LINEAR
---@type SoundDistanceModel
DISTANCE_INVERSE = DISTANCE_INVERSE
---@type SoundDistanceModel
DISTANCE_EXPONENTIAL = DISTANCE_EXPONENTIAL

--- SoundPanningModel enum values
---@alias SoundPanningModel integer

---@type SoundPanningModel
PANNING_LINEAR = PANNING_LINEAR
---@type SoundPanningModel
PANNING_EQUAL_POWER = PANNING_EQUAL_POWER

---@class SoundSource3D : SoundSource
---@field nearDistance number Near distance in world units.
---@field farDistance number Far distance in world units; outside it the source is silent.
---@field innerAngle number Inner cone angle in degrees.
---@field outerAngle number Outer cone angle in degrees.
---@field rolloffFactor number Positive distance rolloff exponent.
---@field distanceModel SoundDistanceModel Distance model: DISTANCE_LINEAR, DISTANCE_INVERSE or DISTANCE_EXPONENTIAL.
---@field panningModel SoundPanningModel Panning model: PANNING_LINEAR or PANNING_EQUAL_POWER.
SoundSource3D = {}

--- Set near/far distance attenuation in world units. Outside farDistance the source is silent.
--- rolloffFactor controls the curve and is clamped to a positive minimum.
---@param nearDistance number
---@param farDistance number
---@param rolloffFactor number
---@return nil
function SoundSource3D:SetDistanceAttenuation(nearDistance, farDistance, rolloffFactor) end

--- Set directional attenuation angles in degrees. 360 degrees disables directional attenuation.
---@param innerAngle number
---@param outerAngle number
---@return nil
function SoundSource3D:SetAngleAttenuation(innerAngle, outerAngle) end

--- Set the distance inside which the source is not attenuated.
---@param distance number
---@return nil
function SoundSource3D:SetNearDistance(distance) end

--- Set the distance outside which the source is fully attenuated.
---@param distance number
---@return nil
function SoundSource3D:SetFarDistance(distance) end

--- Set the inner cone angle in degrees. The default 360 is omnidirectional.
---@param angle number
---@return nil
function SoundSource3D:SetInnerAngle(angle) end

--- Set the outer cone angle in degrees. Outside this cone the source is fully attenuated.
---@param angle number
---@return nil
function SoundSource3D:SetOuterAngle(angle) end

--- Set the positive distance rolloff exponent.
---@param factor number
---@return nil
function SoundSource3D:SetRolloffFactor(factor) end

--- Set how the source attenuates with distance d. DISTANCE_LINEAR (default): (1 - (d - near) / (far - near)) ^ rolloff,
--- silent beyond far. DISTANCE_INVERSE: near / (near + rolloff * (max(d, near) - near)). DISTANCE_EXPONENTIAL:
--- (max(d, near) / near) ^ -rolloff. The last two match WebAudio, ignore far and need a near distance above 0.
---@param model SoundDistanceModel
---@return nil
function SoundSource3D:SetDistanceModel(model) end

--- Set how the source pans. PANNING_LINEAR (default) is louder at the sides than in front; PANNING_EQUAL_POWER
--- matches WebAudio's PannerNode and keeps the power constant (0.71 per channel in front).
---@param model SoundPanningModel
---@return nil
function SoundSource3D:SetPanningModel(model) end

--- Recalculate attenuation and panning from the current source and listener transforms.
--- SoundSource3D::Update calls this automatically; manual calls are only needed after immediate custom changes.
---@return nil
function SoundSource3D:CalculateAttenuation() end

--- Return the near distance in world units.
---@return number
function SoundSource3D:GetNearDistance() end

--- Return the far distance in world units.
---@return number
function SoundSource3D:GetFarDistance() end

--- Return the inner cone angle in degrees.
---@return number
function SoundSource3D:GetInnerAngle() end

--- Return the outer cone angle in degrees.
---@return number
function SoundSource3D:GetOuterAngle() end

--- Return the rolloff exponent. The historical method name contains a spelling error.
---@return number
function SoundSource3D:RollAngleoffFactor() end

--- Return the distance model.
---@return SoundDistanceModel
function SoundSource3D:GetDistanceModel() end

--- Return the panning model.
---@return SoundPanningModel
function SoundSource3D:GetPanningModel() end

