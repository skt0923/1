---@meta

--- Auto-generated from CascadeParticle/CascadeParticle

--- CascadePoolMethod enum values
---@alias CascadePoolMethod integer

---@type CascadePoolMethod
--- 不使用对象池（默认）。
CASCADE_POOL_NONE = 0
---@type CascadePoolMethod
--- 从对象池取用，播放完成后自动归还。
CASCADE_POOL_AUTO_RELEASE = 1
---@type CascadePoolMethod
--- 从对象池取用，由调用方 ReleaseToPool 归还。
CASCADE_POOL_MANUAL_RELEASE = 2
