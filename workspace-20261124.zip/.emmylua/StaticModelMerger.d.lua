---@meta

--- Auto-generated from Graphics/StaticModelMerger

---@class MergedStaticModel : StaticModel
---@field numSources integer
MergedStaticModel = {}

---@return integer
function MergedStaticModel:GetNumSources() end

---@param index integer
---@return StaticModel
function MergedStaticModel:GetSource(index) end


---@class StaticModelMerger : Component
---@field cellSize number
---@field instanceThreshold integer
---@field keepVertexData boolean
---@field merged boolean
---@field numSourceDrawables integer
---@field numMergedDrawables integer
---@field numSkipped integer
StaticModelMerger = {}

---@return boolean
function StaticModelMerger:Merge() end

---@return nil
function StaticModelMerger:Unmerge() end

---@param size number
---@return nil
function StaticModelMerger:SetCellSize(size) end

---@return number
function StaticModelMerger:GetCellSize() end

---@param threshold integer
---@return nil
function StaticModelMerger:SetInstanceThreshold(threshold) end

---@return integer
function StaticModelMerger:GetInstanceThreshold() end

---@param enable boolean
---@return nil
function StaticModelMerger:SetKeepVertexData(enable) end

---@return boolean
function StaticModelMerger:GetKeepVertexData() end

---@return boolean
function StaticModelMerger:IsMerged() end

---@return integer
function StaticModelMerger:GetNumSourceDrawables() end

---@return integer
function StaticModelMerger:GetNumMergedDrawables() end

---@return integer
function StaticModelMerger:GetNumSkipped() end

---@param index integer
---@return MergedStaticModel
function StaticModelMerger:GetMergedDrawable(index) end

