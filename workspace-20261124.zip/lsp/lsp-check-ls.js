// 用 EmmyLuaLS（交互式语言服务器）跑一次全量诊断，输出三档计数。
// 用法: node lsp/lsp-check-ls.js [项目根] [emmylua_ls.exe 路径]
// 与 emmylua_check.exe(CLI) 的区别：LS 会索引整个工作区，能解析 urhox-libs 这类平级目录模块。
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

const root = path.resolve(process.argv[2] || process.cwd());
const exe = process.argv[3] || path.join(
  process.env.LOCALAPPDATA || '',
  'Temp', 'maker-lua-lsp', '0.22.2', 'emmylua_ls.exe'
);

if (!fs.existsSync(exe)) {
  console.error('[LSP-LS] 找不到分析器:', exe);
  process.exit(1);
}

const toUri = (p) => 'file:///' + p.replace(/\\/g, '/').replace(/^\/+/, '');
const child = spawn(exe, ['--communication', 'stdio'], { stdio: ['pipe', 'pipe', 'pipe'] });

let buf = Buffer.alloc(0);
const pending = new Map();
let nextId = 1;
const diag = new Map();
let quietMs = 0;
const QUIET_LIMIT = 15000;

function send(msg) {
  const body = Buffer.from(JSON.stringify({ jsonrpc: '2.0', ...msg }), 'utf8');
  child.stdin.write(`Content-Length: ${body.length}\r\n\r\n`);
  child.stdin.write(body);
}

function request(method, params) {
  const id = nextId++;
  send({ id, method, params });
  return new Promise((resolve) => pending.set(id, resolve));
}

function handle(msgStr) {
  let msg;
  try { msg = JSON.parse(msgStr); } catch { return; }
  quietMs = 0;

  if (msg.id !== undefined && msg.method) {
    // 服务端发来的请求，一律回空结果
    if (msg.method === 'workspace/configuration') send({ id: msg.id, result: (msg.params.items || []).map(() => null) });
    else if (msg.method === 'client/registerCapability' || msg.method === 'window/workDoneProgress/create') send({ id: msg.id, result: null });
    else send({ id: msg.id, result: null });
    return;
  }
  if (msg.id !== undefined && pending.has(msg.id)) {
    pending.get(msg.id)(msg.result);
    pending.delete(msg.id);
    return;
  }
  if (msg.method === 'textDocument/publishDiagnostics') {
    diag.set(msg.params.uri, msg.params.diagnostics || []);
  }
}

child.stdout.on('data', (chunk) => {
  buf = Buffer.concat([buf, chunk]);
  for (;;) {
    const sep = buf.indexOf('\r\n\r\n');
    if (sep < 0) return;
    const header = buf.slice(0, sep).toString('ascii');
    const m = /Content-Length:\s*(\d+)/i.exec(header);
    if (!m) { buf = buf.slice(sep + 4); continue; }
    const len = parseInt(m[1], 10);
    if (buf.length < sep + 4 + len) return;
    const body = buf.slice(sep + 4, sep + 4 + len).toString('utf8');
    buf = buf.slice(sep + 4 + len);
    handle(body);
  }
});
child.stderr.on('data', () => {});

const scriptsDir = fs.existsSync(path.join(root, 'scripts')) ? path.join(root, 'scripts') : root;
const files = [];
(function walk(dir) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p);
    else if (e.name.endsWith('.lua')) files.push(p);
  }
})(scriptsDir);

(async () => {
  await request('initialize', {
    processId: process.pid,
    rootUri: toUri(root),
    rootPath: root,
    workspaceFolders: [ { uri: toUri(root), name: path.basename(root) } ].concat((process.env.LSP_EXTRA_FOLDERS||'').split(',').filter(Boolean).map(d=>{const p=path.resolve(root,'..',d); return {uri:toUri(p),name:path.basename(p)};})),
    capabilities: { workspace: { configuration: false, workspaceFolders: true } },
  });
  send({ method: 'initialized', params: {} });
  const cfgPath = process.env.LSP_PUSH_CONFIG;
  if (cfgPath && fs.existsSync(cfgPath)) {
    send({ method: 'workspace/didChangeConfiguration', params: { settings: (process.env.LSP_WRAP ? { [process.env.LSP_WRAP]: JSON.parse(fs.readFileSync(cfgPath,'utf8')) } : JSON.parse(fs.readFileSync(cfgPath,'utf8'))) } });
  }

  for (const f of files) {
    send({
      method: 'textDocument/didOpen',
      params: { textDocument: { uri: toUri(f), languageId: 'lua', version: 1, text: fs.readFileSync(f, 'utf8') } },
    });
  }

  const started = Date.now();
  await new Promise((resolve) => {
    const timer = setInterval(() => {
      quietMs += 500;
      if (quietMs >= QUIET_LIMIT || Date.now() - started > 180000) { clearInterval(timer); resolve(); }
    }, 500);
  });

  const counts = { error: 0, warning: 0, information: 0, hint: 0 };
  const byCode = {};
  const filesWithDiag = [];
  const scope = scriptsDir + path.sep;
  for (const [uri, list] of diag) {
    if (!list.length) continue;
    const abs = decodeURIComponent(uri.replace(/^file:\/\/\//, '')).replace(/\//g, '\\');
    if (!abs.startsWith(scope)) continue; // 只看用户代码 scripts/，.cache/.emmylua 等不计
    filesWithDiag.push(path.relative(root, abs));
    for (const d of list) {
      const sev = d.severity === 1 ? 'error' : d.severity === 2 ? 'warning' : d.severity === 3 ? 'information' : 'hint';
      counts[sev]++;
      const code = (d.code || 'unknown') + '';
      byCode[(d.severity || 0) + '|' + code] = (byCode[(d.severity || 0) + '|' + code] || 0) + 1;
    }
  }

  console.log(`[LSP-LS] workspace=${root}`);
  console.log(`[LSP-LS] opened=${files.length} files=${filesWithDiag.length}`);
  console.log(`[LSP-LS] errors=${counts.error} warnings=${counts.warning} information=${counts.information} hints=${counts.hint}`);
  for (const k of Object.keys(byCode).sort()) console.log(`  ${k} x${byCode[k]}`);
  for (const f of filesWithDiag.sort()) console.log(`  - ${f}`);

  fs.writeFileSync(path.join(root, 'lsp', 'last-check-ls.json'),
    JSON.stringify({ time: new Date().toISOString(), workspace: root, opened: files.length, files: filesWithDiag.length, counts, byCode }, null, 2));

  try { await request('shutdown', null); send({ method: 'exit' }); } catch {}
  child.kill();
  process.exit(counts.error > 0 ? 2 : 0);
})();