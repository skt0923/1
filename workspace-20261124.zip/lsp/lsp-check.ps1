# ============================================================
# 脚本名：lsp/lsp-check.ps1
# 更新日期：2026-11-19
# 作用：对 scripts/ 跑 emmylua_check 类型检查，并把本次结果落成带时间戳的报告，
#       供「交付前必须有 LSP 痕迹」核对。
# 输入：无（可选透传 emmylua_check 参数）
# 输出：lsp/last-check.json（时间戳/退出码/诊断条数）、lsp/last-check.txt（原始输出）
# ⚠️ 使用前必读：
#   - 本机没有可用的 python（python.exe 是应用商店占位符，退出码 49），因此不再走 lsp-check.py。
#   - scripts/.luarc.json 用大写 Error/Warning/Hint，emmylua_check 0.23.1 只认小写；
#     本脚本在临时配置里做文本级替换（不重新序列化，避免单元素数组被拍平），
#     并把 library 换成绝对路径的 .emmylua 与 urhox-libs。
#   - 退出码直接取 emmylua_check 的退出码；报告每次运行覆盖为本次结果。
# ============================================================
param()

$ErrorActionPreference = "Continue"

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$root = Split-Path -Parent $here
$workspace = Join-Path $root "scripts"
$luarc = Join-Path $workspace ".luarc.json"
$exe = Join-Path $here "emmylua_check.exe"
$reportJson = Join-Path $here "last-check.json"
$reportTxt = Join-Path $here "last-check.txt"
$stamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"

function Write-Report {
    param([int]$code, [string]$reason, [int]$diagnostics, [int]$errors, [int]$warnings)
    $r = [ordered]@{
        time = $stamp
        exit = $code
        reason = $reason
        workspace = $workspace
        diagnostics = $diagnostics
        error_lines = $errors
        warning_lines = $warnings
    }
    $r | ConvertTo-Json | Set-Content -Path $reportJson -Encoding UTF8
}

if (-not (Test-Path $exe)) {
    Write-Report -code -1 -reason "missing emmylua_check.exe" -diagnostics 0 -errors 0 -warnings 0
    Write-Output "[LSP] exit=-1 reason=missing emmylua_check.exe"
    exit 2
}
if (-not (Test-Path $luarc)) {
    Write-Report -code -1 -reason "missing scripts/.luarc.json" -diagnostics 0 -errors 0 -warnings 0
    Write-Output "[LSP] exit=-1 reason=missing scripts/.luarc.json"
    exit 2
}

$text = Get-Content -Path $luarc -Raw -Encoding UTF8
$text = $text.Replace('"Error"', '"error"').Replace('"Warning"', '"warning"').Replace('"Hint"', '"hint"')
$text = $text.Replace('"Fallback"', '"fallback"')
$libA = (Join-Path $root ".emmylua").Replace('\', '\\')
$libB = (Join-Path $root "urhox-libs").Replace('\', '\\')
$libJson = '["' + $libA + '","' + $libB + '"]'
$text = [regex]::Replace($text, '"library"\s*:\s*\[[^\]]*\]', '"library": ' + $libJson)

$tmpCfg = Join-Path $env:TEMP ("emmylua_check_" + [guid]::NewGuid().ToString("N") + ".json")
Set-Content -Path $tmpCfg -Value $text -Encoding UTF8

try {
    $out = & $exe $workspace -c $tmpCfg 2>&1 | ForEach-Object { $_.ToString() }
    $code = $LASTEXITCODE
} finally {
    Remove-Item $tmpCfg -ErrorAction SilentlyContinue
}

$lines = @($out | Where-Object { $_ -ne $null -and $_.Trim() -ne "" })
if ($lines.Count -gt 0) {
    $lines | Set-Content -Path $reportTxt -Encoding UTF8
    $lines | ForEach-Object { Write-Output $_ }
} else {
    Set-Content -Path $reportTxt -Value "" -Encoding UTF8
}

$errors = @($lines | Where-Object { $_ -match "(?i)error" }).Count
$warnings = @($lines | Where-Object { $_ -match "(?i)warning" }).Count

Write-Report -code $code -reason "" -diagnostics $lines.Count -errors $errors -warnings $warnings
Write-Output ("[LSP] exit={0} diagnostics={1} error_lines={2} warning_lines={3} -> lsp/last-check.json" -f $code, $lines.Count, $errors, $warnings)
exit $code