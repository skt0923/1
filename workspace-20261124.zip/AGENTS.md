# UrhoX Lua 游戏开发指南（Agent 入口）

UrhoX 是基于 Urho3D 深度定制的游戏引擎，游戏逻辑用 **Lua 5.4** 编写。它和标准 Urho3D 有不少差异，**不要凭 Urho3D 记忆写代码**。本文件只列「不知道就会写错」的事实和查文档的路由；细节按下方路由打开对应文档。

## 工作区

| 路径 | 内容 |
|---|---|
| `scripts/` | 用户游戏代码，入口 `scripts/main.lua`。分析/review 用户项目只看这里和用户自建目录 |
| `assets/` | 用户资源（纹理、模型、音频…） |
| `templates/` | 项目脚手架，新游戏从这里起步（选型见 `templates/README.md`） |
| `examples/` | 可运行示例（列表见文末；找某个 API 的用法：`grep -rl <API名> examples/`） |
| `engine-docs/` | 引擎文档，完整目录 `engine-docs/index.md` |
| `.cache/packages/<包名>/<版本>/` | 已安装依赖的**只读**开发副本，供源码阅读和 LSP 使用，读取当前版本用同级 `current/`；运行时按依赖配置从 CDN 加载，修改不生效 |
| `urhox-libs/` | 引擎 Lua 库的**只读参考副本**，修改不生效；已安装依赖时，优先阅读 `.cache/packages/urhox-libs/current/` |
| `.emmylua/` | 全部 Lua API 的类型声明——查类/函数签名、字段、枚举、事件参数的权威来源 |

`skills/`、`.claude/` 等是 agent skill；`.project/` 是项目配置；`dist/` `.build/` `.tmp/` 是构建产物。工程内任意 `Editor/` 目录是编辑器脚本，不是游戏运行时代码。

## 工作方式

1. **新游戏从脚手架起步**：复制 `templates/` 下合适的 `scaffold-*.lua` 到 `scripts/main.lua` 再填充，不要从零写。
   - 2D 无物理（消除、卡牌、纯 UI）→ `scaffold-2d.lua`；2D 物理（平台跳跃）→ `scaffold-2d-physics.lua`
   - 3D 场景展示/漫游 → `scaffold-3d-scene.lua`；3D 操控角色 → `scaffold-3d-character.lua`
2. **用到不熟悉的子系统前，先按「文档路由」读对应文档**；函数签名查 `.emmylua/<类名>.d.lua`（文件名不一定等于类名，找不到就 `grep -rn '@class <类名>' .emmylua/`），不要猜 API、资源路径或枚举值。
3. 示例可以当起点，但要按用户需求改造后交付。复制示例目录时连同 `.fsm` / `.json` 等非 Lua 文件一起复制（有 `manifest.json` 就按其 `includes`）。
4. 需要多轮迭代的项目一开始就拆模块：`require "Game.Player"` 对应 scripts/Game/Player.lua；单文件超过约 1000 行就拆。大文件先 Grep 定位再按行读，不要反复整读。
5. 首次交付多打 `print` 日志便于定位问题，稳定后清理。排查运行时问题先看日志、找到具体报错再改，不要凭猜测连续改：云端日志在 `/opt/log/dev/`（客户端脚本 `user_script.log`，服务端 `server_user_script.log`），真机玩家反馈用 `get_debug_feedbacks` 工具拉取；日志里没有线索就加 `print` 后复现。同一文件里内容完全相同的 `print` 每 90 秒只记前 10 次左右（之后出现 `Next log has been output too many times` 并丢弃），每帧或高频的日志要带帧号、数值等会变的内容。
6. 改完 Lua 若有 LSP 诊断工具（本地 `maker-lua-lsp` / 云端 `lua_lsp_client`），先确认无 Error 再构建。构建入口必须是定义了全局 `Start()` 的文件，通常是 `main.lua`（多人项目按模板由它分流到客户端/服务端）；`network/Client.lua`、`Standalone.lua` 这类被入口加载的模块不能当入口。

## 必知事实

### 项目与资源

- **多人还是单机**：看 `.project/settings.json` 的 `@runtime.multiplayer.enabled`。为 `true` 时代码写进 `scripts/` 下的 `network/Client.lua` 和 `network/Server.lua`，并且之后每个功能都按多人实现。首次搭联网结构，或新增、修改远程事件、复制节点、玩家会话时，先读 `engine-docs/recipes/network-game-guide.md`「快速开始」，其余按章节查；只改玩法数值、界面且沿用已有网络通路时不必重读。没开多人时，`scripts/` 下已有 `network/Standalone.lua` 就写在那里，否则按脚手架写 `main.lua`。
- **云变量存档**：`SetInt` / `Add` 只收整数（客户端传小数会被写成 0，服务端直接报错）；写入也传 `error` 回调；读档出错或超时时不要按新玩家覆盖存档。详见 `engine-docs/recipes/client-cloud-score.md`「可靠存档」。
- **资源路径从资源根写起**：`scripts/`、`assets/` 都是资源根。文件 assets/Textures/player.png 写作 `cache:GetResource("Texture2D", "Textures/player.png")`，不要带 `assets/` 前缀。
- **require**：库用 `require("urhox-libs/UI")`；自己的模块相对 `scripts/` 写。部分示例里的 `require "LuaScripts/Utilities/Sample"` 是旧示例框架，新代码不需要它（鼠标锁定用 `urhox-libs/Platform/MouseLockManager.lua`）。
- **单位与坐标**：长度单位是米（角色约 1.8 m）；Y 轴向上的左手坐标系（同 Unity）：+X 右、+Y 上、+Z 前。
- **分辨率**：`graphics:SetMode()` 已禁用，调用无效。屏幕尺寸用 `graphics:GetWidth()` / `graphics:GetHeight()`（物理像素），`graphics:GetDPR()` 取像素比。

### Lua 与引擎绑定

- **Lua 5.4**：没有 `+=`/`++`；用 `table.unpack`（没有全局 `unpack`），且它只有在表构造器最后一项才全部展开；数组下标从 1 开始；Unicode 转义写 `"\u{2605}"`，或直接写字符；`string.format("%d", x)` 的 `x` 必须是整数值，传 `3.5` 会运行时报错，先 `math.floor`。
- **事件**：`SubscribeToEvent("Update", "HandleUpdate")`，handler 签名 `(eventType, eventData)`。取参数必须调类型方法：`eventData["TimeStep"]:GetFloat()` 或 `eventData:GetFloat("TimeStep")`、`eventData["Key"]:GetInt()`；`eventData.Key` 或直接比较 `eventData["Key"]` 都是错的。各事件参数在 `.emmylua/Events.d.lua` 里 grep 事件名查（文件很大，不要整读）。全局 `SubscribeToEvent` 对同一事件只保留最后一次订阅的处理函数（后订阅的静默替换先订阅的，跨文件也一样）：多个模块要每帧更新时，由入口的一个 `Update` 处理函数依次调用各模块，或按 `engine-docs/lua-scripting-guide.md`「同一事件的全局订阅会互相覆盖」给模块单独的接收者。
- **用枚举常量，不写数字**：`KEY_SPACE`、`KEY_W`、`MOUSEB_LEFT`、`MM_RELATIVE`、`LIGHT_DIRECTIONAL`…。运行时的值不是从 0 开始的顺序编号（`MOUSEB_LEFT` 是位掩码 1，`KEY_SPACE` 是 32），`.emmylua/` 里也只声明名字、不写数值。常用枚举见 `engine-docs/api/enums.md`。
- **Vector2 / Vector3 是值类型**：`node.position.x = 1` 改的是副本、不生效，要取出、修改、整体写回。`v:Normalize()` 已废弃（会报 ERROR），用 `v = v:Normalized()`。
- **自己 `Scene()` 出来的场景必须一直有强引用**：全局变量、`self` 字段，或被全局 `Start()`、事件处理函数引用的模块级变量。只存在函数局部变量里，或在文件顶层创建、却没有任何存活的函数引用它，都会被 GC 回收，场景里的东西静默消失或随机崩溃。
- **`time.frameNumber` 是引擎启动以来的全局帧号**，`Start()` 时通常早已不是 0（加载资源也在走帧）；要判断「第 N 帧」，在 `Update` 里自己计数。
- **节点 ID 用 `node.ID` 或 `node:GetID()`**：属性名区分大小写，读 `node.id` 这类不存在的字段得到 nil、不报错（变量没标类型时 LSP 也查不出）。
- **隐藏一整棵节点树**用 `node:SetDeepEnabled(false)`；`SetEnabled(false)` 不会影响子节点。

### UI 与 2D 绘制

- **菜单、HUD、按钮、文字、列表、字幕一律用 `urhox-libs/UI`**（Yoga Flexbox 布局 + NanoVG 渲染，40+ 控件）。原生 UI（`ui.root`、`Text()`、`Button()`…）已废弃；也不要用 raw NanoVG 画 UI（会和 UI 层级冲突）。已有项目的界面本来就是 raw NanoVG 画的（脚本里有 `nvgBeginFrame`、没有 `require("urhox-libs/UI")`），就沿用它的绘制和坐标约定，不用读 `ui.md`，用户没要求就不迁移。

  ```lua
  local UI = require("urhox-libs/UI")

  function Start()
      UI.Init({
          theme = "default-dark",   -- 不传 theme 会用旧默认主题
          scale = UI.Scale.DEFAULT,
      })
      local label = UI.Label { id = "score", text = "Score: 0", fontSize = 18 }
      local root = UI.Panel {
          width = "100%", height = "100%", justifyContent = "center", alignItems = "center",
          children = { label, UI.Button { text = "Start", onClick = function(self) label:SetText("Go!") end } },
      }
      UI.SetRoot(root)
      -- 没有 local 引用时按 id 查找；加 @as 后 LSP 才会检查 SetText 等子类方法名
      local score = root:FindById("score") --[[@as Label]]
      score:SetText("Score: 1")
  end
  ```

  - 必须 `UI.Init(...)` 后 `UI.SetRoot(root)`，否则什么都不显示。
  - 之后要更新的控件，保留 local 引用直接调方法；或用 `FindById` 查找并按上例写 `--[[@as Label]]`（`Button`、`ProgressBar`…同理）。
  - Yoga 的 `flexShrink` 默认是 0（与 CSS 不同），子元素溢出容器时设 `flexShrink = 1`。
  - 游戏层自己处理点击/触摸（点屏幕跳跃等）时，`UI.FindWidgetAt(x / UI.GetScale(), y / UI.GetScale())` 不为 nil 就说明点在 UI 上、应跳过。写法见 `engine-docs/recipes/ui.md`「pointerEvents 与游戏输入协调」。
  - 有风格要求的 UI，先看是否有对应的 `ui-*` 风格 skill，不要自己编配色。
- **raw NanoVG 只用于自定义图形**（图表、特效、整个画面都由 NanoVG 绘制的 2D 游戏）：
  - 绘制代码必须写在 `NanoVGRender` 事件里：`vg = nvgCreate(1)`（类型 `NVGContextWrapper`，先声明为 nil 时标 `---@type NVGContextWrapper|nil`）后 `SubscribeToEvent(vg, "NanoVGRender", "HandleRender")`，handler 内 `nvgBeginFrame(vg, w, h, dpr)` … `nvgEndFrame(vg)`。在 `Update` 里画不会显示，也不报错。
  - 画文字前必须在初始化时用 `nvgCreateFont(vg, "sans", "Fonts/MiSans-Regular.ttf")` 建一次字体（每帧创建会泄漏），绘制时 `nvgFontFace(vg, "sans")`。
  - Lua 函数与 NanoVG C API 同名同参；分辨率/DPR 写法见 `nvg-resolution-mode` skill。

### 3D 场景

- **内置模型**（`Models/Box.mdl` 等）尺寸见 `engine-docs/recipes/built-in-models.md`，或用 `staticModel.boundingBox` 读取，不要猜（Box 是 1×1×1、中心在原点，放在地面上要 `y = 0.5`）。内置模型没有的形状用 `engine-docs/recipes/procedural-geometry.md`。
- **纯色/无贴图材质只用这三个 Technique**：`Techniques/PBR/PBRNoTexture.xml`（不透明）、`Techniques/PBR/PBRNoTextureAlpha.xml`（透明）、`Techniques/NoTextureUnlit.xml`（无光照）。其他材质见 `materials` skill；内置 Technique 做不到的效果写 SurfaceShader（`engine-docs/recipes/surface-shader.md`），不要手写 `.glsl` 或 Technique XML。
- **灯光、雾、天空、后效**先读 `engine-docs/recipes/rendering.md`（LightGroup 预设、Zone 优先级、亮度单位）。
- **相机**：FPS/TPS 用鼠标转视角要设 `input.mouseMode = MM_RELATIVE`。第三人称相机用 `urhox-libs/Camera/ThirdPersonCamera.lua`（用法见 `scaffold-3d-character.lua`），不要手算相机位置。正交相机的 `orthoSize` 是视野**全高**，屏幕坐标换算时乘 0.5。
- **3D 角色控制器**：节点上按顺序创建 `RigidBody` → `CollisionShape`（`SetCapsule`）→ `KinematicCharacterController` → `CharacterComponent`，用 `character.controls:Set(CTRL_FORWARD, true)` 等控制移动、`character.runSpeed` 设速度（米/秒）。缺 `CharacterComponent` 时节点不会动（KCC 本身不回写节点位置）。若直接调 `kcc:SetWalkDirection(v)`，`v` 是**每个物理步的位移**（速度 × 物理步长），传速度会一帧冲出很远、穿墙。完整写法见 `engine-docs/gotchas/physics.md` 与 `scaffold-3d-character.lua`。
- **动画状态机**（`.fsm` + BlendSpace）读 `engine-docs/recipes/state-machine.md`；`engine-docs/recipes/templates/fsm/` 下是带 `$PLACEHOLDER$` 的模板，要替换后才能用。`GetCurrentState(0)` 返回空串说明 `.fsm` 没加载成功（路径错、缺 `layers`/`defaultState`、节点上没有 `AnimatedModel`）。

### LSP 类型检查（报 Error 会阻塞构建）

- 先声明、稍后才赋值的变量，空表 `{}`，用变量下标取值的常量表，以及要做向量运算的函数参数，都要标类型，否则取出的值再访问字段/方法会报 undefined-field（直接用构造结果初始化如 `local scene = Scene()` 则无需标注）：

  ```lua
  ---@type Node
  local player_            -- 不写 `= nil`；写成 Node|nil 会在传给 Node 参数时报错
  ---@type { node: Node, spawnFrame: integer }[]
  local enemies_ = {}
  ---@type integer[][]
  local ROW_COLORS = { { 255, 80, 80 }, { 80, 200, 255 } }
  ---@param from Vector3   -- 不标的话 `to - from` 被当成 number，:Normalized() 报错
  ---@param to Vector3
  local function Dir(from, to) return (to - from):Normalized() end
  ```
- 列表（`ipairs`、`#`、`table.insert/remove`）标 `V[]`；只有稀疏的数字键映射才用 `table<number, V>`，不要写 `table<integer, V>`。
- 之后会存小数的数值用 `0.0` 初始化：`{ vx = 0 }` 会被推断成 integer，再赋小数就报错。
- OOP 类的字段在 `:init()` 之类的冒号方法里赋值，不要只在 `.new()` 静态工厂里赋值。
- 自己写的 `---@return` / `---@param` 要和实际值一致：`tonumber(s)` 可能是 nil，返回给 `number` 时写 `tonumber(s) or 0`；`os.time{...}` 的字段要是整数，小数先 `math.floor`。
- 详细原因与更多写法见 `engine-docs/lua-scripting-guide.md`。

## 文档路由

所有路径相对工作区根。找不到对应条目时看 `engine-docs/index.md`（完整目录）。

| 需求 / 症状 | 读这里 |
|---|---|
| Lua 绑定细节：eventData、SendEvent、NanoVG API、Vector 值语义、Scene 生命周期、LSP 误报；**运行/编译报错** | `engine-docs/lua-scripting-guide.md`（报错先看「常见错误信息速查」） |
| 类名清单 / 某个类有哪些方法 | `engine-docs/api/index.md` → `.emmylua/<类名>.d.lua` |
| 安装、更新或卸载依赖包 / 版本选择 / 依赖缺失或 LSP 未刷新 | [依赖包管理](engine-docs/recipes/package-management.md) |
| urhox-libs 有哪些现成模块（平台、输入、相机、特效、几何…） | 已安装依赖时，优先阅读 `.cache/packages/urhox-libs/current/urhox-libs/README.md`，否则读 `urhox-libs/README.md` |
| 游戏 UI：HUD、菜单、按钮、列表、弹窗、布局、滚动、Spine 动画、SVG（预览版） | `engine-docs/recipes/ui.md`（控件属性查 `recipes/ui-widgets.md`） |
| 屏幕适配、DPR、设计分辨率 | raw NanoVG：`nvg-resolution-mode` skill；`urhox-libs/UI`：`engine-docs/recipes/ui.md` |
| 自定义 2D 绘制（NanoVG） | `engine-docs/api/nanovg.md`（与 C API 的差异）、`examples/01-nanovg-standalone.lua` |
| NanoVG 发光/Bloom | `engine-docs/recipes/nanovg_bloom_glow_guide.md` |
| 在 UI / NanoVG 中显示 3D 场景预览或运行时生成的纹理（`nvgCreateVideo`） | `engine-docs/recipes/scene-to-nanovg.md` |
| 键盘、鼠标、触屏、虚拟摇杆、手柄、滚轮 | `engine-docs/recipes/input-controls.md`、`engine-docs/api/input.md` |
| 内置模型尺寸 / 程序化几何体（球、柱、环、挤出、凸包…） | `engine-docs/recipes/built-in-models.md`、`engine-docs/recipes/procedural-geometry.md` |
| 材质、贴图、Technique | `materials` skill |
| 自定义 shader 效果（溶解、流光、UV 动画、顶点形变、卡通、描边、自定义光照） | `engine-docs/recipes/surface-shader.md` |
| GPU 计算 / compute shader | `engine-docs/recipes/surface-shader-addons/compute.md` |
| 灯光、雾、天空盒、后效开关 | `engine-docs/recipes/rendering.md` |
| 程序化天空、昼夜、环境光跟随天空、物理大气上自写星空/月面/薄云 | `engine-docs/recipes/sky-and-environment-lighting.md` |
| 体积云、云层、自定义云材质（`shader_type cloud`） | `engine-docs/recipes/surface-shader-addons/cloud.md` |
| 阴影、灯光数量上限、面光 | `engine-docs/recipes/lights-and-shadows.md` |
| 延迟渲染、SSR、SSGI、GTAO、TAA | `engine-docs/recipes/deferred-rendering.md` |
| 体积雾、体积光、光柱 | `engine-docs/recipes/volumetric-fog.md` |
| 草地、风吹草动、踩踏草丛 | `engine-docs/recipes/grass.md` |
| 泛光、色调映射、曝光、景深、运动模糊 | `engine-docs/recipes/post-processing.md` |
| 昼夜循环 + 天气 + 水面的完整方案 | `engine-docs/recipes/deferred-scene-weather-lighting.md` |
| 相机：第三人称、俯视、正交缩放 | `engine-docs/recipes/camera.md`、`engine-docs/gotchas/camera.md` |
| 3D 物理、碰撞事件、角色控制器 | `engine-docs/gotchas/physics.md`、`engine-docs/api/physics.md`、`examples/18-physics-collision-3d.lua` |
| 2D 物理（Box2D）、平台跳跃、地面检测 | `engine-docs/api/physics-2d.md`、`examples/04-box2d-platformer.lua` |
| 体素破坏、挖掘、体素载具 | `engine-docs/recipes/voxel-physics.md`（多人：`engine-docs/recipes/voxel-networking.md`） |
| 动画状态机、BlendSpace、AimOffset、骨骼挂点 | `engine-docs/recipes/state-machine.md`、`setup-fsm` skill |
| 次级骨骼运动（弹性骨骼、骨骼物理）：头发、尾巴、裙摆 | `engine-docs/recipes/kawaii-physics.md` |
| 音效、背景音乐 | `engine-docs/api/audio.md` |
| 视频播放（UI / 3D 屏幕） | `engine-docs/recipes/video.md`、`engine-docs/recipes/video-screen-3d.md` |
| 联网多人：权威服务器、场景复制、远程事件、断线重连 | `engine-docs/recipes/network-game-guide.md` |
| 自定义大厅 / 匹配 | `engine-docs/recipes/custom-lobby.md` |
| 云变量、排行榜 | 客户端 `engine-docs/recipes/client-cloud-score.md`，服务端 `engine-docs/recipes/server-cloud-score.md` |
| 聊天、昵称等玩家输入的文本审核 | `engine-docs/recipes/text-moderation.md` |
| 场景云存档 | `engine-docs/recipes/scene-cloud-save.md` |
| 本地存档、文件读写（`io` 库已移除） | `engine-docs/recipes/file-storage.md` |
| JSON、HTTP 请求、服务器时间 | `engine-docs/recipes/json.md`、`engine-docs/recipes/http.md`、`engine-docs/recipes/server-time.md` |
| 广告、成就、内购、平台 SDK | `engine-docs/recipes/sdk.md`，以及 `setup-ads` / `setup-achievements` skill |
| 多语言 | 文本 `engine-docs/recipes/i18n-translation.md`，图片/音频等资源 `engine-docs/recipes/i18n-resource.md` |
| 包体大、资源下载慢、边玩边下、构建资产忽略（按目录追加规则，不逐文件加） | `engine-docs/recipes/preload-and-build-refs.md`、`engine-docs/recipes/download-while-playing.md` |
| 用引擎离线跑 Lua 做程序化生成 / 烘焙 | `engine-docs/recipes/procedural-lua-headless.md` |

## 示例

<!-- BEGIN AUTO-GENERATED EXAMPLES -->
- [NanoVG独立绘图](examples/01-nanovg-standalone.lua)：使用NanoVG原生API绘制矢量图形
- [NanoVG UI组件](examples/02-nanovg-ui-component.lua)：将NanoVG渲染到纹理作为UI组件使用
- [Flappy Bird 游戏](examples/03-flappy-bird-game.lua)：使用NanoVG实现完整的Flappy Bird游戏
- [Box2D 平台跳跃最佳实践](examples/04-box2d-platformer.lua)：展示如何正确使用 Box2D 物理系统实现 2D 平台跳跃游戏，避免常见碰撞检测 BUG
- [超级马里奥兄弟完整实现](examples/05-super-mario-game.lua)：使用 NanoVG 和瓦片地图碰撞实现的完整超级马里奥游戏
- [我的世界体素世界（模块化架构）](examples/07-minecraft-voxel-world)：使用多文件模块化架构实现的 Minecraft 风格体素世界，展示大型项目的最佳实践
- [VoxelTown 可破坏小镇脚手架](examples/27-voxel-town)：官方体素物理脚手架：可破坏小镇沙盒，含载具、水面浮力、玩法工具与昼夜光组，可直接复制为新体素项目起点
- [SurfaceShader 灯光开关](examples/25-surface-custom-light-scene)：演示 SurfaceShader 自定义 light()，并用 urhox-libs/UI 切换三类光源。
- [自定义水体（三帧 FFT）](examples/31-custom-water)：自定义 GPU 波浪接入：Lua 调度三帧 FFT，材质提供位移、运动矢量、相机入水查询和水线；逐像素波面法线、程序细波纹与破碎泡沫。
- [引擎水域：浮力与游泳](examples/32-engine-water)：一个水域节点加引擎波浪，同时驱动水面材质、体素浮力、角色游泳、水面查询和水下效果；面板切换物理大气/程序天空、体积云、FFT 海面与 Gerstner 湖面，并实时调水体参数。
- [鹈鹕骑单车（延迟渲染 + 昼夜 + 晴雨 + 体积光 + FFT 海面）](examples/30-pelican-bike)：延迟渲染效果拉满的综合场景：昼夜循环、晴雨天气、闪电、体积光与光柱、GPU FFT 海面，环境光由 SkyLightCapture 从自写天空实时捕获。
- [程序化天空 + 环境光跟随](examples/29-procedural-sky)：ProceduralSky 画带太阳的昼夜天空，SkyLightCapture 让场景环境光（漫反射 + 反射）自动跟随天空变化。
- [云变量积分与排行榜 API](examples/11-client-cloud-score-leaderboard-api.lua)：clientCloud API 完整用法示例，展示云变量存储和排行榜功能
- [NanoVG Bloom发光特效](examples/10-nanovg-bloom.lua)：使用NanoVG渐变模拟HDR Bloom/Glow发光效果
- [UI 组件库展示](examples/14-ui-widgets-gallery.lua)：展示 UrhoX UI 库全部 41 个组件的综合画廊
- [Yoga Flexbox 布局 + NanoVG 渲染](examples/13-yoga-layout-nanovg-render.lua)：使用 Yoga 实现 Flexbox 布局，NanoVG 渲染 UI，支持 Hover 和点击交互
- [RPG 背包装备系统](examples/15-inventory-drag-drop.lua)：展示 RPG 游戏中完整的背包和装备系统，支持拖拽操作
- [万级数据虚拟列表](examples/16-virtual-list-10k-items.lua)：展示 VirtualList 组件渲染 10000 个物品，使用对象池和视图回收
- [MMO 聊天窗口富文本](examples/17-chat-window-rich-text.lua)：展示 MMO 风格的聊天窗口，支持自定义标签和图文混排
- [3D 物理碰撞最佳实践](examples/18-physics-collision-3d.lua)：展示如何正确使用 3D 物理碰撞事件，包括地面检测、触发器、收集物品和伤害区域
- [WASM 视频播放器](examples/19-video-player-ui.lua)：展示 WASM 平台视频播放功能，支持 UI 叠加在视频上方
- [NanoVG 视频播放器](examples/20-video-player-nanovg.lua)：使用 VideoPlayer + NanoVG 直接渲染视频，不依赖 UI 库
- [3D 视频屏幕（IMAX）](examples/21-video-screen-3d.lua)：在 3D 场景中创建 IMAX 风格视频屏幕，使用 VideoScreen3D 高层组件
- [第三人称射击游戏（模块化架构）](examples/22-third-person-shooter)：使用多文件模块化架构实现的第三人称射击游戏，展示动画状态机、角色控制器、多人网络架构
- [服务端云变量 API 示例](examples/23-server-cloud-score-leaderboard-api)：serverCloud API 自测（G1–G10：Score CRUD、批量、GetUserRank/GetRankTotal、事务、Money/List/Message/Quota），不是排行榜示例（未调用 GetRankList，榜单只排在线玩家）；main.lua 按模式加载 network/Server.lua（启动即跑自测）/ network/Client.lua（展示结果）。写云排行榜看 engine-docs/recipes/server-cloud-score.md「排行榜 + 昵称」
- [运行时模型绘制](examples/24-model-painter.lua)：使用 Paint 库在带 UV1 的模型上实时绘制颜色、金属度和粗糙度，支持笔刷、屏幕取色和多目标切换
- [断线重连骨架](examples/28-session-reconnect-skeleton)：用 urhox-libs/Network/PlayerSessions 管理玩家会话：按认证 user_id 单表、掉线暂存、重连（含顶号）重绑并重推权威快照。
- [嗒啦啦角色展示（卡渲、形态键、弹性骨骼）](examples/33-tarara-character-studio)：嗒啦啦同时展示内置 Toon 卡渲、15 个形态键与头发/完整裙摆骨链物理；默认待机、自动眨眼与物理全开，可切镜头和四段动画、42 秒自动演播。源资产缺少胸部及眼球独立绑定。
<!-- END AUTO-GENERATED EXAMPLES -->
