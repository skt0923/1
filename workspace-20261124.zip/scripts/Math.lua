-- 纯数学工具，无玩法数值（e8）。
local M = {}

---@param v number
---@param lo number
---@param hi number
---@return number
function M.clamp(v, lo, hi)
    return math.min(hi, math.max(lo, v))
end

---@param a number
---@param b number
---@param t number
---@return number
function M.lerp(a, b, t)
    return a + (b - a) * t
end

---@param v number
---@return number
function M.clamp01(v)
    return math.min(1, math.max(0, v))
end

---@param edge0 number
---@param edge1 number
---@param v number
---@return number
function M.smoothstep(edge0, edge1, v)
    local t = M.clamp01((v - edge0) / (edge1 - edge0))
    return t * t * (3 - 2 * t)
end

---@param current number
---@param target number
---@param rate number
---@param dt number
---@return number
function M.damp(current, target, rate, dt)
    return target + (current - target) * math.exp(-rate * dt)
end

--- Wrap an angle in degrees to [-180, 180).
---@param degrees number
---@return number
function M.WrapAngle(degrees)
    return (degrees + 180) % 360 - 180
end

return M
