-- Unified error outlet. Every Error-level report goes through here so the
-- log channel and the on-screen channel can never diverge.
local UI = require("urhox-libs/UI")

local ErrorNotify = {}

local TOAST_WIDTH = 320
local TOAST_TOP = 72
local TOAST_READ_MS = 1000
local THROTTLE_MS = 30000
local MAX_RECENT = 64

---@type table<string, { count: integer, lastMs: number, firstMs: number }>
local throttles = {}

---@type { text: string, shownMs: number, expireMs: number }|nil
local current = nil

---@type string[]
local recent = {}

---@type any
local toast = nil

---@type any
local canvasRoot = nil

---@param ms number
---@return boolean
local function isUiReady(ms)
    if UI.GetRoot() ~= nil then return true end
    return ms >= TOAST_READ_MS * 10
end

---Send an Error-level report through both channels.
---@param tag string Module tag such as "M1" or "RIG".
---@param op string Operation name.
---@param detail string Error text, including location and err.
---@param throttleKey? string Key shared by repeated errors; defaults to tag.."/"..op.
function ErrorNotify.Error(tag, op, detail, throttleKey)
    assert(type(tag) == "string" and tag ~= "", "ErrorNotify.Error requires a tag")
    assert(type(op) == "string" and op ~= "", "ErrorNotify.Error requires an op")
    assert(type(detail) == "string" and detail ~= "", "ErrorNotify.Error requires a detail")

    local key = throttleKey or (tag .. "/" .. op)
    local ms = time.elapsedTime * 1000
    local entry = throttles[key]

    print(string.format("[%s][ERROR] -> FAIL | %s detail=%s", tag, op, detail))

    table.insert(recent, 1, string.format("[%s][ERROR] %s: %s", tag, op, detail))
    if #recent > MAX_RECENT then table.remove(recent) end

    if entry == nil then
        throttles[key] = { count = 1, lastMs = ms, firstMs = ms }
    else
        entry.count = entry.count + 1
        if ms - entry.lastMs < THROTTLE_MS then
            print(string.format("[%s][ERROR] -> NONE | %s suppressed count=%d waitMs=%.0f",
                tag, op, entry.count, THROTTLE_MS - (ms - entry.lastMs)))
            return
        end
        entry.lastMs = ms
    end

    local total = throttles[key].count
    local text = detail
    if total > 1 then
        text = string.format("%s (x%d)", detail, total)
    end
    ErrorNotify.Show(text, tag)
end

---Push a message onto the on-screen channel.
---@param text string
---@param tag string
function ErrorNotify.Show(text, tag)
    local ms = time.elapsedTime * 1000
    local expireMs = ms + TOAST_READ_MS

    if not isUiReady(ms) then
        if canvasRoot == nil then
            -- Fallback 2: paint straight through NanoVG when the UI tree is missing.
            print(string.format("[%s][ERROR] -> NONE | ui-root-missing fallback=none, log kept", tag))
            current = { text = text, shownMs = ms, expireMs = expireMs }
            return
        end
    end

    if UI.GetRoot() ~= nil then
        if toast == nil then
            toast = UI.Panel {
                position = "absolute",
                top = TOAST_TOP,
                left = "50%",
                width = TOAST_WIDTH,
                paddingHorizontal = 12,
                paddingVertical = 10,
                backgroundColor = "#C03030",
                borderRadius = 6,
                pointerEvents = "none",
                children = {
                    UI.Label { id = "error-text", text = text, fontSize = 13, color = "#FFFFFF", flexShrink = 1 },
                },
            }
            canvasRoot = UI.Panel {
                width = "100%",
                height = "100%",
                pointerEvents = "box-none",
                children = { toast },
            }
        end
        local label = toast:FindById("error-text")
        if label ~= nil then label:SetText(text) end
        toast:SetVisible(true)
        UI.SetRoot(canvasRoot, true)
        print(string.format("[%s][ERROR] -> OK | channel=ui text=%s", tag, text))
    else
        print(string.format("[%s][ERROR] -> NONE | channel=ui fallback=none text=%s", tag, text))
    end

    current = { text = text, shownMs = ms, expireMs = expireMs }
end

---Clear the throttle counter for one key after the problem is fixed.
---@param throttleKey string
function ErrorNotify.ResetErrorThrottle(throttleKey)
    assert(type(throttleKey) == "string" and throttleKey ~= "", "ResetErrorThrottle requires a key")
    throttles[throttleKey] = nil
    print(string.format("[ERROR][NOTIFY] -> OK | event=reset key=%s", throttleKey))
end

---Drop the toast once its read window elapsed. Called every frame by the router.
---@param ms number
function ErrorNotify.Update(ms)
    if current ~= nil and ms >= current.expireMs then
        if toast ~= nil then toast:SetVisible(false) end
        print(string.format("[ERROR][NOTIFY] -> OK | event=hide text=%s", current.text))
        current = nil
    end
end

---@return table<string, integer>
function ErrorNotify.GetCounters()
    local out = {}
    for k, v in pairs(throttles) do
        out[k] = math.floor(v.count)
    end
    return out
end

return ErrorNotify
