-- Entry: wiring only. 玩法清单在 AllModes.lua；本文件只做装配与事件转发。
local Router = require("Router")
local ErrorNotify = require("ErrorNotify")
local Math = require("Math")
local Character = require("Tarara")
local SelfTest = require("SelfTest")
local ScreenOrientation = require("ScreenOrientation")
local ModeMenu = require("ModeMenu")
local Studio = require("Showcase.Studio")
local Interface = require("Showcase.Interface")
local Presentation = require("Showcase.Presentation")
local AllModes = require("AllModes")

local TAG = "[BOOT]"
-- 启动目标：固定直接进入玩法一，与菜单顺序解耦。
local BOOT_PAGE_PATH = "modes.M1_Port.Mode"

-- kit 装配：页面类积木的纯函数注入（必须在全部 require 之后、任何 Create 之前）
Studio.SetMath(Math)
Presentation.SetMath(Math)
require("Showcase.Mode").SetMath(Math)

-- 1. 加载清单里的全部模块，收集 id 与显示名
---@class LoadedMode
---@field entry AllModeEntry
---@field module table

---@type LoadedMode[]
local loaded = {}
---@type table<string, table>
local byPath = {}
for _, entry in ipairs(AllModes) do
    local module = require(entry.path)
    assert(type(module) == "table" and module.id ~= nil and module.Create ~= nil,
        "AllModes: 模块未导出 id/Create -> " .. entry.path)
    byPath[entry.path] = module
    loaded[#loaded + 1] = {entry = entry, module = module}
end
print(string.format("%s[MODES] -> OK | total=%d", TAG, #loaded))

-- 2. 菜单项：顺序与 AllModes 一致，跳过 hidden
---@type ModeMenuOption[]
local menuOptions = {}
for _, item in ipairs(loaded) do
    if not item.entry.hidden then
        menuOptions[#menuOptions + 1] = {id = item.module.id, name = item.entry.name}
    end
end

-- 3. 页面类需要的 deps（只给 kind = "page" 的模块）
local pageDeps = {
    Character = Character, Studio = Studio, Interface = Interface,
    Presentation = Presentation, SelfTest = SelfTest,
    ScreenOrientation = ScreenOrientation, ModeMenu = ModeMenu,
    Router = Router,
}

function Start()
    for _, item in ipairs(loaded) do
        local module = item.module
        local entry = item.entry
        Router.Register(module.id, function()
            if entry.kind == "page" then
                return module.Create({
                    id = module.id,
                    menuOptions = menuOptions,
                    deps = pageDeps,
                })
            end
            return module.Create({id = module.id, menuOptions = menuOptions})
        end)
    end

    -- 首跳：固定进展示页作为门户（第 22 节；菜单顺序已把港区放最前，不随首项变化）
    local first = byPath[BOOT_PAGE_PATH]
    assert(first ~= nil, "AllModes 缺少启动页 -> " .. BOOT_PAGE_PATH)
    Router.Enter(first.id)
    print(string.format("%s[ENTER] -> OK | id=%s path=%s", TAG, first.id, BOOT_PAGE_PATH))

    SubscribeToEvent("Update", "HandleUpdate")
    SubscribeToEvent("PostUpdate", "HandlePostUpdate")
    SubscribeToEvent("PostRenderUpdate", "HandlePostRender")
    print(string.format("[ERROR][NOTIFY] -> OK | event=ready module=ErrorNotify"))
    print(string.format("%s[MEM] -> OK | t=%.0fs lua=%.0fKB res=%.0fKB", TAG,
        time.elapsedTime, collectgarbage("count"), cache:GetTotalMemoryUse() / 1024))
end

function HandleUpdate(_eventType, eventData)
    Router.Update(eventData)
    ErrorNotify.Update(time.elapsedTime * 1000)
end

function HandlePostUpdate()
    Router.PostUpdate()
end

function HandlePostRender()
    Router.PostRender()
end

function Stop()
    Router.Stop()
end
