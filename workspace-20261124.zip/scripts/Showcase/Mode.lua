-- Showcase/Mode.lua: 嗒啦啦角色展示模式入口，门户开场展示。
---@type table Math 由 kit 通过 SetMath 注入（第 13 节：积木间禁止直接 require）；
-- 未注入时为空表，调用具体函数会立刻报错，不会静默通过。
local Math = {}
local UI = require("urhox-libs/UI")
-- 由 Create 的 deps 注入（第 13 节：积木间禁止直接 require）
---@type table
local Character
---@type table
local Studio
---@type table
local Interface
---@type table
local Presentation
---@type table
local SelfTest
---@type table
local ScreenOrientation

-- Degrees per second for automatic rotation.
local AUTO_ROTATE_SPEED = 20
-- Starting character heading in degrees: a slight turn towards the character's right hand.
local START_HEADING = 6

---@class TararaApp : ModeInstance
---@field name string
---@field desc string
---@field scene Scene
---@field hero TararaActor
---@field studio TararaStage
---@field interface TararaInterface
---@field demo TararaPresentation
---@field paused boolean
---@field heading number Character heading in degrees, [-180, 180).
---@field tilt number Sideways lean in degrees; only the presentation sets a non-zero value.
---@field autoRotate boolean
---@field bones boolean Draw the simulated chains.
---@field outline number Outline width in metres.
---@field visible boolean Interface visibility.
---@field id string Router id, handed in by main.lua.
---@field menuOptions ModeMenuOption[] Menu entries injected by main.lua; pages never require each other.
---@field prevHdr boolean|nil Render state captured before entering, restored on Stop.
---@field prevMaxFps integer|nil
---@field prevMouseVisible boolean|nil
---@field updates integer Frames advanced since this instance started; used by the freeze-frame capture.
---@field depsModeMenu table ModeMenu injected by kit.
---@field depsRouter table Router injected by kit.
---@field depsCharacter table Tarara injected by kit.
---@field depsStudio table Studio injected by kit.
local Showcase = {}
Showcase.__index = Showcase

Showcase.id = "Showcase"
Showcase.name = "角色展示"
Showcase.desc = "嗒啦啦角色展示与自动演出"

---@class ShowcaseConfig
---@field id string
---@field menuOptions ModeMenuOption[] Menu entries injected by main.lua.
---@field deps table 依赖表（Character/Studio/Interface/Presentation/SelfTest/ScreenOrientation/ModeMenu/Router），由 kit 注入。

--- Create an inactive showcase; Start builds the scene.
---@param config ShowcaseConfig
---@return TararaApp
function Showcase.Create(config)
    assert(config.menuOptions ~= nil, "Showcase.Create requires menuOptions from main.lua")
    assert(config ~= nil and config.id ~= nil, "Showcase.Create requires an id")
    assert(config.deps ~= nil, "Showcase.Create requires deps from kit")
    local deps = config.deps
    assert(deps.Character and deps.Studio and deps.Interface and deps.Presentation
        and deps.SelfTest and deps.ScreenOrientation and deps.ModeMenu and deps.Router,
        "Showcase.Create requires deps.Character/Studio/Interface/Presentation/SelfTest/ScreenOrientation/ModeMenu/Router")
    Character, Studio, Interface, Presentation, SelfTest, ScreenOrientation =
        deps.Character, deps.Studio, deps.Interface, deps.Presentation, deps.SelfTest, deps.ScreenOrientation
    return setmetatable({id = config.id, menuOptions = config.menuOptions, paused = false, heading = START_HEADING,
        tilt = 0, autoRotate = false, bones = false, outline = Character.OUTLINE_THICKNESS, visible = true,
        prevHdr = nil, prevMaxFps = nil, prevMouseVisible = nil, updates = 0,
        depsModeMenu = deps.ModeMenu, depsRouter = deps.Router,
        depsCharacter = deps.Character, depsStudio = deps.Studio}, Showcase)
end

---@class TararaLaunchOptions
---@field framing string
---@field character string "prefab" loads the serialized character; "lua" builds it in code.
---@field animation string
---@field expression? string
---@field demo boolean
---@field freezeFrame? integer Freeze the scene after this many updates, for screenshots.
local options = {framing = "full", character = "prefab", animation = "Idle", demo = false}

--- Read -studio-* command-line options; unknown values are reported and ignored.
---@param app TararaApp
local function ParseArguments(app)
    local function accept(kind, value, isValid)
        if isValid then return value end
        log:Write(LOG_WARNING, "Ignoring unknown " .. kind .. ": " .. value)
        return nil
    end
    for _, arg in ipairs(GetArguments()) do
        local key, value = arg:match("^%-studio%-([%a]+)=(.+)$")
        value = value or ""
        if key == "framing" then
            options.framing = accept("framing", value, value == "full" or value == "face") or options.framing
        elseif key == "character" then
            options.character = accept("character", value, value == "prefab" or value == "lua") or options.character
        elseif key == "animation" then
            options.animation = accept("animation", value, Character.FindClip(value) ~= nil) or options.animation
        elseif key == "expression" then
            options.expression = accept("expression", value, Character.FindExpression(value) ~= nil)
        elseif key == "yaw" then
            app.heading = Math.WrapAngle(tonumber(value) or 0)
        elseif key == "freeze" then
            options.freezeFrame = math.tointeger(tonumber(value))
        elseif arg == "-studio-rotate" then
            app.autoRotate = true
        elseif arg == "-studio-demo" then
            options.demo = true
        elseif arg == "-studio-bones" then
            app.bones = true
        end
    end
end

-- Height in metres of the point the presentation leans the character about.
local LEAN_PIVOT_HEIGHT = 1.4

--- Turn Tarara while keeping particle history, so dragging exercises inertia.
---@param degrees number Any angle; stored wrapped to [-180, 180).
---@param tilt? number Sideways lean in degrees; omitted means upright.
function Showcase:SetHeading(degrees, tilt)
    self.heading, self.tilt = Math.WrapAngle(degrees), tilt or 0
    local rotation = Quaternion(self.heading, Vector3.UP) * Quaternion(self.tilt, Vector3.FORWARD)
    -- Lean about the chest so a close-up keeps the face in frame.
    local pivot = Vector3(0, LEAN_PIVOT_HEIGHT, 0)
    self.hero.node.rotation = rotation
    self.hero.node.position = pivot - rotation * pivot
end

--- Reset the camera and simulation; heading, expression, clip and physics strength are kept.
function Showcase:ResetView()
    self.studio:SetFraming(self.studio.framing)
    self.hero:Reset()
end

--- Freeze or resume animation, morph easing, actor rotation and secondary motion together.
---@param value boolean
function Showcase:SetPaused(value)
    self.paused = value
    self.scene:SetTimeScale(value and 0 or 1)
    self.hero:SetPaused(value)
end

--- Set Tarara's outline width.
---@param value number Metres.
function Showcase:SetOutline(value)
    self.outline = value
    self.hero.model:SetOutlineThickness(value)
end

--- Start the presentation from its first stage, or return control without changing the scene.
---@param enabled boolean
function Showcase:SetDemo(enabled)
    if enabled then self.demo:Start() else self.demo:Stop() end
end

--- Build the showcase scene and its controls.
function Showcase:Start()
    ScreenOrientation.Apply("landscape")
    local app = self
    ParseArguments(app)
    app.prevHdr = renderer:GetHDRRendering()
    app.prevMaxFps = engine:GetMaxFps()
    app.prevMouseVisible = input.mouseVisible
    graphics.windowTitle = "嗒啦啦 · Tarara Character Studio"
    engine:SetMaxFps(60)
    renderer:SetHDRRendering(true)
    input.mouseVisible = true
    app.scene = Scene()
    app.studio = Studio.Create(app.scene)
    -- Both entry points produce the same character; the prefab is the serialized Character.Build.
    if options.character == "lua" then
        app.hero = Character.Create(app.scene, "Tarara")
    else
        app.hero = Character.Load(app.scene, "Tarara")
    end
    app:SetHeading(app.heading)
    if options.expression then app.hero:SetExpression(options.expression) end
    app.hero:Play(options.animation)
    app.studio:SetFraming(options.framing)
    app.studio:SetRim(app.hero.rim)
    app.demo = Presentation.Create(app, {Character = app.depsCharacter})
    app.interface = Interface.Create(app, {
        ModeMenu = app.depsModeMenu, Router = app.depsRouter,
        Character = app.depsCharacter, Studio = app.depsStudio})
    if options.demo then app:SetDemo(true) end
    print("TARARA_STUDIO_READY: character=" .. options.character .. " morphs=" .. app.hero.model.model.numMorphs
        .. " bones=" .. app.hero.model.skeleton.numBones)
    -- 玩法选择并入 Interface 右上角的共享设置菜单，不再另建全屏大厅
    print(string.format("[M1][MODE] -> OK | event=start character=%s menu=shared", options.character))
end

--- Handle the keyboard shortcuts.
function Showcase:HandleKeys()
    local app = self
    if input:GetKeyPress(KEY_SPACE) then app:SetPaused(not app.paused) end
    if input:GetKeyPress(KEY_R) then app.demo:Stop(); app:ResetView() end
    if input:GetKeyPress(KEY_H) then app.visible = not app.visible; app.interface:SetVisible(app.visible) end
    -- The wheel zooms only over the scene, not over a scrolling panel.
    if input.mouseMoveWheel ~= 0 then
        local hovered = UI.GetHoveredWidgetForPointer(0)
        if hovered == app.interface.dragPane or not hovered then app.demo:Stop(); app.studio:Zoom(input.mouseMoveWheel) end
    end
end

--- Advance the showcase by one frame.
---@param dt number Clamped frame time in seconds.
function Showcase:Update(dt)
    local app = self
    local frozen = options.freezeFrame ~= nil and app.updates >= options.freezeFrame
    if not frozen then
        app.updates = app.updates + 1
        app.demo:Update(dt)
        if app.autoRotate and not app.paused then app:SetHeading(app.heading + dt * AUTO_ROTATE_SPEED) end
        app.hero:Update(dt, app.studio.cameraNode.worldPosition)
    end
    app.studio:Update(dt)
    app.studio:SetContactPoints(app.hero:GetContactPoints())
    self:HandleKeys()
    app.interface:Update()
    SelfTest.Tick(self.id, dt)
end

--- Draw optional debug bones after the frame is rendered.
function Showcase:PostRender()
    local app = self
    if app.bones then app.hero:DrawBones(app.studio.debug) end
    if options.freezeFrame and app.updates == options.freezeFrame then
        app.scene:SetTimeScale(0)
        app.updates = app.updates + 1
        print("TARARA_STUDIO_CAPTURE: " .. app.studio.framing)
    end
end

--- Release the shared UI and drop the scene reference.
function Showcase:Stop()
    print("[LOBBY][MODE] -> OK | event=stop")
    renderer:SetHDRRendering(self.prevHdr == true)
    engine:SetMaxFps(self.prevMaxFps or 0)
    input.mouseVisible = self.prevMouseVisible == true
    local hdr = renderer:GetHDRRendering()
    local expectHdr = self.prevHdr == true
    local maxFps = engine:GetMaxFps()
    local expectFps = self.prevMaxFps or 0
    local restored = hdr == expectHdr and maxFps == expectFps
    local detail = string.format("hdr=%s expectHdr=%s maxFps=%.0f expectFps=%.0f",
        tostring(hdr), tostring(expectHdr), maxFps, expectFps)
    if restored then
        print("[LOBBY][RESTORE] -> OK | " .. detail)
    else
        print("[LOBBY][RESTORE] -> FAIL | " .. detail)
    end
    local interface = self.interface
    if interface ~= nil then interface:DestroyMenu() end
    Interface.Shutdown()
end

function Showcase:Dispose()
    self.scene = nil
end

--- 注入纯数学工具（kit 启动时调用；第 13 节禁止积木间直接 require）
---@param mathLib table Math 模块（clamp/lerp/WrapAngle/damp…）
function Showcase.SetMath(mathLib)
-- 注入参数可能为 nil（未注入时），assert 是防御性检查而非冗余
---@diagnostic disable-next-line: unnecessary-assert
    Math = assert(mathLib, "Showcase.SetMath requires Math from kit")
end

return Showcase
