-- 运行期横竖屏：进入玩法时按玩法声明的方向切屏，离开时恢复基准。桌面与 WASM 不支持，走能力探测降级。
local TAG = "[ORIENT]"

local ScreenOrientation = {}

---@type string|nil
local current = nil
---@type boolean|nil
local available = nil

---@return boolean
function ScreenOrientation.Available()
    if available == nil then
        available = type(common) == "table" and type(common.setDeviceOrientation) == "function"
        print(string.format("%s[PROBE] -> %s | api=setDeviceOrientation", TAG, available and "OK" or "NONE"))
    end
    return available
end

---@param value string "portrait" or "landscape"
---@return boolean applied
function ScreenOrientation.Apply(value)
    assert(value == "portrait" or value == "landscape", TAG .. "[APPLY] -> FAIL | reason=value " .. tostring(value))
    if current == value then
        print(string.format("%s[APPLY] -> OK | value=%s cached=true", TAG, value))
        return true
    end
    if not ScreenOrientation.Available() then
        print(string.format("%s[APPLY] -> NONE | value=%s reason=unsupported", TAG, value))
        return false
    end
    local ok, err = pcall(function()
        common.setDeviceOrientation({
            value = value,
            onSuccess = function()
                print(string.format("%s[APPLY] -> OK | value=%s accepted=true", TAG, value))
            end,
            onError = function(response)
                local message = "unknown"
                if response ~= nil and response.errMsg ~= nil then
                    message = response.errMsg
                end
                print(string.format("%s[APPLY] -> FAIL | value=%s err=%s", TAG, value, message))
            end,
        })
    end)
    if not ok then
        print(string.format("%s[APPLY] -> FAIL | value=%s err=%s", TAG, value, tostring(err)))
        return false
    end
    current = value
    print(string.format("%s[REQUEST] -> OK | value=%s", TAG, value))
    return true
end

---@return string|nil 上一次成功请求的方向
function ScreenOrientation.Current()
    return current
end

return ScreenOrientation
