-- Reusable one-button verification harness.
-- Master switch in `config.enabled`, per-check switches through SetCheckEnabled.
-- Generic checks only talk to modes through probes, so another game reuses this file unchanged.

local SelfTest = {}

local DEFAULT_TIMEOUT = 8.0

---@class SelfTestProbe
---@field jump? fun()
---@field jumpRelease? fun()
---@field isGrounded? fun(): boolean
---@field look? fun()
---@field yaw? fun(): number
---@field emptyDrag? fun(): boolean

---@class SelfTestCheck
---@field id string
---@field title string
---@field group? string
---@field enabled? boolean
---@field timeout? number
---@field available? fun(): boolean
---@field enter? fun(state: table)
---@field tick fun(state: table, modeId: string, dt: number, elapsed: number): string
---@field detail? fun(state: table): string

---@type { enabled: boolean, roundTrip: { from: string, via: string, dwell: number, settle: number }|nil, inputMode: string|nil, frameCap: number }
local config = {
    enabled = true,
    roundTrip = nil,
    inputMode = nil,
    frameCap = 0,
}

---@type (fun(summary: { pass: integer, fail: integer, skip: integer, fps: number })|nil)
local presenter

---@type table<string, SelfTestProbe>
local probes = {}
---@type SelfTestCheck[]
local checks = {}
---@type table<string, boolean>
local overrides = {}
---@type table|nil
local run
---@type { pass: integer, fail: integer, skip: integer, total: integer, fps: number }|nil
local pending

--- Supply the on-screen result presenter; nil keeps it log-only.
---@param fn fun(summary: { pass: integer, fail: integer, skip: integer, total: integer, fps: number })|nil
function SelfTest.SetPresenter(fn)
    presenter = fn
end

--- Show the finished result once the configured input mode is active again, so a mode switch
--- cannot tear the toast down with the previous mode's UI. Safe to call every frame.
---@return boolean presented
function SelfTest.PresentResult()
    local summary = pending
    if summary == nil then return false end
    pending = nil
    if presenter == nil then
        print("[SELFTEST][PRESENT] -> NONE | no presenter")
        return false
    end
    presenter(summary)
    print(string.format("[SELFTEST][PRESENT] -> OK | pass=%d fail=%d skip=%d coverage=%d/%d fps=%.1f",
        summary.pass, summary.fail, summary.skip, summary.pass + summary.fail, summary.total, summary.fps))
    return true
end

--- Merge configuration; only the keys given are replaced.
---@param overrides_ { enabled?: boolean, roundTrip?: table|nil, inputMode?: string|nil, frameCap?: number }
function SelfTest.Configure(overrides_)
    for key, value in pairs(overrides_) do
        config[key] = value
    end
end

---@return boolean
function SelfTest.IsEnabled()
    return config.enabled == true
end

---@param enabled boolean
function SelfTest.SetEnabled(enabled)
    config.enabled = enabled == true
end

--- Switch one check on or off without editing its definition.
---@param id string
---@param enabled boolean
function SelfTest.SetCheckEnabled(id, enabled)
    overrides[id] = enabled == true
end

---@param id string
---@return boolean
function SelfTest.IsCheckEnabled(id)
    local value = overrides[id]
    if value ~= nil then return value end
    for _, check in ipairs(checks) do
        if check.id == id then return check.enabled ~= false end
    end
    return false
end

---@param id string
---@param probe SelfTestProbe
function SelfTest.RegisterProbe(id, probe)
    probes[id] = probe
end

---@param id string
---@return SelfTestProbe|nil
function SelfTest.Probe(id)
    return probes[id]
end

---@param check SelfTestCheck
function SelfTest.RegisterCheck(check)
    checks[#checks + 1] = check
end

---@return boolean
function SelfTest.IsRunning()
    return run ~= nil
end

---@param title string
---@param status string
---@param detail string
local function record(title, status, detail)
    if run == nil then return end
    run.results[#run.results + 1] = { title = title, status = status, detail = detail }
    if status == "PASS" then
        print(string.format("[SELFTEST][%s] -> OK | %s", title, detail))
    elseif status == "FAIL" then
        print(string.format("[SELFTEST][%s] -> FAIL | %s", title, detail))
    else
        print(string.format("[SELFTEST][%s] -> NONE | %s", title, detail))
    end
end

local function Finish()
    local current = run
    if current == nil then return end
    local pass, fail, skip = 0, 0, 0
    for _, item in ipairs(current.results) do
        if item.status == "PASS" then pass = pass + 1
        elseif item.status == "FAIL" then fail = fail + 1
        else skip = skip + 1 end
    end
    local fps = current.totalDt > 0 and current.frames / current.totalDt or 0
    local total = #current.results
    -- Skip means a registered check never ran, so it cannot count as a pass.
    local detail = string.format("pass=%d fail=%d skip=%d coverage=%d/%d fps=%.1f lua=%.0fKB res=%.0fKB",
        pass, fail, skip, pass + fail, total, fps,
        collectgarbage("count"), cache:GetTotalMemoryUse() / 1024)
    if fail > 0 then
        print("[SELFTEST][SUMMARY] -> FAIL | " .. detail)
    elseif skip > 0 then
        print("[SELFTEST][SUMMARY] -> NONE | " .. detail)
    else
        print("[SELFTEST][SUMMARY] -> OK | " .. detail)
    end
    run = nil
    pending = { pass = pass, fail = fail, skip = skip, total = total, fps = fps }
end

local function StartCheck(index)
    local current = run
    if current == nil then return false end
    local check = current.active[index]
    if check == nil then
        Finish()
        return false
    end
    current.states[check.id] = {}
    if check.enter then check.enter(current.states[check.id]) end
    return true
end

--- Run every enabled check in the requested group; checks without a group belong to "mode".
---@param group? string
---@return boolean
function SelfTest.Begin(group)
    return SelfTest.BeginOnly(nil, group)
end

--- Run exactly one check by id; used by per-check self-test buttons.
---@param id string|nil
---@param group? string
---@return boolean
function SelfTest.BeginOnly(id, group)
    if not SelfTest.IsEnabled() then
        print("[SELFTEST] disabled")
        return false
    end
    if run ~= nil then return false end
    pending = nil
    group = group or "mode"
    run = { index = 1, elapsed = 0.0, frames = 0, totalDt = 0.0, results = {}, active = {}, states = {} }
    local disabled = 0
    for _, check in ipairs(checks) do
        if (id ~= nil and check.id ~= id) or not SelfTest.IsCheckEnabled(check.id)
            or (check.group or "mode") ~= group then
            disabled = disabled + 1
        elseif check.available and not check.available() then
            record(check.title, "SKIP", "probe missing")
        else
            run.active[#run.active + 1] = check
        end
    end
    local label = id or "all"
    print(string.format("[SELFTEST] begin | group=%s target=%s checks=%d disabled=%d lua=%.0fKB res=%.0fKB",
        group, label, #run.active, disabled, collectgarbage("count"), cache:GetTotalMemoryUse() / 1024))
    if #run.active == 0 then Finish(); return false end
    StartCheck(1)
    return true
end

--- List registered checks for UI buttons.
---@param group? string
---@return { id: string, title: string }[]
function SelfTest.GetChecks(group)
    group = group or "mode"
    local list = {}
    for _, check in ipairs(checks) do
        if (check.group or "mode") == group then
            list[#list + 1] = { id = check.id, title = check.title }
        end
    end
    return list
end

--- Advance the run; every mode calls this once per frame.
---@param modeId string
---@param dt number
function SelfTest.Tick(modeId, dt)
    if run == nil then
        if pending ~= nil and config.inputMode ~= nil and modeId == config.inputMode then
            SelfTest.PresentResult()
        end
        return
    end
    run.frames = run.frames + 1
    run.totalDt = run.totalDt + dt
    run.elapsed = run.elapsed + dt
    local check = run.active[run.index]
    if check == nil then Finish(); return end
    local state = run.states[check.id]
    local status = check.tick(state, modeId, dt, run.elapsed)
    local timeout = check.timeout or DEFAULT_TIMEOUT
    local timedOut = run.elapsed > timeout
    if status == "running" and timedOut then status = "fail" end
    if status == "running" then return end
    local detail = check.detail and check.detail(state) or ""
    if timedOut then detail = detail .. " (timeout)" end
    record(check.title, status == "pass" and "PASS" or "FAIL", detail)
    run.index = run.index + 1
    run.elapsed = 0.0
    StartCheck(run.index)
end


return SelfTest
