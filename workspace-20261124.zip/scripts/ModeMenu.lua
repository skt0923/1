-- Mode switch entry shared by every page: a top-right 菜单 button and its popup.
-- Contract only (e8): page ids, labels and the switch callback come from the caller.
-- The menu never requires Router; switching goes through the injected onSelect.
local UI = require("urhox-libs/UI")

---@class ModeMenuOption
---@field id string
---@field name string

---@class ModeMenuConfig
---@field options ModeMenuOption[]
---@field current string
---@field onSelect fun(id: string)
---@field pageWidget? any Page root; nil when the menu owns the only root
---@field buttonTop? number Override the button's top inset
---@field buttonRight? number Override the button's right inset
---@field variant? string "popup" 时按钮文案为「玩法」，用于页面内使用；默认「设置」

---@class ModeMenu
---@field options ModeMenuOption[]
---@field current string
---@field onSelect fun(id: string)
---@field open boolean
---@field root any
---@field button any
---@field overlay any
---@field buttonTop number
---@field buttonRight number
---@field buttonText string
---@field pageWidget any|nil
local ModeMenu = {}
ModeMenu.__index = ModeMenu
-- 本模块是否已做过 UI.Init：SetRoot 之前的重复调用会让 UI 报 "called twice, ignored"（feedback 54602 f159）。
local initialized_ = false

--- Create the shared NanoVG UI once; later pages reuse the live context.
---@param options? table Options forwarded to UI.Init on the first call.
---@return boolean created True when this call initialised the UI.
function ModeMenu.EnsureUI(options)
    -- UI.Shutdown 之后根为空，标志随之复位；这样同帧连调两次不会重复 UI.Init。
    if initialized_ and UI.GetRoot() == nil then
        initialized_ = false
    end
    if initialized_ then return false end
    UI.Init(options or {theme = "default-dark", scale = UI.Scale.DEFAULT})
    initialized_ = true
    print("[UI][MENU] -> OK | event=init reason=no-root")
    return true
end

local BUTTON_RIGHT = 12
local BUTTON_TOP = 8
local BUTTON_WIDTH = 56
local BUTTON_HEIGHT = 32
local OVERLAY_ALPHA = 170
local PANEL_WIDTH = 240

---@param config ModeMenuConfig
---@return ModeMenu
function ModeMenu.Create(config)
    assert(config ~= nil, "ModeMenu.Create requires a config")
    assert(type(config.options) == "table" and #config.options > 0, "ModeMenu.Create requires options")
    assert(type(config.onSelect) == "function", "ModeMenu.Create requires onSelect")
    ModeMenu.EnsureUI({theme = "default-dark", scale = UI.Scale.DEFAULT})
    local self = setmetatable({
        options = config.options,
        current = config.current,
        onSelect = config.onSelect,
        open = false,
        buttonTop = config.buttonTop or BUTTON_TOP,
        buttonRight = config.buttonRight or BUTTON_RIGHT,
        buttonText = config.variant == "popup" and "玩法" or "菜单",
    }, ModeMenu)
    self.button = UI.Button {
        text = self.buttonText,
        position = "absolute",
        right = self.buttonRight,
        top = self.buttonTop,
        width = BUTTON_WIDTH,
        height = BUTTON_HEIGHT,
        fontSize = 13,
        variant = "secondary",
        onClick = function() self:Toggle() end,
    }
    self.overlay = self:BuildOverlay()
    self.pageWidget = config.pageWidget
    local children = {}
    if config.pageWidget ~= nil then
        table.insert(children, config.pageWidget)
    end
    table.insert(children, self.overlay)
    table.insert(children, self.button)
    self.root = UI.Panel {
        width = "100%",
        height = "100%",
        pointerEvents = "box-none",
        children = children,
    }
    UI.SetRoot(self.root, true)
    print(string.format("[UI][MENU] -> OK | event=create current=%s options=%d top=%d right=%d text=%s",
        tostring(self.current), #self.options, self.buttonTop, self.buttonRight, self.buttonText))
    return self
end

---@param visible boolean
function ModeMenu:SetPageVisible(visible)
    local page = self.pageWidget
    if page ~= nil then page:SetVisible(visible) end
    print(string.format("[UI][MENU] -> OK | event=page-visible visible=%s", tostring(visible)))
end

---@return any
function ModeMenu:BuildOverlay()
    local items = {}
    for index = 1, #self.options do
        local option = self.options[index]
        table.insert(items, UI.Button {
            text = option.name,
            height = 40,
            fontSize = 14,
            flexShrink = 0,
            variant = option.id == self.current and "secondary" or "primary",
            disabled = option.id == self.current,
            onClick = function() self:Select(option.id) end,
        })
    end
    table.insert(items, UI.Button {
        text = "关闭",
        height = 36,
        fontSize = 13,
        flexShrink = 0,
        variant = "secondary",
        onClick = function() self:SetOpen(false) end,
    })
    local panel = UI.Panel {
        width = PANEL_WIDTH,
        flexDirection = "column",
        gap = 8,
        padding = 14,
        backgroundColor = {0, 0, 0, 230},
        children = items,
    }
    local overlay = UI.Panel {
        position = "absolute",
        left = 0,
        right = 0,
        top = 0,
        bottom = 0,
        justifyContent = "center",
        alignItems = "center",
        backgroundColor = {0, 0, 0, OVERLAY_ALPHA},
        pointerEvents = "auto",
        onClick = function() self:SetOpen(false) end,
        children = {panel},
    }
    overlay:SetVisible(false)
    return overlay
end

---@param open boolean
function ModeMenu:SetOpen(open)
    self.open = open
    self.overlay:SetVisible(open)
    print(string.format("[UI][MENU] -> OK | event=%s current=%s", open and "open" or "close", tostring(self.current)))
end

function ModeMenu:Toggle()
    self:SetOpen(not self.open)
end

---@param id string
function ModeMenu:Select(id)
    if id == self.current then
        self:SetOpen(false)
        print(string.format("[UI][MENU] -> NONE | event=select reason=current id=%s", id))
        return
    end
    self:SetOpen(false)
    print(string.format("[UI][MENU] -> OK | event=select from=%s to=%s", tostring(self.current), id))
    self.onSelect(id)
end

function ModeMenu:Destroy()
    self.overlay = nil
    self.button = nil
    self.root = nil
    self.onSelect = nil
    print("[UI][MENU] -> OK | event=destroy")
end

function ModeMenu.Shutdown()
    UI.Shutdown()
    print("[UI][MENU] -> OK | event=shutdown")
end

return ModeMenu
