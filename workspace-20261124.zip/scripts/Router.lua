-- Single owner of the active mode: registration, entry, frame forwarding and teardown.
local Router = {}

-- Longest frame step handed to a mode, in seconds.
local MAX_TIME_STEP = 0.1

---@class ModeInstance
---@field Start fun(self: ModeInstance)
---@field Update fun(self: ModeInstance, dt: number)
---@field PostUpdate fun(self: ModeInstance)|nil
---@field PostRender fun(self: ModeInstance)
---@field Stop fun(self: ModeInstance)
---@field Dispose fun(self: ModeInstance)

---@type table<string, fun():ModeInstance>
local registry = {}
---@type ModeInstance|nil
local current
---@type string|nil
local pending

--- Register a mode factory under an id.
---@param id string
---@param factory fun():ModeInstance
function Router.Register(id, factory)
    registry[id] = factory
end

---@param id string
---@return boolean
function Router.Has(id)
    return registry[id] ~= nil
end

--- Enter a registered mode; the previous mode is stopped and disposed first.
---@param id string
function Router.Enter(id)
    local factory = registry[id] or error("Unknown mode: " .. tostring(id))
    if current then
        current:Stop()
        current:Dispose()
    end
    current = factory()
    current:Start()
    print(string.format("[ROUTER][ENTER] -> OK | id=%s", id))
end

--- Switch modes on the next frame, so a mode can request it from inside its own input or update.
---@param id string
function Router.Request(id)
    if registry[id] == nil then error("Unknown mode: " .. tostring(id)) end
    pending = id
    print(string.format("[ROUTER][REQUEST] -> OK | target=%s", id))
end

--- Stop and dispose the active mode.
function Router.Stop()
    if not current then return end
    current:Stop()
    current:Dispose()
    current = nil
end

--- Forward one engine frame to the active mode.
function Router.Update(eventData)
    if pending ~= nil then
        local target = pending
        pending = nil
        Router.Enter(target)
        return
    end
    if not current then return end
    local dt = math.min(eventData["TimeStep"]:GetFloat(), MAX_TIME_STEP)
    current:Update(dt)
end

--- Forward one post-update frame (after animations) to the active mode.
function Router.PostUpdate()
    if current and current.PostUpdate then current:PostUpdate() end
end

--- Forward one post-render frame to the active mode.
function Router.PostRender()
    if current then current:PostRender() end
end

return Router
