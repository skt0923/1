-- modes/M1_Port/Test/FlowRunner.lua: 全流程自动测试跑者（只给自检用，允许瞬移与输入注入）。
-- 目的：一条命令验完 P3 闭环——等进玩、切三处中继、解锁撤离、瞬移到撤离点、等结算页。
-- 全程走真实链路（真实按住 2.4 秒、真实撤离判定），只有"走位"用瞬移代替。
-- 日志一律带 reason 或步骤名，便于和玩法日志区分。
local TAG = "[M1][RUN]"

---@class M1RunDeps
---@field rig PlayerRig
---@field health M1PlayerHealth
---@field relays M1RelayFlow
---@field extract M1Extract
---@field flow M1GameFlow
---@field stats M1RunStats
---@field rifle ShooterRifle|nil
---@field screens M1MenuScreens|nil
---@field forward fun(): Vector3 水平化的相机前向（交互朝向判定用）。

---@class M1RunStep
---@field name string
---@field timeout number
---@field enter fun(deps: M1RunDeps, runner: M1RunRunner)|nil
---@field done fun(deps: M1RunDeps, runner: M1RunRunner): boolean

---@class M1RunRunner
---@field deps M1RunDeps
---@field steps M1RunStep[]
---@field index integer
---@field elapsed number
---@field active boolean
---@field hold boolean
---@field flipped boolean
---@field results boolean[]
local Runner = {}
Runner.__index = Runner

---@param deps M1RunDeps
---@return M1RunRunner
function Runner.Create(deps)
    assert(deps ~= nil and deps.rig ~= nil, "FlowRunner requires a rig")
    assert(deps.relays ~= nil and deps.extract ~= nil, "FlowRunner requires relays and extract")
    assert(type(deps.forward) == "function", "FlowRunner requires a forward callback")
    ---@type M1RunRunner
    local self = setmetatable({
        deps = deps,
        steps = {},
        index = 1,
        elapsed = 0.0,
        active = false,
        hold = false,
        flipped = false,
        results = {},
    }, Runner)
    self.steps = self:BuildSteps()
    print(string.format("%s[CREATE] -> OK | steps=%d", TAG, #self.steps))
    return self
end

---@param deps M1RunDeps
---@param id string
---@return M1RelayEntry|nil
local function RelayById(deps, id)
    local entries = deps.relays.entries
    for index = 1, #entries do
        if entries[index].id == id then
            return entries[index]
        end
    end
    return nil
end

--- 瞬移 + 设朝向（测试专用；yaw 用弧度，与 controls.yaw 一致）。
---@param deps M1RunDeps
---@param pos Vector3
---@param yaw number
local function Teleport(deps, pos, yaw)
    local rig = deps.rig
    rig.node.position = pos
    rig.lastSafe = pos
    local controls = rig.character.controls
    controls.yaw = yaw
    controls.pitch = 0.0
    print(string.format("%s[TELEPORT] -> OK | pos=(%.1f,%.1f) yaw=%.0f", TAG, pos.x, pos.z, yaw * 180.0 / math.pi))
end

--- 一个切断步骤：瞬移到中继前 1.5 米、面向它、按住到切断。
---@param relayId string
---@param stepName string
---@return M1RunStep
local function CutStep(relayId, stepName)
    return {
        name = stepName,
        timeout = 9.0,
        enter = function(deps, runner)
            runner.hold = true
            runner.flipped = false
            local entry = RelayById(deps, relayId)
            if entry == nil then
                print(string.format("%s[STEP] -> FAIL | name=%s reason=relay-missing id=%s", TAG, stepName, relayId))
                return
            end
            Teleport(deps, Vector3(entry.pos.x - 1.5, 0.0, entry.pos.z), math.pi * 0.5)
        end,
        done = function(deps, runner)
            local entry = RelayById(deps, relayId)
            return entry ~= nil and entry.cut
        end,
    }
end

---@return M1RunStep[]
function Runner:BuildSteps()
    return {
        {
            name = "playing",
            timeout = 8.0,
            enter = nil,
            done = function(deps, runner) return deps.flow:IsPlaying() end,
        },
        CutStep("relay_a", "cut-a"),
        CutStep("relay_b", "cut-b"),
        CutStep("relay_c", "cut-c"),
        {
            name = "extract-unlock",
            timeout = 2.0,
            enter = nil,
            done = function(deps, runner) return deps.extract:IsReady() end,
        },
        {
            name = "extract-reach",
            timeout = 3.0,
            enter = function(deps, runner)
                runner.hold = false
                local data = deps.extract.data
                Teleport(deps, Vector3(data.x, 0.0, data.z), 0.0)
            end,
            done = function(deps, runner) return deps.extract:IsReached() end,
        },
        {
            name = "debrief",
            timeout = 3.0,
            enter = nil,
            done = function(deps, runner)
                local screens = deps.screens
                return deps.flow:IsComplete() and screens ~= nil and screens.screen == "complete"
            end,
        },
    }
end

---@return boolean
function Runner:InteractHeld()
    return self.active and self.hold
end

---@return boolean
function Runner:IsActive()
    return self.active
end

function Runner:Finish(ok)
    self.active = false
    self.hold = false
    local passCount = 0
    for index = 1, #self.results do
        if self.results[index] then passCount = passCount + 1 end
    end
    local failCount = #self.results - passCount
    local result = (ok and failCount == 0) and "OK" or "FAIL"
    print(string.format("%s[RESULT] -> %s | steps=%d pass=%d fail=%d", TAG, result, #self.steps, passCount,
        failCount))
    local stats = self.deps.stats
    if stats ~= nil then stats:Probe() end
end

function Runner:Start()
    self.active = true
    self.index = 1
    self.elapsed = 0.0
    self.results = {}
    self.hold = false
    self.flipped = false
    print(string.format("%s[START] -> OK | steps=%d", TAG, #self.steps))
    local first = self.steps[1]
    if first ~= nil and first.enter ~= nil then first.enter(self.deps, self) end
end

--- 死亡页测试：直接扣血到 0，等 Mode 进 dead 并出死亡页。
function Runner:StartDeath()
    self.active = false
    self.hold = false
    print(string.format("%s[DEATH] -> OK | event=damage amount=999", TAG))
    self.deps.health:Damage(999.0, "test")
end

---@param dt number
function Runner:Update(dt)
    if not self.active then return end
    local step = self.steps[self.index]
    if step == nil then
        self:Finish(true)
        return
    end
    self.elapsed = self.elapsed + dt

    -- 切断步骤的朝向兜底：0.5 秒还没进交互范围就翻半圈（yaw 语义与相机不一致时自救）
    if not self.flipped and self.elapsed > 0.5 and string.sub(step.name, 1, 3) == "cut" then
        local near = self.deps.relays:Nearest(self.deps.rig.node.position, self.deps.forward())
        if near == nil then
            local controls = self.deps.rig.character.controls
            controls.yaw = controls.yaw + math.pi
            self.flipped = true
            print(string.format("%s[TURN] -> OK | name=%s reason=facing-flip", TAG, step.name))
        else
            self.flipped = true
        end
    end

    if step.done(self.deps, self) then
        self.results[#self.results + 1] = true
        print(string.format("%s[STEP] -> OK | name=%s elapsed=%.2f", TAG, step.name, self.elapsed))
        self.index = self.index + 1
        self.elapsed = 0.0
        self.flipped = false
        local nextStep = self.steps[self.index]
        if nextStep == nil then
            self:Finish(true)
        elseif nextStep.enter ~= nil then
            nextStep.enter(self.deps, self)
        end
        return
    end

    if self.elapsed >= step.timeout then
        self.results[#self.results + 1] = false
        print(string.format("%s[STEP] -> FAIL | name=%s timeout=%.1f", TAG, step.name, step.timeout))
        self:Finish(false)
    end
end

function Runner:Destroy()
    self.active = false
    self.hold = false
    self.steps = {}
    print(string.format("%s -> OK | event=destroy", TAG))
end

return Runner
