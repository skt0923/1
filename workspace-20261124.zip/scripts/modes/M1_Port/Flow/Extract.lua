-- modes/M1_Port/Flow/Extract.lua: 撤离点判定（三处中继全切断后，进入撤离半径即完成）。
-- 原作 20-flow：`allCut` 后 `q()` 把撤离点加进 setMarkers，触达时 `emits extraction:reached` 并进 complete。
local TAG = "[M1][EXTRACT]"

---@class M1ExtractData
---@field x number
---@field z number
---@field radius number

---@class M1Extract
---@field data M1ExtractData
---@field ready boolean
---@field reached boolean
local Extract = {}
Extract.__index = Extract

---@param data M1ExtractData
---@return M1Extract
function Extract.Create(data)
    assert(data ~= nil and data.radius > 0, "Extract requires a radius")
    local self = setmetatable({data = data, ready = false, reached = false}, Extract)
    print(string.format("%s[CREATE] -> OK | pos=(%.1f,%.1f) radius=%.1f", TAG, data.x, data.z, data.radius))
    return self
end

---@return boolean
function Extract:IsReady()
    return self.ready
end

---@return boolean
function Extract:IsReached()
    return self.reached
end

--- 中继全切断后撤离点解锁（只打一次日志）。
function Extract:Unlock()
    if self.ready then return end
    self.ready = true
    print(string.format("%s[UNLOCK] -> OK | pos=(%.1f,%.1f) radius=%.1f", TAG, self.data.x, self.data.z,
        self.data.radius))
end

---@param playerPos Vector3
---@return number distance
function Extract:Distance(playerPos)
    local dx = self.data.x - playerPos.x
    local dz = self.data.z - playerPos.z
    return math.sqrt(dx * dx + dz * dz)
end

--- 每帧判一次；到达返回 true（只报一次）。
---@param playerPos Vector3
---@return boolean reached
function Extract:Update(playerPos)
    if self.reached then return false end
    local distance = self:Distance(playerPos)
    if not self.ready then return false end
    if distance > self.data.radius then return false end
    self.reached = true
    print(string.format("%s[REACH] -> OK | dist=%.2f radius=%.1f", TAG, distance, self.data.radius))
    return true
end

---@param playerPos Vector3
---@return string
function Extract:Probe(playerPos)
    local distance = self:Distance(playerPos)
    local result = self.ready and "OK" or "NONE"
    local text = string.format("%s[PROBE] -> %s | ready=%s reached=%s dist=%.2f radius=%.1f", TAG, result,
        tostring(self.ready), tostring(self.reached), distance, self.data.radius)
    print(text)
    return text
end

function Extract:Destroy()
    print(string.format("%s -> OK | event=destroy", TAG))
end

return Extract
