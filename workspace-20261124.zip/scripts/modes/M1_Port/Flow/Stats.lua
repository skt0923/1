-- modes/M1_Port/Flow/Stats.lua: 一局的战斗统计与评级。
-- 原作 20-flow 语句 14：`Y=(time<270?2:time<400?1:0)+(acc>=.5?2:acc>=.3?1:0)+(retries===0?1:0)`，
-- 评级名取 FlowData.rating.names[Y]；命中率 = hits/shots（shots=0 时无命中率）。
local TAG = "[M1][STATS]"

---@class M1RunStats
---@field ratingTable M1RatingData
---@field shots integer
---@field hits integer
---@field kills integer
---@field retries integer
---@field seconds number
local Stats = {}
Stats.__index = Stats

---@param rating M1RatingData
---@return M1RunStats
function Stats.Create(rating)
    assert(rating ~= nil and #rating.names > 0, "RunStats requires rating data")
    local self = setmetatable({
        ratingTable = rating,
        shots = 0,
        hits = 0,
        kills = 0,
        retries = 0,
        seconds = 0.0,
    }, Stats)
    print(string.format("%s[CREATE] -> OK | rating=%d names=%d", TAG, #rating.names, #rating.names))
    return self
end

---@param dt number
function Stats:AddTime(dt)
    self.seconds = self.seconds + dt
end

---@param shots integer
---@param hits integer
---@param kills integer
function Stats:Sync(shots, hits, kills)
    self.shots = shots
    self.hits = hits
    self.kills = kills
end

---@return integer
function Stats:Retries()
    return self.retries
end

function Stats:AddRetry()
    self.retries = self.retries + 1
    print(string.format("%s[RETRY] -> OK | retries=%d", TAG, self.retries))
end

--- 命中率 0..1；没开过枪返回 nil（原作 `P.shots>0?Zn(hits/shots,0,1):null`）。
---@return number|nil
function Stats:Accuracy()
    if self.shots <= 0 then return nil end
    local value = self.hits / self.shots
    if value < 0.0 then return 0.0 end
    if value > 1.0 then return 1.0 end
    return value
end

--- 评级：0..5 分，返回评级名与分数。
---@return string name
---@return integer score
function Stats:Rating()
    local table_ = self.ratingTable
    local timeScore = 0
    if self.seconds < table_.timeFast then
        timeScore = 2
    elseif self.seconds < table_.timeSlow then
        timeScore = 1
    end
    local accuracy = self:Accuracy()
    local accScore = 0
    if accuracy ~= nil then
        if accuracy >= table_.accHigh then
            accScore = 2
        elseif accuracy >= table_.accMid then
            accScore = 1
        end
    end
    local retryScore = 0
    if self.retries == 0 then retryScore = 1 end
    local score = timeScore + accScore + retryScore
    -- 表长 6（0..5 分），越界时退回最低档，不留 nil（第 28 节）
    local name = table_.names[score + 1] or table_.names[1] or "未评级"
    return name, score
end

---@return string
function Stats:TimeText()
    local whole = math.max(0, math.floor(self.seconds))
    return string.format("%02d:%02d", math.floor(whole / 60), whole % 60)
end

---@return string
function Stats:Probe()
    local accuracy = self:Accuracy()
    local accText = accuracy ~= nil and string.format("%.0f%%", accuracy * 100.0) or "—"
    local name, score = self:Rating()
    local text = string.format("%s[PROBE] -> OK | time=%s shots=%d hits=%d kills=%d retries=%d acc=%s rating=%s(%d)",
        TAG, self:TimeText(), self.shots, self.hits, self.kills, self.retries, accText, name, score)
    print(text)
    return text
end

function Stats:Destroy()
    print(string.format("%s -> OK | event=destroy", TAG))
end

return Stats
