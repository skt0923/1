-- modes/M1_Port/Flow/Relay.lua: 三处中继的交互状态（靠近 + 朝向 + 按住累计切断）。
-- 原作 20-flow：relay 表项 { id, short, t, cut, cutting }，交互阈值 interactRange 2.2 / interactFacing .45 / cutSeconds 2.4。
local TAG = "[M1][RELAY]"

---@class M1RelayEntry
---@field id string
---@field short string
---@field pos Vector3
---@field cut boolean
---@field cutting boolean
---@field progress number

---@class M1RelayData
---@field relays { id: string, short: string, x: number, z: number }[]
---@field extract { x: number, z: number, radius: number }

---@class M1RelayFlow
---@field data M1RelayData
---@field flow M1FlowData
---@field entries M1RelayEntry[]
---@field active M1RelayEntry|nil
local Relay = {}
Relay.__index = Relay

---@param data M1RelayData
---@param flowData M1FlowData
---@return M1RelayFlow
function Relay.Create(data, flowData)
    assert(data ~= nil and #data.relays > 0, "RelayFlow requires relay data")
    assert(flowData ~= nil and flowData.interactRange > 0, "RelayFlow requires flow data")
    ---@type M1RelayEntry[]
    local entries = {}
    for index = 1, #data.relays do
        local item = data.relays[index]
        entries[index] = {
            id = item.id,
            short = item.short,
            pos = Vector3(item.x, 0.0, item.z),
            cut = false,
            cutting = false,
            progress = 0.0,
        }
    end
    local self = setmetatable({data = data, flow = flowData, entries = entries, active = nil}, Relay)
    print(string.format("%s[CREATE] -> OK | relays=%d range=%.1f facing=%.2f cut=%.1fs", TAG, #entries,
        flowData.interactRange, flowData.interactFacing, flowData.cutSeconds))
    return self
end

---@return integer
function Relay:Done()
    local count = 0
    for index = 1, #self.entries do
        if self.entries[index].cut then
            count = count + 1
        end
    end
    return count
end

---@return integer
function Relay:Total()
    return #self.entries
end

---@return boolean
function Relay:AllCut()
    return self:Done() >= self:Total()
end

--- 距离与朝向都满足的最近未切断中继；没有就返回 nil。
---@param playerPos Vector3
---@param forward Vector3 已水平化并归一化的相机前向。
---@return M1RelayEntry|nil entry
---@return number distance
function Relay:Nearest(playerPos, forward)
    ---@type M1RelayEntry|nil
    local best = nil
    local bestDistance = -1.0
    for index = 1, #self.entries do
        local entry = self.entries[index]
        if not entry.cut then
            local dx = entry.pos.x - playerPos.x
            local dz = entry.pos.z - playerPos.z
            local distance = math.sqrt(dx * dx + dz * dz)
            -- 中继柜半宽 0.6，交互范围按中心距离再放宽一点
            if distance <= self.flow.interactRange + 0.6 and distance > 0.001 then
                local facing = (dx * forward.x + dz * forward.z) / distance
                if facing >= self.flow.interactFacing and (best == nil or distance < bestDistance) then
                    best = entry
                    bestDistance = distance
                end
            end
        end
    end
    return best, bestDistance
end

---@param dt number
---@param playerPos Vector3
---@param forward Vector3
---@param held boolean 交互键是否按住。
function Relay:Update(dt, playerPos, forward, held)
    local target = self:Nearest(playerPos, forward)
    if target == nil or not held then
        -- 松开或走开：进度归零（原作 t 会回落）
        for index = 1, #self.entries do
            local entry = self.entries[index]
            if entry.progress > 0.0 and not entry.cut then
                entry.progress = 0.0
                entry.cutting = false
            end
        end
        self.active = nil
        return
    end
    self.active = target
    target.cutting = true
    target.progress = math.min(self.flow.cutSeconds, target.progress + dt)
    if target.progress >= self.flow.cutSeconds and not target.cut then
        target.cut = true
        target.cutting = false
        print(string.format("%s[CUT] -> OK | id=%s done=%d/%d", TAG, target.id, self:Done(), self:Total()))
    end
end

--- HUD 用：当前按住的中继与进度百分比。
---@return M1RelayEntry|nil entry
---@return number percent 0..100
function Relay:ActiveProgress()
    local entry = self.active
    if entry == nil then return nil, 0 end
    local percent = entry.progress / self.flow.cutSeconds * 100.0
    return entry, percent
end

---@param playerPos Vector3
---@return string
function Relay:Probe(playerPos)
    local done = self:Done()
    local total = self:Total()
    local nearest = "none"
    local nearestDistance = -1.0
    for index = 1, #self.entries do
        local entry = self.entries[index]
        if not entry.cut then
            local dx = entry.pos.x - playerPos.x
            local dz = entry.pos.z - playerPos.z
            local distance = math.sqrt(dx * dx + dz * dz)
            if nearestDistance < 0.0 or distance < nearestDistance then
                nearest = entry.short
                nearestDistance = distance
            end
        end
    end
    local result = (done >= total) and "NONE" or "OK"
    local text = string.format("%s[PROBE] -> %s | done=%d/%d nearest=%s dist=%.1f", TAG, result, done, total,
        nearest, nearestDistance)
    print(text)
    return text
end

--- 最近一处未切断中继（不考虑朝向），自检传送用。
---@param playerPos Vector3
---@return M1RelayEntry|nil entry
---@return number distance
function Relay:NearestAny(playerPos)
    ---@type M1RelayEntry|nil
    local best = nil
    local bestDistance = -1.0
    for index = 1, #self.entries do
        local entry = self.entries[index]
        if not entry.cut then
            local dx = entry.pos.x - playerPos.x
            local dz = entry.pos.z - playerPos.z
            local distance = math.sqrt(dx * dx + dz * dz)
            if best == nil or distance < bestDistance then
                best = entry
                bestDistance = distance
            end
        end
    end
    return best, bestDistance
end

--- 自检专用：把全部中继直接置为已切断（不等按住计时），日志标注 selftest。
function Relay:ForceAllCut()
    for index = 1, #self.entries do
        local entry = self.entries[index]
        if not entry.cut then
            entry.cut = true
            entry.cutting = false
            entry.progress = self.flow.cutSeconds
        end
    end
    print(string.format("%s[FORCE] -> OK | done=%d/%d reason=selftest", TAG, self:Done(), self:Total()))
end

function Relay:Destroy()
    self.entries = {}
    self.active = nil
    print(string.format("%s -> OK | event=destroy", TAG))
end

return Relay
