-- modes/M1_Port/Flow/GameFlow.lua: 流程状态机的最小实现（intro → playing → dead）。
-- 原作 20-flow 语句 6 的 B(P)：六状态 title/intro/playing/paused/dead/complete；本阶段只做前三个里用得到的。
-- title/paused/extract/complete 与结算页在 P3-B（任务卡 m1-p3a 差异第 4 条）。
local TAG = "[M1][FLOW]"

---@class M1RatingData
---@field timeFast number
---@field timeSlow number
---@field accHigh number
---@field accMid number
---@field names string[]

---@class M1FlowData
---@field introSeconds number
---@field retryIntroSeconds number
---@field interactRange number 中继交互距离（米）。
---@field interactFacing number 交互朝向阈值（水平前向点积）。
---@field cutSeconds number 按住切断所需秒数。
---@field objectiveBase string
---@field objectiveReturn string

---@class M1GameFlow
---@field data M1FlowData
---@field state string
---@field elapsed number
local Flow = {}
Flow.__index = Flow

---@param data M1FlowData
---@return M1GameFlow
function Flow.Create(data)
    assert(data ~= nil and data.introSeconds > 0, "GameFlow requires intro seconds")
    local self = setmetatable({data = data, state = "intro", elapsed = 0.0}, Flow)
    print(string.format("%s[STATE] -> OK | from=none to=intro intro=%.1fs", TAG, data.introSeconds))
    return self
end

---@return boolean
function Flow:IsPlaying()
    return self.state == "playing"
end

---@return boolean
function Flow:IsIntro()
    return self.state == "intro"
end

---@return boolean
function Flow:IsDead()
    return self.state == "dead"
end

---@return boolean
function Flow:IsComplete()
    return self.state == "complete"
end

--- 撤离成功：进入 complete（原作 M("complete")）。
function Flow:Complete()
    if self.state == "complete" then return end
    self:SetState("complete")
    print(string.format("%s[COMPLETE] -> OK | elapsed=%.1f", TAG, self.elapsed))
end

---@return number
function Flow:Elapsed()
    return self.elapsed
end

---@param next string
function Flow:SetState(next)
    local from = self.state
    if from == next then return end
    self.state = next
    self.elapsed = 0.0
    print(string.format("%s[STATE] -> OK | from=%s to=%s", TAG, from, next))
end

--- 玩家死亡：进入 dead，只记录一次（原作 B 的 dead 分支）。
function Flow:MarkDead()
    if self.state == "dead" or self.state == "complete" then
        print(string.format("%s[DEAD] -> NONE | state=%s reason=already", TAG, self.state))
        return
    end
    self:SetState("dead")
    print(string.format("%s[DEAD] -> OK | elapsed=%.1f", TAG, self.elapsed))
end

---@param dt number
function Flow:Update(dt)
    self.elapsed = self.elapsed + dt
    if self.state == "intro" and self.elapsed >= self.data.introSeconds then
        self:SetState("playing")
        print(string.format("%s[PLAY] -> OK | start", TAG))
    end
end

---@return string
function Flow:Probe()
    local text = string.format("%s[PROBE] -> OK | state=%s elapsed=%.1f", TAG, self.state, self.elapsed)
    print(text)
    return text
end

function Flow:Destroy()
    print(string.format("%s -> OK | event=destroy state=%s", TAG, self.state))
end

return Flow
