-- modes/M1_Port/Flow/RelayLamp.lua: 中继柜指示灯的灯色与闪烁（原作 08-props 语句 1 的 B3 setState / update）。
-- 状态唯一来源是 Flow/Relay 的 entries，这里只读不写；灯罩材质按实例取一份独立副本再改（第 21 节）。
-- 1.35 没有 emissive 输出通道也不开 Bloom，用 NoTextureUnlit + MatDiffColor 近似自发光（任务卡 m1-p3c 差异第 1 条）。
local TAG = "[M1][LAMP]"

---@class M1RelayLampColor
---@field r number
---@field g number
---@field b number

---@class M1RelayLampData
---@field childName string 中继柜里灯罩子节点名（Art/Props 的 relay_node 构建器）。
---@field liveColor M1RelayLampColor
---@field cuttingColor M1RelayLampColor
---@field cutColor M1RelayLampColor
---@field maxIntensity number 原作最大强度，用来把强度归一成 0..1 亮度。
---@field liveBase number
---@field liveAmp number
---@field liveHz number
---@field cuttingHz number
---@field cuttingOn number
---@field cuttingOff number
---@field cutFlashSeconds number
---@field cutFlash number
---@field cutFadeSeconds number
---@field cutFade number
---@field cutFlickerLow number
---@field matchTolerance number

---@class M1RelayLampEntry
---@field id string
---@field short string
---@field node Node
---@field model StaticModel
---@field material Material 本实例专属副本，只用于这盏灯。
---@field original Material|nil 原共享材质，Destroy 时还原。
---@field state string live|cutting|cut
---@field timer number 进入 cut 后的秒数。
---@field clock number live / cutting 的呼吸与闪烁相位。
---@field brightness number 最近一帧归一后的亮度，探针用。

---@class M1RelayLamp
---@field data M1RelayLampData
---@field entries M1RelayLampEntry[]
local RelayLamp = {}
RelayLamp.__index = RelayLamp

---@type Technique|nil
local unlitTechnique_ = nil

---@return Technique
local function UnlitTechnique()
    if unlitTechnique_ == nil then
        local ok, technique = pcall(function()
            return cache:GetResource("Technique", "Techniques/NoTextureUnlit.xml")
        end)
        assert(ok and technique ~= nil, "Missing technique: Techniques/NoTextureUnlit.xml")
        unlitTechnique_ = technique --[[@as Technique]]
    end
    return unlitTechnique_ --[[@as Technique]]
end

--- 按名字前缀与水平距离找中继柜根节点；找不到返回 nil，由调用方断言。
---@param props M1PropBuild
---@param pos Vector3
---@param tolerance number
---@return Node|nil
local function FindCabinet(props, pos, tolerance)
    for index = 1, #props.nodes do
        local root = props.nodes[index] --[[@as Node]]
        if string.sub(root.name, 1, 15) == "Prop_relay_node" then
            local origin = root.position
            local dx = origin.x - pos.x
            local dz = origin.z - pos.z
            if dx * dx + dz * dz <= tolerance * tolerance then
                return root
            end
        end
    end
    return nil
end

--- 状态切换只在变化时打日志（第 27 节）。
---@param lamp M1RelayLampEntry
---@param state string
local function SetState(lamp, state)
    if lamp.state == state then return end
    local from = lamp.state
    lamp.state = state
    if state == "cut" then
        lamp.timer = 0.0
    elseif state == "live" then
        lamp.clock = 0.0
    end
    print(string.format("%s[STATE] -> OK | id=%s from=%s to=%s", TAG, lamp.id, from, state))
end

---@param level M1LevelBuild
---@param relayData M1RelayData Flow/Relay.lua 的数据（三处中继坐标与短标）。
---@param data M1RelayLampData
---@return M1RelayLamp
function RelayLamp.Create(level, relayData, data)
    assert(level ~= nil and level.props ~= nil, "RelayLamp requires the level build")
    assert(relayData ~= nil and #relayData.relays > 0, "RelayLamp requires relay data")
    assert(data ~= nil and data.maxIntensity > 0, "RelayLamp requires lamp data")
    local technique = UnlitTechnique()
    ---@type M1RelayLampEntry[]
    local entries = {}
    for index = 1, #relayData.relays do
        local item = relayData.relays[index] --[[@as { id: string, short: string, x: number, z: number }]]
        local pos = Vector3(item.x, 0.0, item.z)
        local cabinet = FindCabinet(level.props, pos, data.matchTolerance)
        assert(cabinet ~= nil, string.format("RelayLamp: cabinet missing for %s at (%.1f,%.1f)",
            item.id, item.x, item.z))
        ---@cast cabinet Node
        local lampNode = cabinet:GetChild(data.childName)
        assert(lampNode ~= nil, "RelayLamp: cabinet has no lamp child: " .. item.id)
        ---@cast lampNode Node
        local okModel, model = pcall(function() return lampNode:GetComponent("StaticModel") end)
        assert(okModel and model ~= nil, "RelayLamp: lamp missing StaticModel: " .. item.id)
        ---@cast model StaticModel
        local original = model:GetMaterial(0)
        local material
        if original ~= nil then
            material = original:Clone("RelayLamp_" .. item.id)
        else
            material = Material:new()
        end
        assert(material ~= nil, "RelayLamp: material unavailable: " .. item.id)
        ---@cast material Material
        material:SetTechnique(0, technique)
        model:SetMaterial(material)
        -- 灯罩不投影：小物件投影只会增加阴影贴图开销
        model:SetCastShadows(false)
        entries[index] = {
            id = item.id,
            short = item.short,
            node = lampNode,
            model = model,
            material = material,
            original = original,
            state = "live",
            timer = 0.0,
            clock = 0.0,
            brightness = 0.0,
        }
    end
    local self = setmetatable({data = data, entries = entries}, RelayLamp)
    for index = 1, #entries do
        local lamp = entries[index] --[[@as M1RelayLampEntry]]
        local intensity, color = self:Sample(lamp, 0.0)
        self:ApplyColor(lamp, intensity, color)
    end
    print(string.format("%s[CREATE] -> OK | lamps=%d child=%s maxIntensity=%.1f", TAG, #entries,
        data.childName, data.maxIntensity))
    return self
end

--- 每帧同步一次状态；唯一权威是 Relay 的 entries（第 15 节）。
---@param entries M1RelayEntry[]
function RelayLamp:Sync(entries)
    assert(entries ~= nil and #entries == #self.entries,
        "RelayLamp sync needs one relay entry per lamp")
    for index = 1, #self.entries do
        local lamp = self.entries[index] --[[@as M1RelayLampEntry]]
        local entry = entries[index] --[[@as M1RelayEntry]]
        assert(entry.id == lamp.id, string.format("RelayLamp order mismatch: lamp=%s relay=%s",
            lamp.id, entry.id))
        if entry.cut then
            SetState(lamp, "cut")
        elseif entry.cutting then
            SetState(lamp, "cutting")
        else
            SetState(lamp, "live")
        end
    end
end

--- 按原作公式算出这一帧的强度与颜色。
---@param lamp M1RelayLampEntry
---@param dt number
---@return number intensity
---@return M1RelayLampColor color
function RelayLamp:Sample(lamp, dt)
    local data = self.data
    if lamp.state == "live" then
        local clock = lamp.clock
        lamp.clock = clock + dt
        return data.liveBase + data.liveAmp * math.sin(clock * data.liveHz), data.liveColor
    end
    if lamp.state == "cutting" then
        local clock = lamp.clock
        lamp.clock = clock + dt
        local on = math.sin(clock * math.pi * 2.0 * data.cuttingHz) > 0.0
        if on then
            return data.cuttingOn, data.cuttingColor
        end
        return data.cuttingOff, data.liveColor
    end
    lamp.timer = lamp.timer + dt
    local timer = lamp.timer
    if timer < data.cutFlashSeconds then
        return data.cutFlash, data.cutColor
    end
    if timer < data.cutFadeSeconds then
        local span = data.cutFadeSeconds - data.cutFlashSeconds
        local fade = 1.0 - (timer - data.cutFlashSeconds) / span
        local flicker = 1.0
        -- 原作：sin(t*37)*sin(t*13.3) > -0.2 时全亮，否则只留 0.08
        if not (math.sin(timer * 37.0) * math.sin(timer * 13.3) > -0.2) then
            flicker = data.cutFlickerLow
        end
        return data.cutFade * fade * fade * flicker, data.cutColor
    end
    return 0.0, data.cutColor
end

---@param lamp M1RelayLampEntry
---@param intensity number
---@param color M1RelayLampColor
function RelayLamp:ApplyColor(lamp, intensity, color)
    local brightness = intensity / self.data.maxIntensity
    if brightness < 0.0 then brightness = 0.0 end
    if brightness > 1.0 then brightness = 1.0 end
    lamp.brightness = brightness
    lamp.material:SetShaderParameter("MatDiffColor", Variant(Color(color.r * brightness,
        color.g * brightness, color.b * brightness, 1.0)))
end

---@param dt number
function RelayLamp:Update(dt)
    for index = 1, #self.entries do
        local lamp = self.entries[index] --[[@as M1RelayLampEntry]]
        local intensity, color = self:Sample(lamp, dt)
        self:ApplyColor(lamp, intensity, color)
    end
end

--- 探针：三盏灯的当前状态与亮度，自检「标记」按钮与交付说明共用。
---@return string
function RelayLamp:Probe()
    local parts = {}
    for index = 1, #self.entries do
        local lamp = self.entries[index] --[[@as M1RelayLampEntry]]
        parts[#parts + 1] = string.format("%s=%s/%.2f", lamp.short, lamp.state, lamp.brightness)
    end
    local text = string.format("%s[PROBE] -> OK | %s", TAG, table.concat(parts, " "))
    print(text)
    return text
end

function RelayLamp:Destroy()
    for index = 1, #self.entries do
        local lamp = self.entries[index] --[[@as M1RelayLampEntry]]
        if lamp.original ~= nil then
            lamp.model:SetMaterial(lamp.original)
        end
    end
    print(string.format("%s -> OK | event=destroy lamps=%d", TAG, #self.entries))
end

return RelayLamp