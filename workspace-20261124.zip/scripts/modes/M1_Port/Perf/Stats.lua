-- modes/M1_Port/Perf/Stats.lua: 帧率与场景规模采样，只测量、不改画面；自检「性能」与定时共用。
-- 依据：docs/交接与台账.md 2026-11-24「场景静态模型 1022 个（未按材质合并网格），移动端帧率未知」，
-- 与第 32 节「该出现的东西没出现、看完代码找不到原因时先上探针取实际值」。合并网格前必须先有两个数字。
local TAG = "[M1][PERF]"

-- 采样周期（秒）。日志内容带数值，不受「相同内容限次」影响。
local INTERVAL = 10.0

---@class M1PerfWalk
---@field nodes integer
---@field static integer
---@field lights integer

---@class M1PerfStats
---@field scene Scene|nil
---@field frames integer
---@field elapsed number
local Stats = {}
Stats.__index = Stats

--- 引擎绘制批次统计：1.35 未必有该字段，探测失败记 -1（第 20 节第 2 条，结果记 NONE）。
---@return integer
local function BatchCount()
    local ok, value = pcall(function()
        ---@diagnostic disable-next-line: undefined-field
        return renderer.numBatches
    end)
    if ok and type(value) == "number" then
        return math.floor(value)
    end
    return -1
end

--- 递归数节点树；组件读取失败会带 err 返回，不吞（第 28 节第 3 条）。
---@param node Node
---@param acc M1PerfWalk
---@return boolean ok
---@return string|nil err
local function Walk(node, acc)
    acc.nodes = acc.nodes + 1
    local okStatic, staticModel = pcall(function() return node:GetComponent("StaticModel") end)
    if not okStatic then
        return false, "static:" .. tostring(staticModel)
    end
    if staticModel ~= nil then acc.static = acc.static + 1 end
    local okLight, light = pcall(function() return node:GetComponent("Light") end)
    if not okLight then
        return false, "light:" .. tostring(light)
    end
    if light ~= nil then acc.lights = acc.lights + 1 end
    local okChildren, children = pcall(function() return node:GetChildren() end)
    if not okChildren then
        return false, "children:" .. tostring(children)
    end
    ---@cast children Node[]
    for index = 1, #children do
        local okChild, childErr = Walk(children[index], acc)
        if not okChild then return false, childErr end
    end
    return true, nil
end

---@param scene Scene
---@return M1PerfStats
function Stats.Create(scene)
    assert(scene ~= nil, "M1PerfStats requires a scene")
    local self = setmetatable({ scene = scene, frames = 0, elapsed = 0.0 }, Stats)
    print(string.format("%s -> OK | event=create interval=%.0fs", TAG, INTERVAL))
    return self
end

--- 打一行统计。reason 区分定时（interval）与自检按钮（selftest）。
---@param reason string
function Stats:Print(reason)
    local scene = self.scene
    if scene == nil then
        print(string.format("%s[PROBE] -> FAIL | reason=scene-missing", TAG))
        return
    end
    ---@type M1PerfWalk
    local acc = { nodes = 0, static = 0, lights = 0 }
    local okWalk, walkErr = Walk(scene, acc)
    local fps = 0.0
    if self.elapsed > 0.0 then fps = self.frames / self.elapsed end
    local result = okWalk and "OK" or "FAIL"
    -- 1.35 没有绘制批次统计时记 NONE，不记 OK（第 20 节第 3 条）。
    local batches = BatchCount()
    local batchesText = batches >= 0 and string.format("%d", batches) or "NONE"
    print(string.format("%s[PROBE] -> %s | fps=%.1f nodes=%d static=%d lights=%d batches=%s window=%.1fs reason=%s%s",
        TAG, result, fps, acc.nodes, acc.static, acc.lights, batchesText, self.elapsed, reason,
        okWalk and "" or (" err=" .. tostring(walkErr))))
    self.frames = 0
    self.elapsed = 0.0
end

---@param dt number
function Stats:Update(dt)
    self.frames = self.frames + 1
    self.elapsed = self.elapsed + dt
    if self.elapsed >= INTERVAL then
        self:Print("interval")
    end
end

function Stats:Destroy()
    self.scene = nil
    print(string.format("%s -> OK | event=destroy", TAG))
end

return Stats
