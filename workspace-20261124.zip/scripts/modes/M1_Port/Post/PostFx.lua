-- 后处理总控（原作 04-postfx）：把原作 20 段后处理链里引擎 Zone 真实具备的开关接上。
-- 每一项都有独立开关（PostFx:GetToggles / PostFx:Toggle），关时写回引擎默认值，
-- 真机上可逐项单独开关、看单项对画面的贡献。
-- 不支持、或 1.35 运行时没有的属性逐项记 NONE（第 20 节能力探测），不摆假开关（第 28 节）。
-- 数值一律来自 Data/PostFx.lua，本文件只做探测、写入、回读、开关与日志。
local TAG = "[M1]"

-- 暗角贴图边长。2026-11-24 本机 A/B：只写 vignetteEnabled/vignetteIntensity、不给贴图时，
-- 属性回读全部 OK 但画面亮度无可测变化 —— 空贴图不绘制，所以必须自建一张。
local VIGNETTE_SIZE = 64

-- 各属性「关」时写回的值。来源：engine-docs/recipes/post-processing.md 的默认值表与 Zone.d.lua 字段注释；
-- 例外是 bloomUEIntensity：引擎默认 0.675 比本作目标值 0.15 更亮，写默认值等于开得更强，
-- 所以它的「关」定义为 0.0（该项不再对画面贡献泛光）。
local OFF_VALUES = {
    bloomMode = BLOOM_MODE_LEGACY,       -- 文档：默认 BLOOM_MODE_LEGACY
    bloomUEIntensity = 0.0,              -- 关 = 强度 0；不是引擎默认 0.675（那会更亮）
    bloomUEThreshold = -1.0,             -- 文档：默认 -1，≤ -1 表示不设阈值
    bloomUESizeScale = 4.0,              -- 文档：默认 4
    tonemapMode = TONEMAP_MODE_LUT,      -- 文档：默认 LUT
    autoExposureEnabled = false,
    autoExposurePlusEnabled = false,
    autoExposureMinBrightness = -10.0,   -- 文档：默认 -10
    autoExposureMaxBrightness = 20.0,    -- 文档：默认 20
    autoExposureBias = 0.0,
    autoExposureSpeedUp = 3.0,
    autoExposureSpeedDown = 1.0,
    autoExposureForceTarget = false,
    vignetteEnabled = false,
    vignetteIntensity = 0.0,
}

---@class M1PostFxToggle
---@field key string Zone 属性名
---@field label string 自检按钮文字
---@field step string 日志操作名
---@field onValue any 开时写入
---@field offValue any 关时写回的值
---@field on boolean 当前是否开启
---@field noDelta boolean 关值与开值相同，切换不改变画面（日志会明说）

---@class M1PostFx
---@field zone Zone 场景 Zone，后处理属性都挂在它上面
---@field data M1PostFxData Data/PostFx 的数值表
---@field probed integer 探测过的属性数
---@field applied integer 写入后回读一致的属性数
---@field toggles M1PostFxToggle[] 逐项开关表，顺序即面板顺序
---@field vignetteOn Texture2D|nil 自建暗角贴图（开）
---@field vignetteOff Texture2D|nil 白色占位贴图（关：不加深）
local PostFx = {}
PostFx.__index = PostFx

-- 动态属性探测：属性名在运行时才确定，且 1.35 与 .emmylua（1.38+）声明不一致，
-- 只能按名字试探；写入与回读都包 pcall，任何一步失败都按不支持处理。
---@param target Zone 场景 Zone 组件
---@param key string 属性名
---@param want any 目标值
---@return boolean ok, any actual
local function TryWrite(target, key, want)
    local obj = target --[[@as any]]
    if not pcall(function() obj[key] = want end) then
        return false, nil
    end
    local okGet, got = pcall(function() return obj[key] end)
    if not okGet then
        return false, nil
    end
    return true, got
end

---@param got any 回读值
---@param want any 目标值
---@return boolean
local function Near(got, want)
    if type(want) == "number" and type(got) == "number" then
        return math.abs(got - want) <= math.abs(want) * 0.02 + 1e-6
    end
    return got == want
end

---@param value any
---@return string
local function Show(value)
    if type(value) == "number" then
        return string.format("%.3f", value)
    end
    return tostring(value)
end

-- 开关值与关值等价时（例如阈值本来就取引擎默认 -1），切换不改变任何东西；
-- 这种项照样保留按钮，但状态与日志会写成 noDelta，不让人误以为在切一个真效果。
---@param onValue any
---@param offValue any
---@return boolean
local function SameValue(onValue, offValue)
    if type(onValue) == "number" and type(offValue) == "number" then
        return math.abs(onValue - offValue) <= 1e-6
    end
    return onValue == offValue
end

-- 径向暗角贴图：中心白、alpha 0；边缘灰（1-0.6）、alpha 1。
-- 这样不管是「乘算」还是「按 alpha 混合」语义，结果都是中心不变、边缘变暗。
---@param size integer
---@param dark number 边缘灰度下限（1 表示不透暗）
---@return Texture2D
local function MakeRadialTexture(size, dark)
    local image = Image:new()
    image:SetSize(size, size, 4)
    local half = (size - 1) * 0.5
    for y = 0, size - 1 do
        for x = 0, size - 1 do
            local dx = (x - half) / half
            local dy = (y - half) / half
            local radius = math.sqrt(dx * dx + dy * dy)
            local t = math.min(1.0, math.max(0.0, (radius - 0.55) / 0.45))
            local smooth = t * t * (3.0 - 2.0 * t)
            local gray = 1.0 - dark * smooth
            image:SetPixel(x, y, Color(gray, gray, gray, smooth))
        end
    end
    local texture = Texture2D:new()
    texture:SetData(image, true)
    return texture
end

-- 1×1 白色不透明占位：作为「关」时的贴图，乘算/混合都不改变画面。
---@return Texture2D
local function MakeWhiteTexture()
    local image = Image:new()
    image:SetSize(1, 1, 4)
    image:SetPixel(0, 0, Color(1.0, 1.0, 1.0, 0.0))
    local texture = Texture2D:new()
    texture:SetData(image, true)
    return texture
end

-- 写一项并立刻回读：只证明赋值没报错不算生效（第 30 节），回读不一致照样记 NONE。
---@param step string 日志里的操作名
---@param key string 属性名
---@param want any 目标值
---@return boolean
function PostFx:Write(step, key, want)
    if want == nil then
        print(string.format("%s[POST][%s] -> NONE | key=%s reason=value-missing", TAG, step, key))
        return false
    end
    local ok, got = TryWrite(self.zone, key, want)
    if not ok then
        print(string.format("%s[POST][%s] -> NONE | key=%s reason=attribute-rejected", TAG, step, key))
        return false
    end
    local same = Near(got, want)
    print(string.format("%s[POST][%s] -> %s | key=%s want=%s got=%s",
        TAG, step, same and "OK" or "NONE", key, Show(want), Show(got)))
    return same
end

---@param step string
---@param label string
---@param key string
---@param onValue any
---@param offValue any|nil 显式关值（贴图类用）；nil 时取 OFF_VALUES[key]
---@return M1PostFxToggle
function PostFx:NewToggle(step, label, key, onValue, offValue)
    local off = offValue
    if off == nil then
        off = OFF_VALUES[key]
    end
    assert(off ~= nil, "PostFx toggle missing OFF value for " .. key)
    return {
        key = key,
        label = label,
        step = step,
        onValue = onValue,
        offValue = off,
        on = true,
        noDelta = SameValue(onValue, off),
    }
end

function PostFx:ApplyOnce()
    local data = self.data
    ---@type M1PostFxToggle[]
    local toggles = {
        self:NewToggle("BLOOM", "泛光模式", "bloomMode", BLOOM_MODE_UE),
        self:NewToggle("BLOOM", "泛光强度", "bloomUEIntensity", data.bloomIntensity),
        self:NewToggle("BLOOM", "泛光阈值", "bloomUEThreshold", data.bloomThreshold),
        self:NewToggle("BLOOM", "泛光范围", "bloomUESizeScale", data.bloomSizeScale),
        self:NewToggle("TONEMAP", "色调映射", "tonemapMode", TONEMAP_MODE_ACES),
        self:NewToggle("EXPOSURE", "曝光开关", "autoExposureEnabled", data.exposureEnabled),
        self:NewToggle("EXPOSURE", "曝光直方图", "autoExposurePlusEnabled", data.exposureEnabled),
        self:NewToggle("EXPOSURE", "曝光下限", "autoExposureMinBrightness", data.exposureMinEV),
        self:NewToggle("EXPOSURE", "曝光上限", "autoExposureMaxBrightness", data.exposureMaxEV),
        self:NewToggle("EXPOSURE", "曝光补偿", "autoExposureBias", data.exposureBias),
        self:NewToggle("EXPOSURE", "适应变亮", "autoExposureSpeedUp", data.exposureSpeed),
        self:NewToggle("EXPOSURE", "适应变暗", "autoExposureSpeedDown", data.exposureSpeed),
        self:NewToggle("EXPOSURE", "锁曝光", "autoExposureForceTarget", data.exposureForceTarget),
    }

    -- 暗角：贴图建不出来就整条跳过（两个开关都不建，避免开出假开关）。
    local okOn, vignetteOn = pcall(MakeRadialTexture, VIGNETTE_SIZE, 0.6)
    local okOff, vignetteOff = pcall(MakeWhiteTexture)
    if okOn and okOff and vignetteOn ~= nil and vignetteOff ~= nil then
        self.vignetteOn = vignetteOn
        self.vignetteOff = vignetteOff
        local textureToggle = self:NewToggle("VIGNETTE", "暗角贴图", "vignetteTexture", vignetteOn, vignetteOff)
        toggles[#toggles + 1] = textureToggle
        toggles[#toggles + 1] = self:NewToggle("VIGNETTE", "暗角开关", "vignetteEnabled", true)
        toggles[#toggles + 1] = self:NewToggle("VIGNETTE", "暗角强度", "vignetteIntensity", data.vignetteBase)
    else
        print(string.format("%s[POST][VIGNETTE] -> NONE | reason=texture-build-failed", TAG))
    end

    self.toggles = toggles
    self.probed = 0
    self.applied = 0
    for index = 1, #toggles do
        local toggle = toggles[index]
        self.probed = self.probed + 1
        if self:Write(toggle.step, toggle.key, toggle.onValue) then
            self.applied = self.applied + 1
        else
            toggle.on = false
        end
    end
    print(string.format("%s[POST][APPLY] -> %s | applied=%d probed=%d toggles=%d",
        TAG, self.applied == self.probed and "OK" or "NONE", self.applied, self.probed, #toggles))
end

---@param key string
---@return M1PostFxToggle
function PostFx:FindToggle(key)
    for index = 1, #self.toggles do
        local toggle = self.toggles[index]
        if toggle.key == key then
            return toggle
        end
    end
    error("PostFx has no toggle for " .. key)
end

---@param key string
---@return M1PostFxToggle
function PostFx:GetToggle(key)
    local toggle = self:FindToggle(key)
    return toggle
end

---@return M1PostFxToggle[]
function PostFx:GetToggles()
    return self.toggles
end

-- 翻转一项：关时写回引擎默认值，开时写回本作目标值，回读结果决定 on 状态是否成立。
---@param key string
---@return M1PostFxToggle
function PostFx:Toggle(key)
    local toggle = self:FindToggle(key)
    local wantOn = not toggle.on
    local target = wantOn and toggle.onValue or toggle.offValue
    local ok = self:Write(toggle.step, toggle.key, target)
    if ok then
        toggle.on = wantOn
    end
    if toggle.noDelta then
        print(string.format("%s[POST][TOGGLE] -> %s | key=%s on=%s noDelta=true note=开值与引擎默认相同，切换不改变画面",
            TAG, ok and "OK" or "FAIL", key, tostring(toggle.on)))
    else
        print(string.format("%s[POST][TOGGLE] -> %s | key=%s on=%s want=%s",
            TAG, ok and "OK" or "FAIL", key, tostring(toggle.on), Show(target)))
    end
    return toggle
end

-- 自检「后处理」按钮入口：打生效项数、逐项开关状态，再回读五项关键属性。
function PostFx:Probe()
    local zone = self.zone --[[@as any]]
    print(string.format("%s[POST][PROBE] -> OK | applied=%d probed=%d toggles=%d",
        TAG, self.applied, self.probed, #self.toggles))
    for index = 1, #self.toggles do
        local toggle = self.toggles[index]
        print(string.format("%s[POST][STATE] -> OK | key=%s on=%s noDelta=%s",
            TAG, toggle.key, tostring(toggle.on), tostring(toggle.noDelta)))
    end
    ---@type string[]
    local keys = { "bloomMode", "bloomUEIntensity", "tonemapMode", "autoExposureBias", "vignetteIntensity" }
    for index = 1, #keys do
        local key = keys[index]
        local ok, got = pcall(function() return zone[key] end)
        print(string.format("%s[POST][READ] -> %s | key=%s value=%s",
            TAG, ok and "OK" or "FAIL", key, ok and Show(got) or "read-failed"))
    end
end

-- 本模块不建节点、不订阅事件、不持有定时器；只持有两张自建贴图，关闭时释放引用（第 16 节）。
function PostFx:Dispose()
    self.vignetteOn = nil
    self.vignetteOff = nil
    print(string.format("%s[POST][DISPOSE] -> OK | applied=%d probed=%d toggles=%d",
        TAG, self.applied, self.probed, #self.toggles))
end

---@param zone Zone
---@param data M1PostFxData
---@return M1PostFx
function PostFx.Apply(zone, data)
    assert(zone ~= nil, "M1 PostFx requires the scene zone")
    assert(data ~= nil, "M1 PostFx requires Data/PostFx values")
    local self = setmetatable({
        zone = zone,
        data = data,
        probed = 0,
        applied = 0,
        toggles = {},
        vignetteOn = nil,
        vignetteOff = nil,
    }, PostFx)
    self:ApplyOnce()
    return self
end

return PostFx