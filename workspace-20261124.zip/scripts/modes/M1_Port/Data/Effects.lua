-- 命中特效数值：枪口光、曳光、火花。
-- 来源：12-effects 语句 10。

---@class M1WeaponEffectsData
---@field tracerTtl number
---@field tracerWidth number
---@field flashTtl number
---@field flashColor Color
---@field flashBrightness number
---@field flashRange number
---@field flashMeshScale number
---@field flashMeshColor [integer, integer, integer]
---@field tracerColor [integer, integer, integer]
---@field sparkTtl number
---@field sparkScale number
---@field sparkColor [integer, integer, integer]

---@type M1WeaponEffectsData
local EffectsData = {
    tracerTtl = 0.05,
    tracerWidth = 0.012,
    flashTtl = 0.05,
    flashColor = Color(1.0, 0.69, 0.376, 1.0),
    flashBrightness = 2.0,
    flashRange = 9,
    flashMeshScale = 0.12,
    flashMeshColor = {255, 200, 120},
    tracerColor = {255, 210, 150},
    sparkTtl = 0.12,
    sparkScale = 0.06,
    sparkColor = {255, 150, 70},
}

return EffectsData
