-- 生命 HUD 布局：生命条、受伤脉冲与低血配色。
-- 来源：本项目 HUD 布局（原作 18-hud 的生命条在 ui.css `.h-hp` 里，逐值对齐留到 P4）。

---@class M1StatusHudBar
---@field width number
---@field height number
---@field marginLeft number
---@field marginBottom number
---@field fontSize number
---@field textGap number
---@field bgColor [integer, integer, integer, integer]
---@field fillColor [integer, integer, integer, integer]
---@field lowColor [integer, integer, integer, integer]
---@field deadColor [integer, integer, integer, integer]
---@field textColor [integer, integer, integer, integer]

---@class M1StatusHudEdge
---@field maxAlpha integer
---@field thickness number
---@field color [integer, integer, integer]

---@class M1StatusHudData
---@field bar M1StatusHudBar
---@field edge M1StatusHudEdge

---@type M1StatusHudData
local StatusHud = {
    bar = {
        width = 260,
        height = 14,
        marginLeft = 46,
        marginBottom = 150,
        fontSize = 16,
        textGap = 6,
        bgColor = { 12, 14, 16, 170 },
        fillColor = { 214, 218, 224, 235 },
        lowColor = { 224, 64, 64, 235 },
        deadColor = { 120, 40, 40, 235 },
        textColor = { 236, 238, 240, 235 },
    },
    edge = {
        maxAlpha = 110,
        thickness = 26,
        color = { 200, 32, 32 },
    },
}

return StatusHud
