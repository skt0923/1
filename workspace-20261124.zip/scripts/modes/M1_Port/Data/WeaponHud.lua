-- 武器 HUD 布局：准星尺寸与弹药文字排版。
-- 来源：18-hud 语句 1。

---@class M1WeaponHudCrosshair
---@field size number
---@field gap number
---@field thickness number
---@field dotRadius number
---@field color [integer, integer, integer, integer]

---@class M1WeaponHudAmmo
---@field fontSize number
---@field stateFontSize number
---@field rightMargin number
---@field topMargin number
---@field color [integer, integer, integer, integer]
---@field lowColor [integer, integer, integer, integer]
---@field reloadColor [integer, integer, integer, integer]

---@class M1WeaponHudData
---@field crosshair M1WeaponHudCrosshair
---@field ammo M1WeaponHudAmmo

---@type M1WeaponHudData
local WeaponHudData = {
    crosshair = {
        size = 18,
        gap = 6,
        thickness = 3,
        dotRadius = 3,
        color = {255, 255, 255, 220},
    },
    ammo = {
        fontSize = 40,
        stateFontSize = 20,
        rightMargin = 132,
        topMargin = 28,
        color = {255, 255, 255, 235},
        lowColor = {255, 90, 80, 255},
        reloadColor = {255, 200, 120, 255},
    },
}

return WeaponHudData
