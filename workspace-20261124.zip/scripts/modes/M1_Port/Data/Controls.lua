-- 触屏操控数值：视角灵敏度与开火/换弹按钮布局。
-- 来源：14-input 语句 v_（按钮布局）、13-audio 语句 9（灵敏度）。
-- 2026-11-24 本地截图：原先三钮与 urhox-libs GameHUD 的 Run/Jump 圆钮重叠（开火压 Run、换弹压第三人称），
-- 整体上移 110 像素拉开垂直距离；偏移仍相对右下角，换分辨率不变。

---@class M1TouchButtonData
---@field position Vector2
---@field radius number
---@field label string
---@field color [integer, integer, integer]
---@field pressedColor [integer, integer, integer]
---@field opacity number
---@field activeOpacity number

---@class M1CombatButtonsData
---@field fire M1TouchButtonData
---@field reload M1TouchButtonData

---@class M1ControlsData
---@field lookSensitivity number Radians per pixel.
---@field combatButtons M1CombatButtonsData
---@field viewButton M1TouchButtonData
---@field interactButton M1TouchButtonData

---@type M1ControlsData
local Controls = {
    lookSensitivity = 0.0021,
    combatButtons = {
        fire = {
            position = Vector2(-330, -430),
            radius = 56,
            label = "开火",
            color = {255, 100, 100},
            pressedColor = {255, 150, 150},
            opacity = 0.5,
            activeOpacity = 0.9,
        },
        reload = {
            position = Vector2(-330, -560),
            radius = 56,
            label = "换弹",
            color = {100, 255, 100},
            pressedColor = {150, 255, 150},
            opacity = 0.5,
            activeOpacity = 0.9,
        },
    },
    -- 中继交互：在换弹与视角钮之间，避开 GameHUD 的 Crouch/Run/Jump（2026-11-24 截图核对）。
    interactButton = {
        position = Vector2(-180, -430),
        radius = 48,
        label = "交互",
        color = {255, 220, 120},
        pressedColor = {255, 235, 170},
        opacity = 0.5,
        activeOpacity = 0.9,
    },
    viewButton = {
        position = Vector2(-180, -560),
        radius = 48,
        label = "第三人称",
        color = {120, 200, 255},
        pressedColor = {170, 220, 255},
        opacity = 0.5,
        activeOpacity = 0.9,
    },
}

return Controls
