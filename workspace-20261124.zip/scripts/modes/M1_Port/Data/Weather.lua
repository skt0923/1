-- 天气数值：雨、雨溅、地面湿润。
-- 来源：11-ground 的雨（雨量 0..1 渐变、风向偏移、室内剔除）与 11-ground 雨溅；
-- 湿地面按 engine-docs/recipes/deferred-scene-weather-lighting.md 4.4 的思路，改到本项目自己的
-- BakedSurface 材质上（无 SSR，水洼只靠高光体现，差异见任务卡 m1-p4b-weather 第 2 条）。

---@class M1WeatherData
---@field rainLevel number 目标雨量 0..1（原作 setRain 的默认档）
---@field rainRampSeconds number 雨量渐变时间（原作按 1/w*0.8 收敛，这里给固定秒数）
---@field rainParticles integer 雨丝粒子数
---@field rainRate number 发射率（每秒），约等于 particles / ttl
---@field rainSpeedMin number
---@field rainSpeedMax number
---@field rainTtlMin number
---@field rainTtlMax number
---@field rainBox Vector3 发射盒尺寸（米），以相机为锚点
---@field rainFollowHeight number 发射盒离地在相机上方的高度
---@field rainWidth number 雨丝宽度（米，U）
---@field rainLength number 雨丝长度（米，V）
---@field wind Vector3 风向与强度（加在方向上的偏移）
---@field streakPixelsX integer 雨丝贴图宽
---@field streakPixelsY integer 雨丝贴图高
---@field splashParticles integer
---@field splashRate number
---@field splashBox Vector3
---@field splashSpeedMin number
---@field splashSpeedMax number
---@field splashTtl number
---@field splashSizeMin number
---@field splashSizeMax number
---@field wetnessRampSeconds number 地面湿润渐变时间

---@type M1WeatherData
local WeatherData = {
    rainLevel = 0.7,
    rainRampSeconds = 2.5,
    rainParticles = 3000,
    rainRate = 3000.0,
    rainSpeedMin = 22.0,
    rainSpeedMax = 28.0,
    rainTtlMin = 0.85,
    rainTtlMax = 1.15,
    rainBox = Vector3(70.0, 2.0, 70.0),
    rainFollowHeight = 13.0,
    rainWidth = 0.02,
    rainLength = 0.55,
    -- 风向：(0.12, -1, 0.05) 归一后带横向偏移，与原作的斜雨一致
    wind = Vector3(0.14, -1.0, 0.06),
    streakPixelsX = 8,
    streakPixelsY = 64,

    splashParticles = 320,
    splashRate = 900.0,
    splashBox = Vector3(24.0, 0.2, 24.0),
    splashSpeedMin = 1.2,
    splashSpeedMax = 2.6,
    splashTtl = 0.28,
    splashSizeMin = 0.02,
    splashSizeMax = 0.07,

    wetnessRampSeconds = 4.0,
}

return WeatherData