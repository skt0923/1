-- 武器数值与第一人称视图锚点：弹匣、射速、伤害、散布、后座、视图盒体与材质。
-- 来源：16-weapon 语句 1（fC,mi）、语句 28（gi,fm,Gv,B_,O_,H_,V_,eu,qv,tu,nu,W_,G_,Yo,pa）。
-- 视图几何为 P0 简化盒体（任务卡 m1-p0b-weapon 差异 1），P4 换回完整 PAC-9 建模。
-- HUD 布局见 WeaponHud.lua，命中特效见 Effects.lua。

---@class M1WeaponHandMount
---@field position Vector3 Offset from the right-hand bone.
---@field rotation Vector3 Euler offset in radians.

---@class M1WeaponViewPart
---@field position Vector3
---@field rotation Vector3
---@field scale Vector3

---@class M1ViewArm
---@field from Vector3 Forearm start in camera space.
---@field to Vector3 Forearm end (near the gun) in camera space.
---@field radius number
---@field color [number, number, number]

---@class M1ViewGlove
---@field position Vector3
---@field half Vector3 Half extents.
---@field color [number, number, number]

---@class M1ViewModelData
---@field gunPosition Vector3 Gun root in camera space.
---@field gunYaw number Degrees; the gun model's own forward is -Z.
---@field arms M1ViewArm[]
---@field gloves M1ViewGlove[]

---@class M1WeaponData
---@field name string
---@field magSize integer
---@field reserve integer
---@field rpm number
---@field damage number
---@field range number
---@field reloadTime number
---@field emptyReloadTime number
---@field reloadMagOut number
---@field reloadMagIn number
---@field autoReloadDelay number
---@field baseSpread number
---@field moveSpread number
---@field bloomSpread number
---@field airSpread number
---@field crouchSpread number
---@field speedRef number
---@field bloomPerShot number
---@field bloomDecay number
---@field maxCatchupShots integer
---@field cooldownFloor number
---@field firingWindow number
---@field lowAmmoFraction number
---@field muzzleLocal Vector3
---@field handMount M1WeaponHandMount
---@field viewModel M1ViewModelData
---@field viewColor [number, number, number]
---@field viewSpecColor [number, number, number]
---@field viewMetallic number
---@field viewRoughness number
---@field viewParts M1WeaponViewPart[]

---@type M1WeaponData
local WeaponData = {
    name = "几猫九式突击步枪",
    magSize = 30,
    reserve = 150,
    rpm = 720,
    damage = 26,
    range = 300,
    reloadTime = 2.1,
    emptyReloadTime = 2.72,
    reloadMagOut = 0.47,
    reloadMagIn = 1.345,
    autoReloadDelay = 0.32,
    baseSpread = 0.0125,
    moveSpread = 0.013,
    bloomSpread = 0.0065,
    airSpread = 0.022,
    crouchSpread = 0.002,
    speedRef = 6,
    bloomPerShot = 0.17,
    bloomDecay = 1.5,
    maxCatchupShots = 3,
    cooldownFloor = -0.001,
    firingWindow = 0.14,
    lowAmmoFraction = 0.27,
    muzzleLocal = Vector3(0, 0, -0.531),
    handMount = {position = Vector3(0, 0, 0), rotation = Vector3(0, 180, 0)},
    -- 第一人称视图模型：原作 16-weapon 的 sleeve/glove/forearm 简化移植（方块手臂 + 方块手套）
    -- 坐标是相机空间，+Z 为前；数值为 e9 首版估值，真机按截图调
    viewModel = {
        gunPosition = Vector3(0.16, -0.15, 0.40),
        gunYaw = 180,
        arms = {
            { from = Vector3(0.34, -0.42, 0.02), to = Vector3(0.18, -0.19, 0.31), radius = 0.048, color = {0.86, 0.78, 0.70} },
            { from = Vector3(-0.26, -0.46, 0.10), to = Vector3(0.02, -0.17, 0.47), radius = 0.044, color = {0.86, 0.78, 0.70} },
        },
        gloves = {
            { position = Vector3(0.17, -0.18, 0.34), half = Vector3(0.045, 0.055, 0.070), color = {0.20, 0.22, 0.25} },
            { position = Vector3(0.02, -0.16, 0.49), half = Vector3(0.042, 0.050, 0.065), color = {0.20, 0.22, 0.25} },
        },
    },
    viewColor = {0.24, 0.25, 0.27},
    viewSpecColor = {0.55, 0.55, 0.56},
    viewMetallic = 0.55,
    viewRoughness = 0.42,
    viewParts = {
        {position = Vector3(0, 0, -0.10), rotation = Vector3.ZERO, scale = Vector3(0.070, 0.100, 0.420)},
        {position = Vector3(0, 0, -0.40), rotation = Vector3.ZERO, scale = Vector3(0.032, 0.032, 0.300)},
        {position = Vector3(0, 0, -0.26), rotation = Vector3.ZERO, scale = Vector3(0.055, 0.055, 0.180)},
        {position = Vector3(0, -0.090, -0.040), rotation = Vector3.ZERO, scale = Vector3(0.045, 0.120, 0.060)},
        {position = Vector3(0, -0.075, 0.060), rotation = Vector3(-0.3, 0, 0), scale = Vector3(0.040, 0.100, 0.050)},
    },
}

return WeaponData
