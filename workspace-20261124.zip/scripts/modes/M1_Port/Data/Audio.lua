-- 音效事件表（P4-E 首批 5 个）。
-- 来源与差异：原作 13-audio 用 WebAudio 程序化合成约 50 个事件；本作用 Python 生成等长 WAV
-- 再由引擎播（本地工具 `tools/gen_audio.py`，确定性种子可重跑；该目录被 .gitignore 忽略，WAV 已入库），事件划分与音色不是原作逐个复刻，
-- 全部登记在任务卡 m1-p4e-audio 的差异表里。数值单位为线性音量与 pitch 倍率。

---@class M1AudioEvent
---@field file string 资源根下的路径（assets 是资源根，故写 Sounds/xxx.wav）
---@field gain number 基础音量 0..1
---@field pitchMin number 每次播放的 pitch 下限
---@field pitchMax number 每次播放的 pitch 上限
---@field loop? boolean 循环播放（环境声）

---@class M1AudioData
---@field poolVoices integer 2D 声部池大小
---@field order string[] 探针打印顺序（表键无序，日志要可读）
---@field events table<string, M1AudioEvent>

---@type M1AudioData
local AudioData = {
    poolVoices = 8,
    order = { "rifle_fire", "rifle_dry", "reload_out", "reload_in", "rain" },
    events = {
        rifle_fire = { file = "Sounds/rifle_fire.wav", gain = 0.85, pitchMin = 0.94, pitchMax = 1.06 },
        rifle_dry = { file = "Sounds/rifle_dry.wav", gain = 0.60, pitchMin = 0.98, pitchMax = 1.02 },
        reload_out = { file = "Sounds/reload_out.wav", gain = 0.55, pitchMin = 0.95, pitchMax = 1.05 },
        reload_in = { file = "Sounds/reload_in.wav", gain = 0.60, pitchMin = 0.95, pitchMax = 1.05 },
        rain = { file = "Sounds/rain_loop.wav", gain = 0.35, pitchMin = 1.00, pitchMax = 1.00, loop = true },
    },
}

return AudioData