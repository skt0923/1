-- 命中表现数值：弹痕贴花、碎屑、火花、弹壳。
-- 来源：12-effects 语句 1 的贴花尺寸表 ZR = {bullet_metal:.25, bullet_concrete:.34, bullet_wood:.24,
--        scorch:2.4, soot:.3, bullet_glass:.3}，以及同一语句里按表面分派的碎屑/火花数量与速度。
-- 差异：池容量按本机性能压小（原作 160/256/3200），逐个登记在任务卡 m1-p4a-impact。

---@class M1ImpactSurfaceData
---@field decal string 贴图名
---@field decalSize number 贴花边长（米，原作 ZR）
---@field debris integer 碎屑数量
---@field sparks integer 火花数量
---@field color [integer, integer, integer] 火花颜色
---@field speed number 碎屑初速（米/秒）

---@class M1ImpactFxData
---@field decalCap integer 贴花池容量（超过后覆盖最旧的一张）
---@field debrisCap integer
---@field sparkCap integer
---@field shellCap integer
---@field debrisTtl number
---@field sparkTtl number
---@field shellTtl number
---@field gravity number 碎屑与弹壳的重力（米/秒²）
---@field debrisScale number
---@field sparkScale number
---@field sparkColor [integer, integer, integer]
---@field shellSize Vector3 弹壳尺寸（米）
---@field shellSpeed number
---@field shellColor [integer, integer, integer]
---@field textureSize integer 贴图边长（像素）
---@field surfaces table<string, M1ImpactSurfaceData>
---@field nameKeys { key: string, surface: string }[] 道具名子串 → 表面类型，按顺序匹配
---@field defaultSurface string

---@type M1ImpactFxData
local ImpactFxData = {
    decalCap = 48,
    debrisCap = 32,
    sparkCap = 24,
    shellCap = 12,
    debrisTtl = 0.55,
    sparkTtl = 0.18,
    shellTtl = 1.4,
    gravity = 9.8,
    debrisScale = 0.035,
    sparkScale = 0.03,
    sparkColor = { 255, 170, 90 },
    shellSize = Vector3(0.012, 0.012, 0.03),
    shellSpeed = 2.2,
    shellColor = { 214, 168, 82 },
    textureSize = 64,

    surfaces = {
        metal = {
            decal = "bullet_metal",
            decalSize = 0.25,
            debris = 10,
            sparks = 16,
            color = { 255, 220, 160 },
            speed = 5.5,
        },
        concrete = {
            decal = "bullet_concrete",
            decalSize = 0.34,
            debris = 14,
            sparks = 8,
            color = { 220, 210, 190 },
            speed = 4.5,
        },
        wood = {
            decal = "bullet_wood",
            decalSize = 0.24,
            debris = 9,
            sparks = 4,
            color = { 200, 160, 100 },
            speed = 4.0,
        },
        glass = {
            decal = "bullet_glass",
            decalSize = 0.30,
            debris = 12,
            sparks = 2,
            color = { 235, 245, 255 },
            speed = 5.0,
        },
    },

    -- 名字命中即停：越具体的放前面
    nameKeys = {
        { key = "container", surface = "metal" },
        { key = "gantry_crane", surface = "metal" },
        { key = "cargo_ship", surface = "metal" },
        { key = "shelf_rack", surface = "metal" },
        { key = "relay_node", surface = "metal" },
        { key = "fence_panel", surface = "metal" },
        { key = "bollard", surface = "metal" },
        { key = "gate_arm", surface = "metal" },
        { key = "guard_booth", surface = "glass" },
        { key = "crate", surface = "wood" },
        { key = "pallet", surface = "wood" },
        { key = "cardboard", surface = "wood" },
    },
    defaultSurface = "concrete",
}

return ImpactFxData