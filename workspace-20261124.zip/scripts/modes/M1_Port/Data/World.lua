-- 世界数值：边界、地面高度、海平面、码头线与救援余量。
-- 来源：00-config 语句 1（oi）。

---@class M1WorldBounds
---@field minX number
---@field maxX number
---@field minY number
---@field maxY number
---@field minZ number
---@field maxZ number

---@class M1WorldData : RigWorld
---@field bounds M1WorldBounds
---@field groundY number
---@field safeMinY number
---@field seaY number
---@field quayX number
---@field boundsPadding number
---@field safeMargin number
---@field rescueDepth number

---@type M1WorldData
local WorldData = {
    bounds = { minX = -40, maxX = 40, minY = 0, maxY = 30, minZ = -30, maxZ = 30 },
    groundY = 0,
    safeMinY = -0.5,
    seaY = -1.6,
    quayX = 30,
    boundsPadding = 0.4,
    safeMargin = 1.2,
    rescueDepth = 2.2,
}

return WorldData
