-- 流程数值：来源 docs/source/3a/parts/20-flow.part.js 语句 1 的 Yi 配置与语句 14 的评级算式。
-- 评级名与阈值逐字取自原作：Y = (time<270?2:time<400?1:0) + (acc>=.5?2:acc>=.3?1:0) + (retries===0?1:0)。
local Flow = {
    introSeconds = 3.5,
    retryIntroSeconds = 1.3,
    interactRange = 2.2,
    interactFacing = 0.45,
    cutSeconds = 2.4,
    objectiveBase = "切断三处中继",
    objectiveReturn = "返回撤离点",
    -- 本地验证开关：true 时进图自动跑一次「全流程」测试；正式交付保持 false。
    autoRunFlow = false,
    rating = {
        timeFast = 270,
        timeSlow = 400,
        accHigh = 0.5,
        accMid = 0.3,
        names = { "险象环生", "火力全开", "稳扎稳打", "干净利落", "精准果断", "完美突击" },
    },
}

return Flow
