-- 关卡分区：四块区域的地面范围、材质与场内盒体尺寸。
-- 区域划分来源：docs/source/3a/parts/09-level.part.js 语句 4（zones 数组 gate/yard/shed/quay 的矩形）。
-- 出生点来源：同文件语句 4（playerStart pos = -32,0,6，yaw = -PI/2）。
-- 地面材质与门洞位置为推导值，登记在任务卡 m1-p1b-props 差异表。
-- 2026-11-24：1.35 的 Texture2D:SetData 只收 level 0、MipDownCS 别名被拒（kit/TextureBaker 已探测降级），
-- 地面 1024 贴图在 8 米一 tile 下欠采样出黑斑/摩尔纹；地面改用 512 低频贴图集并把 tile 放大，见任务卡 m1-p1c-ground-perf。

---@class M1LevelRect
---@field minX number
---@field maxX number
---@field minZ number
---@field maxZ number

---@class M1LevelRegion
---@field name string 区域名，日志与探针使用。
---@field rect M1LevelRect
---@field material string 该区域地面材质预设名。
---@field uvMeters number

---@class M1LevelBox
---@field name string
---@field minX number
---@field maxX number
---@field minZ number
---@field maxZ number
---@field y number 盒体底面高度。
---@field height number
---@field material string
---@field uvMeters number

---@class M1LevelSpawn
---@field x number
---@field y number
---@field z number

---@class M1LevelMark
---@field x number 中心点。
---@field z number
---@field length number 沿 X 轴长度（rotDeg 为 90 时转成沿 Z 轴）。
---@field width number
---@field rotDeg? number 绕 Y 轴角度。
---@field material? string 缺省 paint_white。

---@class M1LevelData
---@field spawn M1LevelSpawn 出生点，位于大门区、离开所有墙体。
---@field groundThickness number
---@field regions M1LevelRegion[]
---@field boxes M1LevelBox[]
---@field markings M1LevelMark[] 地面标线，薄盒贴在分区地面上 6 毫米。
---@field regionOverlap number 相邻地面分区向内侧外扩的米数，消除接缝黑边。
---@field regionYSink number 每个分区地面下沉的米数，避免重叠处共面打架。
---@field fenceThickness number
---@field fenceHeight number
---@field quayHeight number

---@type M1LevelData
local Level = {
    spawn = { x = -32.0, y = 0.0, z = 6.0 },
    groundThickness = 1.0,
    -- 原作 zones：gate x-40..-24；yard x-24..16 z-10..30；shed x-24..16 z-30..-10；quay x16..40。
    regions = {
        { name = "大门", rect = { minX = -40, maxX = -24, minZ = -30, maxZ = 30 },
            material = "concrete_ground", uvMeters = 10 },
        { name = "堆场", rect = { minX = -24, maxX = 16, minZ = -10, maxZ = 30 },
            material = "asphalt_ground", uvMeters = 12 },
        { name = "仓库", rect = { minX = -24, maxX = 16, minZ = -30, maxZ = -10 },
            material = "epoxy_floor", uvMeters = 8 },
        { name = "码头", rect = { minX = 16, maxX = 40, minZ = -30, maxZ = 30 },
            material = "concrete_ground", uvMeters = 10 },
    },
    -- 仓库壳（四面墙 + 屋顶）：南墙留 6 米门洞（x -3..3），门洞位置为推导值。
    boxes = {
        { name = "仓库西墙", minX = -24, maxX = -23.4, minZ = -30, maxZ = -10, y = 0, height = 8,
            material = "concrete", uvMeters = 4 },
        { name = "仓库东墙", minX = 15.4, maxX = 16, minZ = -30, maxZ = -10, y = 0, height = 8,
            material = "concrete", uvMeters = 4 },
        { name = "仓库北墙", minX = -24, maxX = 16, minZ = -30, maxZ = -29.4, y = 0, height = 8,
            material = "concrete", uvMeters = 4 },
        { name = "仓库南墙西段", minX = -24, maxX = -3, minZ = -10.6, maxZ = -10, y = 0, height = 8,
            material = "corrugated_roof", uvMeters = 3 },
        { name = "仓库南墙东段", minX = 3, maxX = 16, minZ = -10.6, maxZ = -10, y = 0, height = 8,
            material = "corrugated_roof", uvMeters = 3 },
        { name = "仓库屋顶", minX = -24, maxX = 16, minZ = -30, maxZ = -10, y = 8, height = 0.4,
            material = "corrugated_roof", uvMeters = 3 },
        -- 码头边沿：沿海侧 x=40 拉开，防止走进海里。
        { name = "码头边沿", minX = 39.4, maxX = 40, minZ = -30, maxZ = 30, y = 0, height = 1.2,
            material = "concrete", uvMeters = 2 },
    },
    regionOverlap = 0.05,
    regionYSink = 0.002,
    -- 标线：原作者用贴花与漆线绘制，这里用薄盒近似；位置与数量为推导值（差异表第 12 条）。
    markings = {
        -- 大门区：横向车道虚线（相机出生点正前方先看到这条纵向虚线）
        { x = -32, z = -20, length = 3, width = 0.25, rotDeg = 90, material = "paint_yellow" },
        { x = -32, z = -14, length = 3, width = 0.25, rotDeg = 90, material = "paint_yellow" },
        { x = -32, z = -8, length = 3, width = 0.25, rotDeg = 90, material = "paint_yellow" },
        { x = -32, z = -2, length = 3, width = 0.25, rotDeg = 90, material = "paint_yellow" },
        { x = -32, z = 4, length = 3, width = 0.25, rotDeg = 90, material = "paint_yellow" },
        { x = -32, z = 10, length = 3, width = 0.25, rotDeg = 90, material = "paint_yellow" },
        { x = -32, z = 16, length = 3, width = 0.25, rotDeg = 90, material = "paint_yellow" },
        { x = -32, z = 22, length = 3, width = 0.25, rotDeg = 90, material = "paint_yellow" },
        -- 大门区入口横向虚线
        { x = -37, z = 6, length = 2, width = 0.2, material = "paint_yellow" },
        { x = -34, z = 6, length = 2, width = 0.2, material = "paint_yellow" },
        { x = -31, z = 6, length = 2, width = 0.2, material = "paint_yellow" },
        { x = -28, z = 6, length = 2, width = 0.2, material = "paint_yellow" },
        { x = -25, z = 6, length = 2, width = 0.2, material = "paint_yellow" },
        -- 堆场/码头车道线
        { x = -6, z = 10, length = 38, width = 0.2, rotDeg = 90, material = "paint_yellow" },
        { x = 6, z = 10, length = 38, width = 0.2, rotDeg = 90, material = "paint_yellow" },
        { x = 26, z = 0, length = 56, width = 0.2, rotDeg = 90, material = "paint_yellow" },
        -- 仓库门洞与内部通道
        { x = 0, z = -10, length = 6, width = 0.3, material = "paint_yellow" },
        { x = 0, z = -20, length = 18, width = 0.2, rotDeg = 90 },
        -- 仓库门洞黄白相间警示带（差异第 16 条）
        { x = -2.6, z = -9.4, length = 0.7, width = 0.35, material = "paint_yellow" },
        { x = -1.8, z = -9.4, length = 0.7, width = 0.35, material = "paint_white" },
        { x = -1.0, z = -9.4, length = 0.7, width = 0.35, material = "paint_yellow" },
        { x = -0.2, z = -9.4, length = 0.7, width = 0.35, material = "paint_white" },
        { x = 0.6, z = -9.4, length = 0.7, width = 0.35, material = "paint_yellow" },
        { x = 1.4, z = -9.4, length = 0.7, width = 0.35, material = "paint_white" },
        { x = 2.2, z = -9.4, length = 0.7, width = 0.35, material = "paint_yellow" },
        -- 中继甲前的黄色框线（4 条）
        { x = 1.5, z = 5.6, length = 3.4, width = 0.15, material = "paint_yellow" },
        { x = 1.5, z = 9.4, length = 3.4, width = 0.15, material = "paint_yellow" },
        { x = -0.2, z = 7.5, length = 3.8, width = 0.15, rotDeg = 90, material = "paint_yellow" },
        { x = 3.2, z = 7.5, length = 3.8, width = 0.15, rotDeg = 90, material = "paint_yellow" },
        -- 码头临水侧警示带
        { x = 39.0, z = 0, length = 58, width = 0.3, rotDeg = 90, material = "paint_yellow" },
    },
    fenceThickness = 0.6,
    fenceHeight = 3.0,
    quayHeight = 1.2,
}

return Level
