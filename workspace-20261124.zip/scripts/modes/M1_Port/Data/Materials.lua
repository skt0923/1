-- 地面材质数值：材质名、UV 尺度与色调。
-- 来源：docs/source/3a/parts/09-level.part.js 语句 1；材质名见 05-material.part.js。
-- 混凝土边沿与分区地面留到 P1-C 四区域总装（任务卡 m1-p1a-foundation 差异 5）。

---@class M1GroundMaterial
---@field material string
---@field uvMeters number Metres one UV unit spans for the floor geometry.
---@field color [number, number, number] Linear tint applied to the baked albedo.

---@class M1MaterialsData
---@field ground M1GroundMaterial

---@type M1MaterialsData
local MaterialsData = {
    ground = { material = "asphalt", uvMeters = 8, color = { 0.62, 0.63, 0.66 } },
}

return MaterialsData
