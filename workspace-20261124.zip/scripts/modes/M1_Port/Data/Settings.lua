-- 设置数值：视角灵敏度、视野、反转 Y 的范围与默认值。
-- 来源：00-config.part.js（Pi.fov 74）；19-menu.part.js（灵敏度与反转Y 可调，原作 setFov 钳制 55..100）；
-- 14-input.part.js（视角输入）；18-hud.part.js（设置持久化）。触摸基准取 urhox-libs/UI/GameHUD 的默认 2.0。

---@class M1SettingsState
---@field sensitivity number Radians per pixel for mouse look.
---@field touchSensitivity number Touch look sensitivity handed to GameHUD.
---@field invertY boolean
---@field fov number Vertical field of view in degrees.

---@class M1SettingsData
---@field file string Save file name inside the engine's isolated save directory.
---@field defaultSensitivity number
---@field defaultTouchSensitivity number
---@field defaultFov number
---@field defaultInvertY boolean
---@field sensitivityMin number
---@field sensitivityMax number
---@field sensitivityStep number
---@field fovMin number
---@field fovMax number
---@field fovStep number

---@type M1SettingsData
local Settings = {
    file = "m1-port-settings.json",
    defaultSensitivity = 0.0021,
    defaultTouchSensitivity = 2.0,
    defaultFov = 74,
    defaultInvertY = false,
    sensitivityMin = 0.0008,
    sensitivityMax = 0.0050,
    sensitivityStep = 0.0002,
    fovMin = 55,
    fovMax = 100,
    fovStep = 1,
}

return Settings
