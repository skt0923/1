-- AI 自检数值：自动驾驶的接敌距离、开火容差与运行时长。
-- 这些值只服务自检，不参与玩法平衡；推导依据是「敌人 rangeMax 18、rangeMin 8」——
-- 走到 12 米内、10 米停住，落在敌人射程中段，既能打中也不至于贴脸。

---@class M1AutoPilotData
---@field duration number 单次自检运行秒数。
---@field engageRange number 允许开火的最大距离（米）。
---@field stopRange number 停止前进的距离（米）。
---@field yawToleranceDeg number 朝向误差容差（度），超过就不开火。
---@field turnRateDeg number 每秒转向角（度）。
---@field retargetEvery number 重新选目标的间隔（秒）。
---@field reloadAmmo integer 弹匣低于这个数就换弹。

---@type M1AutoPilotData
local AutoPilot = {
    duration = 30.0,
    engageRange = 12.0,
    stopRange = 10.0,
    yawToleranceDeg = 2.5,
    turnRateDeg = 180.0,
    retargetEvery = 0.5,
    reloadAmmo = 1,
}

return AutoPilot
