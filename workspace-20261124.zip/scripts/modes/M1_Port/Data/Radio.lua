-- 电台文案：原作 20-flow 的 _l 文案表（intro/low/done），本阶段只取入场与收尾三条。
local Radio = {
    intro = "指挥中心：三处中继已被敌方接管，切断后回到撤离点。",
    allCut = "指挥中心：中继全部切断，前往码头撤离点。",
    done = "指挥中心：撤离完成，行动结束。",
    dead = "指挥中心：干员信号中断。",
}

return Radio
