-- 中继柜指示灯数值：取自原作 08-props 语句 1 的 B3（relay_node）setState / update。
-- 原作颜色是 32 位十六进制，这里换算成 0..1 的分量；强度原为 emissive 值，按 maxIntensity 归一成亮度。
local RelayLamp = {
    childName = "lamp",
    -- 三态颜色：0xFFA028 / 0xFFD9A0 / 0xFF2828
    liveColor = { r = 1.000, g = 0.627, b = 0.157 },
    cuttingColor = { r = 1.000, g = 0.851, b = 0.627 },
    cutColor = { r = 1.000, g = 0.157, b = 0.157 },
    maxIntensity = 9.0,
    -- live：5.5 + 3 * sin(t * 2.2)
    liveBase = 5.5,
    liveAmp = 3.0,
    liveHz = 2.2,
    -- cutting：sin(t * 2π * 5.5) > 0 时 9，否则 0.5
    cuttingHz = 5.5,
    cuttingOn = 9.0,
    cuttingOff = 0.5,
    -- cut：0.3 秒内 9，2.6 秒内按 1 - (t - 0.3) / 2.3 的平方衰减并闪烁，之后熄灭
    cutFlashSeconds = 0.3,
    cutFlash = 9.0,
    cutFadeSeconds = 2.6,
    cutFade = 7.0,
    cutFlickerLow = 0.08,
    -- 中继坐标与道具摆放的水平匹配容差（米）
    matchTolerance = 0.5,
}

return RelayLamp