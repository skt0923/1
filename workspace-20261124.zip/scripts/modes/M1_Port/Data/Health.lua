-- 生命数值：玩家生命上限、回血与伤害换算。
-- 来源：docs/source/3a/parts/15-player.part.js
--   health:100, maxHealth:100                -> maxHealth
--   Mt.regenDelay:4, Mt.regenRate:25         -> regenDelay, regenRate（4 秒未受伤后每秒 25）
--   damage(): w = min(1, w + .35 + F/40)     -> pulseBase, pulseAmountDivisor
--   ie(): w = max(0, w - dt*1.9)             -> pulseDecay
--   落地: ce>13 时 damage((ce-13)*7)          -> fallSpeed, fallScale
--   落水救援: damage(12)                      -> drownDamage
--   lowHealth = sl(.55,.12, health/maxHealth) 的临界值取 0.35 作为「低血」显示线

---@class M1HealthData
---@field maxHealth number
---@field regenDelay number
---@field regenRate number
---@field pulseBase number
---@field pulseAmountDivisor number
---@field pulseDecay number
---@field fallSpeed number Metres per second above which a landing hurts.
---@field fallScale number Damage per metre per second above fallSpeed.
---@field drownDamage number
---@field lowRatio number Health ratio below which the bar turns to the alert colour.

---@type M1HealthData
local Health = {
    maxHealth = 100,
    regenDelay = 4.0,
    regenRate = 25.0,
    pulseBase = 0.35,
    pulseAmountDivisor = 40.0,
    pulseDecay = 1.9,
    fallSpeed = 13.0,
    fallScale = 7.0,
    drownDamage = 12.0,
    lowRatio = 0.35,
}

return Health
