-- 后处理数值表（P4-D）。来源登记，一行一条：
-- 原作 docs/source/3a/parts/04-postfx.part.js 的 TUNE 对象 g：
--   minExposure=0.6 maxExposure=2 adaptTau=1.5 key=0.12
--   bloom=0.065 bloomMix=0.62 streak=0.03 dirt=0.1 flare=0.16
--   agxMix=0.25 ca=0.0013 vignette=0.3 grain=0.02 sharpen=0.3 lookPower=1.18 lookSat=1.22
-- 带「换算」「试调」字样的值不是原作原值，理由写在该行上方。

---@class M1PostFxData
---@field exposureEnabled boolean 自适应曝光总开关
---@field exposureMinEV number 曝光下限（EV）
---@field exposureMaxEV number 曝光上限（EV）
---@field exposureSpeed number 每秒逼近速度
---@field exposureBias number 曝光补偿（EV）
---@field exposureForceTarget boolean true 时每帧直接用目标曝光
---@field bloomIntensity number 泛光强度
---@field bloomThreshold number 泛光亮度阈值，小于 0 表示不设阈值
---@field bloomSizeScale number 泛光扩散范围
---@field vignetteBase number 基础暗角强度

local PostFxData = {
    -- 原作曝光由 1×1 亮度纹理驱动自适应；引擎走 autoExposure（plus 直方图路径）。
    exposureEnabled = true,
    -- 换算：原作 minExposure/maxExposure 是线性亮度倍率，引擎 autoExposure*Brightness 是 EV。
    -- log2(0.6) = -0.737，log2(2.0) = 1.0。
    exposureMinEV = -0.737,
    exposureMaxEV = 1.0,
    -- 换算：原作 adaptTau=1.5 秒是一阶低通时间常数，引擎是每秒逼近速度，取 1/1.5 = 0.667。
    exposureSpeed = 0.667,
    -- 原作 grade pass 无曝光补偿项，中灰 key=0.12 已体现在自适应目标里，故偏置取 0。
    exposureBias = 0.0,
    -- 原作曝光每帧自适应、不锁目标值；锁死会失去进出仓库的明暗过渡。
    exposureForceTarget = false,
    -- 试调：引擎 UE 泛光强度与「原作 grade pass 的 uBloom=0.065」量纲不同（引擎默认 0.675）。
    -- 2026-11-24 本机 A/B：0.55 把整片画面提亮成发白（整体 +4.79），0.15 只让亮部发柔光（整体 +1.61），
    -- 取 0.15；这是按实测收敛的试调值，不等于原作值。
    bloomIntensity = 0.15,
    -- 原作泛光无亮度阈值（所有亮度参与），这里与作品一致取 -1。
    -- 本机 A/B：阈值 0.8 与 1.0 时整体变化只有 +0.3 / +0.4（噪声级）——本场景几乎没有像素过这两个阈值，
    -- 等于没开；只有阈值 -1 才有真实泛光。发白问题改用强度收敛（见上一行），不靠抬阈值。
    bloomThreshold = -1.0,
    -- 试调：原作 6 级降/升采样链的扩散范围，引擎只有单一 sizeScale，取 4 为默认档。
    bloomSizeScale = 4.0,
    -- 原作 vignette=0.3，引擎 vignetteIntensity 量纲未标定，取同值作起点。
    vignetteBase = 0.3,
}

return PostFxData