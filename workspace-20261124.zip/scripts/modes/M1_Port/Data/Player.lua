-- 玩家数值：眼高、速度、加速度、重力、跳跃、FOV 与移动探针窗口。
-- 来源：15-player 语句 1、00-config 语句 1、14-input 语句 1。

---@class PlayerRigProbeData
---@field moveWindow number Seconds of one movement judge window.
---@field accelGuard number Seconds after press before a window is judged.

---@class M1PoseData
---@field handRight Vector3 Right hand target in actor-local metres.
---@field handLeft Vector3 Left hand target in actor-local metres.
---@field gunOffset Vector3 Gun root offset from the right hand in actor-local metres.
---@field gunYaw number Degrees added to the actor yaw so the barrel faces forward.

---@class M1ThirdPersonData
---@field distance number Camera distance behind the target in metres.
---@field offsetY number Aim point height above the target origin.
---@field fov number Third person field of view in degrees.
---@field idleClip string Clip played while standing still.
---@field runClip string Clip played while moving.
---@field actorYawOffset number Degrees added to camera yaw; 0 because the model's forward is +Z.
---@field runSpeedThreshold number Horizontal speed above which runClip plays.

---@class M1PlayerData : RigConfig
---@field eyeHeight number
---@field crouchEyeHeight number
---@field radius number
---@field height number
---@field fov number
---@field viewFov number
---@field walkSpeed number
---@field sprintSpeed number
---@field crouchSpeed number
---@field accelGround number
---@field decelGround number
---@field accelAir number
---@field gravity number
---@field jumpApex number
---@field coyoteTime number
---@field jumpBuffer number
---@field crouchHeight number
---@field eyeRate number
---@field pitchLimit number
---@field nearClip number
---@field farClip number
---@field thirdPerson M1ThirdPersonData
---@field pose M1PoseData
---@field probe PlayerRigProbeData

---@type M1PlayerData
local PlayerData = {
    eyeHeight = 1.68,
    crouchEyeHeight = 1.05,
    radius = 0.32,
    height = 1.8,
    fov = 74,
    viewFov = 54,
    walkSpeed = 3.8,
    sprintSpeed = 6.4,
    crouchSpeed = 1.9,
    accelGround = 34,
    decelGround = 26,
    accelAir = 9,
    gravity = 21,
    jumpApex = 1.0,
    coyoteTime = 0.12,
    jumpBuffer = 0.13,
    crouchHeight = 1.15,
    eyeRate = 11,
    pitchLimit = 1.5,
    nearClip = 0.08,
    farClip = 900,
    probe = { moveWindow = 0.5, accelGuard = 0.3 },
    -- 第三人称：距离/眼高/FOV 沿用原作第三人称镜头；模型前向是 +Z，yawOffset 必须为 0（e9 / feedback 53811 截图反证 180 会让正脸朝镜头）
    thirdPerson = {
        distance = 4.0, offsetY = 1.4, fov = 45,
        idleClip = "Idle", runClip = "Run",
        actorYawOffset = 0, runSpeedThreshold = 0.5,
    },
    -- 持枪姿势目标点：首版估值，待真机 [POSE][HAND] 的 errR/errL 回填（e9）
    pose = {
        handRight = Vector3(0.16, 1.30, 0.24),
        handLeft = Vector3(-0.02, 1.36, 0.44),
        gunOffset = Vector3(0.0, -0.02, 0.06),
        gunYaw = 180,
    },
}

return PlayerData
