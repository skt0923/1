-- 三处中继与撤离点坐标。中继坐标沿用 Data/Props.lua 的 relay_node 摆放（09-level 语句 4；推导，差异第 13 条）。
-- short 取 id 末字母大写，与原作 setRelays 的标记一致。
local Relay = {
    relays = {
        { id = "relay_a", short = "A", x = 1.50, z = 7.50 },
        { id = "relay_b", short = "B", x = -4.00, z = -20.00 },
        { id = "relay_c", short = "C", x = 23.00, z = 14.00 },
    },
    -- 撤离点：码头区东侧，P3-B 的撤离判定用（坐标推导，差异第 13 条）。
    extract = { x = 36.0, z = 0.0, radius = 3.0 },
}

return Relay
