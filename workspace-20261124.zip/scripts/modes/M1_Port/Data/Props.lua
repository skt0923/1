-- 道具尺寸表与首批摆放表。
-- 尺寸与材质来源：docs/source/3a/parts/08-props.part.js 语句 1（Gi 尺寸表，36 类）。
-- 摆放坐标来源：docs/source/3a/parts/09-level.part.js 语句 2（hR 堆场）与语句 3（fR 大门）。
-- 颜色名沿用 09-level 的 color 字段，映射到 05-material 的 paint_<颜色>；"hc" 为 40 尺高柜。
-- 角度由原作弧度换算成度（保留一位小数）。首批 11 类，其余 25 类尺寸已登记，供后续批次直接取用。

---@class M1PropSize
---@field width number X 方向尺寸（米）。
---@field height number Y 方向尺寸（米）。
---@field depth number Z 方向尺寸（米）。
---@field material string 默认材质名。

---@class M1PropPlacement
---@field name string 尺寸表键名，同时决定用哪个构建器。
---@field x number
---@field z number
---@field y? number 底部高度，叠放层使用；缺省 0。
---@field rotDeg? number 绕 Y 轴角度（度）；缺省 0。
---@field color? string 覆盖尺寸表默认材质色。
---@field zone? string 区域名覆盖；背景物件在四区之外时用它跳过区域校验。

---@class M1PropsData
---@field sizes table<string, M1PropSize>
---@field firstBatch string[]
---@field placements M1PropPlacement[]
---@field bakeMaxSize integer 道具材质烘焙的边长上限（像素）。
---@field bakeRestoreSize integer 道具建完恢复的烘焙边长。

---@type M1PropsData
local Props = {
    sizes = {
        container20 = { width = 6.06, height = 2.59, depth = 2.44, material = "paint_red" },
        container40 = { width = 12.19, height = 2.59, depth = 2.44, material = "paint_blue" },
        container40hc = { width = 12.19, height = 2.90, depth = 2.44, material = "paint_green" },
        jersey_barrier = { width = 3.00, height = 0.81, depth = 0.60, material = "concrete" },
        light_mast = { width = 0.50, height = 14.00, depth = 0.50, material = "steel_galv" },
        fence_panel = { width = 3.00, height = 2.40, depth = 0.08, material = "chainlink" },
        guard_booth = { width = 2.60, height = 2.70, depth = 2.20, material = "paint_white" },
        gate_arm = { width = 5.00, height = 1.10, depth = 0.30, material = "hazard_stripes" },
        bollard_mooring = { width = 0.70, height = 0.60, depth = 0.70, material = "steel_dark" },
        bollard_post = { width = 0.17, height = 1.00, depth = 0.17, material = "paint_yellow" },
        relay_node = { width = 1.20, height = 2.40, depth = 0.80, material = "paint_grey" },
        shelf_rack = { width = 2.70, height = 4.20, depth = 1.10, material = "paint_orange" },
        stairs_metal = { width = 3.00, height = 2.60, depth = 1.00, material = "diamond_plate" },
        catwalk = { width = 3.00, height = 1.10, depth = 1.20, material = "diamond_plate" },
        reefer_unit = { width = 0.50, height = 2.30, depth = 2.30, material = "paint_white" },
        barrel = { width = 0.60, height = 0.90, depth = 0.60, material = "paint_blue" },
        pallet = { width = 1.20, height = 0.14, depth = 1.00, material = "wood_pallet" },
        pallet_stack = { width = 1.20, height = 1.15, depth = 1.00, material = "wood_pallet" },
        crate_wood = { width = 1.10, height = 1.00, depth = 0.90, material = "wood_pallet" },
        crate_stack = { width = 1.20, height = 1.90, depth = 1.00, material = "wood_pallet" },
        ibc_tote = { width = 1.20, height = 1.16, depth = 1.00, material = "paint_grey" },
        forklift = { width = 3.40, height = 2.20, depth = 1.25, material = "paint_yellow" },
        cable_reel = { width = 1.30, height = 1.30, depth = 0.80, material = "wood_dark" },
        tire_stack = { width = 0.80, height = 1.00, depth = 0.80, material = "rubber" },
        dumpster = { width = 1.90, height = 1.35, depth = 1.10, material = "paint_green" },
        generator = { width = 2.20, height = 1.40, depth = 1.00, material = "paint_yellow" },
        jerry_can = { width = 0.35, height = 0.47, depth = 0.17, material = "paint_green" },
        traffic_cone = { width = 0.36, height = 0.70, depth = 0.36, material = "paint_red" },
        gas_cylinders = { width = 0.90, height = 1.60, depth = 0.50, material = "steel_galv" },
        tarp_cargo = { width = 2.40, height = 1.50, depth = 1.40, material = "tarp" },
        sandbags = { width = 2.00, height = 0.90, depth = 0.60, material = "tarp" },
        toolbox_cart = { width = 0.90, height = 0.95, depth = 0.50, material = "plastic_red" },
        floodlight_stand = { width = 1.00, height = 2.20, depth = 1.00, material = "paint_yellow" },
        cardboard_boxes = { width = 1.00, height = 0.80, depth = 0.80, material = "cardboard" },
        pipe_stack = { width = 6.00, height = 0.90, depth = 1.20, material = "steel_rust" },
        sign_post = { width = 0.60, height = 2.40, depth = 0.08, material = "paint_white" },
        -- 门柱不在 Gi 尺寸表里，尺寸取自 09-level 语句 3 的 box("steel_dark", .22, 3.4, .22)
        gate_post = { width = 0.22, height = 3.40, depth = 0.22, material = "steel_galv" },
        -- 岸桥与货轮不在 Gi 尺寸表，尺寸取自 10-background 的结构比例，本批按可辨认即可（差异表第 13 条）
        gantry_crane = { width = 12.00, height = 24.00, depth = 8.00, material = "steel_galv" },
        cargo_ship = { width = 60.00, height = 18.00, depth = 18.00, material = "hull_paint" },
    },

    firstBatch = {
        "container20", "container40", "container40hc",
        "jersey_barrier", "barrel", "pallet_stack", "crate_wood", "crate_stack",
        "ibc_tote", "tire_stack", "light_mast",
        "dumpster", "generator", "tarp_cargo", "pipe_stack", "sandbags", "traffic_cone",
        "cardboard_boxes", "cable_reel", "jerry_can", "gas_cylinders",
        "guard_booth", "gate_arm", "gate_post", "bollard_post",
        "shelf_rack", "relay_node", "fence_panel", "sign_post", "gantry_crane", "cargo_ship",
    },

    -- 道具只小占屏幅，512 足够；1024 在真机单套要 20–100 秒（2026-11-24 本地实测）。
    bakeMaxSize = 512,
    bakeRestoreSize = 1024,

    placements = {
        -- 堆场集装箱（09-level 语句 2 的 t() 叠放调用，逐层展开）
        { name = "container20", x = -19.45, z = -5.12, y = 0.00, color = "green" },
        { name = "container20", x = -19.45, z = -5.12, y = 2.59, color = "grey" },
        { name = "container20", x = -19.45, z = -5.12, y = 5.18, color = "orange" },
        { name = "container20", x = -13.30, z = -5.12, y = 0.00, color = "white" },
        { name = "container20", x = 3.70, z = -5.12, y = 0.00, color = "blue" },
        { name = "container20", x = 3.70, z = -5.12, y = 2.59, color = "white" },
        { name = "container20", x = 13.53, z = -5.12, y = 0.00, color = "teal" },
        { name = "container20", x = 13.53, z = -5.12, y = 2.59, color = "grey" },
        { name = "container20", x = -19.45, z = 2.08, y = 0.00, color = "blue" },
        { name = "container20", x = -13.35, z = 2.08, y = 0.00, color = "red" },
        { name = "container40", x = 0.80, z = 2.08, y = 0.00, color = "orange" },
        { name = "container40", x = 0.80, z = 2.08, y = 2.59, color = "teal" },
        { name = "container20", x = 0.80, z = 2.08, y = 5.18, color = "blue" },
        { name = "container20", x = 12.30, z = 2.08, y = 0.00, color = "red" },
        { name = "container20", x = 12.30, z = 2.08, y = 2.59, color = "yellow" },
        { name = "container20", x = -21.10, z = 9.92, y = 0.30, color = "yellow" },
        { name = "container20", x = -13.60, z = 9.92, y = 0.30, color = "green" },
        { name = "container20", x = -13.60, z = 9.92, y = 2.89, color = "blue" },
        { name = "container20", x = -13.60, z = 9.92, y = 5.48, color = "orange" },
        { name = "container20", x = -21.60, z = 12.42, y = 0.30, color = "red" },
        { name = "container20", x = -21.60, z = 12.42, y = 2.89, color = "white" },
        { name = "container20", x = -21.60, z = 12.42, y = 5.48, color = "teal" },
        { name = "container20", x = -15.40, z = 12.42, y = 0.30, color = "grey" },
        { name = "container20", x = 4.43, z = 12.42, y = 0.00, color = "blue" },
        { name = "container20", x = 13.53, z = 12.42, y = 0.00, color = "green" },
        { name = "container40", x = -16.40, z = 20.12, y = 0.00, color = "grey" },
        { name = "container40", x = -16.40, z = 20.12, y = 2.59, color = "green" },
        { name = "container20", x = -2.25, z = 20.12, y = 0.00, color = "red" },
        { name = "container20", x = 3.85, z = 20.12, y = 0.00, color = "white" },
        { name = "container20", x = 3.85, z = 20.12, y = 2.59, color = "blue" },
        { name = "container20", x = 13.53, z = 20.12, y = 0.00, color = "orange" },
        { name = "container20", x = 13.53, z = 20.12, y = 2.59, color = "teal" },
        { name = "container20", x = 13.53, z = 20.12, y = 5.18, color = "red" },
        { name = "container40hc", x = -16.40, z = 22.62, y = 0.00, color = "teal" },
        { name = "container40", x = -16.40, z = 22.62, y = 2.90, color = "yellow" },
        { name = "container40", x = -16.40, z = 22.62, y = 5.49, color = "blue" },
        { name = "container40", x = 0.80, z = 22.62, y = 0.00, color = "green" },
        { name = "container40hc", x = 0.80, z = 22.62, y = 2.59, color = "orange" },
        { name = "container20", x = 13.53, z = 22.62, y = 0.00, color = "grey" },
        -- 仓库区与大门区的集装箱
        { name = "container40", x = -22.60, z = -19.20, y = 0.00, rotDeg = 90.0, color = "red" },
        { name = "container40", x = -22.60, z = -19.20, y = 2.59, rotDeg = 90.0, color = "white" },
        { name = "container20", x = -30.20, z = -18.40, y = 0.00, rotDeg = 20.1, color = "yellow" },
        { name = "container40", x = -31.20, z = 24.70, y = 0.00, color = "teal" },
        { name = "container40", x = -31.20, z = 24.70, y = 2.59, color = "orange" },
        -- 堆场地道具（09-level 语句 2 的 e() 调用）
        { name = "barrel", x = -19.60, z = 3.85, color = "blue" },
        { name = "barrel", x = -18.90, z = 3.95, rotDeg = 40.1, color = "blue" },
        { name = "pallet_stack", x = -17.40, z = 4.00, rotDeg = 4.6 },
        { name = "crate_stack", x = -14.30, z = 8.05, rotDeg = 2.3 },
        { name = "ibc_tote", x = -12.95, z = 7.95, rotDeg = -2.9 },
        { name = "jersey_barrier", x = -2.90, z = 5.30, rotDeg = 6.9 },
        { name = "jersey_barrier", x = 5.60, z = 5.00, rotDeg = -5.7 },
        { name = "ibc_tote", x = 5.90, z = 8.90, rotDeg = 5.7 },
        { name = "ibc_tote", x = 5.95, z = 10.05, rotDeg = -2.9 },
        { name = "barrel", x = 4.90, z = 9.70, color = "red" },
        { name = "crate_stack", x = -3.90, z = 10.50, rotDeg = 5.7 },
        { name = "crate_wood", x = -3.80, z = 9.35, rotDeg = -11.5 },
        { name = "pallet_stack", x = -4.40, z = 11.80, rotDeg = 1.1 },
        { name = "tire_stack", x = -9.60, z = 0.20 },
        { name = "barrel", x = 4.50, z = 0.35, color = "yellow" },
        { name = "barrel", x = 5.20, z = 0.30, rotDeg = 22.9, color = "blue" },
        { name = "jersey_barrier", x = 12.20, z = 0.40, rotDeg = 1.7 },
        { name = "crate_wood", x = 11.20, z = -3.30, rotDeg = 17.2 },
        { name = "jersey_barrier", x = -0.90, z = -7.50, rotDeg = 5.7 },
        { name = "barrel", x = -3.00, z = 18.35, color = "blue" },
        { name = "jersey_barrier", x = 0.60, z = 15.50, rotDeg = 6.9 },
        { name = "tire_stack", x = -8.00, z = 26.90 },
        { name = "pallet_stack", x = 8.70, z = 27.00, rotDeg = 17.2 },
        { name = "crate_wood", x = -2.00, z = 27.00, rotDeg = 11.5 },
        { name = "barrel", x = 11.20, z = 27.10 },
        -- 灯杆（09-level 语句 2 的 light_mast 循环 + 语句 3 的两根）
        { name = "light_mast", x = -23.40, z = 0.50 },
        { name = "light_mast", x = -23.40, z = 21.40 },
        { name = "light_mast", x = 17.00, z = -8.70 },
        { name = "light_mast", x = 17.00, z = 18.60 },
        { name = "light_mast", x = -20.60, z = -11.60 },
        { name = "light_mast", x = -27.60, z = -0.90 },
        { name = "light_mast", x = -36.30, z = 12.40 },
        -- 大门区道具（09-level 语句 3 的 e() 调用）
        { name = "jersey_barrier", x = -34.70, z = 3.75, rotDeg = 94.6 },
        { name = "jersey_barrier", x = -33.30, z = 8.30, rotDeg = 86.6 },
        { name = "jersey_barrier", x = -30.60, z = 10.40, rotDeg = 1.7 },
        { name = "jersey_barrier", x = -27.30, z = 1.45, rotDeg = 2.9 },
        { name = "jersey_barrier", x = -32.20, z = 1.45, rotDeg = -2.3 },
        { name = "barrel", x = -33.90, z = 2.00, color = "yellow" },
        { name = "pallet_stack", x = -36.40, z = 10.30, rotDeg = 11.5 },
        -- 第二批：通用道具（09-level 语句 2 / 3 的 e() 调用，逐条搬运）
        { name = "sandbags", x = -1.70, z = 9.70, rotDeg = 28.6 },
        { name = "sandbags", x = -6.70, z = -7.80, rotDeg = -5.7 },
        { name = "cable_reel", x = 4.20, z = 10.50, rotDeg = 17.2 },
        { name = "cable_reel", x = -18.20, z = -8.00, rotDeg = 11.5 },
        { name = "cable_reel", x = -34.60, z = -22.50, rotDeg = 57.3 },
        { name = "tarp_cargo", x = 12.90, z = 10.00, rotDeg = 2.3 },
        { name = "tarp_cargo", x = -13.50, z = -3.10, rotDeg = 2.9 },
        { name = "tarp_cargo", x = -20.50, z = 18.05, rotDeg = 1.7 },
        { name = "tarp_cargo", x = -27.50, z = -11.60, rotDeg = 17.2 },
        { name = "tarp_cargo", x = -29.90, z = -11.00, rotDeg = -11.5 },
        { name = "cardboard_boxes", x = -2.00, z = 0.30, rotDeg = 11.5 },
        { name = "cardboard_boxes", x = -21.00, z = 26.90, rotDeg = 22.9 },
        { name = "dumpster", x = -12.30, z = -7.05 },
        { name = "dumpster", x = 4.20, z = 14.55, rotDeg = 1.1 },
        { name = "dumpster", x = -17.00, z = -14.00, rotDeg = 90.0 },
        { name = "dumpster", x = -36.40, z = 21.00, rotDeg = 90.0 },
        { name = "gas_cylinders", x = 9.60, z = -10.45 },
        { name = "gas_cylinders", x = -16.90, z = -20.40, rotDeg = 90.0 },
        { name = "traffic_cone", x = 0.20, z = 6.30 },
        { name = "traffic_cone", x = 2.90, z = 6.40 },
        { name = "traffic_cone", x = 2.90, z = 8.80 },
        { name = "traffic_cone", x = 0.10, z = 8.70 },
        { name = "traffic_cone", x = -6.50, z = -9.90 },
        { name = "traffic_cone", x = -0.50, z = -9.90 },
        { name = "pipe_stack", x = -16.00, z = 14.40 },
        { name = "pipe_stack", x = -30.50, z = -27.00, rotDeg = 1.7 },
        { name = "pipe_stack", x = -30.20, z = -25.40, rotDeg = -1.1 },
        { name = "generator", x = -34.20, z = 14.20, rotDeg = 8.6 },
        { name = "jerry_can", x = -33.00, z = 15.20, rotDeg = 22.9 },
        { name = "jerry_can", x = -33.30, z = 15.35, rotDeg = 108.9 },
        -- 大门结构（09-level 语句 3 的 fR）
        { name = "guard_booth", x = -35.20, z = 0.35 },
        { name = "gate_arm", x = -36.30, z = 5.00, rotDeg = 90.0 },
        { name = "gate_post", x = -38.00, z = 2.00 },
        { name = "gate_post", x = -38.00, z = 8.00 },
        { name = "bollard_post", x = -37.00, z = 1.75 },
        { name = "bollard_post", x = -34.40, z = 2.30 },
        { name = "bollard_post", x = -37.00, z = 8.30 },
        { name = "bollard_post", x = -35.60, z = 8.90 },
        { name = "bollard_post", x = -34.40, z = 9.90 },
        { name = "bollard_post", x = -33.50, z = -1.10 },
        -- 仓库内部货架与三处中继（09-level 语句 4 的 relay_node 与仓库内货架；坐标推导，差异第 13 条）
        { name = "shelf_rack", x = -22.5, z = -26.00 },
        { name = "shelf_rack", x = -22.5, z = -22.50 },
        { name = "shelf_rack", x = -22.5, z = -19.00 },
        { name = "shelf_rack", x = 14.5, z = -26.00 },
        { name = "shelf_rack", x = 14.5, z = -22.50 },
        { name = "relay_node", x = 1.50, z = 7.50, rotDeg = 20.1 },
        { name = "relay_node", x = -4.00, z = -20.00, rotDeg = 90.0 },
        { name = "relay_node", x = 23.00, z = 14.00, rotDeg = 11.5 },
        -- 招牌（09-level 语句 3 的 sign_post）
        { name = "sign_post", x = -33.20, z = 9.60, rotDeg = 90.0 },
        { name = "sign_post", x = -25.30, z = 1.10, rotDeg = 90.0 },
        { name = "sign_post", x = -36.60, z = -1.60, rotDeg = 90.0 },
        -- 围栏：沿场地周边每 7 米一片（原作 3.35 米，差异第 14 条）
        { name = "fence_panel", x = -34.50, z = -29.30, rotDeg = 0 },
        { name = "fence_panel", x = -27.50, z = -29.30, rotDeg = 0 },
        { name = "fence_panel", x = -20.50, z = -29.30, rotDeg = 0 },
        { name = "fence_panel", x = -13.50, z = -29.30, rotDeg = 0 },
        { name = "fence_panel", x = -6.50, z = -29.30, rotDeg = 0 },
        { name = "fence_panel", x = 0.50, z = -29.30, rotDeg = 0 },
        { name = "fence_panel", x = 7.50, z = -29.30, rotDeg = 0 },
        { name = "fence_panel", x = 14.50, z = -29.30, rotDeg = 0 },
        { name = "fence_panel", x = 21.50, z = -29.30, rotDeg = 0 },
        { name = "fence_panel", x = 28.50, z = -29.30, rotDeg = 0 },
        { name = "fence_panel", x = -34.50, z = 29.30, rotDeg = 0 },
        { name = "fence_panel", x = -27.50, z = 29.30, rotDeg = 0 },
        { name = "fence_panel", x = -20.50, z = 29.30, rotDeg = 0 },
        { name = "fence_panel", x = -13.50, z = 29.30, rotDeg = 0 },
        { name = "fence_panel", x = -6.50, z = 29.30, rotDeg = 0 },
        { name = "fence_panel", x = 0.50, z = 29.30, rotDeg = 0 },
        { name = "fence_panel", x = 7.50, z = 29.30, rotDeg = 0 },
        { name = "fence_panel", x = 14.50, z = 29.30, rotDeg = 0 },
        { name = "fence_panel", x = 21.50, z = 29.30, rotDeg = 0 },
        { name = "fence_panel", x = 28.50, z = 29.30, rotDeg = 0 },
        { name = "fence_panel", x = -38.50, z = -25.50, rotDeg = 90 },
        { name = "fence_panel", x = -38.50, z = -18.50, rotDeg = 90 },
        { name = "fence_panel", x = -38.50, z = -11.50, rotDeg = 90 },
        { name = "fence_panel", x = -38.50, z = -4.50, rotDeg = 90 },
        { name = "fence_panel", x = -38.50, z = 2.50, rotDeg = 90 },
        { name = "fence_panel", x = -38.50, z = 9.50, rotDeg = 90 },
        { name = "fence_panel", x = -38.50, z = 16.50, rotDeg = 90 },
        { name = "fence_panel", x = -38.50, z = 23.50, rotDeg = 90 },
        -- 背景：岸桥与货轮（10-background；尺寸与位置推导，差异第 13 条）
        { name = "gantry_crane", x = 37.00, z = -18.00 },
        { name = "gantry_crane", x = 37.00, z = 18.00 },
        { name = "cargo_ship", x = 55.00, z = -6.00, zone = "背景" },
    },
}

return Props
