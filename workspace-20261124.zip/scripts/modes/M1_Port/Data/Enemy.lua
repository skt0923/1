-- 敌人数值与生成点。
-- 数值来源：docs/source/3a/parts/17-enemy.part.js 的 Kv 配置（猎犬）：
--   hp 140 / shotDamage 5 / burst 4 / burstGap .11 / telegraph .5 / cooldown 1.8–3
--   runSpeed 4.5 / stalkSpeed 2 / patrolSpeed 1.5 / accel 7 / turnRate 2.5
--   rangeMin 8 / rangeMax 18 / spreadFar .12 / spreadNear .045
--   lungeRange 3 / lungeDamage 15 / lungeCooldown 3.5 / lungeSpeed 9.5
-- 通用数值来自同文件：sightRange 45 / sightCone 200（度）。
-- 生成点来源：09-level 语句 4 的 enemySpawns 地面点（空中点留给飞鸥，本批不用）。
-- 波次数量与命中概率映射为推导值，登记在任务卡 m1-p2a-enemy 差异表。

---@class M1EnemyData
---@field name string
---@field health number
---@field shotDamage number
---@field burst integer
---@field burstGap number
---@field telegraph number
---@field cooldownMin number
---@field cooldownMax number
---@field runSpeed number
---@field patrolSpeed number
---@field rangeMin number
---@field rangeMax number
---@field spreadNear number
---@field spreadFar number
---@field lungeRange number
---@field lungeDamage number
---@field lungeCooldown number
---@field lungeSpeed number
---@field sightRange number
---@field sightConeDeg number
---@field hitRadius number 射线命中半宽（米）；原作是骨骼胶囊，这里用包围盒。

---@class M1EnemySpawn
---@field x number
---@field z number
---@field zone string

---@class M1EnemyWave
---@field count integer
---@field spawnGap number 同波内两只之间的间隔秒数。

---@class M1EnemyConfig
---@field data M1EnemyData
---@field spawns M1EnemySpawn[]
---@field waves M1EnemyWave[]
---@field waveGap number 一波清空到下一波的等待秒数。
---@field maxShooters integer 同时开火的敌人上限（原作 Ui 的 token：maxTokens 2）。
---@field firstDelay number 首波第一只的额外延迟秒数（推导值，原作开场简报未实现前用它兜）。

---@type M1EnemyConfig
local Enemy = {
    data = {
        name = "猎犬",
        health = 140,
        shotDamage = 5,
        burst = 4,
        burstGap = 0.11,
        telegraph = 0.5,
        cooldownMin = 1.8,
        cooldownMax = 3.0,
        runSpeed = 4.5,
        patrolSpeed = 1.5,
        rangeMin = 8.0,
        rangeMax = 18.0,
        spreadNear = 0.045,
        spreadFar = 0.12,
        lungeRange = 3.0,
        lungeDamage = 15,
        lungeCooldown = 3.5,
        lungeSpeed = 9.5,
        sightRange = 45.0,
        sightConeDeg = 200.0,
        hitRadius = 0.9,
    },
    spawns = {
        -- 大门区三个近点：原作生成点里玩家出生附近没有空地，为「一进图就能打」推导补入（差异第 7 条）。
        -- 2026-11-24 本地实测：曾整体后撤到 z=28，撞上 -31.2/24.7 的双层集装箱，视线被挡（SIGHT -> NONE blocked=1），
        -- 敌人只会巡逻不进攻。近点保留；秒杀问题在命中模型与开火名额上修（Combat/Enemy.lua 的 FireOnce、Waves 的 token）。
        { x = -30.0, z = 14.0, zone = "gate" },
        { x = -28.0, z = 18.0, zone = "gate" },
        { x = -33.0, z = 20.0, zone = "gate" },
        { x = -19.0, z = -1.4, zone = "yard" },
        { x = 3.5, z = -1.6, zone = "yard" },
        { x = 14.2, z = 16.4, zone = "yard" },
        { x = -3.2, z = 16.6, zone = "yard" },
        { x = -16.0, z = 26.0, zone = "yard" },
        { x = 6.0, z = 26.0, zone = "yard" },
        { x = 4.2, z = -5.12, zone = "yard" },
        { x = -7.8, z = 21.4, zone = "yard" },
        { x = -11.3, z = 12.5, zone = "yard" },
        { x = 17.5, z = 22.2, zone = "yard" },
        { x = -12.4, z = -24.8, zone = "shed" },
        { x = 9.6, z = -25.3, zone = "shed" },
        { x = -13.4, z = -19.6, zone = "shed" },
        { x = 4.6, z = -13.8, zone = "shed" },
        { x = -21.0, z = -27.2, zone = "shed" },
        { x = -18.6, z = -22.0, zone = "shed" },
        { x = 13.6, z = -24.0, zone = "shed" },
        { x = 27.7, z = -24.2, zone = "quay" },
        { x = 18.3, z = -25.4, zone = "quay" },
        { x = 27.2, z = -12.6, zone = "quay" },
        { x = 20.2, z = 14.0, zone = "quay" },
        { x = 23.4, z = 23.2, zone = "quay" },
        { x = 18.0, z = 24.4, zone = "quay" },
        { x = 27.4, z = 11.6, zone = "quay" },
    },
    waves = {
        { count = 3, spawnGap = 1.2 },
        { count = 4, spawnGap = 1.0 },
        { count = 5, spawnGap = 0.8 },
    },
    waveGap = 4.0,
    -- 首只实际出现时间 = firstDelay + waves[1].spawnGap = 4.8 + 1.2 = 6.0 秒，给玩家入图缓冲。
    firstDelay = 4.8,
    -- 原作 Ui.maxTokens = 2（crowd 场景 3）：同一时刻最多两只开火，其余等名额。
    maxShooters = 2,
}

return Enemy
