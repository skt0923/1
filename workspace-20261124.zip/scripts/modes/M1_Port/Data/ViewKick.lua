-- 枪感数值：后坐弹簧、移动摇摆、冲刺收枪、自动检视。
-- 来源：16-weapon 语句 28 的弹簧组 pa(520,30)/(380,26)/(300,22)/(300,20)/(110,15)/(140,13)/(600,30)、
--       单发冲量 kZ += 1.5 / kP += 1.5 / kY += ±0.5 / bump += 0.3、冲刺 sprintT 速率 9 与开火门限 0.45。
-- 差异：不做相机抖动（addShake .12 未移植）、落地冲量用固定值（原作按竖直速度）。见任务卡 m1-p4c-gunfeel。

---@class M1ViewKickSpringData
---@field freq number 弹簧刚度（1/s²）
---@field damping number 阻尼系数（1/s）
---@field offsetScale number 弹簧位移 → 视图偏移（米或弧度）
---@field impulse number 单发冲量基数（原作 k?.v += 值）

---@class M1ViewKickData
---@field springs table<string, M1ViewKickSpringData>
---@field swayScale number
---@field swayClamp number
---@field landImpulse number
---@field sprintSpeedMin number 水平速度超过它算冲刺（走 3.8 / 跑 6.4）
---@field sprintRamp number
---@field sprintFireBlock number
---@field sprintLower Vector3
---@field sprintPitchDeg number
---@field inspectIdleSeconds number
---@field inspectSeconds number
---@field inspectRollDeg number
---@field inspectYawDeg number
---@field maxSubStep number 弹簧积分上限步长（秒），原作按 8 毫秒切分

---@type M1ViewKickData
local ViewKickData = {
    springs = {
        z = { freq = 520.0, damping = 30.0, offsetScale = 0.010, impulse = 1.5 },
        pitch = { freq = 380.0, damping = 26.0, offsetScale = 0.012, impulse = 1.5 },
        yaw = { freq = 300.0, damping = 22.0, offsetScale = 0.020, impulse = 0.5 },
        roll = { freq = 300.0, damping = 20.0, offsetScale = 0.030, impulse = 0.35 },
        swayYaw = { freq = 110.0, damping = 15.0, offsetScale = 0.010, impulse = 0.0 },
        swayPitch = { freq = 110.0, damping = 15.0, offsetScale = 0.010, impulse = 0.0 },
        bump = { freq = 600.0, damping = 30.0, offsetScale = 0.006, impulse = 0.0 },
    },
    swayScale = 3.2,
    swayClamp = 0.2,
    landImpulse = 0.9,
    sprintSpeedMin = 4.5,
    sprintRamp = 9.0,
    sprintFireBlock = 0.45,
    sprintLower = Vector3(0.0, -0.12, -0.06),
    sprintPitchDeg = -32.0,
    inspectIdleSeconds = 24.0,
    inspectSeconds = 2.2,
    inspectRollDeg = 24.0,
    inspectYawDeg = 12.0,
    maxSubStep = 0.008,
}

return ViewKickData