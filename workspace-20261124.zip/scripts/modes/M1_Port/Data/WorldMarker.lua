-- 世界目标标记数值：原作 18-hud 语句 1 的 h-marks。
-- 原作抬高 relay +1.9 / extract +1.2，视口外按 |x| > 0.9、|y| > 0.82 钳制并加边缘箭头。
local WorldMarker = {
    relayHeight = 1.9,
    extractHeight = 1.2,
    -- 原作的 0.9 / 0.82 是归一化阈值，这里同时给贴边用的 UI 单位边距
    edgeMargin = 28,
    -- 超过这个水平距离不显示（原作无此裁剪，属性能取舍）
    maxDistance = 150.0,
    -- 标记文案只在变化时改文字，避免每帧 SetText
    relayFormat = "%s",
    extractFormat = "撤离",
    leftEdge = "◀ ",
    rightEdge = "▶ ",
}

return WorldMarker