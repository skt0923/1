-- 设置权威：灵敏度 / 视野 / 反转Y 的唯一来源，负责钳制、持久化与变更通知。
-- 数值来自 Data/Settings.lua；存档走引擎隔离目录（File + cjson）。
local TAG = "[M1][SETTINGS]"

---@class M1Settings
---@field data M1SettingsData
---@field state M1SettingsState
---@field listeners fun(state: M1SettingsState)[]
local Settings = {}
Settings.__index = Settings

---@param v number
---@param low number
---@param high number
---@return number
local function Clamp(v, low, high)
    if v ~= v then return low end
    if v < low then return low end
    if v > high then return high end
    return v
end

---@param data M1SettingsData
---@param value number
---@return number
local function ClampSensitivity(data, value)
    local v = Clamp(tonumber(value) or data.defaultSensitivity, data.sensitivityMin, data.sensitivityMax)
    local steps = math.floor((v - data.sensitivityMin) / data.sensitivityStep + 0.5)
    return Clamp(data.sensitivityMin + steps * data.sensitivityStep, data.sensitivityMin, data.sensitivityMax)
end

---@param data M1SettingsData
---@param value number
---@return number
local function ClampFov(data, value)
    local v = Clamp(tonumber(value) or data.defaultFov, data.fovMin, data.fovMax)
    return math.floor(v + 0.5)
end

---@param data M1SettingsData
---@return M1SettingsState
local function Defaults(data)
    return {
        sensitivity = data.defaultSensitivity,
        touchSensitivity = data.defaultTouchSensitivity,
        invertY = data.defaultInvertY,
        fov = data.defaultFov,
    }
end

---@param data M1SettingsData
---@return M1Settings
function Settings.Create(data)
    assert(data ~= nil and type(data.file) == "string", "Settings requires data with a file name")
    assert(type(data.defaultSensitivity) == "number" and data.defaultSensitivity > 0,
        "Settings needs a positive defaultSensitivity")
---@type M1Settings
    local self = setmetatable({ data = data, state = Defaults(data), listeners = {} }, Settings)
    self:Load()
    return self
end

---@param decoded table
---@return M1SettingsState
function Settings:Sanitize(decoded)
    local data = self.data
    return {
        sensitivity = ClampSensitivity(data, decoded.sensitivity),
        touchSensitivity = Clamp(tonumber(decoded.touchSensitivity) or data.defaultTouchSensitivity, 0.2, 8.0),
        invertY = decoded.invertY == true,
        fov = ClampFov(data, decoded.fov),
    }
end

function Settings:Load()
    local path = self.data.file
    if not fileSystem:FileExists(path) then
        print(string.format("%s[LOAD] -> NONE | file=%s reason=first-run defaults used", TAG, path))
        return
    end
    local okOpen, file = pcall(function() return File(path, FILE_READ) end)
    if not okOpen or file == nil then
        print(string.format("%s[LOAD] -> FAIL | file=%s reason=open-failed", TAG, path))
        return
    end
    local okRead, text = pcall(function() return file:ReadString() end)
    pcall(function() file:Close() end)
    if not okRead or type(text) ~= "string" or text == "" then
        print(string.format("%s[LOAD] -> FAIL | file=%s reason=empty", TAG, path))
        return
    end
    local okDecode, decoded = pcall(function() return cjson.decode(text) end)
    if not okDecode or type(decoded) ~= "table" then
        print(string.format("%s[LOAD] -> FAIL | file=%s reason=decode", TAG, path))
        return
    end
    self.state = self:Sanitize(decoded)
    print(string.format("%s[LOAD] -> OK | sensitivity=%.4f fov=%.0f invertY=%s", TAG,
        self.state.sensitivity, self.state.fov, tostring(self.state.invertY)))
end

---@return boolean
function Settings:Save()
    local path = self.data.file
    local okEncode, text = pcall(function() return cjson.encode(self.state) end)
    if not okEncode or type(text) ~= "string" then
        print(string.format("%s[SAVE] -> FAIL | file=%s reason=encode", TAG, path))
        return false
    end
    local okOpen, file = pcall(function() return File(path, FILE_WRITE) end)
    if not okOpen or file == nil then
        print(string.format("%s[SAVE] -> FAIL | file=%s reason=open-failed", TAG, path))
        return false
    end
    local okWrite = pcall(function() file:WriteString(text) end)
    pcall(function() file:Close() end)
    if not okWrite then
        print(string.format("%s[SAVE] -> FAIL | file=%s reason=write-failed", TAG, path))
        return false
    end
    print(string.format("%s[SAVE] -> OK | file=%s bytes=%d", TAG, path, #text))
    return true
end

---@param state M1SettingsState
function Settings:Notify(state)
    for index = 1, #self.listeners do
        self.listeners[index](state)
    end
end

---@param fn fun(state: M1SettingsState)
function Settings:Subscribe(fn)
    assert(type(fn) == "function", "Settings:Subscribe needs a function")
    self.listeners[#self.listeners + 1] = fn
    fn(self.state)
end

---@return M1SettingsState
function Settings:GetState()
    return self.state
end

---@param value number
---@return boolean changed
function Settings:SetSensitivity(value)
    local next = ClampSensitivity(self.data, value)
    if next == self.state.sensitivity then return false end
    self.state.sensitivity = next
    self.state.touchSensitivity = self.data.defaultTouchSensitivity * next / self.data.defaultSensitivity
    print(string.format("%s[SET] -> OK | sensitivity=%.4f touch=%.2f", TAG, next, self.state.touchSensitivity))
    self:Notify(self.state)
    return true
end

---@param value number
---@return boolean changed
function Settings:SetFov(value)
    local next = ClampFov(self.data, value)
    if next == self.state.fov then return false end
    self.state.fov = next
    print(string.format("%s[SET] -> OK | fov=%.0f", TAG, next))
    self:Notify(self.state)
    return true
end

---@param value boolean
---@return boolean changed
function Settings:SetInvertY(value)
    if value == self.state.invertY then return false end
    self.state.invertY = value
    print(string.format("%s[SET] -> OK | invertY=%s", TAG, tostring(value)))
    self:Notify(self.state)
    return true
end

---@return boolean changed
function Settings:Reset()
    self.state = Defaults(self.data)
    print(string.format("%s[RESET] -> OK | sensitivity=%.4f fov=%.0f invertY=%s", TAG,
        self.state.sensitivity, self.state.fov, tostring(self.state.invertY)))
    self:Notify(self.state)
    return true
end

return Settings
