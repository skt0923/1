-- 音效播放（原作 13-audio）：首批 5 个事件（枪声 / 空仓 / 换弹出 / 换弹入 / 雨循环）。
-- 资源是 Python 生成的原生 WAV（本地工具 tools/gen_audio.py；tools/ 被 .gitignore 忽略，WAV 已入库），1.35 直接 cache:GetResource("Sound", ...)。
-- 单个文件缺失只记 NONE 并继续，不阻塞其余事件（第 20 节能力探测）；一个都没加载才 assert。
local TAG = "[M1][SFX]"

---@class M1Sfx
---@field scene Scene
---@field data M1AudioData
---@field node Node 2D 声部池的宿主节点
---@field sounds table<string, Sound>
---@field missing string[]
---@field sources SoundSource[]
---@field cursor integer 轮转游标：不靠 IsPlaying 判断空闲，避免依赖未验证接口
---@field plays table<string, integer> 每个事件的播放次数
---@field ambient SoundSource|nil 环境循环声部
local Sfx = {}
Sfx.__index = Sfx

---@param scene Scene
---@param data M1AudioData
---@return M1Sfx
function Sfx.Create(scene, data)
    assert(scene ~= nil, "Sfx requires a scene")
    assert(data ~= nil and data.events ~= nil, "Sfx requires Data/Audio events")
    local self = setmetatable({
        scene = scene,
        data = data,
        sounds = {},
        missing = {},
        sources = {},
        cursor = 1,
        plays = {},
        ambient = nil,
    }, Sfx)
    self.node = scene:CreateChild("Sfx2D")
    self:LoadAll()
    self:CreateVoices()
    self:StartAmbient()
    return self
end

function Sfx:LoadAll()
    local loaded = 0
    for name, event in pairs(self.data.events) do
        local ok, sound = pcall(function() return cache:GetResource("Sound", event.file) end)
        if not ok or sound == nil then
            self.missing[#self.missing + 1] = name
            print(string.format("%s[LOAD] -> NONE | event=%s file=%s", TAG, name, event.file))
        else
            ---@cast sound Sound
            if event.loop == true then
                sound.looped = true
            end
            self.sounds[name] = sound
            loaded = loaded + 1
            print(string.format("%s[LOAD] -> OK | event=%s file=%s hz=%d",
                TAG, name, event.file, math.floor(sound:GetFrequency())))
        end
    end
    print(string.format("%s[LOAD] -> %s | loaded=%d missing=%d",
        TAG, #self.missing == 0 and "OK" or "NONE", loaded, #self.missing))
    assert(loaded > 0, "Sfx: no sound loaded, check assets/Sounds")
end

function Sfx:CreateVoices()
    for index = 1, self.data.poolVoices do
        local source = self.node:CreateComponent("SoundSource")
        assert(source ~= nil, "Sfx: SoundSource component missing")
        ---@cast source SoundSource
        source.soundType = SOUND_EFFECT
        self.sources[index] = source
    end
    print(string.format("%s[VOICE] -> OK | count=%d", TAG, #self.sources))
end

function Sfx:StartAmbient()
    local sound = self.sounds["rain"]
    local event = self.data.events["rain"]
    if sound == nil or event == nil then
        print(string.format("%s[AMBIENT] -> NONE | reason=sound-missing", TAG))
        return
    end
    local source = self.node:CreateComponent("SoundSource")
    assert(source ~= nil, "Sfx: ambient SoundSource missing")
    ---@cast source SoundSource
    source.soundType = SOUND_AMBIENT
    source:Play(sound, 0, event.gain)
    self.ambient = source
    print(string.format("%s[AMBIENT] -> OK | event=rain gain=%.2f", TAG, event.gain))
end

---@return SoundSource
function Sfx:NextSource()
    local source = self.sources[self.cursor]
    assert(source ~= nil, "Sfx: voice pool is empty")
    self.cursor = self.cursor % #self.sources + 1
    return source
end

---@param name string
---@param opts? { gain?: number, pitch?: number }
---@return boolean
function Sfx:Play(name, opts)
    local sound = self.sounds[name]
    if sound == nil then
        print(string.format("%s[PLAY] -> NONE | event=%s reason=not-loaded", TAG, name))
        return false
    end
    local event = self.data.events[name]
    assert(event ~= nil, "Sfx: event table missing for " .. name)
    local pitch = event.pitchMin + math.random() * (event.pitchMax - event.pitchMin)
    local extraGain = 1.0
    if opts ~= nil then
        if opts.pitch ~= nil then
            pitch = pitch * opts.pitch
        end
        if opts.gain ~= nil then
            extraGain = opts.gain
        end
    end
    local gain = math.max(0.0, math.min(1.0, event.gain * extraGain))
    local source = self:NextSource()
    source:Play(sound, math.floor(sound:GetFrequency() * pitch), gain)
    local count = (self.plays[name] or 0) + 1
    self.plays[name] = count
    -- 连射每秒十余次，只记前三次与每二十次，避免日志刷屏（第 27 节）
    if count <= 3 or count % 20 == 0 then
        print(string.format("%s[PLAY] -> OK | event=%s pitch=%.3f gain=%.2f n=%d",
            TAG, name, pitch, gain, count))
    end
    return true
end

-- 自检「声音」按钮：打音频设备与加载状态，然后把非循环事件各播一次（真机可听）。
function Sfx:Probe()
    local deviceOk = audio ~= nil
    local initialized = deviceOk and audio.initialized == true
    local mixRate = 0
    if deviceOk and audio.mixRate ~= nil then
        mixRate = math.floor(audio.mixRate)
    end
    print(string.format("%s[PROBE] -> %s | initialized=%s mixRate=%d loaded=%d missing=%d voices=%d ambient=%s",
        TAG, initialized and "OK" or "NONE", tostring(initialized), mixRate,
        #self.data.order - #self.missing, #self.missing, #self.sources,
        tostring(self.ambient ~= nil)))
    for index = 1, #self.data.order do
        local name = self.data.order[index]
        local event = self.data.events[name]
        print(string.format("%s[EVENT] -> %s | event=%s file=%s gain=%.2f pitch=%.2f-%.2f loop=%s",
            TAG, self.sounds[name] ~= nil and "OK" or "NONE", name, event.file, event.gain,
            event.pitchMin, event.pitchMax, tostring(event.loop == true)))
        if self.sounds[name] ~= nil and event.loop ~= true then
            self:Play(name)
        end
    end
end

-- 本模块建的节点与声部随场景回收；这里只清引用并留终点日志（第 16 节）。
function Sfx:Dispose()
    self.sources = {}
    self.ambient = nil
    print(string.format("%s[DISPOSE] -> OK | plays=%d missing=%d", TAG, #self.data.order, #self.missing))
end

return Sfx