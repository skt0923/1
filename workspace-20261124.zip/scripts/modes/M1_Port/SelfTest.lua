-- modes/M1_Port/SelfTest.lua: 自检执行器。只按玩家会做的操作序列驱动，不做判定；
-- 结论看各功能探针日志（[RIG][MOVE]、[RIG][JUMP]、[HUD][AMMO]、[M1][FLOOR]）。
-- 依据：docs/参考/任务-selftest-refactor-01.md、c6-selftest。
-- LSP 的临时配置没把 urhox-libs 装进 library 路径，全仓 UI 依赖都会报这条；运行时正常（第 33 节静态误报）
---@diagnostic disable-next-line: unresolved-require
local UI = require("urhox-libs/UI")

-- UI.Button/UI.Panel 是组件类字段，LSP 按无参构造推断，单次包装后统一调用（ModeMenu.lua 同写法不报）。
---@param props table
---@return any
local function MakeButton(props)
---@diagnostic disable-next-line: redundant-parameter
    return UI.Button(props)
end

---@param props table
---@return any
local function MakePanel(props)
---@diagnostic disable-next-line: redundant-parameter
    return UI.Panel(props)
end

local TAG = "[M1][SELFTEST]"

---@class M1SelfTestHud : ShooterPlayerHud
---@field QueueReload fun(self: ShooterPlayerHud)
---@field SetFireOverride fun(self: ShooterPlayerHud, on: boolean)
-- 2026-11-24 本地截图：底部一行 13 个按钮压住触摸 Run/Jump、摇杆与右侧开火/换弹/第三人称圆钮。
-- 改为顶部居中并缩小按钮；顶部左右分别是「设置」与弹药 HUD，居中一行不与其相交。
local BUTTON_WIDTH = 64
local BUTTON_HEIGHT = 32
local PANEL_GAP = 4
local PANEL_TOP = 8
local FLOOR_PITCH = -1.35

---@type integer[]
local HELD_KEYS = { CTRL_FORWARD, CTRL_BACK, CTRL_LEFT, CTRL_RIGHT, CTRL_JUMP }

---@class M1SelfTestAction
---@field at number Seconds from the item start.
---@field kind string pressKey|releaseKey|toggleCrouch|queueReload|fireOn|fireOff|aimFloor|restorePitch|damage
---@field key? integer
---@field target? string 传送目标（kind = teleport 时用）

---@class M1SelfTestItem
---@field name string
---@field label string
---@field duration number
---@field actions M1SelfTestAction[]
---@field noBatch? boolean 不参与「全部」连跑。

---@type M1SelfTestItem[]
local ITEMS = {
    { name = "move", label = "移动", duration = 2.2, actions = {
        { at = 0.0, kind = "pressKey", key = CTRL_FORWARD },
        { at = 1.7, kind = "releaseKey", key = CTRL_FORWARD },
    } },
    { name = "jump", label = "跳跃", duration = 1.6, actions = {
        { at = 0.0, kind = "pressKey", key = CTRL_JUMP },
        { at = 0.1, kind = "releaseKey", key = CTRL_JUMP },
    } },
    { name = "crouch", label = "蹲下", duration = 1.0, actions = {
        { at = 0.0, kind = "toggleCrouch" },
    } },
    { name = "fire", label = "开火", duration = 0.9, actions = {
        { at = 0.0, kind = "fireOn" },
        { at = 0.8, kind = "fireOff" },
    } },
    { name = "reload", label = "换弹", duration = 3.2, actions = {
        { at = 0.0, kind = "queueReload" },
    } },
    { name = "floor", label = "地面", duration = 0.1, actions = {
        { at = 0.0, kind = "aimFloor" },
    } },
    { name = "hurt", label = "受伤", duration = 0.4, actions = {
        { at = 0.0, kind = "damage" },
    } },
    { name = "props", label = "道具", duration = 0.1, actions = {
        { at = 0.0, kind = "probeProps" },
    } },
    { name = "enemy", label = "敌人", duration = 0.1, actions = {
        { at = 0.0, kind = "probeEnemy" },
    } },
    { name = "ai", label = "AI", duration = 0.1, actions = {
        { at = 0.0, kind = "autoPilot" },
    } },
    { name = "perf", label = "性能", duration = 0.1, actions = {
        { at = 0.0, kind = "probePerf" },
    } },
    { name = "relay", label = "中继", duration = 3.6, actions = {
        { at = 0.0, kind = "relayProbe" },
        { at = 0.1, kind = "relayTest" },
    } },
    { name = "rain", label = "雨", duration = 0.1, actions = {
        { at = 0.0, kind = "probeWeather" },
    } },
    { name = "fx", label = "特效", duration = 0.1, actions = {
        { at = 0.0, kind = "probeFx" },
    } },
    { name = "mark", label = "标记", duration = 0.1, actions = {
        { at = 0.0, kind = "probeMarkers" },
    } },
    -- 传送：远端验证室内停雨、码头、撤离点这类与位置有关的表现；会改局面位置，不参与「全部」连跑
    { name = "gun", label = "枪感", duration = 0.1, actions = {
        { at = 0.0, kind = "probeKick" },
    } },
    { name = "post", label = "后处理", duration = 0.1, actions = {
        { at = 0.0, kind = "probePost" },
    } },
    { name = "audio", label = "声音", duration = 0.1, actions = {
        { at = 0.0, kind = "probeSfx" },
    } },
    { name = "tp_gate", label = "大门", duration = 0.1, noBatch = true, actions = {
        { at = 0.0, kind = "teleport", target = "大门" },
    } },
    { name = "tp_yard", label = "堆场", duration = 0.1, noBatch = true, actions = {
        { at = 0.0, kind = "teleport", target = "堆场" },
    } },
    { name = "tp_shed", label = "仓库", duration = 0.1, noBatch = true, actions = {
        { at = 0.0, kind = "teleport", target = "仓库" },
    } },
    { name = "tp_quay", label = "码头", duration = 0.1, noBatch = true, actions = {
        { at = 0.0, kind = "teleport", target = "码头" },
    } },
    { name = "tp_extract", label = "撤离", duration = 0.1, noBatch = true, actions = {
        { at = 0.0, kind = "teleport", target = "撤离" },
    } },
    { name = "extract", label = "撤离", duration = 1.6, actions = {
        { at = 0.0, kind = "extractTest" },
    } },
    -- 两个会改变局面状态的项：只单点，不参与「全部」连跑
    { name = "flow", label = "全流程", duration = 0.1, noBatch = true, actions = {
        { at = 0.0, kind = "flowTest" },
    } },
    { name = "death", label = "死亡", duration = 0.1, noBatch = true, actions = {
        { at = 0.0, kind = "deathTest" },
    } },
}

---@class M1SelfTest
---@field rig PlayerRig
---@field hud M1SelfTestHud
---@field panel any
---@field buttons table<string, any>
---@field probePost fun()|nil 后处理探针（自检「后处理」）。
---@field postFx M1PostFx|nil 后处理模块；非 nil 时建属性级开关面板。
---@field postButtons table<string, any>|nil 开关按钮，key 是 Zone 属性名。
---@field probeSfx fun()|nil 音效探针（自检「声音」）。
---@field current M1SelfTestItem|nil
---@field elapsed number
---@field index integer
---@field steps integer
---@field pitchBefore number|nil
---@field queue M1SelfTestItem[]
---@field batch boolean
---@field probeFloor fun()|nil Prints the live floor material probe.
---@field probeProps fun()|nil Prints the level prop counts.
---@field probeEnemy fun()|nil Prints the wave/enemy counts.
---@field onAutoPilot fun()|nil Starts the auto-pilot self-test.
---@field probePerf fun()|nil Prints the frame rate and scene scale.
---@field probeRelay fun()|nil Prints the relay cut state.
---@field onRelayTest fun()|nil Teleports to the nearest relay and holds the cut.
---@field probeExtract fun()|nil Prints the extract state and run stats.
---@field onExtractTest fun()|nil Cuts all relays, teleports to the extract point.
---@field onFlowTest fun()|nil Runs the whole P3 flow with teleports.
---@field onDeathTest fun()|nil Kills the player to check the dead screen.
---@field probeMarkers fun()|nil Prints the world marker and relay lamp state.
---@field probeFx fun()|nil Prints the decal, burst and shell pool state.
---@field probeWeather fun()|nil Prints rain level, wetness and emitter state.
---@field onTeleport fun(target: string)|nil Moves the player to a named area (self-test only).
---@field probeKick fun()|nil Prints the recoil springs, sprint progress and inspect state.
---@field health M1PlayerHealth
local SelfTest = {}
SelfTest.__index = SelfTest

---@param rig PlayerRig
---@param hud M1SelfTestHud
---@param menu ModeMenu
---@param probeFloor fun() Floor material probe, printed on demand.
---@param health M1PlayerHealth Player health, for the hurt self-test item.
---@param probeProps fun() Level prop probe, printed on demand.
---@param probeEnemy fun() Enemy wave probe, printed on demand.
---@param onAutoPilot fun() Starts the auto-pilot self-test.
---@param probePerf fun() Prints the frame rate and scene scale.
---@param probeRelay fun() Prints the relay cut state.
---@param onRelayTest fun() Teleports to the nearest relay and holds the cut.
---@param probeExtract fun() Prints the extract state and run stats.
---@param onExtractTest fun() Cuts all relays and teleports to the extract point.
---@param onFlowTest fun() Runs the whole P3 flow with teleports.
---@param onDeathTest fun() Kills the player to check the dead screen.
---@param onProbeMarkers fun() Prints the world marker and relay lamp state.
---@param onProbeFx fun() Prints the decal, burst and shell pool state.
---@param onProbeWeather fun() Prints rain level, wetness and emitter state.
---@param onTeleport fun(target: string) Moves the player to a named area (self-test only).
---@param onProbeKick fun() Prints the recoil springs, sprint progress and inspect state.
---@param onProbePost fun() Prints the post-processing apply count and five readbacks.
---@param postFx M1PostFx|nil 后处理模块，用于逐项开关；nil 时不建开关面板。
---@param onProbeSfx fun() Prints the audio device state, the five events and plays each.
---@return M1SelfTest
function SelfTest.Create(rig, hud, menu, probeFloor, health, probeProps, probeEnemy, onAutoPilot,
    probePerf, probeRelay, onRelayTest, probeExtract, onExtractTest, onFlowTest, onDeathTest,
    onProbeMarkers, onProbeFx, onProbeWeather, onTeleport, onProbeKick, onProbePost, postFx,
    onProbeSfx)
    assert(rig ~= nil, "M1 SelfTest requires the player rig")
    assert(hud ~= nil, "M1 SelfTest requires the player HUD")
    assert(menu ~= nil and menu.root ~= nil, "M1 SelfTest requires the mode menu root")
    assert(type(probeFloor) == "function", "M1 SelfTest requires a floor probe callback")
    assert(health ~= nil and type(health.Damage) == "function", "M1 SelfTest requires the player health")
    assert(type(probeProps) == "function", "M1 SelfTest requires a level prop probe callback")
    assert(type(probeEnemy) == "function", "M1 SelfTest requires an enemy probe callback")
    assert(type(onAutoPilot) == "function", "M1 SelfTest requires an auto-pilot callback")
    assert(type(probePerf) == "function", "M1 SelfTest requires a perf probe callback")
    assert(type(probeRelay) == "function", "M1 SelfTest requires a relay probe callback")
    assert(type(onRelayTest) == "function", "M1 SelfTest requires a relay test callback")
    assert(type(probeExtract) == "function", "M1 SelfTest requires an extract probe callback")
    assert(type(onExtractTest) == "function", "M1 SelfTest requires an extract test callback")
    assert(type(onFlowTest) == "function", "M1 SelfTest requires a flow test callback")
    assert(type(onDeathTest) == "function", "M1 SelfTest requires a death test callback")
    assert(type(onProbeMarkers) == "function", "M1 SelfTest requires a marker probe callback")
    assert(type(onProbeFx) == "function", "M1 SelfTest requires a fx probe callback")
    assert(type(onProbeWeather) == "function", "M1 SelfTest requires a weather probe callback")
    assert(type(onTeleport) == "function", "M1 SelfTest requires a teleport callback")
    assert(type(onProbeKick) == "function", "M1 SelfTest requires a kick probe callback")
    assert(type(onProbePost) == "function", "M1 SelfTest requires a postfx probe callback")
    assert(type(onProbeSfx) == "function", "M1 SelfTest requires a sfx probe callback")

---@type M1SelfTest
    local self = setmetatable({
        rig = rig,
        hud = hud,
        panel = nil,
        buttons = {},
        current = nil,
        elapsed = 0.0,
        index = 1,
        steps = 0,
        pitchBefore = nil,
        queue = {},
        batch = false,
        probeFloor = probeFloor,
        health = health,
        probeProps = probeProps,
        probeEnemy = probeEnemy,
        onAutoPilot = onAutoPilot,
        probePerf = probePerf,
        probeRelay = probeRelay,
        onRelayTest = onRelayTest,
        probeExtract = probeExtract,
        onExtractTest = onExtractTest,
        onFlowTest = onFlowTest,
        onDeathTest = onDeathTest,
        probeMarkers = onProbeMarkers,
        probeFx = onProbeFx,
        probeWeather = onProbeWeather,
        onTeleport = onTeleport,
        probeKick = onProbeKick,
        probePost = onProbePost,
        probeSfx = onProbeSfx,
        postFx = postFx,
        postButtons = nil,
    }, SelfTest)
    self:BuildPanel(menu)
    self:BuildPostToggles(menu)
    return self
end

---@param menu ModeMenu
function SelfTest:BuildPanel(menu)
    local owner = self
    local children = {}
    for index = 1, #ITEMS do
        local item = ITEMS[index]
        local button = MakeButton {
            text = item.label,
            width = BUTTON_WIDTH,
            height = BUTTON_HEIGHT,
            fontSize = 12,
            flexShrink = 0,
            variant = "secondary",
            onClick = function() owner:Run(item) end,
        }
        self.buttons[item.name] = button
        children[#children + 1] = button
    end
    children[#children + 1] = MakeButton {
        text = "全部",
        width = BUTTON_WIDTH,
        height = BUTTON_HEIGHT,
        fontSize = 12,
        flexShrink = 0,
        variant = "primary",
        onClick = function() owner:RunAll() end,
    }
    local panel = MakePanel {
        position = "absolute",
        left = 0,
        right = 0,
        top = PANEL_TOP,
        flexDirection = "row",
        flexWrap = "wrap",
        justifyContent = "center",
        gap = PANEL_GAP,
        -- 面板本身不拦截触摸，只有按钮命中；否则底部整条会吞掉拖拽视角
        pointerEvents = "box-none",
        children = children,
    }
    ---@type boolean|nil
    local attached = menu.root:AddChild(panel)
    assert(attached ~= false, "M1 SelfTest panel failed to attach to the mode menu root")
    self.panel = panel
    print(string.format("%s -> OK | event=create items=%d", TAG, #ITEMS))
end

-- 后处理逐项开关面板：16 个 Zone 属性各一个按钮，两行各 8 个，位于自检行下方。
-- 位置依据：自检行本身会折成两行（8 + 32 + 4 + 32 = 76），所以从 88 起；
-- 8×62 + 7×4 = 524 宽并居中，左侧任务条与右侧弹药 HUD 都在 ~520 以外，不相交。
local POST_BUTTON_WIDTH = 78
local POST_BUTTON_HEIGHT = 26
local POST_PANEL_TOP = 88
local POST_PER_ROW = 8

---@param toggle M1PostFxToggle
---@return string
function SelfTest:PostButtonText(toggle)
    return string.format("%s%s", toggle.label, toggle.on and "开" or "关")
end

---@param key string
function SelfTest:TogglePost(key)
    local postFx = self.postFx
    if postFx == nil then
        return
    end
    local buttons = self.postButtons
    assert(buttons ~= nil, "SelfTest post buttons missing")
    local toggle = postFx:Toggle(key)
    local button = buttons[key]
    if button ~= nil then
        button:SetText(self:PostButtonText(toggle))
    end
end

---@param menu ModeMenu
function SelfTest:BuildPostToggles(menu)
    local postFx = self.postFx
    if postFx == nil then
        print(string.format("%s[POSTTGL] -> NONE | reason=postfx-missing", TAG))
        return
    end
    local owner = self
    local toggles = postFx:GetToggles()
    assert(#toggles > 0, "SelfTest post toggles: PostFx returned no toggles")
    self.postButtons = {}
    ---@type any[]
    local rows = {}
    ---@type any[]
    local current = {}
    for index = 1, #toggles do
        local toggle = toggles[index]
        local button = MakeButton {
            text = owner:PostButtonText(toggle),
            width = POST_BUTTON_WIDTH,
            height = POST_BUTTON_HEIGHT,
            fontSize = 10,
            flexShrink = 0,
            variant = "secondary",
            onClick = function() owner:TogglePost(toggle.key) end,
        }
        self.postButtons[toggle.key] = button
        current[#current + 1] = button
        if #current == POST_PER_ROW or index == #toggles then
            rows[#rows + 1] = MakePanel {
                flexDirection = "row",
                justifyContent = "center",
                gap = 6,
                pointerEvents = "box-none",
                children = current,
            }
            current = {}
        end
    end
    local panel = MakePanel {
        position = "absolute",
        left = 0,
        right = 0,
        top = POST_PANEL_TOP,
        flexDirection = "column",
        alignItems = "center",
        gap = PANEL_GAP,
        pointerEvents = "box-none",
        children = rows,
    }
    ---@type boolean|nil
    local attached = menu.root:AddChild(panel)
    assert(attached ~= false, "M1 SelfTest post panel failed to attach to the mode menu root")
    print(string.format("%s[POSTTGL] -> OK | event=create count=%d rows=%d", TAG, #toggles, #rows))
end

---@param action M1SelfTestAction
function SelfTest:Apply(action)
    local controls = self.rig.character.controls
    local key = action.key or 0
    if action.kind == "pressKey" then
        controls:Set(key, true)
    elseif action.kind == "releaseKey" then
        controls:Set(key, false)
    elseif action.kind == "toggleCrouch" then
        self.rig:ToggleCrouch()
    elseif action.kind == "queueReload" then
        self.hud:QueueReload()
    elseif action.kind == "fireOn" then
        self.hud:SetFireOverride(true)
    elseif action.kind == "fireOff" then
        self.hud:SetFireOverride(false)
    elseif action.kind == "damage" then
        self.health:Damage(25, "selftest")
    elseif action.kind == "probeProps" then
        if self.probeProps ~= nil then self.probeProps() end
    elseif action.kind == "probeEnemy" then
        if self.probeEnemy ~= nil then self.probeEnemy() end
    elseif action.kind == "autoPilot" then
        if self.onAutoPilot ~= nil then self.onAutoPilot() end
    elseif action.kind == "probePerf" then
        if self.probePerf ~= nil then self.probePerf() end
    elseif action.kind == "probeMarkers" then
        if self.probeMarkers ~= nil then self.probeMarkers() end
    elseif action.kind == "probeFx" then
        if self.probeFx ~= nil then self.probeFx() end
    elseif action.kind == "probeWeather" then
        if self.probeWeather ~= nil then self.probeWeather() end
    elseif action.kind == "teleport" then
        local target = action.target
        assert(target ~= nil, "SelfTest teleport action needs a target")
        if self.onTeleport ~= nil then self.onTeleport(target) end
    elseif action.kind == "probeKick" then
        if self.probeKick ~= nil then self.probeKick() end
    elseif action.kind == "probePost" then
        if self.probePost ~= nil then self.probePost() end
    elseif action.kind == "probeSfx" then
        if self.probeSfx ~= nil then self.probeSfx() end
    elseif action.kind == "relayProbe" then
        if self.probeRelay ~= nil then self.probeRelay() end
    elseif action.kind == "relayTest" then
        if self.onRelayTest ~= nil then self.onRelayTest() end
    elseif action.kind == "extractProbe" then
        if self.probeExtract ~= nil then self.probeExtract() end
    elseif action.kind == "extractTest" then
        if self.onExtractTest ~= nil then self.onExtractTest() end
    elseif action.kind == "flowTest" then
        if self.onFlowTest ~= nil then self.onFlowTest() end
    elseif action.kind == "deathTest" then
        if self.onDeathTest ~= nil then self.onDeathTest() end
    elseif action.kind == "aimFloor" then
        self.pitchBefore = controls.pitch
        controls.pitch = FLOOR_PITCH
        if self.probeFloor ~= nil then self.probeFloor() end
    elseif action.kind == "restorePitch" then
        if self.pitchBefore ~= nil then
            controls.pitch = self.pitchBefore
            self.pitchBefore = nil
        end
    end
    self.steps = self.steps + 1
    print(string.format("%s -> OK | event=step item=%s index=%d action=%s",
        TAG, tostring(self.current and self.current.name), self.index, action.kind))
end

---@param reason string
function SelfTest:Interrupt(reason)
    if self.current == nil then return end
    local controls = self.rig.character.controls
    for index = 1, #HELD_KEYS do
        controls:Set(HELD_KEYS[index], false)
    end
    self.hud:SetFireOverride(false)
    print(string.format("%s -> NONE | event=interrupt item=%s index=%d steps=%d reason=%s",
        TAG, self.current.name, self.index, self.steps, reason))
    self.current = nil
    self.batch = false
    self.queue = {}
end

function SelfTest:Finish()
    local item = self.current
    if item == nil then return end
    print(string.format("%s -> OK | event=done item=%s steps=%d elapsed=%.2f",
        TAG, item.name, self.steps, self.elapsed))
    self.current = nil
    self.elapsed = 0.0
    self.index = 1
    self.steps = 0
    if #self.queue > 0 then
        local nextItem = table.remove(self.queue, 1)
        ---@cast nextItem M1SelfTestItem
        self:Start(nextItem)
    elseif self.batch then
        self.batch = false
        self:Apply({ at = 0.0, kind = "restorePitch" })
        print(string.format("%s -> OK | event=all-done", TAG))
    end
end

---@param item M1SelfTestItem
function SelfTest:Start(item)
    self.current = item
    self.elapsed = 0.0
    self.index = 1
    self.steps = 0
    print(string.format("%s -> OK | event=start item=%s steps=%d", TAG, item.name, #item.actions))
end

---@param item M1SelfTestItem
function SelfTest:Run(item)
    self:Interrupt("new-run")
    self:Apply({ at = 0.0, kind = "restorePitch" })
    self.queue = {}
    self.batch = false
    self:Start(item)
end

function SelfTest:RunAll()
    self:Interrupt("new-run")
    self:Apply({ at = 0.0, kind = "restorePitch" })
    self.queue = {}
    for index = 2, #ITEMS do
        local item = ITEMS[index]
        -- 「全流程」「死亡」会改局面状态，连跑时不带上
        if not item.noBatch then
            self.queue[#self.queue + 1] = item
        end
    end
    self.batch = true
    print(string.format("%s -> OK | event=all-start items=%d", TAG, #ITEMS))
    local first = ITEMS[1]
    ---@cast first M1SelfTestItem
    self:Start(first)
end

---@param dt number
---@param uiHit boolean True while the settings popup covers the screen.
function SelfTest:Update(dt, uiHit)
    if uiHit and self.current ~= nil then
        self:Interrupt("menu-open")
        return
    end
    local item = self.current
    if item == nil then return end
    self.elapsed = self.elapsed + dt
    while self.index <= #item.actions do
        ---@type M1SelfTestAction|nil
        local action = item.actions[self.index]
        if action == nil or action.at > self.elapsed then break end
        self:Apply(action)
        self.index = self.index + 1
    end
    if self.elapsed >= item.duration then
        self:Finish()
    end
end

function SelfTest:Stop()
    self:Interrupt("stop")
    if self.panel ~= nil then
        self.panel:Remove()
        self.panel = nil
    end
    self.buttons = {}
    print(string.format("%s -> OK | event=stop", TAG))
end

function SelfTest:Dispose()
    self.rig = nil
    self.hud = nil
    self.panel = nil
    self.buttons = {}
    self.current = nil
    self.queue = {}
    self.probeFloor = nil
    self.probeProps = nil
    self.probeEnemy = nil
    self.onAutoPilot = nil
    self.probePerf = nil
    self.probeRelay = nil
    self.onRelayTest = nil
    self.probeExtract = nil
    self.onExtractTest = nil
    self.onFlowTest = nil
    self.onDeathTest = nil
    self.probeMarkers = nil
    self.probeFx = nil
    self.probeWeather = nil
    self.onTeleport = nil
    self.probeKick = nil
    self.health = nil
    print(string.format("%s -> OK | event=dispose", TAG))
end

return SelfTest
