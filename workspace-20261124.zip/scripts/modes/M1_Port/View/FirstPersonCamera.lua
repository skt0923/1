-- 第一人称相机：视线、俯仰限制、FOV 与视角日志；数值全部由玩法 data 传入。
---@type table Math 由 kit 通过 SetMath 注入（第 13 节：积木间禁止直接 require）；
-- 未注入时为空表，调用具体函数会立刻报错，不会静默通过。
local Math = {}

local LOOK_LOG_INTERVAL = 0.5
local LOOK_LOG_EPSILON = 0.1

---@class ShooterFirstPersonCamera
---@field node Node
---@field camera Camera
---@field controls Controls
---@field data M1PlayerData
---@field controlsData M1ControlsData
---@field mouseLook boolean
---@field lookTimer number
---@field lastYaw number
---@field lastPitch number
---@field settings M1SettingsState|nil Live settings (sensitivity, invertY, fov); nil keeps the data defaults.
local FirstPersonCamera = {}
FirstPersonCamera.__index = FirstPersonCamera

---@param scene Scene
---@param data M1PlayerData
---@param controlsData M1ControlsData
---@param controls Controls
---@return ShooterFirstPersonCamera
function FirstPersonCamera.Create(scene, data, controlsData, controls)
    local node = scene:CreateChild("FirstPersonCamera")
-- 组件加载失败需显式中断（f2），.emmylua 声明非 nil 才判多余
---@diagnostic disable-next-line: unnecessary-assert
    local camera = assert(node:CreateComponent("Camera"), "FirstPersonCamera node missing Camera")
    camera.fov = data.fov
    camera.nearClip = data.nearClip
    camera.farClip = data.farClip

-- 触摸平台会把触摸映射成 mouseMove，鼠标视角与触摸视角会叠加
    local platform = GetNativePlatform()
    local mobile = platform == "Android" or platform == "iOS" or platform == "HarmonyOS"
    local mouseLook = not mobile and not input.touchEmulation
    print(string.format("[CAMERA][LOOK] -> OK | event=create mouse=%s platform=%s", tostring(mouseLook), platform))

    return setmetatable({
        node = node,
        camera = camera,
        controls = controls,
        data = data,
        controlsData = controlsData,
        mouseLook = mouseLook,
        lookTimer = 0.0,
        lastYaw = controls.yaw,
        lastPitch = controls.pitch,
    }, FirstPersonCamera)
end

function FirstPersonCamera:UpdateLook()
    if not self.mouseLook or input.mouseMode ~= MM_RELATIVE then return end
    local settings = self.settings
    local sensitivity = math.deg(settings ~= nil and settings.sensitivity or self.controlsData.lookSensitivity)
    local pitchSign = (settings ~= nil and settings.invertY) and -1.0 or 1.0
    self.controls.yaw = self.controls.yaw + input.mouseMoveX * sensitivity
    self.controls.pitch = self.controls.pitch + input.mouseMoveY * sensitivity * pitchSign
end

---Apply live settings; the fov reaches the camera on the next Sync.
---@param settings M1SettingsState
function FirstPersonCamera:SetSettings(settings)
    assert(settings ~= nil and type(settings.fov) == "number", "FirstPersonCamera:SetSettings needs a state")
    self.settings = settings
end

---@param eye Vector3
---@param dt? number
function FirstPersonCamera:Sync(eye, dt)
    dt = dt or 0.0
-- 触摸视角直接写 controls.pitch，需在这里统一钳制
    local limit = math.deg(self.data.pitchLimit)
    self.controls.pitch = Math.clamp(self.controls.pitch, -limit, limit)
    local live = self.settings
    local targetFov = live ~= nil and live.fov or self.data.fov
    if math.abs(self.camera.fov - targetFov) > 0.01 then
        self.camera.fov = targetFov
    end
    self.node.worldPosition = eye
    self.node.worldRotation = Quaternion(self.controls.pitch, self.controls.yaw, 0)

    local yaw = self.controls.yaw
    local pitch = self.controls.pitch
    if math.abs(yaw - self.lastYaw) < LOOK_LOG_EPSILON and math.abs(pitch - self.lastPitch) < LOOK_LOG_EPSILON then
        self.lookTimer = 0.0
        return
    end
    self.lookTimer = self.lookTimer + dt
    if self.lookTimer < LOOK_LOG_INTERVAL then return end
    self.lookTimer = 0.0
    self.lastYaw = yaw
    self.lastPitch = pitch
    print(string.format("[CAMERA][LOOK] -> OK | event=probe source=%s yaw=%.1f pitch=%.1f expectPitch=[%.1f,%.1f]",
        self.mouseLook and "mouse" or "touch", yaw, pitch, -limit, limit))
end

--- 注入纯数学工具（kit 启动时调用；第 13 节禁止积木间直接 require）
---@param mathLib table Math 模块（clamp/lerp/WrapAngle/damp…）
function FirstPersonCamera.SetMath(mathLib)
-- 注入参数可能为 nil（未注入时），assert 是防御性检查而非冗余
---@diagnostic disable-next-line: unnecessary-assert
    Math = assert(mathLib, "FirstPersonCamera.SetMath requires Math from kit")
end

return FirstPersonCamera
