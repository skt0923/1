-- 第三人称相机与角色：角色只在第三人称可见（第一人称用相机上的视图模型，原作做法）。
-- 数值来自 modes/M1_Port/Data/Player.lua（e8/e9）。
local ThirdPersonCamera = require("urhox-libs.Camera.ThirdPersonCamera")
-- 由 Create 的 deps 注入（第 13 节：积木间禁止直接 require）
---@type table
local Character
---@type table
local WeaponPose

local TAG = "[TPVIEW]"

---@class ShooterThirdPersonView
---@field node Node
---@field camera Camera
---@field tpCamera ThirdPersonCameraInstance
---@field actor TararaActor
---@field pose ShooterWeaponPose|nil
---@field yawOffset number
---@field idleClip string
---@field runClip string
---@field runSpeedThreshold number
local ThirdPersonView = {}
ThirdPersonView.__index = ThirdPersonView

---@param scene Scene
---@param data M1PlayerData Mode data table; only the thirdPerson section is read.
---@param deps {Character: table, WeaponPose: table} kit 注入的角色与持枪姿势积木。
---@return ShooterThirdPersonView
function ThirdPersonView.Create(scene, data, deps)
    assert(deps ~= nil and deps.Character ~= nil and deps.WeaponPose ~= nil,
        "ThirdPersonView.Create requires deps.Character and deps.WeaponPose from kit")
    Character, WeaponPose = deps.Character, deps.WeaponPose
-- 数据表缺失需显式中断（f2），.emmylua 声明该字段非 nil 才判多余
---@diagnostic disable-next-line: unnecessary-assert
    local cfg = assert(data.thirdPerson, "ThirdPersonView requires data.thirdPerson")

    local actor = Character.Load(scene, "M1Actor")
    actor:Play(cfg.idleClip)
    -- 第一人称不显示身体
    actor.node:SetDeepEnabled(false)

    local tpCamera = ThirdPersonCamera.Create(scene, {
        modes = {
            normal = { distance = cfg.distance, offset = Vector3(0, cfg.offsetY, 0), fov = cfg.fov },
        },
        initialMode = "normal",
    })
    local camNode = tpCamera:GetNode()
    camNode.name = "ThirdPersonCamera"
    scene:AddChild(camNode)
    local camera = tpCamera:GetCamera()

    print(string.format("%s[CREATE] -> OK | distance=%.1f offsetY=%.2f fov=%.0f idle=%s run=%s yawOffset=%.0f", TAG,
        cfg.distance, cfg.offsetY, cfg.fov, cfg.idleClip, cfg.runClip, cfg.actorYawOffset))

    return setmetatable({
        node = actor.node,
        camera = camera,
        tpCamera = tpCamera,
        actor = actor,
        pose = nil,
        yawOffset = cfg.actorYawOffset,
        idleClip = cfg.idleClip,
        runClip = cfg.runClip,
        runSpeedThreshold = cfg.runSpeedThreshold,
    }, ThirdPersonView)
end

--- 角色位置跟随玩家，朝向为相机 yaw 叠加模型前向补偿（模型前向 +Z，补偿为 0）。
---@param target Node
---@param yaw number Degrees.
---@param pitch number Degrees.
---@param speed number Horizontal speed in metres per second.
function ThirdPersonView:Update(target, yaw, pitch, speed)
    self.node.worldPosition = target.worldPosition
    self.node.worldRotation = Quaternion(0, yaw + self.yawOffset, 0)
    self.tpCamera:Update(0.0, target, yaw, pitch)
    local clip = speed > self.runSpeedThreshold and self.runClip or self.idleClip
    if self.actor.animation ~= clip then self.actor:Play(clip) end
end

--- 绑定持枪姿势（传入挂在角色根节点下的枪）。
---@param gunNode Node
---@param poseCfg M1PoseData
function ThirdPersonView:AttachWeapon(gunNode, poseCfg)
    self.pose = WeaponPose.Create(self.actor, gunNode, poseCfg)
end

--- 每帧动画之后调用（Router 的 PostUpdate 转发到此）。
function ThirdPersonView:PostUpdate()
    local pose = self.pose
    if pose ~= nil then pose:Update() end
end

--- 第一人称隐藏整个角色，第三人称显示。
---@param visible boolean
function ThirdPersonView:SetBodyVisible(visible)
    self.node:SetDeepEnabled(visible == true)
    print(string.format("%s[BODY] -> OK | visible=%s", TAG, tostring(visible == true)))
end

--- 角色真实前向：模型前向是 +Z（feedback 53811 反证 -Z 会正脸朝镜头）
---@return Vector3
function ThirdPersonView:GetForward()
    return self.node.worldRotation * Vector3(0, 0, 1)
end

---@return Camera
function ThirdPersonView:GetCamera()
    return self.camera
end

function ThirdPersonView:Destroy()
    local pose = self.pose
    if pose ~= nil then pose:Destroy() end
    self.pose = nil
    local node = self.node
    if node ~= nil then node:Remove() end
    self.node = nil
    self.camera = nil
    self.tpCamera = nil
    self.actor = nil
    print(string.format("%s[DESTROY] -> OK", TAG))
end

return ThirdPersonView
