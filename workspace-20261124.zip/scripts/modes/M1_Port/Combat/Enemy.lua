-- 单个敌人：占位骨架 + 状态机（巡逻 / 追击 / 攻击 / 死亡）。
-- 数值来自 Data/Enemy.lua；原作 17-enemy 的骨骼动画、寻路与冲刺本批不实现（差异表 m1-p2a-enemy）。
local TAG = "[M1][ENEMY]"

---@class M1EnemyContext
---@field playerPos Vector3
---@field visible fun(from: Vector3, to: Vector3): boolean
---@field onEnemyShot fun(origin: Vector3, dir: Vector3, damage: number): boolean
---@field requestFire fun(enemy: M1Enemy): boolean
---@field releaseFire fun(enemy: M1Enemy): nil
---@field groundY number

---@class M1Enemy
---@field data M1EnemyData
---@field node Node
---@field index integer
---@field zone string
---@field health number
---@field alive boolean
---@field state string patrol|chase|attack|dead
---@field cooldown number
---@field telegraph number
---@field burstLeft integer
---@field burstTimer number
---@field shots integer
---@field spawn Vector3
---@field lastVisible boolean
---@field checkedSight boolean
local Enemy = {}
Enemy.__index = Enemy

local BODY = Vector3(1.5, 0.9, 0.7)
local HEAD = Vector3(0.5, 0.5, 0.5)
local TAIL = Vector3(0.9, 0.3, 0.3)

---@param scene Scene
---@param data M1EnemyData
---@param spawn M1EnemySpawn
---@param index integer
---@param materials table Art/Materials 模块（Get）。
---@return M1Enemy
function Enemy.Create(scene, data, spawn, index, materials)
    assert(scene ~= nil, "Enemy requires a scene")
    assert(data ~= nil and data.health > 0, "Enemy requires enemy data")
    assert(spawn ~= nil and spawn.x ~= nil, "Enemy requires a spawn point")

    local node = scene:CreateChild(string.format("Enemy_%d", index))
    node.position = Vector3(spawn.x, 0.0, spawn.z)
    local ok, model = pcall(function() return cache:GetResource("Model", "Models/Box.mdl") end)
    assert(ok and model ~= nil, "Missing model: Models/Box.mdl")

    ---@param size Vector3
    ---@param offset Vector3
    ---@param materialName string
    local function Part(size, offset, materialName)
        local partNode = node:CreateChild("part")
        partNode.position = offset
        partNode.scale = size
        local okPart, partModel = pcall(function() return partNode:CreateComponent("StaticModel") end)
        assert(okPart and partModel ~= nil, "Enemy part missing StaticModel")
        ---@cast partModel StaticModel
        partModel:SetModel(model --[[@as Model]])
        local okMat, found = pcall(materials.Get, materialName, { uvMeters = 1.0 })
        if okMat and found ~= nil then
            local material = found --[[@as Material]]
            partModel:SetMaterial(material)
        end
        partModel:SetCastShadows(true)
    end

    Part(BODY, Vector3(0.0, 0.45, 0.0), "paint_grey")
    Part(HEAD, Vector3(0.0, 0.9, 0.6), "paint_grey")
    Part(TAIL, Vector3(0.0, 1.0, -0.3), "paint_yellow")

    ---@type M1Enemy
    local self = setmetatable({
        data = data,
        node = node,
        index = index,
        zone = spawn.zone or "unknown",
        health = data.health,
        alive = true,
        state = "patrol",
        cooldown = 0.0,
        telegraph = 0.0,
        burstLeft = 0,
        burstTimer = 0.0,
        shots = 0,
        spawn = Vector3(spawn.x, 0.0, spawn.z),
        lastVisible = false,
        checkedSight = false,
    }, Enemy)
    print(string.format("%s[SPAWN] -> OK | index=%d zone=%s hp=%.0f pos=(%.1f,0.0,%.1f)",
        TAG, index, self.zone, self.health, spawn.x, spawn.z))
    return self
end

---@return Vector3
function Enemy:GetPosition()
    return self.node.position
end

---@return boolean
function Enemy:IsAlive()
    return self.alive
end

---@param amount number
---@param reason string
---@return boolean dead
function Enemy:Damage(amount, reason)
    if not self.alive then
        return false
    end
    if type(amount) ~= "number" or amount <= 0 then
        print(string.format("%s[DAMAGE] -> FAIL | index=%d amount=%s", TAG, self.index, tostring(amount)))
        return false
    end
    self.health = math.max(0.0, self.health - amount)
    if self.health <= 0.0 then
        self.alive = false
        self.state = "dead"
        self.node:SetDeepEnabled(false)
        print(string.format("%s[DEATH] -> OK | index=%d reason=%s shots=%d", TAG, self.index, reason, self.shots))
        return true
    end
    print(string.format("%s[DAMAGE] -> OK | index=%d reason=%s amount=%.1f hp=%.0f", TAG, self.index, reason, amount,
        self.health))
    return false
end

--- 射线与敌人包围盒求交（轴对齐近似，忽略朝向；原作是骨骼胶囊）。
---@param origin Vector3
---@param dir Vector3
---@param maxDist number
---@return number|nil distance
function Enemy:RayHit(origin, dir, maxDist)
    if not self.alive then
        return nil
    end
    local center = self.node.position
    local half = self.data.hitRadius
    local tmin, tmax = 0.0, maxDist
    local missed = false

---@param o number
---@param d number
---@param lo number
---@param hi number
    local function Slab(o, d, lo, hi)
        if missed then return end
        if math.abs(d) < 1e-6 then
            if o < lo or o > hi then
                missed = true
            end
            return
        end
        local t1 = (lo - o) / d
        local t2 = (hi - o) / d
        if t1 > t2 then
            t1, t2 = t2, t1
        end
        if t1 > tmin then tmin = t1 end
        if t2 < tmax then tmax = t2 end
        if tmin > tmax then
            missed = true
        end
    end

    Slab(origin.x, dir.x, center.x - half, center.x + half)
    Slab(origin.y, dir.y, center.y, center.y + 1.4)
    Slab(origin.z, dir.z, center.z - half, center.z + half)
    if missed then
        return nil
    end
    return tmin
end

---@param dt number
---@param ctx M1EnemyContext
function Enemy:Update(dt, ctx)
    if not self.alive then
        return
    end
    local pos = self.node.position
    local toPlayer = ctx.playerPos - pos
    local distance = toPlayer:Length()
    local flat = Vector3(toPlayer.x, 0.0, toPlayer.z)
    local flatLength = flat:Length()

    local visible = false
    if distance <= self.data.sightRange and flatLength > 0.001 then
        visible = ctx.visible(Vector3(pos.x, pos.y + 1.0, pos.z), ctx.playerPos)
    end
    if visible ~= self.lastVisible or not self.checkedSight then
        self.lastVisible = visible
        self.checkedSight = true
        print(string.format("%s[SIGHT] -> %s | index=%d dist=%.1f range=%.0f blocked=%s", TAG,
            visible and "OK" or "NONE", self.index, distance, self.data.sightRange,
            visible and "0" or "1"))
    end

    if self.cooldown > 0.0 then
        self.cooldown = self.cooldown - dt
    end
    if self.burstLeft > 0 then
        self.burstTimer = self.burstTimer - dt
        if self.burstTimer <= 0.0 then
            self:FireOnce(ctx, distance)
            self.burstLeft = self.burstLeft - 1
            self.burstTimer = self.data.burstGap
            if self.burstLeft <= 0 then
                ctx.releaseFire(self)
                self.cooldown = self.data.cooldownMin
                    + math.random() * (self.data.cooldownMax - self.data.cooldownMin)
            end
        end
    end

    if self.telegraph > 0.0 then
        self.telegraph = self.telegraph - dt
        if self.telegraph <= 0.0 then
            self.burstLeft = self.data.burst
            self.burstTimer = 0.0
            print(string.format("%s[FIRE] -> OK | index=%d event=burst burst=%d dist=%.1f",
                TAG, self.index, self.data.burst, distance))
        end
        return
    end

    if not visible then
        ctx.releaseFire(self)
        if self.state ~= "patrol" then
            self.state = "patrol"
            print(string.format("%s[STATE] -> OK | index=%d state=patrol reason=lost-sight", TAG, self.index))
        end
        if flatLength > 0.001 then
            local step = flat * (self.data.patrolSpeed * dt / flatLength)
            pos.x = pos.x - step.x
            pos.z = pos.z - step.z
            self.node.position = pos
        end
        return
    end

    if distance > self.data.rangeMax then
        if self.state ~= "chase" then
            self.state = "chase"
            print(string.format("%s[STATE] -> OK | index=%d state=chase dist=%.1f", TAG, self.index, distance))
        end
        if flatLength > 0.001 then
            local step = flat * (self.data.runSpeed * dt / flatLength)
            pos.x = pos.x + step.x
            pos.z = pos.z + step.z
            self.node.position = pos
        end
        return
    end

    if self.state ~= "attack" then
        self.state = "attack"
        print(string.format("%s[STATE] -> OK | index=%d state=attack dist=%.1f", TAG, self.index, distance))
    end
    if distance < self.data.rangeMin and flatLength > 0.001 then
        local step = flat * (self.data.runSpeed * dt / flatLength)
        pos.x = pos.x - step.x
        pos.z = pos.z - step.z
        self.node.position = pos
    end
    if self.cooldown <= 0.0 and self.burstLeft <= 0 then
        -- 原作 token：同时开火数有上限，抢不到名额就继续等（冷却不清零）。
        if ctx.requestFire(self) then
            self.telegraph = self.data.telegraph
        end
    end
end

---@param ctx M1EnemyContext
---@param distance number
function Enemy:FireOnce(ctx, distance)
    local span = math.max(0.001, self.data.rangeMax - self.data.rangeMin)
    local t = math.min(1.0, math.max(0.0, (distance - self.data.rangeMin) / span))
    local spread = self.data.spreadNear + (self.data.spreadFar - self.data.spreadNear) * t
    -- 原作 17-enemy 语句 z：散布是按弧度加到方向向量上，命中由真实弹道对玩家行胶囊判定；
    -- 原先用 1 - spread/0.5 换成概率，15 米处有 76%，与作动手感差一个量级。
    local pos = self.node.position
    local ox, oy, oz = pos.x, pos.y + 0.9, pos.z
    -- ctx.playerPos 已是玩家眼睛位置（Mode 传 GetEyePosition），不能再抬高。
    local tx, ty, tz = ctx.playerPos.x, ctx.playerPos.y, ctx.playerPos.z
    local dx, dy, dz = tx - ox, ty - oy, tz - oz
    local length = math.sqrt(dx * dx + dy * dy + dz * dz)
    if length < 0.001 then
        print(string.format("%s[FIRE] -> FAIL | index=%d reason=zero-distance", TAG, self.index))
        return
    end
    dx, dy, dz = dx / length, dy / length, dz / length
    dx = dx + (math.random() - 0.5) * 2.0 * spread
    dy = dy + (math.random() - 0.5) * 2.0 * spread
    dz = dz + (math.random() - 0.5) * 2.0 * spread
    local dirLength = math.sqrt(dx * dx + dy * dy + dz * dz)
    local dir = Vector3(dx / dirLength, dy / dirLength, dz / dirLength)
    self.shots = self.shots + 1
    local hit = ctx.onEnemyShot(Vector3(ox, oy, oz), dir, self.data.shotDamage)
    print(string.format(
        "%s[HIT] -> %s | index=%d shot=%d dist=%.1f spread=%.3f dir=(%.2f,%.2f,%.2f) dmg=%.0f",
        TAG, hit and "OK" or "NONE", self.index, self.shots, distance, spread,
        dir.x, dir.y, dir.z, hit and self.data.shotDamage or 0))
end

function Enemy:Dispose()
    local node = self.node
    if node ~= nil then
        node:SetDeepEnabled(false)
        node:Remove()
    end
    print(string.format("%s[DISPOSE] -> OK | index=%d", TAG, self.index))
end

return Enemy
