-- 玩家生命：本玩法唯一的权威生命数据，读写只走本文件。
-- 数值全部来自 Data/Health.lua（15-player 的 health / regen / damage 规则）。
-- 触发源：Rig 的落地与落水回调（Mode.lua 注入），自检按钮「受伤」。
local TAG = "[M1][HURT]"

---@class M1PlayerSnapshot
---@field health number
---@field maxHealth number
---@field alive boolean
---@field hurtPulse number
---@field ratio number

---@class M1PlayerHealth
---@field data M1HealthData
---@field health number
---@field alive boolean
---@field hurtPulse number
---@field sinceHurt number
local PlayerHealth = {}
PlayerHealth.__index = PlayerHealth

---@param data M1HealthData
---@return M1PlayerHealth
function PlayerHealth.Create(data)
    assert(data ~= nil and type(data.maxHealth) == "number" and data.maxHealth > 0,
        "PlayerHealth requires health data with a positive maxHealth")
    assert(type(data.regenDelay) == "number" and data.regenDelay >= 0, "PlayerHealth needs regenDelay")
    assert(type(data.regenRate) == "number" and data.regenRate >= 0, "PlayerHealth needs regenRate")
---@type M1PlayerHealth
    local self = setmetatable({
        data = data,
        health = data.maxHealth,
        alive = true,
        hurtPulse = 0.0,
        sinceHurt = data.regenDelay,
    }, PlayerHealth)
    print(string.format("%s[CREATE] -> OK | health=%.0f/%.0f regenDelay=%.1f regenRate=%.1f",
        TAG, self.health, data.maxHealth, data.regenDelay, data.regenRate))
    return self
end

---Apply damage. Returns false when it was ignored (already dead or not a positive amount).
---@param amount number
---@param reason string Why it hurt: "fall" / "drown" / "selftest" / ...
---@return boolean applied
function PlayerHealth:Damage(amount, reason)
    if not self.alive then
        print(string.format("%s[APPLY] -> NONE | reason=%s already=dead health=%.0f", TAG, tostring(reason), self.health))
        return false
    end
    if type(amount) ~= "number" or amount ~= amount or amount <= 0 then
        print(string.format("%s[APPLY] -> FAIL | reason=%s amount=%s", TAG, tostring(reason), tostring(amount)))
        return false
    end
    self.health = math.max(0.0, self.health - amount)
    self.sinceHurt = 0.0
    self.hurtPulse = math.min(1.0, self.hurtPulse + self.data.pulseBase + amount / self.data.pulseAmountDivisor)
    local dead = self.health <= 0.0
    if dead then
        self.alive = false
    end
    print(string.format("%s[APPLY] -> %s | reason=%s amount=%.1f health=%.0f/%.0f pulse=%.2f",
        TAG, dead and "FAIL" or "OK", tostring(reason), amount, self.health, self.data.maxHealth, self.hurtPulse))
    return true
end

---@param amount number
---@return boolean healed
function PlayerHealth:Heal(amount)
    if not self.alive or type(amount) ~= "number" or amount <= 0 then
        return false
    end
    self.health = math.min(self.data.maxHealth, self.health + amount)
    return true
end

---@param dt number
function PlayerHealth:Update(dt)
    assert(type(dt) == "number" and dt >= 0, "PlayerHealth:Update needs a non-negative dt")
    self.sinceHurt = self.sinceHurt + dt
    if self.alive and self.sinceHurt > self.data.regenDelay and self.health < self.data.maxHealth then
        self.health = math.min(self.data.maxHealth, self.health + self.data.regenRate * dt)
    end
    if self.hurtPulse > 0.0 then
        self.hurtPulse = math.max(0.0, self.hurtPulse - dt * self.data.pulseDecay)
    end
end

---@return boolean
function PlayerHealth:IsAlive()
    return self.alive
end

---@return M1PlayerSnapshot
function PlayerHealth:GetSnapshot()
    return {
        health = self.health,
        maxHealth = self.data.maxHealth,
        alive = self.alive,
        hurtPulse = self.hurtPulse,
        ratio = self.data.maxHealth > 0 and self.health / self.data.maxHealth or 0.0,
    }
end

function PlayerHealth:Reset()
    self.health = self.data.maxHealth
    self.alive = true
    self.hurtPulse = 0.0
    self.sinceHurt = self.data.regenDelay
    print(string.format("%s[RESET] -> OK | health=%.0f/%.0f", TAG, self.health, self.data.maxHealth))
end

return PlayerHealth
