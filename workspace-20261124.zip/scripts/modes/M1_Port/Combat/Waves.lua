-- 波次：按 Data/Enemy.lua 的生成点与波次表投放敌人，管理存活与整波推进。
local TAG = "[M1][WAVE]"
local EnemyModule = require("modes.M1_Port.Combat.Enemy")

---@class M1WaveDeps
---@field materials table
---@field onEnemyShot fun(origin: Vector3, dir: Vector3, damage: number): boolean
---@field visible fun(from: Vector3, to: Vector3): boolean

---@class M1Waves
---@field config M1EnemyConfig
---@field deps M1WaveDeps
---@field enemies M1Enemy[]
---@field waveIndex integer
---@field spawnTimer number
---@field pending integer
---@field cursor integer
---@field gapTimer number
---@field spawned integer
---@field fireTokens table<number, M1Enemy> 当前持有开火名额的敌人，键是 index。
---@field ctx M1EnemyContext 复用同一张上下文，避免每帧新建闭包。
local Waves = {}
Waves.__index = Waves

---@param scene Scene
---@param config M1EnemyConfig
---@param deps M1WaveDeps
---@return M1Waves
function Waves.Create(scene, config, deps)
    assert(scene ~= nil, "Waves requires a scene")
    assert(config ~= nil and #config.waves > 0, "Waves requires wave data")
    assert(deps ~= nil and type(deps.onEnemyShot) == "function", "Waves requires an onEnemyShot callback")
    assert(type(deps.visible) == "function", "Waves requires a visibility probe")

    ---@type M1Waves
    local self = setmetatable({
        config = config,
        deps = deps,
        enemies = {},
        waveIndex = 1,
        -- 负值起算：首只出现要等 firstDelay 补齐再加 spawnGap（Data/Enemy.lua 说明）。
        spawnTimer = -(config.firstDelay or 0.0),
        pending = config.waves[1].count,
        cursor = 1,
        gapTimer = 0.0,
        spawned = 0,
        fireTokens = {},
    }, Waves)
    ---@type M1EnemyContext
    self.ctx = {
        playerPos = Vector3(0.0, 0.0, 0.0),
        visible = deps.visible,
        onEnemyShot = deps.onEnemyShot,
        requestFire = function(enemy) return self:RequestFire(enemy) end,
        releaseFire = function(enemy) self:ReleaseFire(enemy) end,
        groundY = 0.0,
    }
    print(string.format("%s[CREATE] -> OK | waves=%d spawns=%d first=%d delay=%.1f", TAG, #config.waves,
        #config.spawns, config.waves[1].count, config.firstDelay or 0.0))
    return self
end

---@return integer
function Waves:AliveCount()
    local alive = 0
    for index = 1, #self.enemies do
        if self.enemies[index]:IsAlive() then
            alive = alive + 1
        end
    end
    return alive
end

--- 射击回调：origin/dir 来自相机，返回最近的敌人命中。
---@param origin Vector3
---@param dir Vector3
---@param maxDist number
---@return { distance: number, enemy: M1Enemy }|nil
function Waves:RaycastEnemies(origin, dir, maxDist)
    ---@type { distance: number, enemy: M1Enemy }|nil
    local best = nil
    for index = 1, #self.enemies do
        local enemy = self.enemies[index]
        local distance = enemy:RayHit(origin, dir, maxDist)
        if distance ~= nil and (best == nil or distance < best.distance) then
            best = { distance = distance, enemy = enemy }
        end
    end
    return best
end

---@param dt number
---@param playerPos Vector3
---@param scene Scene
function Waves:Update(dt, playerPos, scene)
    assert(type(dt) == "number" and dt >= 0, "Waves:Update needs a non-negative dt")

    local wave = self.config.waves[self.waveIndex]
    if wave ~= nil and self.pending > 0 then
        self.spawnTimer = self.spawnTimer + dt
        if self.spawnTimer >= wave.spawnGap then
            self.spawnTimer = 0.0
            local entry = assert(self.config.spawns[self.cursor], "Waves: spawn table is empty")
            self.cursor = self.cursor % #self.config.spawns + 1
            local enemy = EnemyModule.Create(scene, self.config.data, entry, self.spawned + 1, self.deps.materials)
            self.enemies[#self.enemies + 1] = enemy
            self.spawned = self.spawned + 1
            self.pending = self.pending - 1
            print(string.format("%s[SPAWN] -> OK | wave=%d pending=%d total=%d", TAG, self.waveIndex,
                self.pending, self.spawned))
        end
    end

    local ctx = self.ctx
    ctx.playerPos = playerPos
    for index = 1, #self.enemies do
        self.enemies[index]:Update(dt, ctx)
    end

    -- 敌人死亡或退回巡逻时收不到 release，这里每帧清一遍，避免名额被占死（第 28 节）。
    for index, enemy in pairs(self.fireTokens) do
        if not enemy:IsAlive() or enemy.state ~= "attack" then
            self.fireTokens[index] = nil
        end
    end

    if wave ~= nil and self.pending == 0 and self:AliveCount() == 0 then
        self.gapTimer = self.gapTimer + dt
        if self.gapTimer >= self.config.waveGap then
            self.gapTimer = 0.0
            if self.waveIndex < #self.config.waves then
                self.waveIndex = self.waveIndex + 1
                local nextWave = assert(self.config.waves[self.waveIndex], "Waves: wave table index out of range")
                self.pending = nextWave.count
                print(string.format("%s[NEXT] -> OK | wave=%d spawn=%d", TAG, self.waveIndex,
                    self.pending))
            else
                print(string.format("%s[ALLDONE] -> OK | waves=%d spawned=%d", TAG, #self.config.waves,
                    self.spawned))
            end
        end
    end
end

--- 选最近的活敌人；AI 自检用。
--- 原作 token：同时开火数上限（Data/Enemy.lua 的 maxShooters）。
---@param enemy M1Enemy
---@return boolean granted
function Waves:RequestFire(enemy)
    local index = enemy.index
    if self.fireTokens[index] ~= nil then
        return true
    end
    local count = 0
    for _ in pairs(self.fireTokens) do
        count = count + 1
    end
    if count >= self.config.maxShooters then
        print(string.format("%s[TOKEN] -> NONE | index=%d busy=%d max=%d", TAG, index, count,
            self.config.maxShooters))
        return false
    end
    self.fireTokens[index] = enemy
    return true
end

---@param enemy M1Enemy
function Waves:ReleaseFire(enemy)
    self.fireTokens[enemy.index] = nil
end

---@param playerPos Vector3
---@param skipIndex? integer 跳过的敌人编号（追不到时换目标用）。
---@return M1Enemy|nil enemy
---@return number distance
function Waves:GetNearest(playerPos, skipIndex)
    ---@type M1Enemy|nil
    local best = nil
    local bestDistance = -1.0
    for index = 1, #self.enemies do
        local enemy = self.enemies[index]
        if enemy:IsAlive() and enemy.index ~= skipIndex then
            local distance = (enemy:GetPosition() - playerPos):Length()
            if best == nil or distance < bestDistance then
                best = enemy
                bestDistance = distance
            end
        end
    end
    return best, bestDistance
end

---@class M1WaveStats
---@field spawned integer
---@field alive integer
---@field killed integer

---@return M1WaveStats
function Waves:GetStats()
    local alive = self:AliveCount()
    return { spawned = self.spawned, alive = alive, killed = self.spawned - alive }
end

---@param playerPos Vector3
---@return string
function Waves:Probe(playerPos)
    local nearest = -1.0
    local nearestHealth = 0.0
    for index = 1, #self.enemies do
        local enemy = self.enemies[index]
        if enemy:IsAlive() then
            local distance = (enemy:GetPosition() - playerPos):Length()
            if nearest < 0.0 or distance < nearest then
                nearest = distance
                nearestHealth = enemy.health
            end
        end
    end
    local text = string.format(
        "%s[PROBE] -> OK | wave=%d pending=%d alive=%d spawned=%d nearest=%.1f nearestHp=%.0f",
        TAG, self.waveIndex, self.pending, self:AliveCount(), self.spawned, nearest, nearestHealth)
    print(text)
    return text
end

function Waves:Dispose()
    for index = 1, #self.enemies do
        self.enemies[index]:Dispose()
    end
    self.enemies = {}
    self.fireTokens = {}
    print(string.format("%s[DISPOSE] -> OK | spawned=%d", TAG, self.spawned))
end

return Waves
