-- AI 自检：接管玩家角色自己打——选最近敌人、转向、接近、开火、缺弹换弹，到点出报告。
-- 只用于自检按钮「AI」与本地/真机跑测，不进入正常玩法路径。
local TAG = "[M1][AI]"

---@class M1AutoPilotDeps
---@field visible fun(from: Vector3, to: Vector3): boolean
---@field rig PlayerRig
---@field hud ShooterPlayerHud
---@field rifle ShooterRifle
---@field waves M1Waves
---@field data M1AutoPilotData

---@class M1AutoPilot
---@field deps M1AutoPilotDeps
---@field data M1AutoPilotData
---@field running boolean
---@field elapsed number
---@field retarget number
---@field target M1Enemy|nil
---@field shots0 integer
---@field health0 number
---@field idleLogged boolean
---@field outOfRangeLogged boolean
---@field firing boolean
---@field blockedLogged boolean
---@field lastDistance number
---@field stuckTimer number
---@field detourTimer number
---@field detourSign number
---@field stuckCount integer
---@field skipIndex integer
---@field skipTimer number
local AutoPilot = {}
AutoPilot.__index = AutoPilot

---@param deps M1AutoPilotDeps
---@return M1AutoPilot
function AutoPilot.Create(deps)
    assert(deps ~= nil, "AutoPilot requires dependencies")
    assert(deps.rig ~= nil, "AutoPilot requires the player rig")
    assert(deps.hud ~= nil and type(deps.hud.SetFireOverride) == "function", "AutoPilot requires the player HUD")
    assert(deps.rifle ~= nil, "AutoPilot requires the rifle")
    assert(deps.waves ~= nil and type(deps.waves.GetNearest) == "function", "AutoPilot requires the wave controller")
    assert(deps.data ~= nil and deps.data.duration > 0, "AutoPilot requires auto-pilot data")

    ---@type M1AutoPilot
    local self = setmetatable({
        deps = deps,
        data = deps.data,
        running = false,
        elapsed = 0.0,
        retarget = 0.0,
        target = nil,
        shots0 = 0,
        health0 = 0.0,
        idleLogged = false,
        outOfRangeLogged = false,
        firing = false,
        blockedLogged = false,
        lastDistance = -1.0,
        stuckTimer = 0.0,
        detourTimer = 0.0,
        detourSign = 1.0,
        stuckCount = 0,
        skipIndex = -1,
        skipTimer = 0.0,
    }, AutoPilot)
    print(string.format("%s[CREATE] -> OK | duration=%.0f engage=%.0f stop=%.0f", TAG,
        self.data.duration, self.data.engageRange, self.data.stopRange))
    return self
end

---@return boolean
function AutoPilot:IsRunning()
    return self.running
end

---@param health M1PlayerHealth|nil
function AutoPilot:Start(health)
    if self.running then
        print(string.format("%s[START] -> NONE | reason=already-running elapsed=%.1f", TAG, self.elapsed))
        return
    end
    self.running = true
    self.elapsed = 0.0
    self.retarget = 0.0
    self.target = nil
    self.idleLogged = false
    self.outOfRangeLogged = false
    self.shots0 = self.deps.rifle.shots
    self.health0 = health ~= nil and health:GetSnapshot().health or 0.0
    print(string.format("%s[START] -> OK | shots=%d health=%.0f", TAG, self.shots0, self.health0))
end

---@param health M1PlayerHealth|nil
---@param waves M1Waves|nil
function AutoPilot:Stop(health, waves)
    if not self.running then
        return
    end
    self.running = false
    self.deps.hud:SetFireOverride(false)
    self.deps.rig.character.controls:Set(CTRL_FORWARD, false)
    local stats = waves ~= nil and waves.GetStats ~= nil and waves:GetStats() or { spawned = 0, alive = 0, killed = 0 }
    local shots = self.deps.rifle.shots - self.shots0
    local healthNow = health ~= nil and health:GetSnapshot().health or 0.0
    print(string.format("%s[STOP] -> OK | elapsed=%.1f shots=%d kills=%d alive=%d spawned=%d hp=%.0f->%.0f",
        TAG, self.elapsed, shots, stats.killed, stats.alive, stats.spawned, self.health0, healthNow))
end

---@param dt number
---@param health M1PlayerHealth|nil
---@param waves M1Waves|nil
function AutoPilot:Update(dt, health, waves)
    if not self.running then
        return
    end
    self.elapsed = self.elapsed + dt
    if self.elapsed >= self.data.duration then
        self:Stop(health, waves)
        return
    end

    local rig = self.deps.rig
    local controls = rig.character.controls

    -- 玩家阵亡就收工，别再打空枪
    if health ~= nil and not health:IsAlive() then
        print(string.format("%s[STOP] -> NONE | reason=player-dead elapsed=%.1f", TAG, self.elapsed))
        self:Stop(health, waves)
        return
    end

    self.retarget = self.retarget - dt
    if self.skipTimer > 0.0 then
        self.skipTimer = self.skipTimer - dt
        if self.skipTimer <= 0.0 then
            self.skipIndex = -1
        end
    end

    if self.target == nil or not self.target:IsAlive() or self.retarget <= 0.0 then
        self.retarget = self.data.retargetEvery
        local enemy, distance = self.deps.waves:GetNearest(rig:GetEyePosition(), self.skipIndex)
        self.target = enemy
        if enemy ~= nil then
            print(string.format("%s[TARGET] -> OK | index=%d dist=%.1f hp=%.0f", TAG, enemy.index,
                distance, enemy.health))
        end
    end

    local target = self.target
    if target == nil then
        self.deps.hud:SetFireOverride(false)
        controls:Set(CTRL_FORWARD, false)
        if not self.idleLogged then
            self.idleLogged = true
            print(string.format("%s[IDLE] -> NONE | reason=no-enemy elapsed=%.1f", TAG, self.elapsed))
        end
        return
    end
    self.idleLogged = false

    local eye = rig:GetEyePosition()
    local enemyPos = target:GetPosition()
    local dx = enemyPos.x - eye.x
    local dz = enemyPos.z - eye.z
    local flat = math.sqrt(dx * dx + dz * dz)
    local desiredYaw = math.deg(math.atan(dx, dz))
    if self.detourTimer > 0.0 then
        self.detourTimer = self.detourTimer - dt
        desiredYaw = desiredYaw + 55.0 * self.detourSign
    end
    -- 转向有速度上限，避免瞬移式锁头
    local yaw = controls.yaw
    local delta = ((desiredYaw - yaw + 540.0) % 360.0) - 180.0
    local step = self.data.turnRateDeg * dt
    if math.abs(delta) <= step then
        yaw = yaw + delta
    else
        yaw = yaw + (delta > 0 and step or -step)
    end
    controls.yaw = (yaw + 360.0) % 360.0

    -- 俯角对准敌人躯干中心（约 0.7 米高）；controls.pitch 用角度、正值向下
    local aimDrop = eye.y - (enemyPos.y + 0.7)
    local pitch = math.deg(math.atan(aimDrop, math.max(0.1, flat)))
    controls.pitch = math.max(-85.0, math.min(85.0, pitch))

    -- 前进；贴墙推不动时改成偏航绕行（横移会越走越远）
    local moving = flat > self.data.stopRange
    controls:Set(CTRL_FORWARD, moving)
    if moving then
        if self.lastDistance < 0.0 or flat < self.lastDistance - 0.1 then
            self.stuckTimer = 0.0
        else
            self.stuckTimer = self.stuckTimer + dt
            if self.stuckTimer > 1.2 then
                self.stuckTimer = 0.0
                self.stuckCount = self.stuckCount + 1
                self.detourSign = -self.detourSign
                self.detourTimer = 1.0
                print(string.format("%s[STUCK] -> NONE | event=detour dist=%.1f dir=%s count=%d", TAG, flat,
                    self.detourSign > 0 and "right" or "left", self.stuckCount))
                if self.stuckCount >= 3 then
                    -- 绕不过去就换目标，别在原地打转
                    self.skipIndex = target.index
                    self.skipTimer = 10.0
                    self.stuckCount = 0
                    self.detourTimer = 0.0
                    self.target = nil
                    self.retarget = 0.0
                    print(string.format("%s[SKIP] -> NONE | index=%d reason=no-path", TAG, self.skipIndex))
                end
            end
        end
        self.lastDistance = flat
    else
        self.lastDistance = flat
        self.stuckTimer = 0.0
        self.stuckCount = 0
    end

    local aligned = math.abs(delta) <= self.data.yawToleranceDeg
    local lineOfSight = self.deps.visible(eye, Vector3(enemyPos.x, enemyPos.y + 0.7, enemyPos.z))
    if lineOfSight then
        self.blockedLogged = false
    elseif not self.blockedLogged then
        self.blockedLogged = true
        print(string.format("%s[HOLD] -> NONE | reason=blocked dist=%.1f", TAG, flat))
    end

    local shouldFire = flat <= self.data.engageRange and aligned and lineOfSight
    self.deps.hud:SetFireOverride(shouldFire)
    if shouldFire ~= self.firing then
        self.firing = shouldFire
        print(string.format("%s[%s] -> %s | dist=%.1f yawErr=%.1f los=%s", TAG,
            shouldFire and "FIRE" or "HOLD", shouldFire and "OK" or "NONE", flat, math.abs(delta),
            tostring(lineOfSight)))
    end
    if not shouldFire and not self.outOfRangeLogged then
        self.outOfRangeLogged = true
        print(string.format("%s[HOLD] -> NONE | reason=%s dist=%.1f yawErr=%.1f", TAG,
            flat > self.data.engageRange and "too-far" or "turning", flat, math.abs(delta)))
    end

    -- 弹匣空了自动换弹（与开火互斥，避免空枪空转）
    if self.deps.rifle.ammo <= 0 then
        self.deps.hud:SetFireOverride(false)
        self.deps.hud:QueueReload()
        print(string.format("%s[RELOAD] -> OK | reason=empty elapsed=%.1f", TAG, self.elapsed))
    end
end

function AutoPilot:Dispose()
    self.deps.hud:SetFireOverride(false)
    self.deps.rig.character.controls:Set(CTRL_FORWARD, false)
    self.target = nil
    print(string.format("%s[DISPOSE] -> OK", TAG))
end

return AutoPilot
