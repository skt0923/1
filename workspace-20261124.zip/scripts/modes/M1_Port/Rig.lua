-- 角色控制器：胶囊 + KCC + CharacterComponent，移动/跳跃/蹲伏与边界救援；不含任何玩法名。
---@type table Math 由 kit 通过 SetMath 注入（第 13 节：积木间禁止直接 require）；
-- 未注入时为空表，调用具体函数会立刻报错，不会静默通过。
local Math = {}

local SHAPE_MARGIN = 0.04
-- 窗口净位移低于此值视为没动（0.1 m/s × 0.5 s）
local MIN_WINDOW_DISTANCE = 0.05
local MOVE_TOLERANCE = 0.15
local APEX_TOLERANCE = 0.2
local EYE_SETTLE_EPSILON = 0.02
---@type integer[]
local MOVE_KEYS = { CTRL_FORWARD, CTRL_BACK, CTRL_LEFT, CTRL_RIGHT }

---@param controls Controls
---@return boolean
local function MoveHeld(controls)
    for index = 1, #MOVE_KEYS do
        if controls:IsDown(MOVE_KEYS[index]) then return true end
    end
    return false
end

---@class RigConfig
---@field eyeHeight number
---@field crouchEyeHeight number
---@field radius number
---@field height number
---@field walkSpeed number
---@field sprintSpeed number
---@field crouchSpeed number
---@field accelGround number
---@field accelAir number
---@field gravity number
---@field jumpApex number
---@field eyeRate number
---@field probe PlayerRigProbeData

---@class RigWorld
---@field bounds {minX:number,maxX:number,minZ:number,maxZ:number}
---@field boundsPadding number
---@field seaY number
---@field rescueDepth number
---@field safeMinY number
---@field quayX number
---@field safeMargin number

---@class PlayerRig
---@field node Node
---@field character CharacterComponent
---@field kcc KinematicCharacterController
---@field data RigConfig
---@field world RigWorld
---@field eyeHeight number
---@field crouching boolean
---@field lastSafe Vector3
---@field prevPosition Vector3
---@field moveTimer number
---@field moveAccumX number
---@field moveAccumZ number
---@field wasOnGround boolean
---@field airTime number
---@field jumpStartY number
---@field apexY number
---@field crouchProbePending boolean
---@field airKind string
---@field rescuePending boolean
---@field onLand fun(speed: number)|nil Called with the vertical speed of a landing; the mode decides the damage.
---@field onDrown fun()|nil Called when the player is returned from the water.
---@field speed number
---@field jumpFallback number|nil Remaining rise speed when the engine jump velocity is unreadable.
---@field jumpStartSpeed number
---@field jumpStartVy number
---@field probe PlayerRigProbeData Movement judge window settings from the mode data.
---@field lastGroundY number Node height of the last grounded frame.
---@field holdTime number Seconds the current movement hold has lasted.
---@field windowStartHold number Hold time when the current judge window began.
---@field windowHadRelease boolean True when a movement key was released inside the window.
local PlayerRig = {}
PlayerRig.__index = PlayerRig

---@param scene Scene
---@param data RigConfig
---@param world RigWorld
---@return PlayerRig
function PlayerRig.Create(scene, data, world)
    assert(data.probe ~= nil and data.probe.moveWindow ~= nil and data.probe.accelGuard ~= nil,
        "PlayerRig requires data.probe moveWindow/accelGuard")
    local node = scene:CreateChild("Player")
    node.position = Vector3.ZERO

-- 组件加载失败需显式中断（f2），.emmylua 声明非 nil 才判多余
---@diagnostic disable-next-line: unnecessary-assert
    local body = assert(node:CreateComponent("RigidBody"), "Player missing RigidBody")
    body:SetMass(1)
    body:SetLinearFactor(Vector3.ZERO)
    body:SetAngularFactor(Vector3.ZERO)
    body:SetCollisionEventMode(COLLISION_ALWAYS)

-- 组件加载失败需显式中断（f2），.emmylua 声明非 nil 才判多余
---@diagnostic disable-next-line: unnecessary-assert
    local shape = assert(node:CreateComponent("CollisionShape"), "Player missing CollisionShape")
    shape:SetCapsule(data.radius * 2, data.height, Vector3(0, data.height * 0.5 - SHAPE_MARGIN, 0))

-- 组件加载失败需显式中断（f2），.emmylua 声明非 nil 才判多余
---@diagnostic disable-next-line: unnecessary-assert
    local kcc = assert(node:CreateComponent("KinematicCharacterController"), "Player missing KinematicCharacterController")
    kcc:SetCollisionLayerAndMask(CollisionLayerKinematic, CollisionMaskKinematic)
    kcc:SetGravity(Vector3(0, -data.gravity, 0))
    kcc.jumpSpeed = math.sqrt(2 * data.gravity * data.jumpApex)

-- 组件加载失败需显式中断（f2），.emmylua 声明非 nil 才判多余
---@diagnostic disable-next-line: unnecessary-assert
    local character = assert(node:CreateComponent("CharacterComponent"), "Player missing CharacterComponent")
    character:SetWalkSpeed(data.walkSpeed)
    character:SetRunSpeed(data.sprintSpeed)
    character:SetEnableWalkMode(true)
    character:SetAirControlFactor(data.accelAir / data.accelGround)

    return setmetatable({
        node = node,
        character = character,
        kcc = kcc,
        data = data,
        world = world,
        eyeHeight = data.eyeHeight,
        crouching = false,
        lastSafe = node.position,
        prevPosition = node.position,
        moveTimer = 0.0,
        moveAccumX = 0.0,
        moveAccumZ = 0.0,
        wasOnGround = true,
        airTime = 0.0,
        jumpStartY = 0.0,
        apexY = 0.0,
        crouchProbePending = false,
        airKind = "jump",
        rescuePending = false,
        speed = 0.0,
        jumpFallback = nil,
        jumpStartSpeed = 0.0,
        jumpStartVy = 0.0,
        probe = data.probe,
        lastGroundY = 0.0,
        holdTime = 0.0,
        windowStartHold = 0.0,
        windowHadRelease = true,
    }, PlayerRig)
end

---@param on boolean
function PlayerRig:SetCrouch(on)
    if on == self.crouching then return end
    self.crouching = on
    self.character:SetWalkSpeed(on and self.data.crouchSpeed or self.data.walkSpeed)
    self.character:SetRunSpeed(on and self.data.crouchSpeed or self.data.sprintSpeed)
    self.crouchProbePending = true
    print(string.format("[RIG][CROUCH] -> OK | event=enter on=%s eyeTarget=%.2f walk=%.2f run=%.2f",
        tostring(on),
        on and self.data.crouchEyeHeight or self.data.eyeHeight,
        self.character:GetWalkSpeed(),
        self.character:GetRunSpeed()))
end

function PlayerRig:ToggleCrouch()
    self:SetCrouch(not self.crouching)
end

---@param dt number
function PlayerRig:Update(dt)
    if self.jumpFallback ~= nil then
        -- 1.35 读不到引擎垂直速度时按 v²=2gh 自行积分，让 JUMP 探针仍有高度序列
        local vy = self.jumpFallback - self.data.gravity * dt
        local p = self.node.position
        self.node.position = Vector3(p.x, p.y + vy * dt, p.z)
        self.jumpFallback = vy > 0 and vy or nil
    end
    local target = self.crouching and self.data.crouchEyeHeight or self.data.eyeHeight
    self.eyeHeight = Math.damp(self.eyeHeight, target, self.data.eyeRate, dt)
    self:ClampToWorld()
    self:Probe(dt)
end

---@param dt number
function PlayerRig:Probe(dt)
    local pos = self.node.position
    local dx = pos.x - self.prevPosition.x
    local dz = pos.z - self.prevPosition.z
    local distance = math.sqrt(dx * dx + dz * dz)
    self.speed = dt > 0.0 and distance / dt or 0.0

    if self.rescuePending then
        self.speed = 0.0
        self.rescuePending = false
        self.prevPosition = pos
        self.moveTimer = 0.0
        self.wasOnGround = self.character:IsOnGround()
        print(string.format("[RIG][RESCUE] -> OK | event=return pos=(%.2f,%.2f,%.2f)",
            pos.x, pos.y, pos.z))
        return
    end

    local onGround = self.character:IsOnGround()

    if onGround then
        self.jumpFallback = nil
        -- 起跳首帧已在空中，起跳前最后着地高度才是 JUMP 探针的正确起点
        self.lastGroundY = pos.y
        if not self.wasOnGround and self.airTime > 0.05 then
            if self.airKind == "jump" then
                local startY = self.lastGroundY
                local apexY = self.apexY
                local apex = apexY - startY
                local low, high = self.data.jumpApex * (1 - APEX_TOLERANCE), self.data.jumpApex * (1 + APEX_TOLERANCE)
                local result = (apex >= low and apex <= high) and "OK" or "FAIL"
                print(string.format(
                    "[RIG][JUMP] -> %s | event=land start=%.2f apex=%.2f land=%.2f rise=%.2f drop=%.2f air=%.2fs expect=[%.2f,%.2f] v0=%.2f vy=%.2f kccJump=%.2f kccMax=%.2f",
                    result, startY, apexY, pos.y, apex, apexY - pos.y, self.airTime, low, high,
                    self.jumpStartSpeed, self.jumpStartVy,
                    self.kcc:GetJumpSpeed() or 0, self.kcc:GetMaxJumpHeight() or 0))
            else
                print(string.format("[RIG][FALL] -> OK | event=land drop=%.2f air=%.2fs",
                    self.jumpStartY - pos.y, self.airTime))
            end
            local landDrop = self.jumpStartY - pos.y
            if self.onLand ~= nil then
                self.onLand(math.sqrt(2 * self.data.gravity * math.max(0.0, landDrop)))
            end
        end
        self.airTime = 0.0
    else
        if self.wasOnGround then
            self.jumpStartY = pos.y
            self.apexY = pos.y
            self.airTime = 0.0
            local jumped = self.character:IsJumpStarted() or self.character:IsJumping()
            self.airKind = jumped and "jump" or "fall"
            if jumped then
                local okVy, vy = pcall(function() return self.kcc:GetLinearVelocity().y end)
                self.jumpStartVy = okVy and vy or 0
                self.jumpStartSpeed = math.sqrt(2 * self.data.gravity * self.data.jumpApex)
                -- 引擎垂直速度小于起跳量的一半时视为读不到，改由本文件积分高度
                if okVy and vy > self.jumpStartSpeed * 0.5 then
                    self.jumpFallback = nil
                else
                    self.jumpFallback = self.jumpStartSpeed
                end
                -- 首帧已在空中，起点用最后着地高度，否则日志显示 0.20 让人误判起跳高度（feedback 54602）。
                print(string.format("[RIG][JUMP] -> OK | event=start y=%.2f v0=%.2f vy=%.2f expectApex=%.2f kccJump=%.2f air=%.2f",
                    self.lastGroundY, self.jumpStartSpeed, self.jumpStartVy, self.data.jumpApex,
                    self.kcc:GetJumpSpeed() or 0, self.airTime))
            else
                print(string.format("[RIG][FALL] -> OK | event=start y=%.2f", pos.y))
            end
        end
        self.airTime = self.airTime + dt
        if pos.y > self.apexY then self.apexY = pos.y end
    end
    self.wasOnGround = onGround

    local controls = self.character.controls
    local held = MoveHeld(controls)
    if held then
        self.holdTime = self.holdTime + dt
    else
        self.holdTime = 0.0
        if self.moveTimer > 0.0 then self.windowHadRelease = true end
    end
    self.moveAccumX = self.moveAccumX + dx
    self.moveAccumZ = self.moveAccumZ + dz
    local window = self.probe.moveWindow
    if self.moveTimer == 0.0 then
        self.windowStartHold = self.holdTime
        self.windowHadRelease = not held
    end
    local elapsed = self.moveTimer + dt
    if elapsed >= window then
        self.moveTimer = 0.0
        local moveX, moveZ = self.moveAccumX, self.moveAccumZ
        self.moveAccumX, self.moveAccumZ = 0.0, 0.0
        local moved = math.sqrt(moveX * moveX + moveZ * moveZ)
        local released = self.windowHadRelease or not held
        self.windowHadRelease = false
        if onGround and moved > MIN_WINDOW_DISTANCE then
            -- 持续输入只按窗口净位移判定；瞬时速度受摇杆波动影响，仅记录不参与判定（d3）
            local speed = moved / elapsed
            local run = controls:IsDown(CTRL_RUN)
            local kind = "walk"
            local expected = self.data.walkSpeed
            if self.crouching then
                kind = "crouch"
                expected = self.data.crouchSpeed
            elseif run then
                kind = "run"
                expected = self.data.sprintSpeed
            end
            local low = expected * elapsed * (1 - MOVE_TOLERANCE)
            local high = expected * elapsed * (1 + MOVE_TOLERANCE)
            local result, reason
            if released then
                -- 窗口跨按下/松开边界时净位移不可比，标 NONE 不判 FAIL（d3）
                result, reason = "NONE", "transition"
            elseif self.windowStartHold < self.probe.accelGuard then
                -- 起步加速期用匀速期望判定必然偏低，只记录（d3）
                result, reason = "NONE", "accel"
            elseif moved < low and speed < 0.3 then
                -- 被墙体或道具挡住时净位移必然不足，这是环境不是位移缺陷，记 NONE（第 28 节）
                result, reason = "NONE", "blocked"
            else
                result = (moved >= low and moved <= high) and "OK" or "FAIL"
                reason = "steady"
            end
            print(string.format(
                "[RIG][MOVE] -> %s | reason=%s mode=%s moved=%.2f expect=[%.2f,%.2f] speed=%.2f dir=(%.2f,%.2f) yaw=%.1f pos=(%.2f,%.2f,%.2f) ground=%s",
                result, reason, kind, moved, low, high, speed, moveX / moved, moveZ / moved,
                controls.yaw, pos.x, pos.y, pos.z, tostring(onGround)))
        end
    else
        self.moveTimer = elapsed
    end

    if self.crouchProbePending then
        local target = self.crouching and self.data.crouchEyeHeight or self.data.eyeHeight
        if math.abs(self.eyeHeight - target) < EYE_SETTLE_EPSILON then
            self.crouchProbePending = false
            print(string.format("[RIG][CROUCH] -> OK | event=settle on=%s eye=%.2f expect=%.2f walk=%.2f run=%.2f",
                tostring(self.crouching), self.eyeHeight, target,
                self.character:GetWalkSpeed(), self.character:GetRunSpeed()))
        end
    end

    self.prevPosition = pos
end

function PlayerRig:ClampToWorld()
    local world = self.world
    local bounds = world.bounds
    local p = self.node.position
    local x = Math.clamp(p.x, bounds.minX + world.boundsPadding, bounds.maxX - world.boundsPadding)
    local z = Math.clamp(p.z, bounds.minZ + world.boundsPadding, bounds.maxZ - world.boundsPadding)
    if x ~= p.x or z ~= p.z then
        self.node.position = Vector3(x, p.y, z)
        p = self.node.position
    end
    if p.y < world.seaY - world.rescueDepth then
        self.node.position = self.lastSafe
        self.rescuePending = true
        if self.onDrown ~= nil then
            self.onDrown()
        end
    elseif p.y > world.safeMinY and p.x <= world.quayX - world.safeMargin then
        self.lastSafe = p
    end
end

---@return number
function PlayerRig:GetHorizontalSpeed()
    return self.speed
end

---@return Vector3
function PlayerRig:GetEyePosition()
    local p = self.node.position
    return Vector3(p.x, p.y + self.eyeHeight, p.z)
end

--- 注入纯数学工具（kit 启动时调用；第 13 节禁止积木间直接 require）
---@param mathLib table Math 模块（clamp/lerp/WrapAngle/damp…）
function PlayerRig.SetMath(mathLib)
-- 注入参数可能为 nil（未注入时），assert 是防御性检查而非冗余
---@diagnostic disable-next-line: unnecessary-assert
    Math = assert(mathLib, "PlayerRig.SetMath requires Math from kit")
end

return PlayerRig
