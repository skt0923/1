-- modes/M1_Port/Mode.lua: 港区行动模式入口，只做装配与生命周期；数值在 Data/ 下按域分文件（e9）。
-- 数据来源：14-input 语句 v_、13-audio 语句 9、09-level 语句 1、16-weapon 语句 1/28、18-hud 语句 1、
-- 12-effects 语句 10；差异见任务卡 m1-p0b-weapon、m1-p1a-foundation。
local Geometry = require("modes.M1_Port.Art.Geometry")
local Materials = require("modes.M1_Port.Art.Materials")
local PlayerRig = require("modes.M1_Port.Rig")
local FirstPersonCamera = require("modes.M1_Port.View.FirstPersonCamera")
local PlayerHud = require("modes.M1_Port.Hud.PlayerHud")
local WeaponHud = require("modes.M1_Port.Hud.WeaponHud")
local StatusHud = require("modes.M1_Port.Hud.StatusHud")
local Level = require("modes.M1_Port.Level")
local PlayerHealth = require("modes.M1_Port.Combat.PlayerHealth")
local Router = require("Router")
local ScreenOrientation = require("ScreenOrientation")
local ModeMenu = require("ModeMenu")
local Math = require("Math")
PlayerRig.SetMath(Math)
FirstPersonCamera.SetMath(Math)
local WeaponMount = require("modes.M1_Port.Weapon.WeaponMount")
local Effects = require("modes.M1_Port.Art.Effects")
local Rifle = require("modes.M1_Port.Weapon.Rifle")
local SelfTest = require("modes.M1_Port.SelfTest")
local PostFx = require("modes.M1_Port.Post.PostFx")
local PostFxData = require("modes.M1_Port.Data.PostFx") --[[@as M1PostFxData]]
local Sfx = require("modes.M1_Port.Audio.Sfx")
local AudioData = require("modes.M1_Port.Data.Audio") --[[@as M1AudioData]]
local PlayerData = require("modes.M1_Port.Data.Player")
local WorldData = require("modes.M1_Port.Data.World")
local ControlsData = require("modes.M1_Port.Data.Controls")
local WeaponData = require("modes.M1_Port.Data.Weapon")
local WeaponHudData = require("modes.M1_Port.Data.WeaponHud")
local StatusHudData = require("modes.M1_Port.Data.StatusHud")
local HealthData = require("modes.M1_Port.Data.Health")
local LevelData = require("modes.M1_Port.Data.Level")
local Settings = require("modes.M1_Port.Settings")
local SettingsData = require("modes.M1_Port.Data.Settings")
local SettingsPanel = require("modes.M1_Port.Hud.SettingsPanel")
local EffectsData = require("modes.M1_Port.Data.Effects")
local ImpactFxData = require("modes.M1_Port.Data.ImpactFx")
local Decals = require("modes.M1_Port.Art.Decals")
local ImpactBursts = require("modes.M1_Port.Art.ImpactBursts")
local ShellPool = require("modes.M1_Port.Art.ShellPool")
local Weather = require("modes.M1_Port.Art.Weather")
local WeatherData = require("modes.M1_Port.Data.Weather")
local ViewKick = require("modes.M1_Port.Weapon.ViewKick")
local ViewKickData = require("modes.M1_Port.Data.ViewKick")
local MaterialsData = require("modes.M1_Port.Data.Materials")
local EnemyData = require("modes.M1_Port.Data.Enemy")
local Waves = require("modes.M1_Port.Combat.Waves")
local AutoPilot = require("modes.M1_Port.Combat.AutoPilot")
local AutoPilotData = require("modes.M1_Port.Data.AutoPilot")
local PerfStats = require("modes.M1_Port.Perf.Stats")
local GameFlow = require("modes.M1_Port.Flow.GameFlow")
local RelayFlow = require("modes.M1_Port.Flow.Relay")
local RelayLamp = require("modes.M1_Port.Flow.RelayLamp")
local WorldMarker = require("modes.M1_Port.Hud.WorldMarker")
local ObjectiveHud = require("modes.M1_Port.Hud.ObjectiveHud")
local InteractPrompt = require("modes.M1_Port.Hud.InteractPrompt")
local FlowData = require("modes.M1_Port.Data.Flow")
local RelayData = require("modes.M1_Port.Data.Relay")
local RelayLampData = require("modes.M1_Port.Data.RelayLamp")
local WorldMarkerData = require("modes.M1_Port.Data.WorldMarker")
local RunStats = require("modes.M1_Port.Flow.Stats")
local Extract = require("modes.M1_Port.Flow.Extract")
local RadioHud = require("modes.M1_Port.Hud.Radio")
local MenuScreens = require("modes.M1_Port.Hud.MenuScreens")
local RadioData = require("modes.M1_Port.Data.Radio")
local FlowRunner = require("modes.M1_Port.Test.FlowRunner")

---@class M1PortMode : ModeInstance
---@field id string
---@field name string
---@field desc string
---@field scene Scene
---@field world M1WorldData
---@field rig PlayerRig
---@field camera ShooterFirstPersonCamera
---@field hud ShooterPlayerHud|nil
---@field menu ModeMenu|nil
---@field weaponMount ShooterWeaponMount|nil
---@field tpView table|nil
---@field probeInFrames number|nil Frames to wait before sampling the weapon aim probe.
---@field weaponHud ShooterWeaponHud|nil
---@field statusHud ShooterStatusHud|nil
---@field health M1PlayerHealth|nil
---@field settings M1Settings|nil
---@field settingsPanel M1SettingsPanel|nil
---@field rifle ShooterRifle|nil
---@field effects ShooterEffects|nil
---@field floorNode Node|nil
---@field floorMaterial Material|nil
---@field level M1LevelBuild|nil
---@field selfTest M1SelfTest|nil
---@field waves M1Waves|nil
---@field autoPilot M1AutoPilot|nil
---@field perf M1PerfStats|nil
---@field flow M1GameFlow|nil
---@field relays M1RelayFlow|nil
---@field lamps M1RelayLamp|nil
---@field markers M1WorldMarker|nil
---@field decals M1Decals|nil
---@field bursts M1ImpactBursts|nil
---@field shells M1ShellPool|nil
---@field weather M1Weather|nil
---@field viewKick M1ViewKick|nil
---@field postfx M1PostFx|nil 后处理（Zone 属性探测式接入，见 Post/PostFx.lua）。
---@field sfx M1Sfx|nil 音效模块（见 Audio/Sfx.lua）。
---@field shedRect { minX: number, maxX: number, minZ: number, maxZ: number }|nil
---@field objectiveHud M1ObjectiveHud|nil
---@field promptHud M1InteractPrompt|nil
---@field relayTestTimer number|nil 自检「中继」时的自动按住计时。
---@field stats M1RunStats|nil
---@field extract M1Extract|nil
---@field radio M1RadioHud|nil
---@field screens M1MenuScreens|nil
---@field radioIntroSent boolean
---@field runner M1RunRunner|nil 全流程测试跑者（只给自检用）。
---@field autoRan boolean|nil 自动流程只跑一次。
---@field prevMouseMode integer
---@field prevMouseVisible boolean
---@field menuOptions ModeMenuOption[]
local Mode = {}
Mode.__index = Mode

Mode.id = "M1_Port"
Mode.name = "港区行动"
Mode.desc = "第一人称港区作战"

---@class M1PortConfig
---@field id string
---@field menuOptions ModeMenuOption[]

---@param config M1PortConfig
---@return M1PortMode
function Mode.Create(config)
    assert(config ~= nil and config.id ~= nil, "M1Port Mode.Create requires an id")
    assert(config.menuOptions ~= nil, "M1Port Mode.Create requires menuOptions from main.lua")
    return setmetatable({id = config.id, menuOptions = config.menuOptions}, Mode)
end

function Mode:Start()
    ScreenOrientation.Apply("landscape")
    self.world = WorldData
    self.prevMouseMode = input.mouseMode
    self.prevMouseVisible = input.mouseVisible
    input.mouseVisible = false
    input.mouseMode = MM_RELATIVE

    self.scene = Scene()
    assert(self.scene:CreateComponent("Octree") ~= nil, "Scene missing Octree")
    assert(self.scene:CreateComponent("PhysicsWorld") ~= nil, "Scene missing PhysicsWorld")
    assert(self.scene:CreateComponent("DebugRenderer") ~= nil, "Scene missing DebugRenderer")

    local zoneNode = self.scene:CreateChild("Zone")
-- 组件加载失败需显式中断（f2），LSP 判为多余
---@diagnostic disable-next-line: unnecessary-assert
    local zone = assert(zoneNode:CreateComponent("Zone"), "Zone node missing Zone component")
    zone.boundingBox = BoundingBox(Vector3(-1000, -1000, -1000), Vector3(1000, 1000, 1000))
    zone.ambientSource = AMBIENT_COLOR
    zone.ambientColor = Color(0.62, 0.66, 0.72)
    zone.fogColor = Color(0.72, 0.80, 0.88)
    zone.depthFogStart = 40
    zone.depthFogEnd = 220

    local lightNode = self.scene:CreateChild("Sun")
    lightNode.direction = Vector3(0.6, -1.0, 0.8)
-- 组件加载失败需显式中断（f2），LSP 判为多余
---@diagnostic disable-next-line: unnecessary-assert
    local light = assert(lightNode:CreateComponent("Light"), "Sun node missing Light component")
    light.lightType = LIGHT_DIRECTIONAL
    light.color = Color(1.0, 0.96, 0.90)
    light.brightness = 2.6
    light.castShadows = true

    local okSky, sky = pcall(function() return zoneNode:CreateComponent("ProceduralSky") end)
    if okSky and sky ~= nil then
        sky:SetSkyTopColor(Color(0.26, 0.44, 0.78))
        sky:SetSkyHorizonColor(Color(0.72, 0.82, 0.92))
        sky:SetGroundBottomColor(Color(0.20, 0.21, 0.23))
        sky:SetGroundHorizonColor(Color(0.58, 0.61, 0.66))
        sky:SetExposure(1.0)
        sky:SetSunLight(light)
        print("[M1][SKY] -> OK | kind=procedural")
    else
        zone.skyFogIntensity = 1.0
        print("[M1][SKY] -> NONE | reason=ProceduralSky unavailable")
    end

    -- 后处理：1.35 的 Zone 未必带后处理属性（.emmylua 按 1.38+ 声明），
    -- PostFx 内部逐项探测，缺哪项就记 NONE，不中断其余项。
    self.postfx = PostFx.Apply(zone, PostFxData)

    -- 音效：单个文件缺失只记 NONE，不阻塞开局（第 20 节）。
    self.sfx = Sfx.Create(self.scene, AudioData)

    self:CreateFloor()
    self.rig = PlayerRig.Create(self.scene, PlayerData, WorldData)
    -- 出生点取自 Data/Level.lua 的 spawn（原作 09-level 语句 4：-32,0,6），落在大门区、不贴墙体。
    local spawn = LevelData.spawn
    self.rig.node.position = Vector3(spawn.x, spawn.y, spawn.z)
    self.rig.lastSafe = self.rig.node.position
    print(string.format("[M1][SPAWN] -> OK | pos=(%.1f,%.1f,%.1f)", spawn.x, spawn.y, spawn.z))
    self.camera = FirstPersonCamera.Create(self.scene, PlayerData, ControlsData, self.rig.character.controls)
    self.camera:Sync(self.rig:GetEyePosition(), 0.0)
    local weaponMount = WeaponMount.Create(self.camera.node, WeaponData)
    local ThirdPersonView = require("modes.M1_Port.View.ThirdPersonView")
    local Character = require("Tarara")
    local WeaponPose = require("modes.M1_Port.Weapon.WeaponPose")
    local view = ThirdPersonView.Create(self.scene, PlayerData,
        {Character = Character, WeaponPose = WeaponPose})
    weaponMount:AttachActor(view.actor)
    view:AttachWeapon(weaponMount.actorRoot, PlayerData.pose)
    weaponMount:SetMode(false)
    view:SetBodyVisible(false)
    local effects = Effects.Create(self.scene, EffectsData)
    -- P4-A：命中表现（弹痕贴花 / 碎屑与火花 / 弹壳），数值在 Data/ImpactFx.lua
    self.decals = Decals.Create(self.scene, ImpactFxData)
    self.bursts = ImpactBursts.Create(self.scene, ImpactFxData)
    self.shells = ShellPool.Create(self.scene, ImpactFxData, self.world.groundY)
    effects:Attach({ decals = self.decals, bursts = self.bursts, shells = self.shells })
    -- P4-B：天气（雨 / 雨溅 / 地面湿润）；仓房矩形取自 Data/Level.lua 的「仓库」分区
    ---@type { minX: number, maxX: number, minZ: number, maxZ: number }|nil
    local shed = nil
    for index = 1, #LevelData.regions do
        local region = LevelData.regions[index]
        if region.name == "仓库" then
            shed = {
                minX = region.rect.minX, maxX = region.rect.maxX,
                minZ = region.rect.minZ, maxZ = region.rect.maxZ,
            }
        end
    end
    assert(shed ~= nil, "Mode: level data has no 仓库 region for weather culling")
    self.shedRect = shed
    local weatherLevel = self.level
    assert(weatherLevel ~= nil, "Mode: level build missing before weather")
    self.weather = Weather.Create(self.scene, WeatherData, weatherLevel)
    local rifle = Rifle.Create(self.scene, self.camera.node, weaponMount, WeaponData, effects)
    self.weaponMount = weaponMount
    -- P4-C：枪感（后坐弹簧 / 移动摇摆 / 冲刺收枪 / 自动检视），数值在 Data/ViewKick.lua
    self.viewKick = ViewKick.Create(weaponMount, self.camera.node, WeaponData, ViewKickData)
    self.tpView = view
    self.effects = effects
    self.rifle = rifle
    rifle.onShot = function()
        local kick = self.viewKick
        if kick ~= nil then kick:Shot() end
    end
    self.hud = PlayerHud.Create(self.rig, self.camera, ControlsData)
    self.weaponHud = WeaponHud.Create(rifle, WeaponHudData, WeaponData.name)
    -- 生命：数值在 Data/Health，Rig 只上报落地与落水，伤害由这里换算。
    local health = PlayerHealth.Create(HealthData)
    self.health = health
    self.rig.onLand = function(speed)
        local over = speed - HealthData.fallSpeed
        if over > 0.0 then
            health:Damage(over * HealthData.fallScale, "fall")
        end
        local kick = self.viewKick
        if kick ~= nil then kick:OnLand() end
    end
    self.rig.onDrown = function()
        health:Damage(HealthData.drownDamage, "drown")
    end
    self.statusHud = StatusHud.Create(health, StatusHudData)
    -- 敌人：波次与状态机在 Combat/，这里只接玩家位置、视线与扣血
    local blockLogs = 0
    -- 组件缺失必须显式中断；.emmylua 声明非 nil，LSP 判为多余（第 20 节）
---@diagnostic disable-next-line: unnecessary-assert
    local physics = assert(self.scene:GetComponent("PhysicsWorld"), "Mode requires PhysicsWorld")
    -- 视线：射线在玩家胶囊前 0.8 米收住，否则命中自己的碰撞体永远判遮挡
---@param from Vector3
---@param to Vector3
---@return boolean
    local function CanSee(from, to)
        local delta = to - from
        local length = delta:Length()
        if length <= 0.001 then return true end
        local probe = length - 0.8
        if probe <= 0.0 then return true end
        local hit = physics:RaycastSingle(Ray(from, delta * (1.0 / length)), probe, CollisionMaskStatic)
        if hit.body ~= nil and blockLogs < 3 then
            blockLogs = blockLogs + 1
            local hp = hit.position
            print(string.format("[M1][ENEMY][SIGHT][BLOCK] -> NONE | probe=%.1f hitDist=%.2f at=(%.1f,%.1f,%.1f)",
                probe, hit.distance or -1.0, hp.x, hp.y, hp.z))
        end
        return hit.body == nil
    end
    -- 敌方子弹：原作 17-enemy 语句 z 用真实弹道；这里把玩家胶囊近似成球（中心 +1.2，半径 0.5），
    -- 只判几何命中。视线已由 CanSee 保证，命中就扣血。
    ---@param origin Vector3
    ---@param dir Vector3
    ---@param damage number
    ---@return boolean hit
    local function EnemyShot(origin, dir, damage)
        local rigPos = self.rig.node.position
        local cx = rigPos.x - origin.x
        local cy = rigPos.y + 1.2 - origin.y
        local cz = rigPos.z - origin.z
        local proj = cx * dir.x + cy * dir.y + cz * dir.z
        if proj < 0.0 then
            return false
        end
        local ox = dir.x * proj - cx
        local oy = dir.y * proj - cy
        local oz = dir.z * proj - cz
        local miss = math.sqrt(ox * ox + oy * oy + oz * oz)
        local hit = miss <= 0.5
        if hit then
            health:Damage(damage, "enemy")
        end
        return hit
    end
    local waves = Waves.Create(self.scene, EnemyData, {
        materials = Materials,
        onEnemyShot = EnemyShot,
        visible = CanSee,
    })
    self.waves = waves
    rifle.hitscan = function(origin, dir, maxDist) return waves:RaycastEnemies(origin, dir, maxDist) end
    -- AI 自检：按钮「AI」接管角色自己找敌人打
    local autoPilot = AutoPilot.Create {
        visible = CanSee,
        rig = self.rig,
        hud = self.hud,
        rifle = rifle,
        waves = waves,
        data = AutoPilotData,
    }
    self.autoPilot = autoPilot
    -- 设置：权威在 Settings，相机与触摸层各自订阅，改完即时生效。
    local settings = Settings.Create(SettingsData)
    self.settings = settings
    local camera = self.camera
    settings:Subscribe(function(state)
        camera:SetSettings(state)
        PlayerHud.ApplySettings(state)
    end)
    renderer:SetViewport(0, Viewport:new(self.scene, self.camera.camera))
    local menu = self:BuildMenu()
    -- 帧率与场景规模：先取数再决定是否按材质合并网格（第 32 节）。
    self.perf = PerfStats.Create(self.scene)
    -- P3-A：流程状态机 + 三处中继 + 目标条与交互提示
    self.flow = GameFlow.Create(FlowData)
    self.relays = RelayFlow.Create(RelayData, FlowData)
    -- P3-C：中继柜灯色（原作 08-props B3）与世界目标标记（原作 18-hud h-marks）
    local level = self.level
    assert(level ~= nil, "Mode: level build missing before P3-C visuals")
    self.lamps = RelayLamp.Create(level, RelayData, RelayLampData)
    self.markers = WorldMarker.Create(menu.root, WorldMarkerData)
    self.objectiveHud = ObjectiveHud.Create(menu.root)
    self.promptHud = InteractPrompt.Create(menu.root)
    self.stats = RunStats.Create(FlowData.rating)
    self.extract = Extract.Create(RelayData.extract)
    self.radio = RadioHud.Create(menu.root)
    self.screens = MenuScreens.Create(menu.root)
    self.radioIntroSent = false
    self.runner = FlowRunner.Create {
        rig = self.rig,
        health = health,
        relays = self.relays,
        extract = self.extract,
        flow = self.flow,
        stats = self.stats,
        rifle = rifle,
        screens = self.screens,
        forward = function() return self:GetForward() end,
    }
    self.selfTest = SelfTest.Create(self.rig, self.hud, menu, function() self:ProbeFloor() end, health,
        function() self:ProbeProps() end, function() self:ProbeEnemy() end,
        function() self:StartAutoPilot() end, function() self:ProbePerf() end,
        function() self:ProbeRelay() end, function() self:StartRelayTest() end,
        function() self:ProbeExtract() end, function() self:StartExtractTest() end,
        function() self:StartFlowTest() end, function() self:StartDeathTest() end,
        function() self:ProbeMarkers() end, function() self:ProbeFx() end,
        function() self:ProbeWeather() end, function(target) self:TeleportTo(target) end,
        function() self:ProbeKick() end,
        function() self:ProbePostFx() end, self.postfx,
        function() self:ProbeSfx() end)
    self.settingsPanel = SettingsPanel.Create(settings, menu.root)
    -- 角色与相机探针（d7）：回答场景里有没有角色、枪挂在谁身上
    local rigNode = self.rig.node
    local rigPos = rigNode.worldPosition
    local camWorld = self.camera.node.worldPosition
    print(string.format("[M1][RIG] -> OK | pos=(%.2f,%.2f,%.2f) yaw=%.1f camWorld=(%.2f,%.2f,%.2f)",
        rigPos.x, rigPos.y, rigPos.z, rigNode.worldRotation:YawAngle(),
        camWorld.x, camWorld.y, camWorld.z))
    local okActors, actors = pcall(function() return self.scene:GetChildrenWithComponent("AnimatedModel", true) end)
    if okActors and actors ~= nil then
        local count = #actors
        print(string.format("[M1][ACTOR] -> %s | animatedModels=%d", count > 0 and "OK" or "NONE", count))
    else
        print("[M1][ACTOR] -> NONE | reason=api-unavailable")
    end
    local mount = self.weaponMount
    if mount ~= nil then
        local gun = mount:GetActiveNode()
        print(string.format("[M1][GUN] -> OK | mode=%s parent=%s seen=%s",
            mount.thirdPerson and "third" or "first",
            gun.parent ~= nil and gun.parent.name or "none", tostring(gun.enabled)))
    end
    print("[M1][MODE] -> OK | event=start")
end

-- 设置入口：按钮在最右上，弹药 HUD 已由 WeaponData 下移避让。
function Mode:BuildMenu()
    local id = self.id
    self.menu = ModeMenu.Create {
        options = self.menuOptions,
        current = id,
        onSelect = function(target) Router.Request(target) end,
    }
    return self.menu
end

-- 地面：四区域分区 + 仓库壳 + 码头边沿 + 围挡 + 首批道具，数据在 Data/Level.lua 与 Data/Props.lua（P1-1 / P1-2）。
-- 原作 09-level 语句 1 的地面写法；差异见任务卡 m1-p1a-foundation。
function Mode:CreateFloor()
    -- P1-1：四区域地面分区 + 仓库壳 + 码头边沿 + 围挡，全部来自 Data/Level.lua。
    local build = Level.Create(self.scene, Geometry, Materials, self.world, LevelData)
    self.level = build
    self.floorNode = build.yardNode
    self.floorMaterial = build.yardMaterial
    return
end

-- 旧的单块地面实现保留为参考路径（当前不再调用）。
function Mode:CreateSingleFloor()
    local bounds = self.world.bounds
    local width = bounds.maxX - bounds.minX
    local depth = bounds.maxZ - bounds.minZ
    local thickness = 1.0
    local y = self.world.groundY - thickness * 0.5

    local pitch = Geometry.Box(width, thickness, depth, {
        uvMeters = MaterialsData.ground.uvMeters,
        bottom = false,
    })
    local node = self.scene:CreateChild("Floor")
    node.position = Vector3(0, y, 0)
-- 组件加载失败需显式中断（f2），LSP 判为多余
---@diagnostic disable-next-line: unnecessary-assert
    local model = assert(node:CreateComponent("StaticModel"), "Floor node missing StaticModel")

    -- 1.35 的 ProceduralGeometry 没有 ToModel（真机 53521 待探针确认），缺失时退回内置盒体模型
    local floorModel
    local trisText = "?"
    local pitchModel
    if pitch ~= nil then
-- 1.35 的 ProceduralGeometry 可能没有 ToModel，缺失时 pitchModel 保持 nil 走内置模型分支
---@diagnostic disable-next-line: undefined-field
        if type(pitch.ToModel) == "function" then
            local okModel, built = pcall(function() return pitch:ToModel() end)
            if okModel then pitchModel = built end
        end
    end
    local built = pitch
    if pitchModel ~= nil and built ~= nil then
        floorModel = pitchModel
        node.scale = Vector3.ONE
---@diagnostic disable-next-line: undefined-field
        if type(built.GetIndexCount) == "function" then
---@diagnostic disable-next-line: undefined-field
            trisText = tostring(built:GetIndexCount() // 3)
        end
    else
-- 资源加载失败需显式中断（f2），LSP 判为多余
---@diagnostic disable-next-line: unnecessary-assert
        floorModel = assert(cache:GetResource("Model", "Models/Box.mdl"), "Missing model: Models/Box.mdl")
        node.scale = Vector3(width, thickness, depth)
        print(string.format("[M1][FLOOR] -> NONE | geometry=fallback reason=procedural unavailable tris=%s", trisText))
    end

    model:SetModel(floorModel)
    self.floorNode = node
    -- 材质也做降级：1.35 若缺 TextureBaker 或 SurfaceShader，退回纯色，避免整局进不去
    local tint = MaterialsData.ground.color
    local okMat, groundMaterial = pcall(Materials.Get, MaterialsData.ground.material, {
        -- 几何已按米 UV 生成，材质端不再重复缩放（uvMeters=1 表示一个 UV 单位即 1 米）
        uvMeters = 1,
        color = tint and Color(tint[1], tint[2], tint[3]) or nil,
        macro = { ground = self.world.groundY },
    })
    if okMat and groundMaterial ~= nil then
        model:SetMaterial(groundMaterial)
        self.floorMaterial = groundMaterial
        -- 贴图尺寸决定颗粒是否出图；烘焙完成前是 1x1 占位（d3）
        print(string.format(
            "[M1][FLOOR] -> OK | material=baked name=%s uvMeters=%s color=%s macro=%s tris=%s tex=%s",
            tostring(MaterialsData.ground.material), tostring(MaterialsData.ground.uvMeters),
            tostring(tint ~= nil), tostring(self.world.groundY), trisText, self:FloorTextureSize()))
    else
-- 资源加载失败需显式中断（f2），LSP 判为多余
---@diagnostic disable-next-line: unnecessary-assert
        local plainTechnique = assert(cache:GetResource("Technique", "Techniques/PBR/PBRNoTexture.xml"),
            "Missing technique: Techniques/PBR/PBRNoTexture.xml")
        local plain = Material:new()
        plain:SetTechnique(0, plainTechnique)
        plain:SetShaderParameter("MatDiffColor", Variant(Color(0.30, 0.31, 0.33, 1.0)))
        plain:SetShaderParameter("Metallic", Variant(0.0))
        plain:SetShaderParameter("Roughness", Variant(0.9))
        model:SetMaterial(plain)
        print("[M1][FLOOR] -> NONE | material=plain reason=" .. tostring(groundMaterial))
    end

-- 组件加载失败需显式中断（f2），LSP 判为多余
---@diagnostic disable-next-line: unnecessary-assert
    local body = assert(node:CreateComponent("RigidBody"), "Floor node missing RigidBody")
    body:SetCollisionLayerAndMask(CollisionLayerStatic, CollisionMaskStatic)

-- 组件加载失败需显式中断（f2），LSP 判为多余
---@diagnostic disable-next-line: unnecessary-assert
    local shape = assert(node:CreateComponent("CollisionShape"), "Floor node missing CollisionShape")
    shape:SetBox(Vector3(width, thickness, depth))

    print(string.format("[M1][FLOOR] -> OK | size=%.0fx%.0f y=%.2f material=%s uvMeters=%.0f tris=%s",
        width, depth, y, MaterialsData.ground.material, MaterialsData.ground.uvMeters, trisText))
end

-- 地面材质探针：贴图尺寸与节点尺寸，自检「地面」按钮与启动时共用（d3）。
---@return string
function Mode:FloorTextureSize()
    local material = self.floorMaterial
    if material == nil then return "none" end
    local okTex, tex = pcall(function() return material:GetTexture(0) end)
    if not okTex or tex == nil then return "none" end
    local w, h = tex:GetWidth(), tex:GetHeight()
    if w == nil or h == nil or w <= 0 or h <= 0 then return "unknown" end
    return string.format("%dx%d", w, h)
end

function Mode:ProbeFloor()
    local texSize = self:FloorTextureSize()
    local node = self.floorNode
    local size = "none"
    if node ~= nil then
        local scale = node.scale
        size = string.format("%.0fx%.0f", scale.x, scale.z)
    end
    local baked = texSize ~= "1x1" and texSize ~= "none"
    local result = baked and "OK" or "NONE"
    print(string.format("[M1][FLOOR] -> %s | event=probe name=%s tex=%s size=%s baked=%s",
        result, tostring(MaterialsData.ground.material), texSize, size, tostring(baked)))
end

-- 道具探针：确认摆放数与分区数，自检「道具」按钮与启动日志共用（第 29 节）。
function Mode:ProbeProps()
    local level = self.level
    if level == nil then
        print("[M1][PROPS] -> FAIL | event=probe reason=level-missing")
        return
    end
    local props = level.props
    local zoneText = {}
    for name, count in pairs(props.zones) do
        zoneText[#zoneText + 1] = string.format("%s:%d", name, count)
    end
    table.sort(zoneText)
    local result = props.placed > 0 and "OK" or "FAIL"
    print(string.format("[M1][PROPS] -> %s | event=probe placed=%d builders=%d zones=%s first=(%.1f,%.1f,%.1f) last=(%.1f,%.1f,%.1f)",
        result, props.placed, props.builders, table.concat(zoneText, ","),
        props.first.x, props.first.y, props.first.z, props.last.x, props.last.y, props.last.z))
end

--- 水平化相机前向，交互朝向判定用（忽略俯仰，原作 interactFacing 是水平夹角）。
---@return Vector3
function Mode:GetForward()
    local camera = self.camera
    if camera == nil then return Vector3(0.0, 0.0, 1.0) end
    local dir = camera.node.worldDirection
    local flat = Vector3(dir.x, 0.0, dir.z)
    if flat:Length() < 0.001 then return Vector3(0.0, 0.0, 1.0) end
    return flat:Normalized()
end

-- 自检传送：把玩家放到指定分区的中央（分区坐标来自 Data/Level.lua，撤离点来自 Data/Relay.lua）。
-- 只服务自检，不参与玩法；传送后同步 lastSafe，避免 Rig 把玩家当掉出边界拉回原地。
---@param target string 大门 / 堆场 / 仓库 / 码头 / 撤离
function Mode:TeleportTo(target)
    assert(type(target) == "string" and target ~= "", "Mode:TeleportTo needs a target")
    ---@type Vector3|nil
    local pos = nil
    if target == "撤离" then
        local extract = self.extract
        assert(extract ~= nil, "Mode:TeleportTo extract module missing")
        ---@cast extract M1Extract
        pos = Vector3(extract.data.x, 0.0, extract.data.z)
    else
        for index = 1, #LevelData.regions do
            local region = LevelData.regions[index]
            if region.name == target then
                pos = Vector3((region.rect.minX + region.rect.maxX) * 0.5, 0.0,
                    (region.rect.minZ + region.rect.maxZ) * 0.5)
            end
        end
    end
    assert(pos ~= nil, "Mode:TeleportTo unknown target: " .. target)
    self.rig.node.position = pos
    self.rig.lastSafe = pos
    print(string.format("[M1][TELEPORT] -> OK | target=%s pos=(%.1f,%.1f,%.1f)", target, pos.x, pos.y,
        pos.z))
end

-- 全流程测试：等进玩 → 切三处中继 → 解锁撤离 → 瞬移到撤离点 → 出结算（瞬移只用于走位）。
function Mode:StartFlowTest()
    local runner = self.runner
    if runner == nil then
        print("[M1][RUN][START] -> FAIL | reason=runner-missing")
        return
    end
    runner:Start()
end

-- 死亡页测试：直接把血量打到 0，看 dead 状态与死亡页。
function Mode:StartDeathTest()
    local runner = self.runner
    if runner == nil then
        print("[M1][RUN][DEATH] -> FAIL | reason=runner-missing")
        return
    end
    runner:StartDeath()
end

-- 撤离探针：撤离点是否解锁、距离、是否已达成。
function Mode:ProbeExtract()
    local extract = self.extract
    if extract == nil then
        print("[M1][EXTRACT][PROBE] -> FAIL | reason=extract-missing")
        return
    end
    extract:Probe(self.rig.node.position)
    local stats = self.stats
    if stats ~= nil then stats:Probe() end
end

-- 自检「撤离」：先把三处中继置为已切断，再传送到撤离点，两秒内应进 complete。
function Mode:StartExtractTest()
    local relays = self.relays
    local extract = self.extract
    if relays == nil or extract == nil then
        print("[M1][EXTRACT][TEST] -> FAIL | reason=missing-module")
        return
    end
    relays:ForceAllCut()
    local pos = Vector3(extract.data.x, 0.0, extract.data.z)
    self.rig.node.position = pos
    self.rig.lastSafe = pos
    print(string.format("[M1][EXTRACT][TEST] -> OK | pos=(%.1f,%.1f)", pos.x, pos.z))
end

-- 枪感探针：自检「枪感」按钮用，打印后坐弹簧、冲刺进度、检视状态。
function Mode:ProbeKick()
    local kick = self.viewKick
    if kick == nil then
        print("[M1][KICK][PROBE] -> FAIL | reason=module-missing")
        return
    end
    kick:Probe()
end

-- 后处理探针：自检「后处理」按钮用，打印已生效项数与五项回读值。
function Mode:ProbePostFx()
    local postfx = self.postfx
    if postfx == nil then
        print("[M1][POST][PROBE] -> FAIL | reason=module-missing")
        return
    end
    postfx:Probe()
end

-- 音效探针：自检「声音」按钮用，打印设备状态与 5 个事件，并把非循环事件各播一次。
function Mode:ProbeSfx()
    local sfx = self.sfx
    if sfx == nil then
        print("[M1][SFX][PROBE] -> FAIL | reason=module-missing")
        return
    end
    sfx:Probe()
end

-- 天气探针：自检「雨」按钮用，打印雨量、湿润度、室内标记与两个发射器状态。
function Mode:ProbeWeather()
    local weather = self.weather
    if weather == nil then
        print("[M1][WEATHER][PROBE] -> FAIL | reason=module-missing")
        return
    end
    weather:Probe()
end

-- 命中表现探针：自检「特效」按钮用，打印贴花 / 碎屑火花 / 弹壳三池状态。
function Mode:ProbeFx()
    local decals = self.decals
    local bursts = self.bursts
    local shells = self.shells
    if decals == nil or bursts == nil or shells == nil then
        print("[M1][FX][PROBE] -> FAIL | reason=module-missing")
        return
    end
    decals:Probe()
    bursts:Probe()
    shells:Probe()
end

-- 灯色与标记探针：自检「标记」按钮用，打印槽位文案与三盏灯状态。
function Mode:ProbeMarkers()
    local markers = self.markers
    if markers == nil then
        print("[M1][WMARK][PROBE] -> FAIL | reason=marker-missing")
        return
    end
    markers:Probe()
    local lamps = self.lamps
    if lamps ~= nil then lamps:Probe() end
end

-- 中继探针：三处中继的切断状态与最近距离。
function Mode:ProbeRelay()
    local relays = self.relays
    if relays == nil then
        print("[M1][RELAY][PROBE] -> FAIL | reason=relay-missing")
        return
    end
    relays:Probe(self.rig.node.position)
end

-- 自检「中继」：传送到最近未切断中继前 1.5 米、朝向它，随后自动按住到切断。
function Mode:StartRelayTest()
    local relays = self.relays
    if relays == nil then
        print("[M1][RELAY][TEST] -> FAIL | reason=relay-missing")
        return
    end
    local entry = relays:NearestAny(self.rig.node.position)
    if entry == nil then
        print("[M1][RELAY][TEST] -> NONE | reason=all-cut")
        relays:Probe(self.rig.node.position)
        return
    end
    local pos = Vector3(entry.pos.x - 1.5, 0.0, entry.pos.z)
    self.rig.node.position = pos
    self.rig.lastSafe = pos
    local controls = self.rig.character.controls
    controls.yaw = math.pi * 0.5
    controls.pitch = 0.0
    self.relayTestTimer = 3.5
    print(string.format("[M1][RELAY][TEST] -> OK | target=%s pos=(%.1f,%.1f) hold=%.1fs",
        entry.short, pos.x, pos.z, FlowData.cutSeconds))
end

-- 性能探针：自检「性能」按钮调用，输出帧率、节点数、静态模型数、绘制批次（未量化前不合并网格）。
function Mode:ProbePerf()
    local perf = self.perf
    if perf == nil then
        print("[M1][PERF][PROBE] -> FAIL | reason=stats-missing")
        return
    end
    perf:Print("selftest")
end

-- AI 自检入口：按钮「AI」按下后由 AutoPilot 接管一局（默认 30 秒），结束打 [M1][AI][STOP]。
function Mode:StartAutoPilot()
    local autoPilot = self.autoPilot
    if autoPilot == nil then
        print("[M1][AI] -> FAIL | reason=autopilot-missing")
        return
    end
    autoPilot:Start(self.health)
end

-- 敌人探针：自检「敌人」按钮调用，回答刷了几只、活着几只、最近多远（第 29 节）。
function Mode:ProbeEnemy()
    local waves = self.waves
    if waves == nil then
        print("[M1][ENEMY] -> FAIL | event=probe reason=waves-missing")
        return
    end
    waves:Probe(self.rig:GetEyePosition())
end

---@param dt number
function Mode:Update(dt)
    self.camera:UpdateLook()
    local menu = self.menu
    local panel = self.settingsPanel
    local uiHit = (menu ~= nil and menu.open) or (panel ~= nil and panel:IsOpen())
    local selfTest = self.selfTest
    if selfTest ~= nil then selfTest:Update(dt, uiHit) end
    if uiHit then
        -- 弹层打开时吞掉战斗输入，避免点到弹层背后还在开枪
        local hudOpen = self.hud
        if hudOpen ~= nil then hudOpen:ConsumeReload() end
    end
    self.rig:Update(dt)
    local health = self.health
    if health ~= nil then
        health:Update(dt)
    end
    local waves = self.waves
    if waves ~= nil then
        waves:Update(dt, self.rig:GetEyePosition(), self.scene)
    end
    local autoPilot = self.autoPilot
    if autoPilot ~= nil then
        autoPilot:Update(dt, self.health, self.waves)
    end
    self.camera:Sync(self.rig:GetEyePosition(), dt)
    local hud = self.hud
    if hud ~= nil and hud:ConsumeViewToggle() then
        self:SetThirdPerson(not hud.isThirdPerson)
    end
    local tpView = self.tpView
    if tpView ~= nil then
        local controls = self.rig.character.controls
        -- 角色朝向与位置由 ThirdPersonView 独占写入，这里不再重复（第 15 节）
        tpView:Update(self.rig.node, controls.yaw, controls.pitch, self.rig:GetHorizontalSpeed())
        local probe = self.probeInFrames
        if probe ~= nil then
            if probe <= 1 then
                local mount = self.weaponMount
                if mount ~= nil then mount:ProbeAim(tpView:GetForward()) end
                self.probeInFrames = nil
            else
                self.probeInFrames = probe - 1
            end
        end
    end
    local rifle = self.rifle
    if rifle ~= nil and hud ~= nil then
        rifle:Update(dt, {
            fireHeld = not uiHit and hud:IsFireHeld()
                and not (self.viewKick ~= nil and self.viewKick:IsFireBlocked()),
            reloadPressed = hud:ConsumeReload(),
            speed = self.rig:GetHorizontalSpeed(),
            onGround = self.rig.character:IsOnGround(),
            crouching = self.rig.crouching,
            sfx = self.sfx,
        })
    end
    local effects = self.effects
    if effects ~= nil then effects:Update(dt) end
    local weather = self.weather
    if weather ~= nil then
        weather:Update(dt, self.camera.node, self.rig.node.position, self.shedRect)
    end
    local viewKick = self.viewKick
    if viewKick ~= nil then
        viewKick:Update(dt, self.rig:GetHorizontalSpeed(), self.rig.character:IsOnGround())
    end
    local perf = self.perf
    if perf ~= nil then perf:Update(dt) end
    self:UpdateFlow(dt)
    self:UpdateMarkers(dt)
end

-- 流程与中继：状态机推进、交互累计、目标条与提示刷新、死亡锁输入。
---@param dt number
function Mode:UpdateFlow(dt)
    local flow = self.flow
    if flow == nil then return end
    flow:Update(dt)
    local health = self.health
    if health ~= nil and not health.alive and not flow:IsDead() then
        flow:MarkDead()
        local deadScreens = self.screens
        local deadStats = self.stats
        local deadRelays = self.relays
        if deadScreens ~= nil and deadStats ~= nil and deadRelays ~= nil then
            deadScreens:ShowDead(deadStats:TimeText(), deadRelays:Done(), deadRelays:Total())
        end
        local deadRadio = self.radio
        if deadRadio ~= nil then deadRadio:Say(RadioData.dead, 2.5) end
        local controls = self.rig.character.controls
        controls:Set(CTRL_FORWARD, false)
        controls:Set(CTRL_BACK, false)
        controls:Set(CTRL_LEFT, false)
        controls:Set(CTRL_RIGHT, false)
        controls:Set(CTRL_JUMP, false)
    end
    local radio = self.radio
    if radio ~= nil then
        radio:Update(dt)
        if flow:IsIntro() and not self.radioIntroSent and flow:Elapsed() >= 1.3 then
            self.radioIntroSent = true
            radio:Say(RadioData.intro, 4.2)
        end
    end
    local stats = self.stats
    local rifle = self.rifle
    local waves = self.waves
    if stats ~= nil and flow:IsPlaying() then
        stats:AddTime(dt)
        local kills = 0
        if waves ~= nil then kills = waves:GetStats().killed end
        stats:Sync(rifle ~= nil and rifle.shots or 0, rifle ~= nil and rifle.hits or 0, kills)
    end
    local runner = self.runner
    if runner ~= nil then runner:Update(dt) end
    -- 本地验证开关：FlowData.autoRunFlow = true 时进玩后自动跑一次全流程（正式包为 false）。
    -- LSP 把 Data/Flow.lua 里的字面量 false 当常量，判为恒假；本地验证时会临时改 true。
---@diagnostic disable-next-line: unnecessary-if
    if FlowData.autoRunFlow and flow:IsPlaying() and self.autoRan ~= true then
        self.autoRan = true
        self:StartFlowTest()
    end
    local relays = self.relays
    local hud = self.hud
    if relays == nil then return end
    local held = false
    local timer = self.relayTestTimer
    if timer ~= nil and timer > 0.0 then
        self.relayTestTimer = timer - dt
        held = true
    elseif hud ~= nil then
        held = hud:IsInteractHeld()
    end
    local forward = self:GetForward()
    if runner ~= nil and runner:InteractHeld() then
        held = true
        -- 测试跑者按住时，朝向直接对准目标中继，绕开相机朝向的不确定性（仅 runner 活动时生效）
        local target = relays:NearestAny(self.rig.node.position)
        if target ~= nil then
            local px = target.pos.x - self.rig.node.position.x
            local pz = target.pos.z - self.rig.node.position.z
            local len = math.sqrt(px * px + pz * pz)
            if len > 0.001 then
                forward = Vector3(px / len, 0.0, pz / len)
            end
        end
    end
    if flow:IsDead() then held = false end
    relays:Update(dt, self.rig.node.position, forward, held)
    -- P3-C：灯色跟随中继状态（原作 08-props B3），Relay 是唯一权威
    local lamps = self.lamps
    if lamps ~= nil then
        lamps:Sync(relays.entries)
        lamps:Update(dt)
    end
    local objHud = self.objectiveHud
    if objHud ~= nil then
        local shorts = {}
        local entries = relays.entries
        for index = 1, #entries do shorts[index] = entries[index].short end
        objHud:Set(FlowData.objectiveBase, relays:Done(), relays:Total(), shorts)
    end
    local extract = self.extract
    if extract ~= nil and relays:AllCut() then
        extract:Unlock()
        if extract:Update(self.rig.node.position) and stats ~= nil then
            local name = stats:Rating()
            flow:Complete()
            local screens = self.screens
            if screens ~= nil then
                local accuracy = stats:Accuracy()
                screens:ShowComplete {
                    time = stats:TimeText(),
                    accuracy = accuracy ~= nil and string.format("%.0f%%", accuracy * 100.0) or "—",
                    kills = stats.kills,
                    retries = stats:Retries(),
                    rating = name,
                }
            end
            if radio ~= nil then radio:Say(RadioData.done, 3.0) end
        end
    end
    local prompt = self.promptHud
    if prompt ~= nil then
        local entry, percent = relays:ActiveProgress()
        if entry ~= nil then
            prompt:Show("切断中继 " .. entry.short, percent)
        else
            local near = relays:Nearest(self.rig.node.position, self:GetForward())
            if near ~= nil then
                prompt:Show("切断中继 " .. near.short, 0.0)
            else
                prompt:Hide()
            end
        end
    end
end

-- 世界标记：只在游玩态显示未切断的中继，全部切断后追加撤离点；权威仍是 Relay 与 Extract。
---@param _dt number
function Mode:UpdateMarkers(_dt)
    local markers = self.markers
    if markers == nil then return end
    local relays = self.relays
    local flow = self.flow
    if relays == nil or flow == nil then
        markers:HideAll()
        return
    end
    ---@type M1MarkerCandidate[]
    local candidates = {}
    if flow:IsPlaying() then
        local entries = relays.entries
        for index = 1, #entries do
            local entry = entries[index]
            if not entry.cut then
                candidates[#candidates + 1] = {
                    id = entry.id,
                    text = string.format(WorldMarkerData.relayFormat, entry.short),
                    pos = entry.pos,
                    height = WorldMarkerData.relayHeight,
                }
            end
        end
        local extract = self.extract
        if extract ~= nil and relays:AllCut() and not extract:IsReached() then
            candidates[#candidates + 1] = {
                id = "extract",
                text = WorldMarkerData.extractFormat,
                pos = Vector3(extract.data.x, 0.0, extract.data.z),
                height = WorldMarkerData.extractHeight,
            }
        end
    end
    markers:Update(self.rig:GetEyePosition(), self:ActiveCamera(), candidates)
end

--- 当前渲染相机组件：第三人称时换成角色相机（相机节点由标记模块自己读）。
---@return Camera
function Mode:ActiveCamera()
    local mount = self.weaponMount
    local view = self.tpView
    if mount ~= nil and mount.thirdPerson and view ~= nil then
        return view:GetCamera()
    end
    return self.camera.camera
end

--- Switch between first person and third person. Only toggles visibility (f4).
---@param on boolean
function Mode:SetThirdPerson(on)
    on = on == true
    local hud = self.hud
    if hud ~= nil then hud:SetThirdPerson(on) end
    local mount = self.weaponMount
    if mount == nil then return end

    local view = self.tpView
    assert(view ~= nil, "ThirdPersonView missing at switch time")
    if on then
        mount:SetMode(true)
        view:SetBodyVisible(true)
        -- 等角色姿态与骨骼世界变换生效一帧再取样，否则角色是单位旋转，探针恒为 1.0（第 29 节）
        self.probeInFrames = 60
        renderer:SetViewport(0, Viewport:new(self.scene, view:GetCamera()))
        print("[M1][VIEW] -> OK | event=switch mode=third")
    else
        self.probeInFrames = nil
        mount:SetMode(false)
        view:SetBodyVisible(false)
        renderer:SetViewport(0, Viewport:new(self.scene, self.camera.camera))
        print("[M1][VIEW] -> OK | event=switch mode=first")
    end
end

--- 动画之后覆盖骨骼：姿势必须在这一帧生效（第 19、29 节）。
function Mode:PostUpdate()
    local view = self.tpView
    if view ~= nil then view:PostUpdate() end
end

function Mode:PostRender() end

function Mode:Stop()
    local selfTest = self.selfTest
    if selfTest ~= nil then
        selfTest:Stop()
        selfTest:Dispose()
        self.selfTest = nil
    end
    local autoPilot = self.autoPilot
    if autoPilot ~= nil then
        autoPilot:Dispose()
        self.autoPilot = nil
    end
    local waves = self.waves
    if waves ~= nil then
        waves:Dispose()
        self.waves = nil
    end
    local perf = self.perf
    if perf ~= nil then
        perf:Destroy()
        self.perf = nil
    end
    local promptHud = self.promptHud
    if promptHud ~= nil then
        promptHud:Destroy()
        self.promptHud = nil
    end
    local objectiveHud = self.objectiveHud
    if objectiveHud ~= nil then
        objectiveHud:Destroy()
        self.objectiveHud = nil
    end
    local lamps = self.lamps
    if lamps ~= nil then
        lamps:Destroy()
        self.lamps = nil
    end
    local markers = self.markers
    if markers ~= nil then
        markers:Destroy()
        self.markers = nil
    end
    local relays = self.relays
    if relays ~= nil then
        relays:Destroy()
        self.relays = nil
    end
    local flow = self.flow
    if flow ~= nil then
        flow:Destroy()
        self.flow = nil
    end
    self.relayTestTimer = nil
    local runner = self.runner
    if runner ~= nil then
        runner:Destroy()
        self.runner = nil
    end
    local screens = self.screens
    if screens ~= nil then
        screens:Destroy()
        self.screens = nil
    end
    local radio = self.radio
    if radio ~= nil then
        radio:Destroy()
        self.radio = nil
    end
    local extract = self.extract
    if extract ~= nil then
        extract:Destroy()
        self.extract = nil
    end
    local stats = self.stats
    if stats ~= nil then
        stats:Destroy()
        self.stats = nil
    end
    local statusHud = self.statusHud
    if statusHud ~= nil then
        statusHud:Destroy()
        self.statusHud = nil
    end
    local weaponHud = self.weaponHud
    if weaponHud ~= nil then
        weaponHud:Destroy()
        self.weaponHud = nil
    end
    self.rig.onLand = nil
    self.rig.onDrown = nil
    self.health = nil
    self.waves = nil
    self.autoPilot = nil
    local panel = self.settingsPanel
    if panel ~= nil then
        panel:Destroy()
        self.settingsPanel = nil
    end
    self.settings = nil
    local effects = self.effects
    if effects ~= nil then
        effects:Destroy()
        self.effects = nil
    end
    local decals = self.decals
    if decals ~= nil then
        decals:Destroy()
        self.decals = nil
    end
    local bursts = self.bursts
    if bursts ~= nil then
        bursts:Destroy()
        self.bursts = nil
    end
    local shells = self.shells
    if shells ~= nil then
        shells:Destroy()
        self.shells = nil
    end
    local weather = self.weather
    if weather ~= nil then
        weather:Destroy()
        self.weather = nil
    end
    local viewKick = self.viewKick
    if viewKick ~= nil then
        viewKick:Destroy()
        self.viewKick = nil
    end
    local menu = self.menu
    if menu ~= nil then menu:Destroy() end
    self.menu = nil
    local hud = self.hud
    if hud ~= nil then hud:Destroy() end
    self.hud = nil
    local tpView = self.tpView
    if tpView ~= nil then
        tpView:Destroy()
        self.tpView = nil
    end
    local mount = self.weaponMount
    if mount ~= nil then mount:Destroy() end
    self.weaponMount = nil
    self.rifle = nil
    input.mouseMode = self.prevMouseMode
    input.mouseVisible = self.prevMouseVisible
    ModeMenu.Shutdown()
    print("[M1][MODE] -> OK | event=stop")
end

function Mode:Dispose()
    local mount = self.weaponMount
    if mount ~= nil then mount:Destroy() end
    self.rifle = nil
    self.weaponMount = nil
    self.effects = nil
    self.weaponHud = nil
    self.hud = nil
    self.menu = nil
    self.selfTest = nil
    local sfx = self.sfx
    if sfx ~= nil then
        sfx:Dispose()
        self.sfx = nil
    end
    self.floorNode = nil
    self.floorMaterial = nil
    self.perf = nil
    self.flow = nil
    self.relays = nil
    self.objectiveHud = nil
    self.promptHud = nil
    self.stats = nil
    self.extract = nil
    self.radio = nil
    self.screens = nil
    self.runner = nil
    self.scene = nil
    print("[M1][MODE] -> OK | event=dispose")
end

return Mode
