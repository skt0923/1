-- 道具构建器：按 Data/Props.lua 的尺寸表与摆放表生成静态节点。
-- 尺寸、材质取自 08-props 语句 1（Gi 尺寸表）；原作每个道具是程序化几何拼装，
-- 这里用内置 Box / Cylinder 模型按同一包围盒拼装，细节件按任务卡 m1-p1b-props 的差异表简化。
-- 内置模型的 UV 是每面 0-1，所以每件按「面尺寸 ÷ 每 UV 米数」传 uvScale，否则木箱等会被拉成格纹。
local TAG = "[M1][PROPS]"

local Props = {}

---@type Model|nil
local boxModel_ = nil
---@type Model|nil
local cylinderModel_ = nil
---@type Model|nil
local coneModel_ = nil

-- 颜色名 → 材质名（09-level 的 color 字段，映射 05-material 的 paint_* 命名）。
---@type table<string, string>
local COLOR_MATERIAL = {
    red = "paint_red",
    blue = "paint_blue",
    green = "paint_green",
    yellow = "paint_yellow",
    orange = "paint_orange",
    white = "paint_white",
    grey = "paint_grey",
    teal = "paint_teal",
}

---@param kind "box"|"cylinder"|"cone"
---@return Model
local function BaseModel(kind)
    if kind == "cone" then
        if coneModel_ == nil then
            local ok, model = pcall(function() return cache:GetResource("Model", "Models/Cone.mdl") end)
            assert(ok and model ~= nil, "Missing model: Models/Cone.mdl")
            coneModel_ = model --[[@as Model]]
        end
        return coneModel_ --[[@as Model]]
    end
    if kind == "box" then
        if boxModel_ == nil then
            local ok, model = pcall(function() return cache:GetResource("Model", "Models/Box.mdl") end)
            assert(ok and model ~= nil, "Missing model: Models/Box.mdl")
            boxModel_ = model --[[@as Model]]
        end
        return boxModel_ --[[@as Model]]
    end
    if cylinderModel_ == nil then
        local ok, model = pcall(function() return cache:GetResource("Model", "Models/Cylinder.mdl") end)
        assert(ok and model ~= nil, "Missing model: Models/Cylinder.mdl")
        cylinderModel_ = model --[[@as Model]]
    end
    return cylinderModel_ --[[@as Model]]
end

---@class M1PropContext
---@field size M1PropSize
---@field material string 主件材质名（已按 color 覆盖）。
---@field mat fun(name: string, uvMeters: number, uvScale: Vector2): Material|nil

--- 取材质；取不到返回 nil，由调用方记 NONE 并继续用无贴图材质。
---@param materials table
---@param name string
---@param uvMeters number
---@param uvScale Vector2
---@return Material|nil
local function GetMaterial(materials, name, uvMeters, uvScale)
    local ok, material = pcall(materials.Get, name, { uvMeters = uvMeters, uvScale = uvScale })
    if not ok or material == nil then
        print(string.format("%s[MAT] -> NONE | name=%s uvMeters=%.2f reason=%s",
            TAG, tostring(name), uvMeters, tostring(material)))
        return nil
    end
    return material --[[@as Material]]
end

--- 建一个零件：位置是零件中心（相对道具根节点），尺寸用节点 scale 表达。
---@param parent Node
---@param ctx M1PropContext
---@param name string
---@param kind "box"|"cylinder"|"cone"
---@param size Vector3
---@param materialName string
---@param metersPerUV number
---@param offset Vector3
---@param yawDeg? number 绕 Y 轴角度。
---@param rollDeg? number 绕 Z 轴角度（横置圆柱用）；给了就以它为准，忽略 yawDeg。
---@return Node
local function Part(parent, ctx, name, kind, size, materialName, metersPerUV, offset, yawDeg, rollDeg)
    local node = parent:CreateChild(name)
    node.position = offset
    node.scale = size
    if rollDeg ~= nil and rollDeg ~= 0.0 then
        node.rotation = Quaternion(rollDeg, Vector3(0.0, 0.0, 1.0))
    elseif yawDeg ~= nil and yawDeg ~= 0.0 then
        node.rotation = Quaternion(yawDeg, Vector3(0.0, 1.0, 0.0))
    end
    local ok, model = pcall(function() return node:CreateComponent("StaticModel") end)
    assert(ok and model ~= nil, "Prop part missing StaticModel: " .. name)
    ---@cast model StaticModel
    model:SetModel(BaseModel(kind))
    local material = ctx.mat(materialName, metersPerUV, Vector2(size.x / metersPerUV, size.y / metersPerUV))
    if material ~= nil then
        model:SetMaterial(material)
    end
    model:SetCastShadows(true)
    return node
end

--- 集装箱：箱体 + 四角柱 + 上下框（原作 08-props 的 M3 有波纹与门缝，这里按差异表简化）。
---@param parent Node
---@param ctx M1PropContext
local function BuildContainer(parent, ctx)
    local size = ctx.size
    local width, height, depth = size.width, size.height, size.depth
    Part(parent, ctx, "body", "box", Vector3(width, height, depth), ctx.material, 2.5,
        Vector3(0.0, height * 0.5, 0.0))
    local post = 0.12
    for _, sx in ipairs({ -1.0, 1.0 }) do
        for _, sz in ipairs({ -1.0, 1.0 }) do
            Part(parent, ctx, "post", "box", Vector3(post, height, post), "steel_galv", 1.0,
                Vector3(sx * (width * 0.5 - post * 0.5), height * 0.5,
                    sz * (depth * 0.5 - post * 0.5)))
        end
    end
    Part(parent, ctx, "toprail", "box", Vector3(width, post, depth), "steel_galv", 1.0,
        Vector3(0.0, height - post * 0.5, 0.0))
    Part(parent, ctx, "bottomrail", "box", Vector3(width, post * 1.2, depth), "steel_galv", 1.0,
        Vector3(0.0, post * 0.6, 0.0))
    -- 门端（-Z）：两根锁杆 + 门号牌；原作贴花带编号文字，这里只做几何（差异第 16 条）
    local doorZ = -depth * 0.5 - 0.02
    for _, sx in ipairs({ -1.0, 1.0 }) do
        Part(parent, ctx, "lockbar", "box", Vector3(0.06, height * 0.8, 0.06), "steel_galv", 1.0,
            Vector3(sx * depth * 0.22, height * 0.5, doorZ))
    end
    Part(parent, ctx, "plate", "box", Vector3(depth * 0.42, 0.45, 0.03), "paint_white", 1.0,
        Vector3(0.0, height * 0.72, doorZ))
end

--- 隔离墩：底座 + 收窄墩身（原作 S3 的上下轮廓，这里用两段盒体近似）。
---@param parent Node
---@param ctx M1PropContext
local function BuildJerseyBarrier(parent, ctx)
    local size = ctx.size
    Part(parent, ctx, "base", "box", Vector3(size.width, 0.33, size.depth), ctx.material, 1.0,
        Vector3(0.0, 0.165, 0.0))
    Part(parent, ctx, "body", "box", Vector3(size.width, size.height - 0.33, size.depth * 0.43),
        ctx.material, 1.0, Vector3(0.0, 0.33 + (size.height - 0.33) * 0.5, 0.0))
end

--- 油桶：桶身 + 三道箍 + 顶盖。
---@param parent Node
---@param ctx M1PropContext
local function BuildBarrel(parent, ctx)
    local size = ctx.size
    local dia, height = size.width, size.height
    Part(parent, ctx, "body", "cylinder", Vector3(dia, height - 0.06, dia), ctx.material, 1.0,
        Vector3(0.0, (height - 0.06) * 0.5, 0.0))
    for _, ratio in ipairs({ 0.3, 0.5, 0.7 }) do
        Part(parent, ctx, "rib", "cylinder", Vector3(dia + 0.02, 0.04, dia + 0.02), "steel_galv", 1.0,
            Vector3(0.0, height * ratio, 0.0))
    end
    Part(parent, ctx, "lid", "cylinder", Vector3(dia - 0.02, 0.04, dia - 0.02), "steel_galv", 1.0,
        Vector3(0.0, height - 0.02, 0.0))
end

--- 托盘堆：8 层托盘（原作 pallet_stack 1.15 米高）。
---@param parent Node
---@param ctx M1PropContext
local function BuildPalletStack(parent, ctx)
    local size = ctx.size
    local layers = 8
    local slab = size.height / layers
    for index = 1, layers do
        Part(parent, ctx, "pallet", "box", Vector3(size.width, slab, size.depth), ctx.material, 0.5,
            Vector3(0.0, slab * (index - 0.5), 0.0))
    end
end

--- 木箱：箱体 + 四角护条 + 顶板。
---@param parent Node
---@param ctx M1PropContext
local function BuildCrateWood(parent, ctx)
    local size = ctx.size
    local height = math.min(size.height, 0.9)
    Part(parent, ctx, "body", "box", Vector3(size.width, height, size.depth), ctx.material, 0.5,
        Vector3(0.0, height * 0.5, 0.0))
    for _, sx in ipairs({ -1.0, 1.0 }) do
        for _, sz in ipairs({ -1.0, 1.0 }) do
            Part(parent, ctx, "brace", "box", Vector3(0.06, height, 0.06), ctx.material, 0.5,
                Vector3(sx * (size.width * 0.5 - 0.03), height * 0.5,
                    sz * (size.depth * 0.5 - 0.03)))
        end
    end
    Part(parent, ctx, "lid", "box", Vector3(size.width, 0.1, size.depth), ctx.material, 0.5,
        Vector3(0.0, height + 0.05, 0.0))
end

--- 木箱两件套：下箱 + 上箱（原作 crate_stack 1.9 米高）。
---@param parent Node
---@param ctx M1PropContext
local function BuildCrateStack(parent, ctx)
    local size = ctx.size
    local lower = 0.95
    Part(parent, ctx, "crate_low", "box", Vector3(size.width, lower, size.depth), ctx.material, 0.5,
        Vector3(0.0, lower * 0.5, 0.0))
    Part(parent, ctx, "crate_high", "box", Vector3(size.width, lower, size.depth), ctx.material, 0.5,
        Vector3(0.0, lower * 1.5, 0.0))
end

--- IBC 吨桶：托盘底 + 内胆 + 四根护笼立柱 + 顶框。
---@param parent Node
---@param ctx M1PropContext
local function BuildIbcTote(parent, ctx)
    local size = ctx.size
    Part(parent, ctx, "pallet", "box", Vector3(size.width, 0.14, size.depth), "wood_pallet", 0.5,
        Vector3(0.0, 0.07, 0.0))
    Part(parent, ctx, "tank", "box", Vector3(size.width * 0.9, size.height - 0.3, size.depth * 0.9),
        ctx.material, 1.0, Vector3(0.0, 0.14 + (size.height - 0.3) * 0.5, 0.0))
    for _, sx in ipairs({ -1.0, 1.0 }) do
        for _, sz in ipairs({ -1.0, 1.0 }) do
            Part(parent, ctx, "cagepost", "box", Vector3(0.05, size.height - 0.14, 0.05), "steel_galv", 1.0,
                Vector3(sx * (size.width * 0.5 - 0.025), 0.14 + (size.height - 0.14) * 0.5,
                    sz * (size.depth * 0.5 - 0.025)))
        end
    end
    Part(parent, ctx, "topframe", "box", Vector3(size.width, 0.05, size.depth), "steel_galv", 1.0,
        Vector3(0.0, size.height - 0.025, 0.0))
end

--- 轮胎堆：5 只平叠。
---@param parent Node
---@param ctx M1PropContext
local function BuildTireStack(parent, ctx)
    local size = ctx.size
    local layers = 5
    local slab = size.height / layers
    for index = 1, layers do
        Part(parent, ctx, "tire", "cylinder", Vector3(size.width, slab, size.depth), ctx.material, 0.5,
            Vector3(0.0, slab * (index - 0.5), 0.0))
    end
end

--- 灯杆：基座 + 杆身 + 警示环 + 两个灯头。
---@param parent Node
---@param ctx M1PropContext
local function BuildLightMast(parent, ctx)
    local size = ctx.size
    local height = size.height
    Part(parent, ctx, "base", "box", Vector3(size.width, 0.6, size.depth), "concrete", 1.0,
        Vector3(0.0, 0.3, 0.0))
    Part(parent, ctx, "pole", "cylinder", Vector3(size.width * 0.8, height - 0.6, size.depth * 0.8),
        "steel_galv", 1.0, Vector3(0.0, 0.6 + (height - 0.6) * 0.5, 0.0))
    Part(parent, ctx, "band", "cylinder", Vector3(size.width * 0.86, 1.2, size.depth * 0.86),
        "paint_yellow", 1.0, Vector3(0.0, 1.2, 0.0))
    for _, sx in ipairs({ -1.0, 1.0 }) do
        Part(parent, ctx, "lamp", "box", Vector3(0.6, 0.2, 0.4), "steel_galv", 1.0,
            Vector3(sx * 0.6, height - 0.3, 0.0))
    end
end

--- 垃圾箱：箱体 + 桶盖 + 四轮。
---@param parent Node
---@param ctx M1PropContext
local function BuildDumpster(parent, ctx)
    local size = ctx.size
    local width, depth = size.width, size.depth
    Part(parent, ctx, "body", "box", Vector3(width, 1.05, depth), ctx.material, 1.0,
        Vector3(0.0, 0.625, 0.0))
    Part(parent, ctx, "lid", "box", Vector3(width, 0.12, depth + 0.05), "steel_galv", 1.0,
        Vector3(0.0, 1.21, 0.0))
    for _, sx in ipairs({ -1.0, 1.0 }) do
        for _, sz in ipairs({ -1.0, 1.0 }) do
            Part(parent, ctx, "wheel", "cylinder", Vector3(0.24, 0.1, 0.24), "rubber", 0.5,
                Vector3(sx * (width * 0.5 - 0.2), 0.12, sz * (depth * 0.5 - 0.2)), nil, 90.0)
        end
    end
end

--- 发电机：机身 + 机罩 + 排气管。
---@param parent Node
---@param ctx M1PropContext
local function BuildGenerator(parent, ctx)
    local size = ctx.size
    Part(parent, ctx, "body", "box", Vector3(size.width, 0.9, size.depth), ctx.material, 1.0,
        Vector3(0.0, 0.45, 0.0))
    Part(parent, ctx, "canopy", "box", Vector3(size.width, 0.5, size.depth), "steel_galv", 1.0,
        Vector3(0.0, 1.15, 0.0))
    Part(parent, ctx, "exhaust", "cylinder", Vector3(0.08, 0.3, 0.08), "steel_galv", 1.0,
        Vector3(size.width * 0.35, 1.5, 0.0))
end

--- 苫布货堆：货体 + 顶部隆起 + 两道捆绳。
---@param parent Node
---@param ctx M1PropContext
local function BuildTarpCargo(parent, ctx)
    local size = ctx.size
    Part(parent, ctx, "body", "box", Vector3(size.width, 1.0, size.depth), ctx.material, 1.0,
        Vector3(0.0, 0.5, 0.0))
    Part(parent, ctx, "mound", "box", Vector3(size.width * 0.82, 0.5, size.depth * 0.8), ctx.material, 1.0,
        Vector3(0.0, 1.25, 0.0))
    for _, offset in ipairs({ -0.6, 0.6 }) do
        Part(parent, ctx, "rope", "box", Vector3(0.05, 1.02, size.depth * 1.02), "wood_dark", 0.5,
            Vector3(offset, 0.5, 0.0))
    end
end

--- 管堆：三根横放钢管（圆柱绕 Z 轴转 90 度）。
---@param parent Node
---@param ctx M1PropContext
local function BuildPipeStack(parent, ctx)
    local size = ctx.size
    for _, offset in ipairs({ -0.3, 0.0, 0.3 }) do
        Part(parent, ctx, "pipe", "cylinder", Vector3(0.3, size.width, 0.3), ctx.material, 1.0,
            Vector3(0.0, 0.15, offset), nil, 90.0)
    end
end

--- 沙袋墙：下三上一。
---@param parent Node
---@param ctx M1PropContext
local function BuildSandbags(parent, ctx)
    local size = ctx.size
    local bagW = size.width / 3.0
    local bagH = size.height * 0.34
    for _, offset in ipairs({ -bagW, 0.0, bagW }) do
        Part(parent, ctx, "bag_low", "box", Vector3(bagW * 0.96, bagH, size.depth), ctx.material, 0.5,
            Vector3(offset, bagH * 0.5, 0.0))
    end
    for _, offset in ipairs({ -bagW * 0.5, bagW * 0.5 }) do
        Part(parent, ctx, "bag_high", "box", Vector3(bagW * 0.96, bagH, size.depth), ctx.material, 0.5,
            Vector3(offset, bagH * 1.5, 0.0))
    end
end

--- 锥桶：底座 + 锥体。
---@param parent Node
---@param ctx M1PropContext
local function BuildTrafficCone(parent, ctx)
    local size = ctx.size
    Part(parent, ctx, "base", "box", Vector3(size.width, 0.04, size.depth), ctx.material, 0.5,
        Vector3(0.0, 0.02, 0.0))
    Part(parent, ctx, "cone", "cone", Vector3(size.width, size.height, size.depth), ctx.material, 0.5,
        Vector3(0.0, 0.02 + size.height * 0.5, 0.0))
end

--- 纸箱堆：三只叠放，逐层缩小并转向。
---@param parent Node
---@param ctx M1PropContext
local function BuildCardboardBoxes(parent, ctx)
    local size = ctx.size
    Part(parent, ctx, "box_low", "box", Vector3(size.width, 0.4, size.depth), ctx.material, 0.5,
        Vector3(0.0, 0.2, 0.0))
    Part(parent, ctx, "box_mid", "box", Vector3(size.width * 0.8, 0.4, size.depth * 0.85), ctx.material, 0.5,
        Vector3(0.0, 0.6, 0.0), 8.0)
    Part(parent, ctx, "box_high", "box", Vector3(size.width * 0.6, 0.35, size.depth * 0.6), ctx.material, 0.5,
        Vector3(0.0, 0.85, 0.0), -6.0)
end

--- 电缆盘：两侧盘片 + 中间卷筒（横置）。
---@param parent Node
---@param ctx M1PropContext
local function BuildCableReel(parent, ctx)
    local size = ctx.size
    for _, sx in ipairs({ -1.0, 1.0 }) do
        Part(parent, ctx, "disc", "cylinder", Vector3(size.height, 0.08, size.height), ctx.material, 0.5,
            Vector3(sx * (size.depth * 0.5 - 0.04), size.height * 0.5, 0.0), nil, 90.0)
    end
    Part(parent, ctx, "drum", "cylinder", Vector3(size.height * 0.5, size.depth - 0.16, size.height * 0.5),
        "wood_pallet", 0.5, Vector3(0.0, size.height * 0.5, 0.0), nil, 90.0)
end

--- 油壶：壶体 + 壶盖。
---@param parent Node
---@param ctx M1PropContext
local function BuildJerryCan(parent, ctx)
    local size = ctx.size
    Part(parent, ctx, "body", "box", Vector3(size.width, size.height - 0.07, size.depth), ctx.material, 0.5,
        Vector3(0.0, (size.height - 0.07) * 0.5, 0.0))
    Part(parent, ctx, "cap", "box", Vector3(0.08, 0.07, 0.08), "steel_galv", 1.0,
        Vector3(size.width * 0.25, size.height - 0.035, 0.0))
end

--- 气瓶组：三只竖放钢瓶。
---@param parent Node
---@param ctx M1PropContext
local function BuildGasCylinders(parent, ctx)
    local size = ctx.size
    for _, offset in ipairs({ -0.3, 0.0, 0.3 }) do
        Part(parent, ctx, "cylinder", "cylinder", Vector3(0.25, size.height, 0.25), ctx.material, 1.0,
            Vector3(offset, size.height * 0.5, 0.0))
    end
end

--- 岗亭：亭身 + 顶板 + 门框（原作 R3 有玻璃与内景，这里按差异表简化）。
---@param parent Node
---@param ctx M1PropContext
local function BuildGuardBooth(parent, ctx)
    local size = ctx.size
    local width, depth = size.width, size.depth
    Part(parent, ctx, "body", "box", Vector3(width, size.height - 0.3, depth), ctx.material, 1.0,
        Vector3(0.0, (size.height - 0.3) * 0.5, 0.0))
    Part(parent, ctx, "roof", "box", Vector3(width + 0.2, 0.3, depth + 0.2), "steel_galv", 1.0,
        Vector3(0.0, size.height - 0.15, 0.0))
    Part(parent, ctx, "door", "box", Vector3(0.9, 1.9, 0.06), "paint_grey", 1.0,
        Vector3(0.0, 0.95, depth * 0.5 + 0.03))
end

--- 道杆：四段黄白相间的横杆 + 转轴座。
---@param parent Node
---@param ctx M1PropContext
local function BuildGateArm(parent, ctx)
    local size = ctx.size
    local bar = size.width - 0.4
    local segment = bar / 4.0
    for index = 1, 4 do
        local color = index % 2 == 1 and "paint_yellow" or "paint_white"
        Part(parent, ctx, "bar", "box", Vector3(segment, 0.12, 0.12), color, 1.0,
            Vector3(-size.width * 0.5 + 0.2 + segment * (index - 0.5), 1.0, 0.0))
    end
    Part(parent, ctx, "pivot", "box", Vector3(0.2, 1.1, 0.3), "steel_galv", 1.0,
        Vector3(-size.width * 0.5 + 0.1, 0.55, 0.0))
end

--- 门柱：方柱 + 底部警示带。
---@param parent Node
---@param ctx M1PropContext
local function BuildGatePost(parent, ctx)
    local size = ctx.size
    Part(parent, ctx, "post", "box", Vector3(size.width, size.height, size.depth), ctx.material, 1.0,
        Vector3(0.0, size.height * 0.5, 0.0))
    Part(parent, ctx, "band", "box", Vector3(size.width + 0.04, 1.2, size.depth + 0.04), "paint_yellow", 1.0,
        Vector3(0.0, 0.6, 0.0))
end

--- 系船柱：柱身 + 顶帽。
---@param parent Node
---@param ctx M1PropContext
local function BuildBollardPost(parent, ctx)
    local size = ctx.size
    Part(parent, ctx, "post", "cylinder", Vector3(size.width, size.height, size.depth), ctx.material, 1.0,
        Vector3(0.0, size.height * 0.5, 0.0))
    Part(parent, ctx, "cap", "cylinder", Vector3(size.width * 1.1, 0.08, size.depth * 1.1), "steel_galv", 1.0,
        Vector3(0.0, size.height, 0.0))
end

--- 货架：四立柱 + 三层横板（原作 shelf_rack，斜撑略）。
---@param parent Node
---@param ctx M1PropContext
local function BuildShelfRack(parent, ctx)
    local size = ctx.size
    local post = 0.08
    for _, sx in ipairs({ -1.0, 1.0 }) do
        for _, sz in ipairs({ -1.0, 1.0 }) do
            Part(parent, ctx, "post", "box", Vector3(post, size.height, post), ctx.material, 1.0,
                Vector3(sx * (size.width * 0.5 - post * 0.5), size.height * 0.5,
                    sz * (size.depth * 0.5 - post * 0.5)))
        end
    end
    for _, ratio in ipairs({ 0.05, 0.5, 0.95 }) do
        Part(parent, ctx, "shelf", "box", Vector3(size.width, 0.06, size.depth), "steel_galv", 1.0,
            Vector3(0.0, size.height * ratio, 0.0))
    end
end

--- 中继柜：柜体 + 顶盖 + 底座 + 指示灯。
---@param parent Node
---@param ctx M1PropContext
local function BuildRelayNode(parent, ctx)
    local size = ctx.size
    Part(parent, ctx, "base", "box", Vector3(size.width + 0.1, 0.2, size.depth + 0.1), "concrete", 1.0,
        Vector3(0.0, 0.1, 0.0))
    Part(parent, ctx, "body", "box", Vector3(size.width, size.height - 0.4, size.depth), ctx.material, 1.0,
        Vector3(0.0, 0.2 + (size.height - 0.4) * 0.5, 0.0))
    Part(parent, ctx, "cap", "box", Vector3(size.width + 0.12, 0.2, size.depth + 0.12), "steel_galv", 1.0,
        Vector3(0.0, size.height - 0.1, 0.0))
    Part(parent, ctx, "lamp", "box", Vector3(0.14, 0.14, 0.06), "paint_green", 1.0,
        Vector3(0.0, size.height - 0.5, size.depth * 0.5 + 0.03))
end

--- 围栏片：两立柱 + 上下横梁 + 网面。
---@param parent Node
---@param ctx M1PropContext
local function BuildFencePanel(parent, ctx)
    local size = ctx.size
    for _, sx in ipairs({ -1.0, 1.0 }) do
        Part(parent, ctx, "post", "box", Vector3(0.06, size.height, 0.06), "steel_galv", 1.0,
            Vector3(sx * (size.width * 0.5 - 0.03), size.height * 0.5, 0.0))
    end
    for _, ratio in ipairs({ 0.12, 0.92 }) do
        Part(parent, ctx, "rail", "box", Vector3(size.width, 0.05, 0.05), "steel_galv", 1.0,
            Vector3(0.0, size.height * ratio, 0.0))
    end
    Part(parent, ctx, "mesh", "box", Vector3(size.width - 0.1, size.height * 0.8, size.depth), ctx.material, 1.0,
        Vector3(0.0, size.height * 0.52, 0.0))
end

--- 招牌：立柱 + 白色牌面（无文字贴图，差异第 15 条）。
---@param parent Node
---@param ctx M1PropContext
local function BuildSignPost(parent, ctx)
    local size = ctx.size
    Part(parent, ctx, "post", "cylinder", Vector3(0.07, size.height, 0.07), "steel_galv", 1.0,
        Vector3(0.0, size.height * 0.5, 0.0))
    Part(parent, ctx, "board", "box", Vector3(size.width, 0.5, size.depth), ctx.material, 1.0,
        Vector3(0.0, size.height - 0.45, 0.0))
end

--- 岸桥：四条腿 + 两道横梁 + 悬臂 + 小车。
---@param parent Node
---@param ctx M1PropContext
local function BuildGantryCrane(parent, ctx)
    local size = ctx.size
    local leg = 0.8
    for _, sx in ipairs({ -1.0, 1.0 }) do
        for _, sz in ipairs({ -1.0, 1.0 }) do
            Part(parent, ctx, "leg", "box", Vector3(leg, size.height, leg), ctx.material, 1.0,
                Vector3(sx * (size.width * 0.5 - leg * 0.5), size.height * 0.5,
                    sz * (size.depth * 0.5 - leg * 0.5)))
        end
    end
    for _, sz in ipairs({ -1.0, 1.0 }) do
        Part(parent, ctx, "beam", "box", Vector3(size.width, 1.2, 1.2), "steel_galv", 1.0,
            Vector3(0.0, size.height * 0.55, sz * (size.depth * 0.5 - leg * 0.5)))
    end
    Part(parent, ctx, "boom", "box", Vector3(18.0, 1.0, 1.4), "steel_galv", 1.0,
        Vector3(size.width * 0.5 + 9.0, size.height - 1.0, 0.0))
    Part(parent, ctx, "trolley", "box", Vector3(2.0, 1.6, 2.2), "paint_yellow", 1.0,
        Vector3(size.width * 0.5 + 6.0, size.height - 2.4, 0.0))
end

--- 货轮：船体 + 甲板 + 上层建筑 + 烟囱。
---@param parent Node
---@param ctx M1PropContext
local function BuildCargoShip(parent, ctx)
    local size = ctx.size
    Part(parent, ctx, "hull", "box", Vector3(size.width, size.height * 0.4, size.depth), ctx.material, 2.0,
        Vector3(0.0, size.height * 0.2, 0.0))
    Part(parent, ctx, "deck", "box", Vector3(size.width * 0.94, 0.4, size.depth * 0.9), "steel_galv", 1.0,
        Vector3(0.0, size.height * 0.42, 0.0))
    Part(parent, ctx, "house", "box", Vector3(10.0, 8.0, size.depth * 0.7), "paint_white", 1.0,
        Vector3(-size.width * 0.35, size.height * 0.42 + 4.0, 0.0))
    Part(parent, ctx, "funnel", "box", Vector3(3.0, 4.0, 3.0), "paint_red", 1.0,
        Vector3(-size.width * 0.35, size.height * 0.42 + 10.0, 0.0))
end

---@type table<string, fun(parent: Node, ctx: M1PropContext)>
local BUILDERS = {
    container20 = BuildContainer,
    container40 = BuildContainer,
    container40hc = BuildContainer,
    jersey_barrier = BuildJerseyBarrier,
    barrel = BuildBarrel,
    pallet_stack = BuildPalletStack,
    crate_wood = BuildCrateWood,
    crate_stack = BuildCrateStack,
    ibc_tote = BuildIbcTote,
    tire_stack = BuildTireStack,
    light_mast = BuildLightMast,
    dumpster = BuildDumpster,
    generator = BuildGenerator,
    tarp_cargo = BuildTarpCargo,
    pipe_stack = BuildPipeStack,
    sandbags = BuildSandbags,
    traffic_cone = BuildTrafficCone,
    cardboard_boxes = BuildCardboardBoxes,
    cable_reel = BuildCableReel,
    jerry_can = BuildJerryCan,
    gas_cylinders = BuildGasCylinders,
    guard_booth = BuildGuardBooth,
    gate_arm = BuildGateArm,
    gate_post = BuildGatePost,
    bollard_post = BuildBollardPost,
    shelf_rack = BuildShelfRack,
    relay_node = BuildRelayNode,
    fence_panel = BuildFencePanel,
    sign_post = BuildSignPost,
    gantry_crane = BuildGantryCrane,
    cargo_ship = BuildCargoShip,
}

---@class M1PropBuild
---@field nodes Node[]
---@field counts table<string, integer>
---@field zones table<string, integer>
---@field placed integer
---@field builders integer
---@field first Vector3
---@field last Vector3

--- 判定摆放点落在哪个区域；不落在任何区域直接报错（第 28 节）。
---@param regions M1LevelRegion[]
---@param x number
---@param z number
---@return string
local function ZoneOf(regions, x, z)
    for index = 1, #regions do
        local region = regions[index]
        local rect = region.rect
        if x >= rect.minX and x <= rect.maxX and z >= rect.minZ and z <= rect.maxZ then
            return region.name
        end
    end
    error(string.format("Props placement (%.1f, %.1f) is outside every level region", x, z))
end

--- 按摆放表建全部道具。
---@param scene Scene
---@param materials table Art/Materials 模块（Get）。
---@param data M1PropsData
---@param regions M1LevelRegion[]
---@return M1PropBuild
function Props.Create(scene, materials, data, regions)
    assert(scene ~= nil, "Props requires a scene")
    assert(materials ~= nil and type(materials.Get) == "function", "Props requires the Materials module")
    assert(data ~= nil and type(data.placements) == "table", "Props requires placement data")
    assert(regions ~= nil and #regions > 0, "Props requires level regions")

    ---@type Node[]
    local nodes = {}
    ---@type table<string, integer>
    local counts = {}
    ---@type table<string, integer>
    local zones = {}

    for index = 1, #data.placements do
        local placement = data.placements[index]
        local size = data.sizes[placement.name]
        assert(size ~= nil, "Props data missing size for " .. tostring(placement.name))
        local builder = BUILDERS[placement.name]
        assert(builder ~= nil, "Props builder missing for " .. tostring(placement.name))

        local materialName = COLOR_MATERIAL[placement.color or ""] or size.material
        local root = scene:CreateChild(string.format("Prop_%s_%d", placement.name, index))
        local baseY = placement.y or 0.0
        root.position = Vector3(placement.x, baseY, placement.z)
        root.rotation = Quaternion(placement.rotDeg or 0.0, Vector3(0.0, 1.0, 0.0))

        ---@type M1PropContext
        local ctx = {
            size = size,
            material = materialName,
            mat = function(name, uvMeters, uvScale)
                return GetMaterial(materials, name, uvMeters, uvScale)
            end,
        }
        builder(root, ctx)

        -- 碰撞：只有可站可挡的大家具加静态盒，油桶、托盘、轮胎不加（差异表第 6 条）。
        if placement.name == "container20" or placement.name == "container40"
            or placement.name == "container40hc" or placement.name == "jersey_barrier"
            or placement.name == "guard_booth" or placement.name == "relay_node"
            or placement.name == "shelf_rack" then
            local solid = root:CreateChild("solid")
            solid.position = Vector3(0.0, size.height * 0.5, 0.0)
            local okBody, body = pcall(function() return solid:CreateComponent("RigidBody") end)
            assert(okBody and body ~= nil, "Prop solid missing RigidBody: " .. placement.name)
            ---@cast body RigidBody
            body.mass = 0.0
            body.useGravity = false
            local okShape, shape = pcall(function() return solid:CreateComponent("CollisionShape") end)
            assert(okShape and shape ~= nil, "Prop solid missing CollisionShape: " .. placement.name)
            ---@cast shape CollisionShape
            shape:SetBox(Vector3(size.width, size.height, size.depth))
        end

        local zone = placement.zone or ZoneOf(regions, placement.x, placement.z)
        counts[placement.name] = (counts[placement.name] or 0) + 1
        zones[zone] = (zones[zone] or 0) + 1
        nodes[#nodes + 1] = root
    end

    -- 空摆放表是真缺陷，必须断言（第 28 节）；LSP 认为数组元素非 nil，判为多余断言
---@diagnostic disable-next-line: unnecessary-assert
    local first = assert(data.placements[1], "Props data has no placements")
---@diagnostic disable-next-line: unnecessary-assert
    local last = assert(data.placements[#data.placements], "Props data has no placements")
    ---@type M1PropBuild
    local build = {
        nodes = nodes,
        counts = counts,
        zones = zones,
        placed = #nodes,
        builders = Props.BuilderCount(),
        first = Vector3(first.x, first.y or 0.0, first.z),
        last = Vector3(last.x, last.y or 0.0, last.z),
    }
    return build
end

---@return integer
function Props.BuilderCount()
    local count = 0
    for _ in pairs(BUILDERS) do
        count = count + 1
    end
    return count
end

return Props
