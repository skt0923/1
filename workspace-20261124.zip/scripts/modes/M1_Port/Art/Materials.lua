-- 材质查表：把 TextureBaker 预设名转成共享材质实例（e8：只接受参数，不含玩法数值）。
-- 来源：docs/source/3a/parts/05-material.part.js 语句 1（Tn 材质名表 / Gg 材质工厂）。
-- 差异：原作按 seed 生成独立 GLSL 材质；这里用 TextureBaker 烘焙 PBR，名字与原作逐字一致。
-- 用本玩法目录下的副本：1.35 不认 compute shader 的 render_mode flow_control_prefer，副本已去该行
local TextureBaker = require("modes.M1_Port.kit.TextureBaker")
-- 材质预设只给出 set 名（如 concrete_painted -> concrete），Bake 只认纹理集名
local Presets = require("modes.M1_Port.kit.TextureBaker.Presets")

---@class SceneMaterials
local Materials = {}

---@class MaterialOptions : KitTextureBakerMaterialOptions
---@field uvMeters? number|Vector2 Metres per UV unit; default 1.

---@type table<string, Material>
local cache = {}

---@param name string
---@return boolean
function Materials.Has(name)
    local names = TextureBaker.GetMaterialNames()
    for index = 1, #names do
        if names[index] == name then
            return true
        end
    end
    return false
end

--- 取材质；名字不存在直接报错并列出可选名，不静默回退。
---@param name string
---@param options? MaterialOptions
---@return Material
function Materials.Get(name, options)
    assert(type(name) == "string" and name ~= "", "Materials.Get needs a material name")
    options = options or {}
    local key = name
    if next(options) ~= nil then
        -- uvScale 决定每个面平铺几次，必须进缓存键，否则不同尺寸的零件会串用同一份材质。
        local scaleX, scaleY = 1.0, 1.0
        local uvScale = options.uvScale
        if uvScale ~= nil then
            if type(uvScale) == "number" then
                scaleX, scaleY = uvScale, uvScale
            else
                scaleX, scaleY = uvScale.x, uvScale.y
            end
        end
        local uvX, uvY = 1.0, 1.0
        local uvMeters = options.uvMeters
        if uvMeters ~= nil then
            if type(uvMeters) == "number" then
                uvX, uvY = uvMeters, uvMeters
            else
                uvX, uvY = uvMeters.x, uvMeters.y
            end
        end
        key = string.format("%s|%.4f|%.4f|%.4f|%.4f|%s|%s|%s",
            name, uvX, uvY, scaleX, scaleY,
            options.color and options.color:ToUInt() or "",
            tostring(options.vertexColor),
            options.macro == false and "nomacro" or "")
    end
    local cached = cache[key]
    if cached ~= nil then
        return cached
    end

    if not Materials.Has(name) then
        local names = TextureBaker.GetMaterialNames()
        error(string.format("[MAT][ERROR] unknown material '%s'; available: %s",
            name, table.concat(names, ", ")))
    end

    local ok, material = pcall(TextureBaker.CreateMaterial, name, options)
    if not ok then
        error(string.format("[MAT][ERROR] TextureBaker failed for '%s': %s", name, tostring(material)))
    end
    assert(material ~= nil, string.format("[MAT][ERROR] TextureBaker returned nil for '%s'", name))

    cache[key] = material
    -- 第 20 节第 3 条：烘焙不可用时贴图退成 1x1 均值，必须记 NONE 并写明原因。
    -- 同一 set 已由上面的 CreateMaterial 入队，Bake 走缓存，不重复烘焙。
    local preset = Presets.materials[name]
    local setName = preset and preset.set or nil
    local baked, reason = true, nil
    if setName ~= nil then
        local probeOk, probe, probeErr = pcall(TextureBaker.Bake, setName)
        if not probeOk then
            baked, reason = false, "probe-error:" .. tostring(probe)
        elseif probe == nil then
            baked, reason = false, tostring(probeErr)
        end
    end
    if baked then
        print(string.format("[MAT][GET] -> OK | name=%s set=%s vertexColor=%s uvMeters=%s baked=true",
            name, tostring(setName or "none"), tostring(options.vertexColor == true), tostring(options.uvMeters or 1)))
    else
        print(string.format("[MAT][GET] -> NONE | name=%s set=%s baked=false reason=%s",
            name, tostring(setName), tostring(reason)))
    end
    return material
end

return Materials