-- modes/M1_Port/Art/ImpactBursts.lua: 命中碎屑与火花（原作 12-effects 的受光/加色粒子池子集）。
-- 用固定容量的 StaticModel 池自己积分：1.35 的 ParticleEffect 没有 Reset，突发一次不好控制，这里直接算位移与重力。
-- 数量、速度、颜色来自 Data/ImpactFx.lua 的 surfaces 表（原作按表面分派）。
local TAG = "[M1][BURST]"

local LOG_EVERY = 10

---@class M1BurstParticle
---@field node Node
---@field model StaticModel
---@field vx number
---@field vy number
---@field vz number
---@field ttl number

---@class M1ImpactBursts
---@field data M1ImpactFxData
---@field debris M1BurstParticle[]
---@field sparks M1BurstParticle[]
---@field debrisNext integer
---@field sparkNext integer
---@field fired integer
---@field lastSurface string
---@field debrisLive integer
---@field sparksLive integer
local Bursts = {}
Bursts.__index = Bursts

---@param scene Scene
---@param data M1ImpactFxData
---@param model Model
---@param technique Technique
---@param scale number
---@param color [integer, integer, integer]
---@param prefix string
---@param count integer
---@return M1BurstParticle[]
local function BuildPool(scene, data, model, technique, scale, color, prefix, count)
    ---@type M1BurstParticle[]
    local pool = {}
    for index = 1, count do
        local node = scene:CreateChild(string.format("%s_%d", prefix, index))
        ---@diagnostic disable-next-line: unnecessary-assert
        local staticModel = assert(node:CreateComponent("StaticModel"), prefix .. " node missing StaticModel")
        local material = Material:new()
        material:SetTechnique(0, technique)
        material:SetShaderParameter("MatDiffColor", Variant(Color(color[1] / 255.0, color[2] / 255.0,
            color[3] / 255.0, 1.0)))
        staticModel:SetModel(model)
        staticModel:SetMaterial(material)
        staticModel.castShadows = false
        node.scale = Vector3(scale, scale, scale)
        node:SetEnabled(false)
        pool[index] = { node = node, model = staticModel, vx = 0.0, vy = 0.0, vz = 0.0, ttl = 0.0 }
    end
    assert(#pool == count, "ImpactBursts pool size mismatch: " .. prefix)
    assert(data.gravity > 0.0, "ImpactBursts requires gravity")
    return pool
end

---@param scene Scene
---@param data M1ImpactFxData
---@return M1ImpactBursts
function Bursts.Create(scene, data)
    assert(scene ~= nil, "ImpactBursts requires a scene")
    assert(data ~= nil and data.debrisCap > 0 and data.sparkCap > 0, "ImpactBursts requires pool sizes")
    local okModel, model = pcall(function() return cache:GetResource("Model", "Models/Box.mdl") end)
    assert(okModel and model ~= nil, "Missing model: Models/Box.mdl")
    ---@cast model Model
    local okTechnique, technique = pcall(function()
        return cache:GetResource("Technique", "Techniques/NoTextureUnlit.xml")
    end)
    assert(okTechnique and technique ~= nil, "Missing technique: Techniques/NoTextureUnlit.xml")
    ---@cast technique Technique

    local self = setmetatable({
        data = data,
        debris = BuildPool(scene, data, model, technique, data.debrisScale, data.sparkColor, "Debris",
            data.debrisCap),
        sparks = BuildPool(scene, data, model, technique, data.sparkScale, data.sparkColor, "Spark",
            data.sparkCap),
        debrisNext = 1,
        sparkNext = 1,
        fired = 0,
        lastSurface = "none",
        debrisLive = 0,
        sparksLive = 0,
    }, Bursts)
    print(string.format("%s[CREATE] -> OK | debris=%d sparks=%d", TAG, data.debrisCap, data.sparkCap))
    return self
end

---@param pool M1BurstParticle[]
---@param cursor integer
---@param count integer
---@param point Vector3
---@param normal Vector3
---@param speed number
---@return integer nextCursor
function Bursts:Scatter(pool, cursor, count, point, normal, speed)
    local size = #pool
    for index = 0, count - 1 do
        local slot = pool[(cursor - 1 + index) % size + 1] --[[@as M1BurstParticle]]
        -- 沿法线半球散射：法线 + 随机切向
        local tx = math.random() * 2.0 - 1.0
        local ty = math.random() * 2.0 - 1.0
        local tz = math.random() * 2.0 - 1.0
        local jitter = 0.75
        local vx = normal.x + tx * jitter
        local vy = normal.y + ty * jitter
        local vz = normal.z + tz * jitter
        local length = math.sqrt(vx * vx + vy * vy + vz * vz)
        if length < 0.0001 then length = 1.0 end
        local boost = speed * (0.6 + math.random() * 0.8)
        slot.vx = vx / length * boost
        slot.vy = vy / length * boost
        slot.vz = vz / length * boost
        slot.ttl = 0.0
        slot.node.position = point + normal * 0.01
        slot.node:SetEnabled(true)
    end
    return (cursor - 1 + count) % size + 1
end

--- 一次命中：按表面分派碎屑与火花（原作 case 分派）。
---@param point Vector3
---@param normal Vector3
---@param surface string
function Bursts:Spawn(point, normal, surface)
    local data = self.data
    local surfaceData = data.surfaces[surface] or data.surfaces[data.defaultSurface]
    assert(surfaceData ~= nil, "ImpactBursts: no surface data for " .. tostring(surface))
    if surfaceData.debris > 0 then
        self.debrisNext = self:Scatter(self.debris, self.debrisNext, surfaceData.debris, point, normal,
            surfaceData.speed)
    end
    if surfaceData.sparks > 0 then
        self.sparkNext = self:Scatter(self.sparks, self.sparkNext, surfaceData.sparks, point, normal,
            surfaceData.speed * 1.6)
    end
    self.fired = self.fired + 1
    self.lastSurface = surface
    if self.fired == 1 or self.fired % LOG_EVERY == 0 then
        print(string.format("%s[SPAWN] -> OK | n=%d surface=%s debris=%d sparks=%d at=(%.2f,%.2f,%.2f)",
            TAG, self.fired, surface, surfaceData.debris, surfaceData.sparks, point.x, point.y, point.z))
    end
end

---@param pool M1BurstParticle[]
---@param dt number
---@param ttl number
---@return integer live
function Bursts:Step(pool, dt, ttl)
    local gravity = self.data.gravity
    local live = 0
    for index = 1, #pool do
        local slot = pool[index] --[[@as M1BurstParticle]]
        if slot.ttl >= 0.0 and slot.node.enabled then
            slot.ttl = slot.ttl + dt
            if slot.ttl >= ttl then
                slot.node:SetEnabled(false)
            else
                live = live + 1
                slot.vy = slot.vy - gravity * dt
                local position = slot.node.position
                slot.node.position = Vector3(position.x + slot.vx * dt, position.y + slot.vy * dt,
                    position.z + slot.vz * dt)
            end
        end
    end
    return live
end

---@param dt number
function Bursts:Update(dt)
    self.debrisLive = self:Step(self.debris, dt, self.data.debrisTtl)
    self.sparksLive = self:Step(self.sparks, dt, self.data.sparkTtl)
end

---@return string
function Bursts:Probe()
    local text = string.format("%s[PROBE] -> OK | fired=%d debrisLive=%d/%d sparksLive=%d/%d last=%s",
        TAG, self.fired, self.debrisLive or 0, #self.debris, self.sparksLive or 0, #self.sparks,
        self.lastSurface)
    print(text)
    return text
end

function Bursts:Destroy()
    self.debris = {}
    self.sparks = {}
    print(string.format("%s -> OK | event=destroy fired=%d", TAG, self.fired))
end

return Bursts