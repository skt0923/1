-- 几何拼装入口：盒/倒角盒/圆柱/管缆，UV 统一按米（e8：只接受参数，不含玩法数值）。
-- 来源：docs/source/3a/parts/01-geometry.part.js 语句 1 $e、2 Wi、3 ot、4 Fn、8 Lc；
-- 差异见 docs/玩法/M1_Port/任务-m1-p1a-foundation.md（倒角为平倒角、管缆无 tension）。
---@class SceneGeometry
local Geometry = {}

local EPSILON = 1e-6

---@param value number|Vector2|nil
---@param fallback number
---@return Vector2
local function ToVector2(value, fallback)
    if value == nil then
        return Vector2(fallback, fallback)
    elseif type(value) == "number" then
        return Vector2(value, value)
    end
    return Vector2(value.x, value.y)
end

---@class GeometryBoxOptions
---@field uvMeters? number|Vector2 Metres per UV unit; default 1.
---@field bevel? number Chamfer width; 0 or absent for a sharp box.
---@field bottom? boolean Move the box so its bottom face sits on y = 0.

--- 按米 UV 的盒体；bevel > 0 时用平倒角盒（原作 01 语句 2 的圆弧倒角在此为平倒角）。
---@param width number
---@param height number
---@param depth number
---@param options? GeometryBoxOptions
---@return ProceduralGeometry|nil Returns nil when the engine lacks the procedural geometry API (1.35).
function Geometry.Box(width, height, depth, options)
    assert(width > EPSILON and height > EPSILON and depth > EPSILON,
        string.format("Geometry.Box needs positive size, got %.3f x %.3f x %.3f", width, height, depth))
    options = options or {}
    local geo
-- 1.35 缺 ChamferBoxGeometry / BoxGeometry 时返回 nil，由调用方降级到内置模型
    if options.bevel ~= nil and options.bevel > EPSILON and type(ChamferBoxGeometry) == "function" then
        geo = ChamferBoxGeometry(width, height, depth, options.bevel)
    elseif type(BoxGeometry) == "function" then
        geo = BoxGeometry(width, height, depth, 1, 1, 1)
    else
        print("[GEO][CREATE] -> NONE | kind=box reason=BoxGeometry unavailable")
        return nil
    end
    if geo == nil then
        print("[GEO][CREATE] -> NONE | kind=box reason=constructor returned nil")
        return nil
    end
    local uv = ToVector2(options.uvMeters, 1)
-- 1.35 的 ProceduralGeometry 没有 ScaleUVToMeters（真机 53521 日志证实），缺失时跳过并按面尺寸传 uvMeters
---@diagnostic disable-next-line: undefined-field
    if type(geo.ScaleUVToMeters) == "function" and (math.abs(uv.x - 1) > EPSILON or math.abs(uv.y - 1) > EPSILON) then
        geo:ScaleUVToMeters(uv.x)
    end
    if options.bottom then
        geo:Translate(0, height * 0.5, 0)
    end
    print(string.format("[GEO][CREATE] -> OK | kind=box size=%.2f,%.2f,%.2f uvMeters=%.2f,%.2f bevel=%.3f",
        width, height, depth, uv.x, uv.y, options.bevel or 0.0))
    return geo
end

---@class GeometryCylinderOptions
---@field segments? integer Radial segments; default 16.
---@field axis? "x"|"y"|"z" Cylinder axis; default "y".
---@field uvMeters? number Metres per UV unit; default 1.

--- 按周长展开 UV 的圆柱，轴可切换。
---@param radiusTop number
---@param radiusBottom number
---@param height number
---@param options? GeometryCylinderOptions
---@return ProceduralGeometry
function Geometry.Cylinder(radiusTop, radiusBottom, height, options)
    assert(radiusTop > EPSILON and radiusBottom > EPSILON and height > EPSILON,
        string.format("Geometry.Cylinder needs positive size, got %.3f / %.3f / %.3f",
            radiusTop, radiusBottom, height))
    options = options or {}
    local segments = options.segments or 16
    local geo = CylinderGeometry(radiusTop, radiusBottom, height, segments, 1, false)
    geo:ScaleUVToMeters(options.uvMeters or 1)
    local axis = options.axis or "y"
    if axis == "x" then
        geo:ApplyQuaternion(Quaternion(90, Vector3.RIGHT))
    elseif axis == "z" then
        geo:ApplyQuaternion(Quaternion(90, Vector3.FORWARD))
    elseif axis ~= "y" then
        error("Geometry.Cylinder: axis must be x, y or z, got " .. tostring(axis))
    end
    print(string.format("[GEO][CREATE] -> OK | kind=cylinder r=%.2f,%.2f h=%.2f seg=%d axis=%s",
        radiusTop, radiusBottom, height, segments, axis))
    return geo
end

---@class GeometryTubeOptions
---@field radialSegments? integer Ring segments; default 6.
---@field tubularSegments? integer Segments along the path; default derived from path length.
---@field uvPerMeter? number UV repeat per metre of length; default 1.

--- 折线管缆：按点表生成 Catmull-Rom 管道（原作 01 语句 4 的张力参数在此不可配）。
---@param points Vector3[]
---@param radius number
---@param options? GeometryTubeOptions
---@return ProceduralGeometry
function Geometry.Tube(points, radius, options)
    assert(type(points) == "table" and #points >= 2, "Geometry.Tube needs at least two points")
    assert(radius > EPSILON, "Geometry.Tube needs a positive radius")
    options = options or {}
    local radial = options.radialSegments or 6
    local length = 0.0
    for index = 2, #points do
        local current = points[index]
        local previous = points[index - 1]
-- Lua 表取值在类型系统里可能为 nil；上方 assert 已保证 #points >= 2
---@diagnostic disable-next-line: need-check-nil
        length = length + (current - previous):Length()
    end
    local tubular = options.tubularSegments or math.max(2, math.ceil(length * 4))
    local geo = TubeGeometry(points, tubular, radius, radial, false)
    geo:ScaleUVToMeters(options.uvPerMeter or 1)
    print(string.format("[GEO][CREATE] -> OK | kind=tube points=%d length=%.2f r=%.3f tubular=%d radial=%d",
        #points, length, radius, tubular, radial))
    return geo
end

---@class GeometryNoiseOptions
---@field seed? integer Pattern seed; default 0.
---@field base? number Factor at noise 0; default 0.8.
---@field range? number Added at noise 1; default 0.2.
---@field scale? number|Vector3 Noise frequency; default 1.

--- 顶点色噪声：在零件自身坐标里乘上 0.8±0.2 的明暗差（原作 01 语句 8 的 ±10% 磨损）。
---@param geo ProceduralGeometry
---@param options? GeometryNoiseOptions
---@return ProceduralGeometry
function Geometry.PaintNoise(geo, options)
    assert(geo ~= nil, "Geometry.PaintNoise needs a geometry")
    options = options or {}
    local params = {
        seed = options.seed or 0,
        base = options.base or 0.8,
        range = options.range or 0.2,
    }
    if options.scale ~= nil then
        params.scale = options.scale
    end
    geo:ApplyNoiseColor(params)
    return geo
end

return Geometry