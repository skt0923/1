-- 命中表现：枪口光、曳光、命中火花。
-- 对应 12-effects 语句 10 的 muzzleFlash/tracer/impact 子集，弹壳/碎屑/贴花/烟留 P4。
-- 数值来自 modes/M1_Port/Data/Effects.lua（e8）。
local EFFECT_FIRE_LOG_EVERY = 10

---@class M1Impact
---@field point Vector3
---@field normal Vector3
---@field nodeName string

---@class M1ImpactModules
---@field decals M1Decals
---@field bursts M1ImpactBursts
---@field shells M1ShellPool

---@class ShooterEffects
---@field data M1WeaponEffectsData
---@field flashNode Node
---@field flashLight Light
---@field tracerNode Node
---@field sparkNode Node
---@field flashTime number
---@field tracerTime number
---@field sparkTime number
---@field shots integer
---@field decals M1Decals|nil
---@field bursts M1ImpactBursts|nil
---@field shells M1ShellPool|nil
---@field impacts integer
---@field impactsMissingLogged boolean
local Effects = {}
Effects.__index = Effects

---@param node Node
---@param model Model
---@param technique Technique
---@param color [integer, integer, integer]
---@return StaticModel
local function AddUnlitModel(node, model, technique, color)
    local material = Material:new()
    material:SetTechnique(0, technique)
    material:SetShaderParameter("MatDiffColor", Variant(Color(color[1] / 255, color[2] / 255, color[3] / 255, 1.0)))
-- 组件加载失败需显式中断（f2）
---@diagnostic disable-next-line: unnecessary-assert
    local staticModel = assert(node:CreateComponent("StaticModel"), "Effects node missing StaticModel")
    staticModel:SetModel(model)
    staticModel:SetMaterial(material)
    staticModel.castShadows = false
    return staticModel
end

---@param scene Scene
---@param data M1WeaponEffectsData
---@return ShooterEffects
function Effects.Create(scene, data)
    assert(scene ~= nil, "Effects requires scene")
    assert(data ~= nil and data.tracerTtl ~= nil, "Effects requires effect data")

-- 资源加载失败需显式中断（f2）
---@diagnostic disable-next-line: unnecessary-assert
    local boxModel = assert(cache:GetResource("Model", "Models/Box.mdl"), "Missing model: Models/Box.mdl")
-- 资源加载失败需显式中断（f2）
---@diagnostic disable-next-line: unnecessary-assert
    local sphereModel = assert(cache:GetResource("Model", "Models/Sphere.mdl"), "Missing model: Models/Sphere.mdl")
-- 资源加载失败需显式中断（f2）
---@diagnostic disable-next-line: unnecessary-assert
    local technique = assert(cache:GetResource("Technique", "Techniques/NoTextureUnlit.xml"), "Missing technique: Techniques/NoTextureUnlit.xml")

    local flashNode = scene:CreateChild("MuzzleFlash")
    AddUnlitModel(flashNode, sphereModel, technique, data.flashMeshColor)
    flashNode.scale = Vector3(data.flashMeshScale, data.flashMeshScale, data.flashMeshScale)
-- 组件加载失败需显式中断（f2）
---@diagnostic disable-next-line: unnecessary-assert
    local flashLight = assert(flashNode:CreateComponent("Light"), "MuzzleFlash missing Light")
    flashLight.lightType = LIGHT_POINT
    flashLight.color = data.flashColor
    flashLight.brightness = data.flashBrightness
    flashLight.range = data.flashRange
    flashLight.castShadows = false
    flashNode:SetEnabled(false)

    local tracerNode = scene:CreateChild("Tracer")
    AddUnlitModel(tracerNode, boxModel, technique, data.tracerColor)
    tracerNode:SetEnabled(false)

    local sparkNode = scene:CreateChild("ImpactSpark")
    AddUnlitModel(sparkNode, sphereModel, technique, data.sparkColor)
    sparkNode.scale = Vector3(data.sparkScale, data.sparkScale, data.sparkScale)
    sparkNode:SetEnabled(false)

    print(string.format("[FX][CREATE] -> OK | flashTtl=%.2f tracerTtl=%.2f sparkTtl=%.2f",
        data.flashTtl, data.tracerTtl, data.sparkTtl))

    return setmetatable({
        data = data,
        flashNode = flashNode,
        flashLight = flashLight,
        tracerNode = tracerNode,
        sparkNode = sparkNode,
        flashTime = 0.0,
        tracerTime = 0.0,
        sparkTime = 0.0,
        shots = 0,
        decals = nil,
        bursts = nil,
        shells = nil,
        impacts = 0,
        impactsMissingLogged = false,
    }, Effects)
end

---@param muzzle Vector3
---@param hitPoint Vector3
---@param impact M1Impact|nil 命中信息（P4-A）；nil 时只做枪口光 / 曳光 / 火花
---@param right Vector3|nil 枪的右向，抛壳用
function Effects:Fire(muzzle, hitPoint, impact, right)
    local delta = hitPoint - muzzle
    local distance = delta.length
    if distance > 0.0001 then
        self.tracerNode.position = muzzle + delta * 0.5
        self.tracerNode:LookAt(hitPoint)
        self.tracerNode.scale = Vector3(self.data.tracerWidth, self.data.tracerWidth, distance)
        self.tracerNode:SetEnabled(true)
        self.tracerTime = self.data.tracerTtl
    else
        self.tracerNode:SetEnabled(false)
        self.tracerTime = 0.0
    end

    self.flashNode.position = muzzle
    self.flashNode:SetEnabled(true)
    self.flashTime = self.data.flashTtl

    self.sparkNode.position = hitPoint
    self.sparkNode:SetEnabled(true)
    self.sparkTime = self.data.sparkTtl

    -- P4-A：命中反馈由注入的三个模块完成；模块缺失只记一次 NONE，不打断射击
    local decals = self.decals
    local bursts = self.bursts
    local shells = self.shells
    if impact ~= nil then
        if decals ~= nil and bursts ~= nil then
            local surface = decals:SurfaceOf(impact.nodeName)
            decals:Add(impact.point, impact.normal, surface)
            bursts:Spawn(impact.point, impact.normal, surface)
        elseif self.impactsMissingLogged ~= true then
            self.impactsMissingLogged = true
            print("[FX][IMPACT] -> NONE | reason=modules-missing")
        end
        if shells ~= nil and right ~= nil then
            shells:Eject(muzzle, right)
        end
        self.impacts = self.impacts + 1
    end

    self.shots = self.shots + 1
    if self.shots == 1 or self.shots % EFFECT_FIRE_LOG_EVERY == 0 then
        print(string.format("[FX][FIRE] -> OK | shot=%d distance=%.2f muzzle=(%.2f,%.2f,%.2f) hit=(%.2f,%.2f,%.2f)",
            self.shots, distance,
            muzzle.x, muzzle.y, muzzle.z,
            hitPoint.x, hitPoint.y, hitPoint.z))
    end
end

--- 注入命中表现模块（贴花 / 碎屑火花 / 弹壳）；缺模块时只记 NONE（第 20 节探测式降级）。
---@param modules M1ImpactModules
function Effects:Attach(modules)
    assert(modules ~= nil, "Effects:Attach requires modules")
    self.decals = modules.decals
    self.bursts = modules.bursts
    self.shells = modules.shells
    print(string.format("[FX][ATTACH] -> OK | decals=%s bursts=%s shells=%s",
        tostring(modules.decals ~= nil), tostring(modules.bursts ~= nil),
        tostring(modules.shells ~= nil)))
end

---@param dt number
function Effects:Update(dt)
    if self.flashTime > 0.0 then
        self.flashTime = self.flashTime - dt
        if self.flashTime <= 0.0 then
            self.flashTime = 0.0
            self.flashNode:SetEnabled(false)
        end
    end
    if self.tracerTime > 0.0 then
        self.tracerTime = self.tracerTime - dt
        if self.tracerTime <= 0.0 then
            self.tracerTime = 0.0
            self.tracerNode:SetEnabled(false)
        end
    end
    if self.sparkTime > 0.0 then
        self.sparkTime = self.sparkTime - dt
        if self.sparkTime <= 0.0 then
            self.sparkTime = 0.0
            self.sparkNode:SetEnabled(false)
        end
    end
    local decals = self.decals
    if decals ~= nil then decals:Update(dt) end
    local bursts = self.bursts
    if bursts ~= nil then bursts:Update(dt) end
    local shells = self.shells
    if shells ~= nil then shells:Update(dt) end
end

function Effects:Destroy()
    self.decals = nil
    self.bursts = nil
    self.shells = nil
    self.flashNode:SetEnabled(false)
    self.tracerNode:SetEnabled(false)
    self.sparkNode:SetEnabled(false)
    print("[FX][DESTROY] -> OK")
end

return Effects
