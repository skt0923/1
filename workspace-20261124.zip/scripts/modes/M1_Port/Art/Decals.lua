-- modes/M1_Port/Art/Decals.lua: 弹痕贴花池（原作 12-effects 语句 1 的贴花池 j1，cap 160）。
-- 贴图在 Lua 里用 Image 逐像素画出（原作 06-decal 用 Canvas 2D），走 DiffUnlitAlpha + Models/Plane 的薄盒替代；
-- 弹痕尺寸取原作 ZR 表，表面类型由调用方按命中节点名判定（Data/ImpactFx.lua 的 nameKeys）。
local TAG = "[M1][DECAL]"

local DECAL_THICKNESS = 0.004
local DECAL_NORMAL_OFFSET = 0.006
local LOG_EVERY = 10

---@class M1DecalSlot
---@field node Node
---@field model StaticModel
---@field live boolean
---@field ttl number

---@class M1Decals
---@field data M1ImpactFxData
---@field materials table<string, Material>
---@field slots M1DecalSlot[]
---@field next integer
---@field added integer
---@field lastSurface string
local Decals = {}
Decals.__index = Decals

--- 位置哈希噪声：贴图生成用，避免依赖全局 random 影响玩法随机数。
---@param x integer
---@param y integer
---@param seed integer
---@return number 0..1
local function Hash2(x, y, seed)
    local n = x * 374761393 + y * 668265263 + seed * 2246822519
    n = (n * (n * n * 15731 + 789221) + 1376312589) % 2147483647
    return n / 2147483647.0
end

--- 生成一张弹痕贴图：半径衰减的 Alpha + 表面色 + 放射裂纹。
---@param kind string bullet_metal|bullet_concrete|bullet_wood|bullet_glass
---@param size integer
---@return Image
local function MakeDecalImage(kind, size)
    local image = Image:new()
    image:SetSize(size, size, 4)
    local seed = 0
    local coreR, coreG, coreB = 0.06, 0.06, 0.06
    local rimR, rimG, rimB = 0.35, 0.33, 0.30
    local crackGain = 0.0
    if kind == "bullet_metal" then
        seed = 11
        coreR, coreG, coreB = 0.90, 0.86, 0.72
        rimR, rimG, rimB = 0.16, 0.15, 0.14
        crackGain = 0.35
    elseif kind == "bullet_concrete" then
        seed = 23
        coreR, coreG, coreB = 0.08, 0.08, 0.08
        rimR, rimG, rimB = 0.62, 0.60, 0.56
        crackGain = 0.22
    elseif kind == "bullet_wood" then
        seed = 37
        coreR, coreG, coreB = 0.10, 0.07, 0.04
        rimR, rimG, rimB = 0.48, 0.34, 0.20
        crackGain = 0.12
    elseif kind == "bullet_glass" then
        seed = 53
        coreR, coreG, coreB = 0.95, 0.97, 1.00
        rimR, rimG, rimB = 0.55, 0.65, 0.75
        crackGain = 0.65
    end
    local half = size * 0.5
    for y = 0, size - 1 do
        for x = 0, size - 1 do
            local dx = (x + 0.5 - half) / half
            local dy = (y + 0.5 - half) / half
            -- 木纹横向拉长
            if kind == "bullet_wood" then dx = dx * 2.6 end
            local radius = math.sqrt(dx * dx + dy * dy)
            local core = radius < 0.26 and 1.0 or 0.0
            local rim = math.max(0.0, 1.0 - math.abs(radius - 0.42) / 0.30)
            local grain = Hash2(x, y, seed)
            local alpha = (1.0 - radius) ^ 1.6
            if alpha < 0.0 then alpha = 0.0 end
            alpha = alpha * (0.55 + grain * 0.65)
            if core > 0.0 then alpha = 1.0 end
            -- 放射裂纹：角度锯齿 + 高频噪声
            if crackGain > 0.0 then
                local angle = math.atan(dy, dx)
                local spoke = math.abs(math.sin(angle * 7.0 + seed))
                if spoke > 0.985 and radius > 0.18 and radius < 0.95 and grain > 0.35 then
                    alpha = math.min(1.0, alpha + crackGain)
                    core = 1.0
                end
            end
            if alpha <= 0.02 then
                image:SetPixel(x, y, Color(0.0, 0.0, 0.0, 0.0))
            else
                local r = core * coreR + (1.0 - core) * rimR
                local g = core * coreG + (1.0 - core) * rimG
                local b = core * coreB + (1.0 - core) * rimB
                image:SetPixel(x, y, Color(r, g, b, alpha))
            end
        end
    end
    return image
end

---@param scene Scene
---@param data M1ImpactFxData
---@return M1Decals
function Decals.Create(scene, data)
    assert(scene ~= nil, "Decals requires a scene")
    assert(data ~= nil and data.decalCap > 0, "Decals requires impact fx data")
    local okTechnique, technique = pcall(function()
        return cache:GetResource("Technique", "Techniques/DiffUnlitAlpha.xml")
    end)
    assert(okTechnique and technique ~= nil, "Missing technique: Techniques/DiffUnlitAlpha.xml")
    ---@cast technique Technique
    local okModel, model = pcall(function() return cache:GetResource("Model", "Models/Box.mdl") end)
    assert(okModel and model ~= nil, "Missing model: Models/Box.mdl")
    ---@cast model Model

    ---@type table<string, Material>
    local materials = {}
    local textureCount = 0
    for surfaceName, surface in pairs(data.surfaces) do
        local material = Material:new()
        material:SetTechnique(0, technique)
        local okTexture, texture = pcall(function()
            local image = MakeDecalImage(surface.decal, data.textureSize)
            local created = Texture2D:new()
            created:SetData(image, true)
            return created
        end)
        assert(okTexture and texture ~= nil, "Decals: texture build failed for " .. surface.decal)
        ---@cast texture Texture2D
        material:SetTexture(TU_DIFFUSE, texture)
        materials[surfaceName] = material
        textureCount = textureCount + 1
    end

    ---@type M1DecalSlot[]
    local slots = {}
    for index = 1, data.decalCap do
        local node = scene:CreateChild(string.format("Decal_%d", index))
        ---@diagnostic disable-next-line: unnecessary-assert
        local staticModel = assert(node:CreateComponent("StaticModel"), "Decal node missing StaticModel")
        staticModel:SetModel(model)
        staticModel.castShadows = false
        node:SetEnabled(false)
        slots[index] = { node = node, model = staticModel, live = false, ttl = 0.0 }
    end

    local self = setmetatable({
        data = data,
        materials = materials,
        slots = slots,
        next = 1,
        added = 0,
        lastSurface = "none",
    }, Decals)
    print(string.format("%s[CREATE] -> OK | cap=%d textures=%d size=%dpx", TAG, data.decalCap,
        textureCount, data.textureSize))
    return self
end

---@param name string 命中节点名
---@return string surface
function Decals:SurfaceOf(name)
    local data = self.data
    for index = 1, #data.nameKeys do
        local entry = data.nameKeys[index]
        if string.find(name, entry.key, 1, true) ~= nil then
            return entry.surface
        end
    end
    return data.defaultSurface
end

--- 在命中点生成一张贴花；池满时覆盖最旧的一张（原作同做法）。
---@param point Vector3
---@param normal Vector3
---@param surface string
function Decals:Add(point, normal, surface)
    local data = self.data
    local surfaceData = data.surfaces[surface] or data.surfaces[data.defaultSurface]
    assert(surfaceData ~= nil, "Decals: no surface data for " .. tostring(surface))
    local slot = self.slots[self.next]
    assert(slot ~= nil, "Decals: pool slot missing")
    self.next = self.next % data.decalCap + 1

    local size = surfaceData.decalSize
    slot.node.position = point + normal * DECAL_NORMAL_OFFSET
    slot.node.rotation = Quaternion(Vector3(0.0, 0.0, 1.0), normal)
    slot.node.scale = Vector3(size, size, DECAL_THICKNESS)
    slot.model:SetMaterial(self.materials[surface] or self.materials[data.defaultSurface])
    slot.node:SetEnabled(true)
    slot.live = true
    slot.ttl = 0.0

    self.added = self.added + 1
    self.lastSurface = surface
    if self.added == 1 or self.added % LOG_EVERY == 0 then
        print(string.format("%s[ADD] -> OK | n=%d surface=%s size=%.2f at=(%.2f,%.2f,%.2f) nrm=(%.2f,%.2f,%.2f)",
            TAG, self.added, surface, size, point.x, point.y, point.z, normal.x, normal.y, normal.z))
    end
end

---@return integer
function Decals:Live()
    local count = 0
    for index = 1, #self.slots do
        local slot = self.slots[index] --[[@as M1DecalSlot]]
        if slot.live then count = count + 1 end
    end
    return count
end

--- 贴花常驻直到被覆盖；这里只累计 TTL 供探针判断「有没有新贴花」。
---@param dt number
function Decals:Update(dt)
    for index = 1, #self.slots do
        local slot = self.slots[index] --[[@as M1DecalSlot]]
        if slot.live then slot.ttl = slot.ttl + dt end
    end
end

---@return string
function Decals:Probe()
    local text = string.format("%s[PROBE] -> OK | live=%d cap=%d added=%d last=%s", TAG, self:Live(),
        self.data.decalCap, self.added, self.lastSurface)
    print(text)
    return text
end

function Decals:Destroy()
    if self.materials ~= nil then
        self.materials = {}
    end
    self.slots = {}
    print(string.format("%s -> OK | event=destroy added=%d", TAG, self.added))
end

return Decals