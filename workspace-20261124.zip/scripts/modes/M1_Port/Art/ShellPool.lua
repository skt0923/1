-- modes/M1_Port/Art/ShellPool.lua: 抛壳（原作 12-effects 的弹壳池，cap 60）。
-- 简化为薄盒 + 抛物线：落地后停在原地，到期回收；弹性与滚动属表现差异（任务卡 m1-p4a-impact 差异第 4 条）。
local TAG = "[M1][SHELL]"

local LOG_EVERY = 10

---@class M1ShellSlot
---@field node Node
---@field model StaticModel
---@field vx number
---@field vy number
---@field vz number
---@field ttl number
---@field resting boolean

---@class M1ShellPool
---@field data M1ImpactFxData
---@field slots M1ShellSlot[]
---@field next integer
---@field ejected integer
---@field groundY number
local Shells = {}
Shells.__index = Shells

---@param scene Scene
---@param data M1ImpactFxData
---@param groundY number 地面高度，弹壳落到这个高度就停住
---@return M1ShellPool
function Shells.Create(scene, data, groundY)
    assert(scene ~= nil, "ShellPool requires a scene")
    assert(data ~= nil and data.shellCap > 0, "ShellPool requires impact fx data")
    local okModel, model = pcall(function() return cache:GetResource("Model", "Models/Box.mdl") end)
    assert(okModel and model ~= nil, "Missing model: Models/Box.mdl")
    ---@cast model Model
    local okTechnique, technique = pcall(function()
        return cache:GetResource("Technique", "Techniques/NoTextureUnlit.xml")
    end)
    assert(okTechnique and technique ~= nil, "Missing technique: Techniques/NoTextureUnlit.xml")
    ---@cast technique Technique

    local material = Material:new()
    material:SetTechnique(0, technique)
    material:SetShaderParameter("MatDiffColor", Variant(Color(data.shellColor[1] / 255.0,
        data.shellColor[2] / 255.0, data.shellColor[3] / 255.0, 1.0)))

    ---@type M1ShellSlot[]
    local slots = {}
    for index = 1, data.shellCap do
        local node = scene:CreateChild(string.format("Shell_%d", index))
        ---@diagnostic disable-next-line: unnecessary-assert
        local staticModel = assert(node:CreateComponent("StaticModel"), "Shell node missing StaticModel")
        staticModel:SetModel(model)
        staticModel:SetMaterial(material)
        staticModel.castShadows = false
        node.scale = data.shellSize
        node:SetEnabled(false)
        slots[index] = { node = node, model = staticModel, vx = 0.0, vy = 0.0, vz = 0.0, ttl = 0.0, resting = false }
    end

    local self = setmetatable({
        data = data,
        slots = slots,
        next = 1,
        ejected = 0,
        groundY = groundY,
    }, Shells)
    print(string.format("%s[CREATE] -> OK | cap=%d groundY=%.2f", TAG, data.shellCap, groundY))
    return self
end

--- 抛出一枚弹壳：从抛壳口向右上方飞出。
---@param origin Vector3 抛壳口位置
---@param right Vector3 枪的右向（世界）
function Shells:Eject(origin, right)
    local slot = self.slots[self.next]
    assert(slot ~= nil, "ShellPool: slot missing")
    local data = self.data
    self.next = self.next % #self.slots + 1
    slot.vx = right.x * data.shellSpeed + (math.random() - 0.5) * 0.4
    slot.vy = 1.2 + math.random() * 0.5
    slot.vz = right.z * data.shellSpeed + (math.random() - 0.5) * 0.4
    slot.ttl = 0.0
    slot.resting = false
    slot.node.position = origin
    slot.node.rotation = Quaternion(math.random() * 360.0, Vector3(0.0, 1.0, 0.0))
    slot.node:SetEnabled(true)
    self.ejected = self.ejected + 1
    if self.ejected == 1 or self.ejected % LOG_EVERY == 0 then
        print(string.format("%s[EJECT] -> OK | n=%d at=(%.2f,%.2f,%.2f) v=(%.2f,%.2f,%.2f)", TAG,
            self.ejected, origin.x, origin.y, origin.z, slot.vx, slot.vy, slot.vz))
    end
end

---@param dt number
function Shells:Update(dt)
    local gravity = self.data.gravity
    local resting = self.groundY + self.data.shellSize.y * 0.5
    for index = 1, #self.slots do
        local slot = self.slots[index] --[[@as M1ShellSlot]]
        if slot.node.enabled then
            slot.ttl = slot.ttl + dt
            if slot.ttl >= self.data.shellTtl then
                slot.node:SetEnabled(false)
            elseif not slot.resting then
                slot.vy = slot.vy - gravity * dt
                local position = slot.node.position
                local nextY = position.y + slot.vy * dt
                if nextY <= resting then
                    slot.resting = true
                    slot.node.position = Vector3(position.x + slot.vx * dt, resting, position.z + slot.vz * dt)
                else
                    slot.node.position = Vector3(position.x + slot.vx * dt + 0.0, nextY, position.z + slot.vz * dt)
                end
            end
        end
    end
end

---@return string
function Shells:Probe()
    local live = 0
    for index = 1, #self.slots do
        local slot = self.slots[index] --[[@as M1ShellSlot]]
        if slot.node.enabled then live = live + 1 end
    end
    local text = string.format("%s[PROBE] -> OK | ejected=%d live=%d cap=%d", TAG, self.ejected, live,
        #self.slots)
    print(text)
    return text
end

function Shells:Destroy()
    self.slots = {}
    print(string.format("%s -> OK | event=destroy ejected=%d", TAG, self.ejected))
end

return Shells