-- modes/M1_Port/Art/Weather.lua: 天气表现（雨丝 / 雨溅 / 地面湿润）。
-- 雨丝与雨溅用 ParticleEmitter + ParticleEffect（贴图在 Lua 里用 Image 画，不依赖图片资源），
-- 做法见 engine-docs/recipes/deferred-scene-weather-lighting.md 4.3；地面湿润改到项目自己的
-- BakedSurface 材质（uniform wetness），无 SSR 所以水洼只有高光、没有倒影（任务卡差异第 2 条）。
-- 数值全部来自 Data/Weather.lua。
local TAG = "[M1][WEATHER]"

---@class M1Weather
---@field data M1WeatherData
---@field rainNode Node
---@field rainEmitter ParticleEmitter
---@field splashNode Node
---@field splashEmitter ParticleEmitter
---@field groundMaterials Material[]
---@field level number 当前雨量 0..1
---@field target number 目标雨量 0..1
---@field wetness number 0..1
---@field appliedWetness number 上一次写到材质的湿润度
---@field indoors boolean
---@field clock number
local Weather = {}
Weather.__index = Weather

--- 纵向渐隐的雨丝贴图：中间亮、两端淡，横向高斯衰减。
---@param data M1WeatherData
---@return Texture2D
local function MakeStreakTexture(data)
    local image = Image:new()
    local w, h = data.streakPixelsX, data.streakPixelsY
    image:SetSize(w, h, 4)
    for y = 0, h - 1 do
        local v = math.sin((y + 0.5) / h * math.pi)
        for x = 0, w - 1 do
            local u = (x - (w - 1) * 0.5) / math.max(1.0, (w - 1) * 0.5)
            local a = v * math.exp(-u * u * 3.0)
            image:SetPixel(x, y, Color(a, a, a, a))
        end
    end
    local texture = Texture2D:new()
    texture:SetData(image, true)
    return texture
end

--- 雨溅贴图：中心亮的小圆点，带一圈扩散。
---@return Texture2D
local function MakeSplashTexture()
    local size = 16
    local image = Image:new()
    image:SetSize(size, size, 4)
    local half = size * 0.5
    for y = 0, size - 1 do
        for x = 0, size - 1 do
            local dx = (x + 0.5 - half) / half
            local dy = (y + 0.5 - half) / half
            local radius = math.sqrt(dx * dx + dy * dy)
            local a = math.max(0.0, 1.0 - radius) ^ 1.6
            if radius < 0.35 then a = 1.0 end
            image:SetPixel(x, y, Color(a, a * 1.02, a * 1.06, a))
        end
    end
    local texture = Texture2D:new()
    texture:SetData(image, true)
    return texture
end

---@param scene Scene
---@param data M1WeatherData
---@param texture Texture2D
---@param particles integer
---@param rate number
---@param box Vector3
---@param dirMin Vector3
---@param dirMax Vector3
---@param speedMin number
---@param speedMax number
---@param ttlMin number
---@param ttlMax number
---@param sizeMin Vector2
---@param sizeMax Vector2
---@param name string
---@return Node node
---@return ParticleEmitter emitter
local function BuildEmitter(scene, data, texture, particles, rate, box, dirMin, dirMax, speedMin, speedMax,
    ttlMin, ttlMax, sizeMin, sizeMax, name)
    local okTechnique, technique = pcall(function()
        return cache:GetResource("Technique", "Techniques/DiffUnlitParticleAdd.xml")
    end)
    assert(okTechnique and technique ~= nil, "Missing technique: Techniques/DiffUnlitParticleAdd.xml")
    ---@cast technique Technique
    local material = Material:new()
    material:SetTechnique(0, technique)
    material:SetTexture(TU_DIFFUSE, texture)

    local effect = ParticleEffect:new()
    effect:SetMaterial(material)
    effect:SetNumParticles(particles)
    effect:SetEmitterType(EMITTER_BOX)
    effect:SetEmitterSize(box)
    effect:SetMinDirection(dirMin)
    effect:SetMaxDirection(dirMax)
    effect:SetMinVelocity(speedMin)
    effect:SetMaxVelocity(speedMax)
    effect:SetMinTimeToLive(ttlMin)
    effect:SetMaxTimeToLive(ttlMax)
    effect:SetMinParticleSize(sizeMin)
    effect:SetMaxParticleSize(sizeMax)
    effect:SetMinEmissionRate(rate)
    effect:SetMaxEmissionRate(rate)
    effect:SetUpdateInvisible(true)

    local node = scene:CreateChild(name)
    local okEmitter, emitter = pcall(function() return node:CreateComponent("ParticleEmitter") end)
    assert(okEmitter and emitter ~= nil, "Missing ParticleEmitter component on " .. name)
    ---@cast emitter ParticleEmitter
    emitter:SetEffect(effect)
    -- 雨丝沿速度方向拉伸；雨溅也用它，避免始终面向相机
    emitter:SetFaceCameraMode(FC_DIRECTION)
    emitter.castShadows = false
    node:SetEnabled(false)
    assert(data.rainParticles > 0 or data.splashParticles > 0, "Weather data without particles")
    return node, emitter
end

---@param level M1LevelBuild
---@return Material[]
local function GroundMaterials(level)
    ---@type Material[]
    local list = {}
    for name, zoneNode in pairs(level.zones) do
        local okModel, model = pcall(function() return zoneNode:GetComponent("StaticModel") end)
        assert(okModel and model ~= nil, "Weather: ground zone missing StaticModel: " .. tostring(name))
        ---@cast model StaticModel
        local material = model:GetMaterial(0)
        if material ~= nil then
            list[#list + 1] = material
        end
    end
    assert(#list > 0, "Weather: no ground material found")
    return list
end

---@param scene Scene
---@param data M1WeatherData
---@param level M1LevelBuild
---@return M1Weather
function Weather.Create(scene, data, level)
    assert(scene ~= nil, "Weather requires a scene")
    assert(data ~= nil and data.rainLevel >= 0.0, "Weather requires weather data")
    assert(level ~= nil and level.zones ~= nil, "Weather requires the level build")

    local streak = MakeStreakTexture(data)
    local splash = MakeSplashTexture()
    local dirMin = Vector3(data.wind.x, -1.0, data.wind.z)
    local dirMax = Vector3(data.wind.x + 0.04, -1.0, data.wind.z + 0.03)
    local rainNode, rainEmitter = BuildEmitter(scene, data, streak, data.rainParticles, data.rainRate,
        data.rainBox, dirMin, dirMax, data.rainSpeedMin, data.rainSpeedMax, data.rainTtlMin,
        data.rainTtlMax, Vector2(data.rainWidth, data.rainLength),
        Vector2(data.rainWidth * 1.3, data.rainLength * 1.3), "Rain")
    local splashNode, splashEmitter = BuildEmitter(scene, data, splash, data.splashParticles,
        data.splashRate, data.splashBox, Vector3(0.0, 1.0, 0.0), Vector3(0.3, 1.0, 0.3),
        data.splashSpeedMin, data.splashSpeedMax, data.splashTtl, data.splashTtl,
        Vector2(data.splashSizeMin, data.splashSizeMin), Vector2(data.splashSizeMax, data.splashSizeMax),
        "RainSplash")

    local self = setmetatable({
        data = data,
        rainNode = rainNode,
        rainEmitter = rainEmitter,
        splashNode = splashNode,
        splashEmitter = splashEmitter,
        groundMaterials = GroundMaterials(level),
        level = 0.0,
        target = data.rainLevel,
        wetness = 0.0,
        appliedWetness = -1.0,
        indoors = false,
        clock = 0.0,
    }, Weather)
    print(string.format("%s[CREATE] -> OK | rain=%d splash=%d ground=%d target=%.2f", TAG,
        data.rainParticles, data.splashParticles, #self.groundMaterials, data.rainLevel))
    return self
end

--- 目标雨量 0..1（0 = 停雨）；与 setRain 同义。
---@param level number
function Weather:SetRainLevel(level)
    level = math.max(0.0, math.min(1.0, level))
    if math.abs(level - self.target) < 0.001 then return end
    local from = self.target
    self.target = level
    print(string.format("%s[RAIN] -> OK | from=%.2f to=%.2f", TAG, from, level))
end

---@param value number
function Weather:ApplyWetness(value)
    for index = 1, #self.groundMaterials do
        local material = self.groundMaterials[index] --[[@as Material]]
        material:SetShaderParameter("wetness", Variant(value))
    end
end

--- 玩家是否在仓房内（雨要剔除）：矩形来自 Data/Level.lua 的「仓库」分区。
---@param position Vector3
---@param shed { minX: number, maxX: number, minZ: number, maxZ: number }
---@return boolean
local function InsideRect(position, shed)
    return position.x >= shed.minX and position.x <= shed.maxX and position.z >= shed.minZ
        and position.z <= shed.maxZ
end

---@param dt number
---@param cameraNode Node 相机节点，雨跟随它
---@param playerPos Vector3
---@param shed { minX: number, maxX: number, minZ: number, maxZ: number }|nil 仓房矩形，nil 表示不剔除
function Weather:Update(dt, cameraNode, playerPos, shed)
    local data = self.data
    self.clock = self.clock + dt
    -- 雨量向目标收敛（原作 level 用 1 - exp 收敛，这里线性近似）
    local ramp = dt / math.max(0.1, data.rainRampSeconds)
    if self.level < self.target then
        self.level = math.min(self.target, self.level + ramp)
    elseif self.level > self.target then
        self.level = math.max(self.target, self.level - ramp)
    end

    local indoors = false
    if shed ~= nil then
        indoors = InsideRect(playerPos, shed)
    end
    if indoors ~= self.indoors then
        self.indoors = indoors
        print(string.format("%s[INDOOR] -> %s | pos=(%.1f,%.1f)", TAG, indoors and "NONE" or "OK",
            playerPos.x, playerPos.z))
    end

    local raining = self.level > 0.01 and not indoors
    if self.rainNode.enabled ~= raining then
        self.rainNode:SetEnabled(raining)
        self.splashNode:SetEnabled(raining)
        if raining then
            print(string.format("%s[SHOW] -> OK | level=%.2f particles=%d", TAG, self.level,
                data.rainParticles))
        else
            print(string.format("%s[SHOW] -> NONE | level=%.2f indoors=%s", TAG, self.level,
                tostring(indoors)))
        end
    end
    if raining then
        -- 发射盒跟着相机（原作同做法），XZ 对齐相机、Y 抬到相机上方
        local position = cameraNode.worldPosition
        self.rainNode.position = Vector3(position.x, position.y + data.rainFollowHeight, position.z)
        self.splashNode.position = Vector3(playerPos.x, playerPos.y + 0.05, playerPos.z)
    end

    -- 地面湿润跟随雨量，带独立渐变；只在变化超过 0.01 时写材质
    local wetRamp = dt / math.max(0.1, data.wetnessRampSeconds)
    local wetTarget = indoors and 0.0 or self.level
    if self.wetness < wetTarget then
        self.wetness = math.min(wetTarget, self.wetness + wetRamp)
    elseif self.wetness > wetTarget then
        self.wetness = math.max(wetTarget, self.wetness - wetRamp)
    end
    if math.abs(self.wetness - self.appliedWetness) > 0.01 then
        self.appliedWetness = self.wetness
        self:ApplyWetness(self.wetness)
    end
end

---@return string
function Weather:Probe()
    local text = string.format(
        "%s[PROBE] -> OK | level=%.2f target=%.2f wetness=%.2f indoors=%s rain=%s splash=%s ground=%d",
        TAG, self.level, self.target, self.wetness, tostring(self.indoors),
        tostring(self.rainNode.enabled), tostring(self.splashNode.enabled), #self.groundMaterials)
    print(text)
    return text
end

function Weather:Destroy()
    if self.rainNode ~= nil then
        self.rainNode:SetEnabled(false)
        self.rainNode:Remove()
        self.rainNode = nil
    end
    if self.splashNode ~= nil then
        self.splashNode:SetEnabled(false)
        self.splashNode:Remove()
        self.splashNode = nil
    end
    self.groundMaterials = {}
    print(string.format("%s -> OK | event=destroy level=%.2f", TAG, self.level))
end

return Weather