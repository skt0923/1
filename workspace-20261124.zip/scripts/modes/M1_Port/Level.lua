-- 场地总装：把 Data/Level.lua 的四块地面、仓库壳、码头沿与围挡摆进场景，再挂 Data/Props.lua 的首批道具。
-- 1.35 的 ProceduralGeometry 没有 ToModel（真机 53521），盒体统一用内置 Models/Box.mdl + node.scale。
local TAG = "[M1][LEVEL]"
local PropsArt = require("modes.M1_Port.Art.Props")
local PropsData = require("modes.M1_Port.Data.Props")
local TextureBaker = require("modes.M1_Port.kit.TextureBaker")

---@class M1LevelBuild
---@field zones table<string, Node> Ground slabs by region name.
---@field yardNode Node The yard slab, used by the floor probe.
---@field yardMaterial Material|nil
---@field nodes Node[]
---@field props M1PropBuild
---@field regions M1LevelRegion[]

---@class M1LevelModule
local Module = {}

---@type Model|nil
local boxModel_ = nil

-- 内置单位盒（1x1x1，中心在原点）：非均匀 scale 就是目标尺寸。
---@return Model
local function DefaultBox()
    if boxModel_ == nil then
        local ok, model = pcall(function() return cache:GetResource("Model", "Models/Box.mdl") end)
        assert(ok and model ~= nil, "Missing model: Models/Box.mdl")
        boxModel_ = model --[[@as Model]]
    end
    return boxModel_
end

-- 材质取用统一走这里：pcall 包一层，取不到返回 nil，由调用方记 NONE。
---@param materials table
---@param name string
---@param uvMeters number
---@return Material|nil
local function GetMaterial(materials, name, uvMeters)
    local ok, material = pcall(materials.Get, name, { uvMeters = uvMeters })
    if not ok or material == nil then
        return nil
    end
    return material --[[@as Material]]
end

-- 建一块盒体：位置是盒体中心，尺寸用节点 scale 表达。
---@param scene Scene
---@param nodeName string
---@param center Vector3
---@param size Vector3
---@param material Material|nil
---@param tag string
---@param label string
---@param solid boolean When true the box also gets a static collision body.
---@return Node
local function AddBox(scene, nodeName, center, size, material, tag, label, solid)
    local node = scene:CreateChild(nodeName)
    node.position = center
    node.scale = size
    local okModel, model = pcall(function() return node:CreateComponent("StaticModel") end)
    assert(okModel and model ~= nil, "Level: StaticModel failed for " .. label)
    ---@cast model StaticModel
    model:SetModel(DefaultBox())
    -- 地面与墙体必须有碰撞体：KCC 只认物理世界，StaticModel 本身挡不住玩家。
    if solid then
        local okBody, body = pcall(function() return node:CreateComponent("RigidBody") end)
        assert(okBody and body ~= nil, "Level: RigidBody failed for " .. label)
        ---@cast body RigidBody
        body.mass = 0.0
        body.useGravity = false
        local okShape, shape = pcall(function() return node:CreateComponent("CollisionShape") end)
        assert(okShape and shape ~= nil, "Level: CollisionShape failed for " .. label)
        ---@cast shape CollisionShape
        shape:SetBox(size)
    end
    local result = "NONE"
    if material ~= nil then
        model:SetMaterial(material)
        result = "OK"
    end
    print(string.format("%s[%s] -> %s | name=%s size=%.1fx%.1fx%.1f at=(%.1f,%.1f,%.1f)",
        TAG, tag, result, label, size.x, size.y, size.z, center.x, center.y, center.z))
    return node
end

---@param scene Scene
---@param geometry table Geometry module (kept for the documented dependency; boxes use the built-in model).
---@param materials table Materials module (Get).
---@param world M1WorldData
---@param data M1LevelData
---@return M1LevelBuild
function Module.Create(scene, geometry, materials, world, data)
    assert(scene ~= nil, "Level requires a scene")
    assert(geometry ~= nil and type(geometry.Box) == "function", "Level requires the Geometry module")
    assert(materials ~= nil and type(materials.Get) == "function", "Level requires the Materials module")
    assert(world ~= nil and world.bounds ~= nil, "Level requires world data")
    assert(data ~= nil and type(data.regions) == "table", "Level requires level data")

    ---@type table<string, Node>
    local zones = {}
    ---@type Node[]
    local nodes = {}
    ---@type Material|nil
    local yardMaterial = nil
    local thickness = data.groundThickness

    for index = 1, #data.regions do
        local region = data.regions[index]
        local rect = region.rect
        local width = rect.maxX - rect.minX
        local depth = rect.maxZ - rect.minZ
        assert(width > 0 and depth > 0, "Level region has an empty rect: " .. tostring(region.name))
        local material = GetMaterial(materials, region.material, region.uvMeters)
        -- 相邻分区各自成盒，边对边会在接缝漏黑边（2026-11-24 本地截图确认）：
        -- 非外边界各外扩 regionOverlap，并按序号下沉 regionYSink，避免共面打架。
        local overlap = data.regionOverlap
        local bounds = world.bounds
        local minX = rect.minX > bounds.minX and rect.minX - overlap or rect.minX
        local maxX = rect.maxX < bounds.maxX and rect.maxX + overlap or rect.maxX
        local minZ = rect.minZ > bounds.minZ and rect.minZ - overlap or rect.minZ
        local maxZ = rect.maxZ < bounds.maxZ and rect.maxZ + overlap or rect.maxZ
        local center = Vector3((minX + maxX) * 0.5,
            world.groundY - thickness * 0.5 - index * data.regionYSink, (minZ + maxZ) * 0.5)
        local node = AddBox(scene, "Ground_" .. region.name, center,
            Vector3(maxX - minX, thickness, maxZ - minZ), material, "ZONE", region.name, true)
        zones[region.name] = node
        -- 采样频率 = 贴图边长 / 每个 tile 覆盖米数；真机看这一行判断黑斑是否随 tile 变大而消退。
        print(string.format("%s[GROUND] -> OK | region=%s material=%s uvMeters=%.0f size=%.0fx%.0f",
            TAG, region.name, region.material, region.uvMeters, maxX - minX, maxZ - minZ))
        nodes[#nodes + 1] = node
        if region.name == "堆场" then
            yardMaterial = material
        end
    end

    for index = 1, #data.boxes do
        local box = data.boxes[index]
        local width = box.maxX - box.minX
        local depth = box.maxZ - box.minZ
        assert(width > 0 and depth > 0 and box.height > 0, "Level box has an empty size: " .. box.name)
        local material = GetMaterial(materials, box.material, box.uvMeters)
        local center = Vector3((box.minX + box.maxX) * 0.5, box.y + box.height * 0.5,
            (box.minZ + box.maxZ) * 0.5)
        nodes[#nodes + 1] = AddBox(scene, box.name, center, Vector3(width, box.height, depth),
            material, "BOX", box.name, true)
    end

    -- 围挡：沿 world.bounds 四边各一块薄盒，避免玩家走出地面。
    local bounds = world.bounds
    local t = data.fenceThickness
    local fences = {
        { name = "北围挡", minX = bounds.minX, maxX = bounds.maxX, minZ = bounds.minZ, maxZ = bounds.minZ + t },
        { name = "南围挡", minX = bounds.minX, maxX = bounds.maxX, minZ = bounds.maxZ - t, maxZ = bounds.maxZ },
        { name = "西围挡", minX = bounds.minX, maxX = bounds.minX + t, minZ = bounds.minZ, maxZ = bounds.maxZ },
        { name = "东围挡", minX = bounds.maxX - t, maxX = bounds.maxX, minZ = bounds.minZ, maxZ = bounds.maxZ },
    }
    local fenceMaterial = GetMaterial(materials, "concrete", 2)
    for index = 1, #fences do
        local fence = fences[index]
        local width = fence.maxX - fence.minX
        local depth = fence.maxZ - fence.minZ
        local center = Vector3((fence.minX + fence.maxX) * 0.5, world.groundY + data.fenceHeight * 0.5,
            (fence.minZ + fence.maxZ) * 0.5)
        nodes[#nodes + 1] = AddBox(scene, fence.name, center, Vector3(width, data.fenceHeight, depth),
            fenceMaterial, "FENCE", fence.name, true)
    end

    -- 地面标线：薄盒贴在各分区地面上 6 毫米，不投影、不碰撞（差异表第 12 条）。
    local marks = data.markings or {}
    for index = 1, #marks do
        local mark = marks[index]
        local material = GetMaterial(materials, mark.material or "paint_white", 1.0)
        local size = Vector3(mark.length, 0.012, mark.width)
        local node = AddBox(scene, "Mark_" .. index, Vector3(mark.x, world.groundY + 0.006, mark.z), size,
            material, "MARK", string.format("%d", index), false)
        if mark.rotDeg ~= nil and mark.rotDeg ~= 0 then
            node.rotation = Quaternion(mark.rotDeg, Vector3(0.0, 1.0, 0.0))
        end
        local okModel, model = pcall(function() return node:GetComponent("StaticModel") end)
        if okModel and model ~= nil then
            ---@cast model StaticModel
            model:SetCastShadows(false)
        end
        nodes[#nodes + 1] = node
    end
    print(string.format("%s[MARK] -> %s | count=%d", TAG, #marks > 0 and "OK" or "NONE", #marks))

    -- 首批道具：尺寸与坐标来自 Data/Props.lua，区域由 Data/Level.lua 的矩形判定。
    -- 道具材质烘焙压到 bakeMaxSize，建完立刻恢复：1024 单套在真机要几十秒（第 20 节能力探测）。
    local capOk = pcall(TextureBaker.SetMaxSize, PropsData.bakeMaxSize)
    local props = PropsArt.Create(scene, materials, PropsData, data.regions)
    local backOk = capOk and pcall(TextureBaker.SetMaxSize, PropsData.bakeRestoreSize)
    print(string.format("%s[PROPS][BAKE] -> %s | maxSize=%d restore=%d",
        TAG, backOk and "OK" or "NONE", PropsData.bakeMaxSize, PropsData.bakeRestoreSize))
    local zoneText = {}
    for name, count in pairs(props.zones) do
        zoneText[#zoneText + 1] = string.format("%s:%d", name, count)
    end
    table.sort(zoneText)
    print(string.format("%s[PROPS] -> OK | placed=%d builders=%d zones=%s",
        TAG, props.placed, props.builders, table.concat(zoneText, ",")))

    local yard = zones["堆场"]
    assert(yard ~= nil, "Level data must define the 堆场 region")

    print(string.format("%s[CREATE] -> OK | regions=%d boxes=%d fences=4 marks=%d nodes=%d props=%d",
        TAG, #data.regions, #data.boxes, #marks, #nodes, props.placed))
    return {
        zones = zones,
        yardNode = yard,
        yardMaterial = yardMaterial,
        nodes = nodes,
        props = props,
        regions = data.regions,
    }
end

return Module
