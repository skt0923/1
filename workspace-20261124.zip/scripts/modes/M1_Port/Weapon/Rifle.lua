-- 步枪状态机：射速、散布、换弹时间轴、射线命中。
-- 对应 16-weapon 语句 28（Gv/B_/O_/H_/V_/W_/G_/Yo）与语句 37 的 Xe/Be/Fe 子集，伤害与弱点结算留 P2。
-- 数值来自 modes/M1_Port/Data/Weapon.lua（e8）。
---@class ShooterWeaponContext
---@field fireHeld boolean
---@field reloadPressed boolean
---@field speed number
---@field onGround boolean
---@field crouching boolean
---@field sfx M1Sfx|nil 音效模块；nil 时不发声（自检或无音频环境可用）。

---@class ShooterReloadState
---@field elapsed number
---@field total number
---@field empty boolean
---@field magOutLogged boolean
---@field magInLogged boolean

--- Mount host 接口声明在 modes/M1_Port/WeaponMount.lua，Library 只引用不定义
---@class ShooterRifle
---@field data M1WeaponData
---@field mount ShooterWeaponMountHost
---@field cameraNode Node
---@field physics PhysicsWorld
---@field effects ShooterEffects
---@field ammo integer
---@field reserve integer
---@field cooldown number
---@field bloom number
---@field autoReload number
---@field reload ShooterReloadState|nil
---@field dryLatched boolean
---@field fireTimer number
---@field shots integer
---@field hits integer 命中敌人的发数（命中率 = hits/shots，原作 combat.stats）。
---@field hitscan fun(origin: Vector3, dir: Vector3, maxDist: number): { distance: number, enemy: any }|nil
---@field onShot fun()|nil 开火后回调（枪感用，P4-C）
local Rifle = {}
Rifle.__index = Rifle

---@param scene Scene
---@param cameraNode Node
---@param mount ShooterWeaponMountHost
---@param data M1WeaponData
---@param effects ShooterEffects
---@return ShooterRifle
function Rifle.Create(scene, cameraNode, mount, data, effects)
    assert(scene ~= nil, "Rifle requires scene")
    assert(cameraNode ~= nil and mount ~= nil, "Rifle requires camera and mount")
    assert(type(mount.GetActiveNode) == "function", "Rifle mount must expose GetActiveNode()")
    assert(effects ~= nil, "Rifle requires effects")
    assert(data ~= nil, "Rifle requires weapon data")
    assert(data.magSize ~= nil and data.magSize > 0, "Weapon data missing magSize")
    assert(data.rpm ~= nil and data.rpm > 0, "Weapon data missing rpm")
    assert(data.reloadTime ~= nil and data.emptyReloadTime ~= nil, "Weapon data missing reload times")
    assert(data.baseSpread ~= nil and data.speedRef ~= nil, "Weapon data missing spread params")
    assert(data.maxCatchupShots ~= nil, "Weapon data missing maxCatchupShots")

-- 组件加载失败需显式中断（f2），.emmylua 声明非 nil 才判多余
---@diagnostic disable-next-line: unnecessary-assert
    local physics = assert(scene:GetComponent("PhysicsWorld"), "Rifle requires PhysicsWorld")

    print(string.format("[WEAPON][CREATE] -> OK | name=%s mag=%d reserve=%d rpm=%.0f reload=%.2f empty=%.2f",
        data.name, data.magSize, data.reserve, data.rpm, data.reloadTime, data.emptyReloadTime))

    return setmetatable({
        data = data,
        mount = mount,
        cameraNode = cameraNode,
        physics = physics,
        effects = effects,
        ammo = data.magSize,
        reserve = data.reserve,
        cooldown = 0.0,
        bloom = 0.0,
        autoReload = -1.0,
        reload = nil,
        dryLatched = false,
        fireTimer = 0.0,
        shots = 0,
        hits = 0,
    }, Rifle)
end

---@param ctx ShooterWeaponContext
---@return number spread
---@return number speedFraction
function Rifle:CurrentSpread(ctx)
    local speedFraction = math.min(1.0, ctx.speed / self.data.speedRef)
    local spread = self.data.baseSpread
        + speedFraction * self.data.moveSpread
        + self.bloom * self.data.bloomSpread
    if not ctx.onGround then
        spread = spread + self.data.airSpread
    end
    if ctx.crouching then
        spread = spread - self.data.crouchSpread
    end
    return spread, speedFraction
end

---@param ctx ShooterWeaponContext
function Rifle:FireOne(ctx)
    local data = self.data
    self.ammo = self.ammo - 1
    self.bloom = math.min(1.0, self.bloom + data.bloomPerShot)
    self.fireTimer = data.firingWindow
    if ctx.sfx ~= nil then
        ctx.sfx:Play("rifle_fire")
    end

    local spread, speedFraction = self:CurrentSpread(ctx)
    local angle = math.random() * math.pi * 2.0
    local radius = math.tan(spread) * math.sqrt(math.random())
    -- 相机前向是 +Z，射线的 z 分量必须为正，否则子弹朝身后飞
    local localDir = Vector3(math.cos(angle) * radius, math.sin(angle) * radius, 1.0):Normalized()
    local dir = self.cameraNode.worldRotation * localDir
    local origin = self.cameraNode.worldPosition

    local hit = self.physics:RaycastSingle(Ray(origin, dir), data.range, CollisionMaskStatic)
    local hitBody = hit.body ~= nil
    local hitDistance = hitBody and hit.distance or data.range
    -- 敌人不在静态碰撞掩码里，由玩法注入的 hitscan 回调用包围盒求交，取更近的那个
    local target = nil
    local hitscan = self.hitscan
    if hitscan ~= nil then
        local okScan, scan = pcall(hitscan, origin, dir, hitDistance)
        assert(okScan, "Rifle hitscan callback failed: " .. tostring(scan))
        if scan ~= nil then
            hitDistance = scan.distance
            target = scan.enemy
        end
    end
---@type Vector3
    local point = origin + dir * hitDistance

    -- P4-A：命中点、法线与表面交给表现层（贴花 / 碎屑与火花 / 弹壳）
    ---@type M1Impact|nil
    local impact = nil
    if hitBody then
        local hitNode = nil
        local okNode, sceneNode = pcall(function() return hit.body:GetNode() end)
        if okNode and sceneNode ~= nil then
            hitNode = sceneNode
        end
        impact = {
            point = hit.position,
            normal = hit.normal,
            nodeName = hitNode ~= nil and hitNode.name or "",
        }
    elseif target ~= nil then
        impact = { point = point, normal = Vector3(-dir.x, -dir.y, -dir.z), nodeName = "enemy" }
    end

    local muzzle = self.mount:GetActiveNode():LocalToWorld(data.muzzleLocal)
    self.effects:Fire(muzzle, point, impact, self.cameraNode.worldRight)

    -- P4-C：枪感（后坐弹簧）由玩法注入的回调驱动
    local onShot = self.onShot
    if onShot ~= nil then onShot() end

    self.shots = self.shots + 1
    if target ~= nil then
        self.hits = self.hits + 1
        target:Damage(data.damage, "rifle")
    end
    print(string.format("[WEAPON][SHOT] -> OK | shot=%d ammo=%d/%d reserve=%d spread=%.4f speedFrac=%.2f bloom=%.2f air=%s crouch=%s origin=(%.2f,%.2f,%.2f) dir=(%.3f,%.3f,%.3f) hit=%s dist=%.2f point=(%.2f,%.2f,%.2f) dmg=%.0f range=%.0f target=%s",
        self.shots, self.ammo, data.magSize, self.reserve,
        spread, speedFraction, self.bloom, tostring(not ctx.onGround), tostring(ctx.crouching),
        origin.x, origin.y, origin.z,
        dir.x, dir.y, dir.z,
        (target ~= nil or hitBody) and "1" or "0",
        hitDistance,
        point.x, point.y, point.z,
        data.damage, data.range, target ~= nil and "enemy" or "world"))
end

---@return boolean
function Rifle:RequestReload()
    if self.reload ~= nil then
        print("[WEAPON][RELOAD] -> NONE | reason=in-progress")
        return false
    end
    if self.ammo >= self.data.magSize then
        print(string.format("[WEAPON][RELOAD] -> NONE | reason=full ammo=%d/%d", self.ammo, self.data.magSize))
        return false
    end
    if self.reserve <= 0 then
        print("[WEAPON][RELOAD] -> NONE | reason=empty-reserve")
        return false
    end

    local empty = self.ammo <= 0
    local total = empty and self.data.emptyReloadTime or self.data.reloadTime
    self.reload = {
        elapsed = 0.0,
        total = total,
        empty = empty,
        magOutLogged = false,
        magInLogged = false,
    }
    self.autoReload = -1.0
    print(string.format("[WEAPON][RELOAD] -> OK | event=start empty=%s T=%.2f ammo=%d reserve=%d",
        tostring(empty), total, self.ammo, self.reserve))
    return true
end

---@param dt number
---@param ctx ShooterWeaponContext
function Rifle:AdvanceReload(dt, ctx)
    local reload = self.reload
    if reload == nil then return end

    reload.elapsed = reload.elapsed + dt

    if not reload.magOutLogged and reload.elapsed >= self.data.reloadMagOut then
        reload.magOutLogged = true
        print(string.format("[WEAPON][RELOAD] -> OK | event=magout t=%.2f", reload.elapsed))
        if ctx.sfx ~= nil then
            ctx.sfx:Play("reload_out")
        end
    end

    if not reload.magInLogged and reload.elapsed >= self.data.reloadMagIn then
        reload.magInLogged = true
        local need = self.data.magSize - self.ammo
        local moved = math.min(need, self.reserve)
        self.ammo = self.ammo + moved
        self.reserve = self.reserve - moved
        print(string.format("[WEAPON][RELOAD] -> OK | event=magin t=%.2f ammo=%d reserve=%d moved=%d",
            reload.elapsed, self.ammo, self.reserve, moved))
        if ctx.sfx ~= nil then
            ctx.sfx:Play("reload_in")
        end
    end

    if reload.elapsed >= reload.total then
        print(string.format("[WEAPON][RELOAD] -> OK | event=done t=%.2f ammo=%d reserve=%d",
            reload.elapsed, self.ammo, self.reserve))
        self.reload = nil
    end
end

---@param dt number
---@param ctx ShooterWeaponContext
function Rifle:Update(dt, ctx)
    if ctx.reloadPressed then
        self:RequestReload()
    end

    if self.autoReload >= 0.0 then
        self.autoReload = self.autoReload - dt
        if self.autoReload < 0.0 then
            self.autoReload = -1.0
            self:RequestReload()
        end
    end

    self:AdvanceReload(dt, ctx)

    self.cooldown = self.cooldown - dt

    if ctx.fireHeld and self.reload == nil then
        if self.ammo > 0 then
            local fired = 0
            while self.cooldown <= 0.0 and self.ammo > 0 and fired < self.data.maxCatchupShots do
                self:FireOne(ctx)
                self.cooldown = self.cooldown + 60.0 / self.data.rpm
                fired = fired + 1
            end
            self.dryLatched = false
        elseif not self.dryLatched then
            self.dryLatched = true
            print(string.format("[WEAPON][DRY] -> NONE | ammo=0 reserve=%d autoReload=%.2f",
                self.reserve, self.data.autoReloadDelay))
            if ctx.sfx ~= nil then
                ctx.sfx:Play("rifle_dry")
            end
            if self.reserve > 0 then
                self.autoReload = self.data.autoReloadDelay
            end
        end
    else
        self.dryLatched = false
    end

    if self.cooldown < self.data.cooldownFloor then
        self.cooldown = self.data.cooldownFloor
    end

    self.bloom = math.max(0.0, self.bloom - self.data.bloomDecay * dt)

    if self.fireTimer > 0.0 then
        self.fireTimer = self.fireTimer - dt
        if self.fireTimer < 0.0 then self.fireTimer = 0.0 end
    end
end

---@return integer ammo
---@return integer reserve
---@return integer magSize
---@return string state
---@return boolean low
function Rifle:GetHudState()
    local state = "idle"
    if self.reload ~= nil then
        state = "reloading"
    elseif self.fireTimer > 0.0 then
        state = "firing"
    elseif self.ammo <= 0 then
        state = "empty"
    end
    local low = self.ammo <= math.ceil(self.data.magSize * self.data.lowAmmoFraction)
    return self.ammo, self.reserve, self.data.magSize, state, low
end

return Rifle
