-- 第三人称持枪姿势：在动画之后覆盖左右臂骨骼（两骨 IK），并把枪摆到右手位置。
-- 必须在 PostUpdate 阶段执行：AnimatedModel 在 Update 阶段会重写骨骼变换，写早了会被覆盖。
-- 枪是角色根节点的子节点，用本地变换写，不受骨链缩放影响（feedback 53817 dot=0.35 的原因）。
-- 目标点来自 modes/M1_Port/Data/Player.lua 的 pose 段（e9）。

local TAG = "[POSE]"

---@class ShooterWeaponPose
---@field actor TararaActor
---@field gunNode Node
---@field cfg M1PoseData
---@field rUpper Bone
---@field rFore Bone
---@field rHand Bone
---@field lUpper Bone
---@field lFore Bone
---@field lHand Bone
---@field frames integer
---@field Update fun(self: ShooterWeaponPose)
---@field Destroy fun(self: ShooterWeaponPose)
local WeaponPose = {}
WeaponPose.__index = WeaponPose

---@param skeleton Skeleton
---@param name string
---@return Bone
local function FindBone(skeleton, name)
    local bone = skeleton:GetBone(name)
-- 骨骼缺失需显式中断（f2）
---@diagnostic disable-next-line: unnecessary-assert
    local checked = assert(bone, "Missing bone: " .. name)
    return checked
end

--- 骨骼在自己局部空间里指向子骨骼的单位方向；刚性链，动画不改变它。
---@param bone Bone
---@param child Bone
---@return Vector3 dir
---@return number length
local function ChildDir(bone, child)
    local delta = child.node.worldPosition - bone.node.worldPosition
    local len = delta:Length()
    if len < 1e-6 then return Vector3(1, 0, 0), 0.0 end
    local dir = bone.node.worldRotation:Inverse() * (delta * (1.0 / len))
    return dir:Normalized(), len
end

--- 把骨骼的“指向子骨骼”方向掰到 desiredDir（世界空间）。
---@param bone Bone
---@param dirLocal Vector3
---@param desiredDir Vector3
local function AimBone(bone, dirLocal, desiredDir)
    local old = bone.node.worldRotation
    local current = old * dirLocal
    local dot = current:DotProduct(desiredDir)
    if dot > 0.9995 then return end
    -- 反向时 Quaternion(from, to) 的轴退化，改用绕世界 Y 的 180 度
    local delta = dot < -0.9995 and Quaternion(180, Vector3(0, 1, 0)) or Quaternion(current, desiredDir)
    bone.node.worldRotation = delta * old
end

--- 两骨 IK：返回肘部位置。
---@param shoulder Vector3
---@param target Vector3
---@param l1 number
---@param l2 number
---@param pole Vector3
---@return Vector3 elbow
local function SolveElbow(shoulder, target, l1, l2, pole)
    local toTarget = target - shoulder
    local dist = toTarget:Length()
    if dist < 1e-5 then return shoulder + pole:Normalized() * l1 end
    local d = math.min(dist, (l1 + l2) * 0.999)
    local dir = toTarget * (1.0 / dist)
    local a = (l1 * l1 - l2 * l2 + d * d) / (2.0 * d)
    local h = math.sqrt(math.max(0.0, l1 * l1 - a * a))
    local side = (pole - dir * pole:DotProduct(dir)):Normalized()
    return shoulder + dir * a + side * h
end

---@param actor TararaActor
---@param gunNode Node
---@param cfg M1PoseData
---@return ShooterWeaponPose
function WeaponPose.Create(actor, gunNode, cfg)
    assert(actor ~= nil, "WeaponPose requires actor")
    assert(actor.model ~= nil, "WeaponPose requires actor model")
    assert(gunNode ~= nil, "WeaponPose requires gun node")
    assert(cfg ~= nil, "WeaponPose requires pose data")

    local skeleton = actor.model.skeleton
    local self = setmetatable({
        actor = actor,
        gunNode = gunNode,
        cfg = cfg,
        rUpper = FindBone(skeleton, "Bip001 R UpperArm"),
        rFore = FindBone(skeleton, "Bip001 R Forearm"),
        rHand = FindBone(skeleton, "Bip001 R Hand"),
        lUpper = FindBone(skeleton, "Bip001 L UpperArm"),
        lFore = FindBone(skeleton, "Bip001 L Forearm"),
        lHand = FindBone(skeleton, "Bip001 L Hand"),
        frames = 0,
    }, WeaponPose)

    print(string.format("%s[CREATE] -> OK | handR=right hand handL=left hand gunYaw=%.0f", TAG, cfg.gunYaw))
    return self
end

---@param upper Bone
---@param fore Bone
---@param hand Bone
---@param target Vector3
---@param pole Vector3
local function SolveArm(upper, fore, hand, target, pole)
    local shoulder = upper.node.worldPosition
    local forePos = fore.node.worldPosition
    local dirUpper = ChildDir(upper, fore)
    local l1 = (forePos - shoulder):Length()
    local l2 = (hand.node.worldPosition - forePos):Length()
    local elbow = SolveElbow(shoulder, target, l1, l2, pole)
    AimBone(upper, dirUpper, (elbow - shoulder):Normalized())
    local dirFore = ChildDir(fore, hand)
    local foreNow = fore.node.worldPosition
    AimBone(fore, dirFore, (target - foreNow):Normalized())
end

-- 手臂够不到目标时按可达距离收一点；返回可用目标、还差多少（0 表示够得到）、目标距离。
---@param upper Bone
---@param fore Bone
---@param hand Bone
---@param target Vector3
---@return Vector3, number, number
local function ReachableTarget(upper, fore, hand, target)
    local shoulder = upper.node.worldPosition
    local reach = (fore.node.worldPosition - shoulder):Length() +
                      (hand.node.worldPosition - fore.node.worldPosition):Length()
    local offset = target - shoulder
    local need = offset:Length()
    local limit = reach * 0.995
    if need > limit then
        return shoulder + offset * (limit / need), need - limit, need
    end
    return target, 0.0, need
end

-- 站立不动时探针数值逐帧相同，按变化打印，避免被引擎限流丢掉（feedback 54602 f3991）。
---@type string|nil
local lastHandKey_ = nil

--- 在动画之后调用：抬双臂、摆枪、必要时打探针。
function WeaponPose:Update()
    local cfg = self.cfg
    local actorNode = self.actor.node
    local origin = actorNode.worldPosition
    local rot = actorNode.worldRotation

    local right = rot * Vector3(1, 0, 0)
    local down = Vector3(0, -1, 0)

    SolveArm(self.rUpper, self.rFore, self.rHand,
        origin + rot * cfg.handRight, right + down * 0.6)
    local targetL, shortL, needL = ReachableTarget(self.lUpper, self.lFore, self.lHand,
        origin + rot * cfg.handLeft)
    SolveArm(self.lUpper, self.lFore, self.lHand,
        targetL, right * -1.0 + down * 0.6)

    -- 枪：角色根节点下的本地变换，枪模型自身前向是 -Z，绕 Y 转 gunYaw 指向前方
    self.gunNode.position = cfg.handRight + cfg.gunOffset
    self.gunNode.rotation = Quaternion(0, cfg.gunYaw, 0)

    self.frames = self.frames + 1
    if self.frames % 60 == 0 then
        local handR = self.rHand.node.worldPosition
        local handL = self.lHand.node.worldPosition
        local wantR = origin + rot * cfg.handRight
        local wantL = origin + rot * cfg.handLeft
        local errR = (handR - wantR):Length()
        local errL = (handL - wantL):Length()
        local muzzleDir = self.gunNode.worldRotation * Vector3(0, 0, -1)
        local wantDir = rot * Vector3(0, 0, 1)
        local dot = muzzleDir:DotProduct(wantDir)
        -- shortL>0 表示左手够不到枪护木，属于可达性限制，记 NONE 并写出差额，不冒充 FAIL。
        local verdict = (errR < 0.06 and errL < 0.10 and dot > 0.9 and shortL <= 0.0) and "OK" or "NONE"
        local key = string.format("%s|%.3f|%.3f|%.2f|%.3f", verdict, errR, errL, dot, shortL)
        if key ~= lastHandKey_ or self.frames % 300 == 0 then
            lastHandKey_ = key
            print(string.format(
                "%s[HAND] -> %s | errR=%.3f errL=%.3f dot=%.2f shortL=%.3f needL=%.3f frame=%d",
                TAG, verdict, errR, errL, dot, shortL, needL, self.frames))
        end
    end
end

function WeaponPose:Destroy()
    self.actor = nil
    self.gunNode = nil
    print(string.format("%s[DESTROY] -> OK", TAG))
end

return WeaponPose
