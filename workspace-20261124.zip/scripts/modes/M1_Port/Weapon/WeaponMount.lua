-- 武器挂点：两套视图模型。
-- first person：挂在相机下，枪 + 两条前臂 + 手套（原作的 sleeve/glove/forearm 简化移植）。
-- third person：枪单独挂在角色根节点下，世界位姿由 WeaponPose 每帧按 IK 结果写入。
-- 几何与材质参数全部来自 modes/M1_Port/Data/Weapon.lua（e8/e9）。

local TAG = "[WEAPON]"

--- 枪位宿主接口：Rifle 只依赖这一个方法（第 14 节模块接口）。
---@class ShooterWeaponMountHost
---@field GetActiveNode fun(self: ShooterWeaponMountHost): Node

---@class ShooterWeaponMount : ShooterWeaponMountHost
---@field data M1WeaponData
---@field fpRoot Node
---@field actorRoot Node
---@field activeNode Node
---@field thirdPerson boolean
---@field actorAttached boolean
---@field destroyed boolean
local WeaponMount = {}
WeaponMount.__index = WeaponMount

---@return Technique
local function GetTechnique()
    local technique = cache:GetResource("Technique", "Techniques/PBR/PBRNoTexture.xml")
-- 资源加载失败需显式中断（f2）
---@diagnostic disable-next-line: unnecessary-assert
    assert(technique ~= nil, "Missing technique: Techniques/PBR/PBRNoTexture.xml")
    return technique
end

---@param technique Technique
---@param color [number, number, number]
---@param metallic number
---@param roughness number
---@return Material
local function BuildMaterial(technique, color, metallic, roughness)
    local material = Material:new()
    material:SetTechnique(0, technique)
    material:SetShaderParameter("MatDiffColor", Variant(Color(color[1], color[2], color[3], 1.0)))
    material:SetShaderParameter("MatSpecColor", Variant(Color(color[1], color[2], color[3], 1.0)))
    material:SetShaderParameter("Metallic", Variant(metallic))
    material:SetShaderParameter("Roughness", Variant(roughness))
    return material
end

---@param root Node
---@param name string
---@param position Vector3
---@param rotation Quaternion
---@param scale Vector3
---@param material Material
local function AddBox(root, name, position, rotation, scale, material)
-- 资源加载失败需显式中断（f2）
---@diagnostic disable-next-line: unnecessary-assert
    local model = assert(cache:GetResource("Model", "Models/Box.mdl"), "Missing model: Models/Box.mdl")
-- 组件加载失败需显式中断（f2）
---@diagnostic disable-next-line: unnecessary-assert
    local staticModel = assert(root:CreateChild(name):CreateComponent("StaticModel"),
        "Missing StaticModel for " .. name)
    local node = staticModel.node
    node.position = position
    node.rotation = rotation
    node.scale = scale
    staticModel:SetModel(model)
    staticModel:SetMaterial(material)
    staticModel.castShadows = false
end

---@param root Node
---@param data M1WeaponData
---@param material Material
local function BuildGunParts(root, data, material)
    for index, part in ipairs(data.viewParts) do
        AddBox(root, "WeaponPart" .. index, part.position,
            Quaternion(part.rotation.x, part.rotation.y, part.rotation.z), part.scale, material)
    end
end

--- 把 from→to 的线段搭成一根圆柱感的方柱（Box 1x1x1，长轴 Z）。
---@param root Node
---@param name string
---@param from Vector3
---@param to Vector3
---@param radius number
---@param material Material
local function AddSegment(root, name, from, to, radius, material)
    local delta = to - from
    local len = delta:Length()
    assert(len > 1e-4, "Zero length segment: " .. name)
    local rotation = Quaternion(Vector3(0, 0, 1), delta * (1.0 / len))
    AddBox(root, name, (from + to) * 0.5, rotation, Vector3(radius * 2.0, radius * 2.0, len), material)
end

---@param tech Technique
---@param arms M1ViewArm[]
---@param gloves M1ViewGlove[]
---@param root Node
local function BuildArms(tech, arms, gloves, root)
    for index, arm in ipairs(arms) do
        local material = BuildMaterial(tech, arm.color, 0.0, 0.85)
        AddSegment(root, "ViewForearm" .. index, arm.from, arm.to, arm.radius, material)
    end
    for index, glove in ipairs(gloves) do
        local material = BuildMaterial(tech, glove.color, 0.1, 0.6)
        AddBox(root, "ViewGlove" .. index, glove.position, Quaternion(0, 0, 0),
            Vector3(glove.half.x * 2.0, glove.half.y * 2.0, glove.half.z * 2.0), material)
    end
end

---@param cameraNode Node
---@param data M1WeaponData
---@return ShooterWeaponMount
function WeaponMount.Create(cameraNode, data)
    assert(cameraNode ~= nil, "WeaponMount requires camera node")
    assert(data ~= nil and data.viewParts ~= nil, "WeaponMount requires weapon view data")
    local vm = data.viewModel
    assert(vm ~= nil, "WeaponMount requires data.viewModel")

    local tech = GetTechnique()
    local gunMaterial = BuildMaterial(tech, data.viewColor, data.viewMetallic, data.viewRoughness)

    -- 第一人称视图模型：枪 + 手臂 + 手套，全部挂在相机下
    local fpRoot = cameraNode:CreateChild("WeaponMountFirstPerson")
    fpRoot.position = vm.gunPosition
    fpRoot.rotation = Quaternion(0, vm.gunYaw, 0)
    BuildGunParts(fpRoot, data, gunMaterial)
    BuildArms(tech, vm.arms, vm.gloves, fpRoot)

    -- 第三人称：枪挂在角色根节点下（不挂手骨，避免骨链缩放假旋转），先建后隐藏
    local actorRoot = cameraNode:CreateChild("WeaponMountActor")
    BuildGunParts(actorRoot, data, gunMaterial)
    actorRoot:SetDeepEnabled(false)

    print(string.format("%s[MOUNT] -> OK | name=%s parts=%d arms=%d gloves=%d fpPos=(%.2f,%.2f,%.2f)",
        TAG, data.name, #data.viewParts, #vm.arms, #vm.gloves,
        vm.gunPosition.x, vm.gunPosition.y, vm.gunPosition.z))

    return setmetatable({
        data = data,
        fpRoot = fpRoot,
        actorRoot = actorRoot,
        activeNode = fpRoot,
        thirdPerson = false,
        actorAttached = false,
        destroyed = false,
    }, WeaponMount)
end

--- 把第三人称那把枪挂到角色根节点。幂等：重复调用直接返回（第 29 节）。
---@param actor TararaActor
function WeaponMount:AttachActor(actor)
    assert(actor ~= nil, "WeaponMount requires actor")
    if self.actorAttached then return end
    self.actorRoot:SetParent(actor.node)
    self.actorAttached = true
    print(string.format("%s[ATTACH] -> OK | parent=%s", TAG, actor.node.name))
end

--- 切换视角：只切两套模型的可见性与激活指针。
---@param third boolean
function WeaponMount:SetMode(third)
    third = third == true
    if third and not self.actorAttached then
        print(string.format("%s[MODE] -> FAIL | reason=actor-not-attached mode=third", TAG))
        return
    end
    self.thirdPerson = third
    self.fpRoot:SetDeepEnabled(not third)
    self.actorRoot:SetDeepEnabled(third)
    self.activeNode = third and self.actorRoot or self.fpRoot
    local pos = self.activeNode.worldPosition
    print(string.format("%s[MODE] -> OK | mode=%s active=%s world=(%.2f,%.2f,%.2f)", TAG,
        third and "third" or "first", self.activeNode.name, pos.x, pos.y, pos.z))
end

--- 枪口朝向探针（d7）：dot >= 0.9 才算枪管与期望方向一致。
---@param wantDir Vector3
---@return number
function WeaponMount:ProbeAim(wantDir)
    local node = self.activeNode
    local gotDir = node.worldRotation * Vector3(0, 0, -1)
    local dot = wantDir:DotProduct(gotDir)
    local pos = node.worldPosition
    print(string.format("%s[AIM] -> %s | mode=%s world=(%.2f,%.2f,%.2f) muzzleDir=(%.2f,%.2f,%.2f) wantDir=(%.2f,%.2f,%.2f) dot=%.2f",
        TAG, dot >= 0.9 and "OK" or "FAIL", self.thirdPerson and "third" or "first",
        pos.x, pos.y, pos.z, gotDir.x, gotDir.y, gotDir.z, wantDir.x, wantDir.y, wantDir.z, dot))
    return dot
end

---@return Node
function WeaponMount:GetActiveNode()
    return self.activeNode
end

function WeaponMount:Destroy()
    if self.destroyed then return end
    self.destroyed = true
    self.fpRoot:Remove()
    self.actorRoot:Remove()
    print(string.format("%s[DESTROY] -> OK", TAG))
end

return WeaponMount
