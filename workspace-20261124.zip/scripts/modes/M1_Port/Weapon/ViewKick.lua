-- modes/M1_Port/Weapon/ViewKick.lua: 第一人称枪感（后坐弹簧 / 移动摇摆 / 冲刺收枪 / 自动检视）。
-- 原作 16-weapon 语句 28 的弹簧组与冲量；这里只写视图模型节点，不碰相机（相机姿态权威仍在
-- View/FirstPersonCamera.lua），相机抖动属登记差异（任务卡 m1-p4c-gunfeel 差异第 1 条）。
-- 弹簧积分按原作切 8 毫秒子步，避免 freq 520 在 60 帧下发散。
local TAG = "[M1][KICK]"

local SPRING_KEYS = { "z", "pitch", "yaw", "roll", "swayYaw", "swayPitch", "bump" }

---@class M1KickSpring
---@field x number
---@field v number

---@class M1ViewKick
---@field data M1ViewKickData
---@field mount ShooterWeaponMount
---@field cameraNode Node
---@field basePosition Vector3
---@field baseYawDeg number
---@field springs table<string, M1KickSpring>
---@field sprint number
---@field idle number
---@field inspect number -1 表示未在检视
---@field lastYaw number
---@field lastPitch number
---@field shots integer
---@field blocked boolean
local ViewKick = {}
ViewKick.__index = ViewKick

---@param mount ShooterWeaponMount
---@param cameraNode Node
---@param weaponData M1WeaponData
---@param data M1ViewKickData
---@return M1ViewKick
function ViewKick.Create(mount, cameraNode, weaponData, data)
    assert(mount ~= nil and mount.fpRoot ~= nil, "ViewKick requires the weapon mount")
    assert(cameraNode ~= nil, "ViewKick requires the camera node")
    assert(weaponData ~= nil and weaponData.viewModel ~= nil, "ViewKick requires weapon view data")
    assert(data ~= nil and data.springs ~= nil, "ViewKick requires kick data")
    ---@type table<string, M1KickSpring>
    local springs = {}
    for index = 1, #SPRING_KEYS do
        local key = SPRING_KEYS[index]
        assert(data.springs[key] ~= nil, "ViewKick: missing spring " .. key)
        springs[key] = { x = 0.0, v = 0.0 }
    end
    local self = setmetatable({
        data = data,
        mount = mount,
        cameraNode = cameraNode,
        basePosition = weaponData.viewModel.gunPosition,
        baseYawDeg = weaponData.viewModel.gunYaw,
        springs = springs,
        sprint = 0.0,
        idle = 0.0,
        inspect = -1.0,
        lastYaw = 0.0,
        lastPitch = 0.0,
        shots = 0,
        blocked = false,
    }, ViewKick)
    local rotation = cameraNode.worldRotation
    self.lastYaw = rotation:YawAngle()
    self.lastPitch = rotation:PitchAngle()
    print(string.format("%s[CREATE] -> OK | springs=%d base=(%.2f,%.2f,%.2f)", TAG, #SPRING_KEYS,
        self.basePosition.x, self.basePosition.y, self.basePosition.z))
    return self
end

---@param key string
---@param impulse number
function ViewKick:Impulse(key, impulse)
    local spring = self.springs[key]
    assert(spring ~= nil, "ViewKick: unknown spring " .. key)
    spring.v = spring.v + impulse
end

--- 开火：后坐三个轴 + bump（原作 kZ/kP/kY/kR + bump）。
function ViewKick:Shot()
    local data = self.data
    self.shots = self.shots + 1
    for index = 1, #SPRING_KEYS do
        local key = SPRING_KEYS[index]
        local springData = data.springs[key]
        assert(springData ~= nil, "ViewKick: missing spring data " .. key)
        if springData.impulse > 0.0 then
            local jitter = 1.0
            if key == "yaw" or key == "roll" then
                jitter = (math.random() * 2.0 - 1.0)
            end
            self:Impulse(key, springData.impulse * jitter)
        end
    end
    self:Impulse("bump", data.springs.bump.impulse + 0.3)
    self.idle = 0.0
    self.inspect = -1.0
    if self.shots == 1 or self.shots % 20 == 0 then
        print(string.format("%s[SHOT] -> OK | n=%d sprint=%.2f blocked=%s", TAG, self.shots,
            self.sprint, tostring(self.blocked)))
    end
end

--- 落地：固定冲量（原作按竖直速度，差异第 2 条）。
function ViewKick:OnLand()
    self:Impulse("pitch", -self.data.landImpulse)
    self:Impulse("bump", self.data.landImpulse * 0.6)
end

---@param spring M1KickSpring
---@param springData M1ViewKickSpringData
---@param dt number
---@param maxStep number
local function Integrate(spring, springData, dt, maxStep)
    local steps = math.max(1, math.ceil(dt / maxStep))
    local step = dt / steps
    for _ = 1, steps do
        local accel = -springData.freq * spring.x - springData.damping * spring.v
        spring.v = spring.v + accel * step
        spring.x = spring.x + spring.v * step
    end
end

--- 是否禁止开火（冲刺中，原作 sprintT >= 0.45）。
---@return boolean
function ViewKick:IsFireBlocked()
    return self.blocked
end

---@return number
function ViewKick:Sprint()
    return self.sprint
end

--- 检视计时：活动即重置；超过 idle 秒开始播放一次。
---@param kick M1ViewKick
---@param moving boolean
---@param dt number
local function UpdateIdle(kick, moving, dt)
    local data = kick.data
    if moving then
        kick.idle = 0.0
        if kick.inspect >= 0.0 then kick.inspect = -1.0 end
        return
    end
    if kick.inspect >= 0.0 then return end
    kick.idle = kick.idle + dt
    if kick.idle >= data.inspectIdleSeconds then
        kick.inspect = 0.0
        kick.idle = 0.0
        print(string.format("%s[INSPECT] -> OK | reason=idle seconds=%.1f", TAG, data.inspectSeconds))
    end
end

---@param dt number
---@param speed number 水平速度（米/秒）
---@param onGround boolean
function ViewKick:Update(dt, speed, onGround)
    local data = self.data
    if dt <= 0.0 then return end

    -- 相机转角差 → 摇摆冲量（原作 swY/swP 读 look 增量）
    local rotation = self.cameraNode.worldRotation
    local yaw = rotation:YawAngle()
    local pitch = rotation:PitchAngle()
    local dYaw = yaw - self.lastYaw
    if dYaw > math.pi then dYaw = dYaw - math.pi * 2.0 elseif dYaw < -math.pi then dYaw = dYaw + math.pi * 2.0 end
    local dPitch = pitch - self.lastPitch
    self.lastYaw = yaw
    self.lastPitch = pitch
    local clamp = data.swayClamp
    if dYaw > clamp then dYaw = clamp elseif dYaw < -clamp then dYaw = -clamp end
    if dPitch > clamp then dPitch = clamp elseif dPitch < -clamp then dPitch = -clamp end
    self:Impulse("swayYaw", dYaw * data.swayScale)
    self:Impulse("swayPitch", dPitch * data.swayScale)

    -- 冲刺收枪：原作 sprintT 以 rate 9 向 0/1 收敛
    local sprinting = onGround and speed >= data.sprintSpeedMin
    local sprintTarget = sprinting and 1.0 or 0.0
    local ramp = dt * data.sprintRamp
    if self.sprint < sprintTarget then
        self.sprint = math.min(sprintTarget, self.sprint + ramp)
    elseif self.sprint > sprintTarget then
        self.sprint = math.max(sprintTarget, self.sprint - ramp)
    end
    local blocked = self.sprint >= data.sprintFireBlock
    if blocked ~= self.blocked then
        self.blocked = blocked
        print(string.format("%s[SPRINT] -> %s | sprintT=%.2f block=%.2f speed=%.2f", TAG,
            blocked and "NONE" or "OK", self.sprint, data.sprintFireBlock, speed))
    end

    -- 自动检视：长期不动 → 播放一次（原作 idleT > 24 触发）
    local moving = speed > 0.2 or math.abs(dYaw) > 0.002 or math.abs(dPitch) > 0.002
    UpdateIdle(self, moving, dt)

    for index = 1, #SPRING_KEYS do
        local key = SPRING_KEYS[index]
        local spring = self.springs[key] --[[@as M1KickSpring]]
        local springData = data.springs[key] --[[@as M1ViewKickSpringData]]
        Integrate(spring, springData, dt, data.maxSubStep)
    end

    self:Apply(dt)
end

--- 把弹簧结果写进视图模型节点。
---@param dt number
function ViewKick:Apply(dt)
    local data = self.data
    local mount = self.mount
    ---@type M1KickSpring
    local z = self.springs.z --[[@as M1KickSpring]]
    ---@type M1KickSpring
    local pitch = self.springs.pitch --[[@as M1KickSpring]]
    ---@type M1KickSpring
    local yaw = self.springs.yaw --[[@as M1KickSpring]]
    ---@type M1KickSpring
    local roll = self.springs.roll --[[@as M1KickSpring]]
    ---@type M1KickSpring
    local swayYaw = self.springs.swayYaw --[[@as M1KickSpring]]
    ---@type M1KickSpring
    local swayPitch = self.springs.swayPitch --[[@as M1KickSpring]]
    ---@type M1KickSpring
    local bump = self.springs.bump --[[@as M1KickSpring]]

    local zScale = data.springs.z.offsetScale
    local pitchScale = data.springs.pitch.offsetScale
    local yawScale = data.springs.yaw.offsetScale
    local rollScale = data.springs.roll.offsetScale
    local swayYawScale = data.springs.swayYaw.offsetScale
    local swayPitchScale = data.springs.swayPitch.offsetScale
    local bumpScale = data.springs.bump.offsetScale

    -- 检视进度 0..1（-1 = 未在检视）
    local inspectRoll = 0.0
    local inspectYaw = 0.0
    if self.inspect >= 0.0 then
        self.inspect = self.inspect + dt
        local t = self.inspect / math.max(0.1, data.inspectSeconds)
        if t >= 1.0 then
            self.inspect = -1.0
        else
            -- 先抬起再看，最后复位：sin 半周期包络
            local envelope = math.sin(math.pi * t)
            inspectRoll = math.rad(data.inspectRollDeg) * envelope
            inspectYaw = math.rad(data.inspectYawDeg) * envelope
        end
    end

    local position = Vector3(
        self.basePosition.x + swayYaw.x * swayYawScale,
        self.basePosition.y - bump.x * bumpScale + swayPitch.x * swayPitchScale,
        self.basePosition.z - z.x * zScale)
    if self.sprint > 0.0 then
        position = Vector3(position.x + data.sprintLower.x * self.sprint,
            position.y + data.sprintLower.y * self.sprint,
            position.z + data.sprintLower.z * self.sprint)
    end

    local pitchRad = pitch.x * pitchScale - math.rad(data.sprintPitchDeg) * self.sprint
    local rotation = Quaternion(self.baseYawDeg + math.deg(yaw.x * yawScale + inspectYaw), Vector3(0, 1, 0))
        * Quaternion(math.deg(pitchRad), Vector3(1, 0, 0))
        * Quaternion(math.deg(roll.x * rollScale) , Vector3(0, 0, 1))
    if inspectRoll ~= 0.0 then
        rotation = rotation * Quaternion(math.deg(inspectRoll), Vector3(0, 0, 1))
    end

    mount.fpRoot.position = position
    mount.fpRoot.rotation = rotation
end

---@return string
function ViewKick:Probe()
    local data = self.data
    local z = self.springs.z --[[@as M1KickSpring]]
    local pitch = self.springs.pitch --[[@as M1KickSpring]]
    local text = string.format(
        "%s[PROBE] -> OK | shots=%d z=%.4f v=%.2f pitch=%.4f sprint=%.2f blocked=%s idle=%.1f inspect=%.2f",
        TAG, self.shots, z.x, z.v, pitch.x, self.sprint, tostring(self.blocked), self.idle, self.inspect)
    print(text)
    return text
end

function ViewKick:Destroy()
    -- 复位视图模型，避免退出时枪停在收枪位置
    self.mount.fpRoot.position = self.basePosition
    self.mount.fpRoot.rotation = Quaternion(self.baseYawDeg, Vector3(0, 1, 0))
    print(string.format("%s -> OK | event=destroy shots=%d", TAG, self.shots))
end

return ViewKick