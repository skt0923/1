-- 设置面板：左上「设置」入口按钮 + 居中面板（灵敏度 / 视野 / 反转Y / 重置 / 关闭）。
-- 挂在 ModeMenu 的 UI 根上；打开时 IsOpen() 为 true，玩法据此停掉触摸视角与自检。
local UI = require("urhox-libs/UI")

local TAG = "[M1][SETTINGS]"

local STEP_BUTTON_WIDTH = 44
local STEP_BUTTON_HEIGHT = 34
local PANEL_WIDTH = 300
local ENTRY_LEFT = 12
local ENTRY_TOP = 8

---@class M1SettingsPanel
---@field entry any
---@field panel any
---@field root any
---@field settings M1Settings
---@field rows table<string, any>
---@field open boolean
local SettingsPanel = {}
SettingsPanel.__index = SettingsPanel

---@param props table
---@return any
local function Button(props)
---@diagnostic disable-next-line: redundant-parameter
    return UI.Button(props)
end

---@param props table
---@return any
local function Label(props)
---@diagnostic disable-next-line: redundant-parameter
    return UI.Label(props)
end

---@param props table
---@return any
local function Panel(props)
---@diagnostic disable-next-line: redundant-parameter
    return UI.Panel(props)
end

---@param settings M1Settings
---@param menuRoot any
---@return M1SettingsPanel
function SettingsPanel.Create(settings, menuRoot)
    assert(settings ~= nil and type(settings.SetFov) == "function", "SettingsPanel requires settings")
    assert(menuRoot ~= nil, "SettingsPanel requires the mode menu root")
---@type M1SettingsPanel
    local self = setmetatable({
        entry = nil, panel = nil, root = menuRoot, settings = settings, rows = {}, open = false,
    }, SettingsPanel)
    self.entry = Button {
        text = "设置",
        position = "absolute",
        left = ENTRY_LEFT,
        top = ENTRY_TOP,
        width = 64,
        height = 32,
        fontSize = 13,
        variant = "secondary",
        onClick = function() self:SetOpen(true) end,
    }
    local attached = menuRoot:AddChild(self.entry)
    assert(attached ~= false, "SettingsPanel failed to attach the entry button")
    print(string.format("%s[UI] -> OK | event=create entry=设置", TAG))
    return self
end

---@param text string
---@return any
function SettingsPanel:ValueLabel(text)
    return Label { text = text, fontSize = 15 }
end

function SettingsPanel:Refresh()
    local state = self.settings:GetState()
    local sens = self.rows["灵敏度"]
    if sens ~= nil then sens:SetText(string.format("%.2f×", state.sensitivity / 0.0021)) end
    local fov = self.rows["视野"]
    if fov ~= nil then fov:SetText(string.format("%.0f°", state.fov)) end
    local invert = self.rows["反转Y"]
    if invert ~= nil then invert:SetText(state.invertY and "开启" or "关闭") end
end

---@param title string
---@param initial string
---@param onMinus fun()
---@param onPlus fun()
---@return any
function SettingsPanel:StepRow(title, initial, onMinus, onPlus)
    local value = self:ValueLabel(initial)
    self.rows[title] = value
    return Panel {
        flexDirection = "row",
        alignItems = "center",
        justifyContent = "space-between",
        gap = 8,
        children = {
            Label { text = title, fontSize = 15 },
            Button { text = "－", width = STEP_BUTTON_WIDTH, height = STEP_BUTTON_HEIGHT, fontSize = 15,
                variant = "secondary", onClick = function() onMinus() end },
            value,
            Button { text = "＋", width = STEP_BUTTON_WIDTH, height = STEP_BUTTON_HEIGHT, fontSize = 15,
                variant = "secondary", onClick = function() onPlus() end },
        },
    }
end

---@return any
function SettingsPanel:BuildOverlay()
    local settings = self.settings
    local data = settings.data
    local state = settings:GetState()
    local invertValue = self:ValueLabel(state.invertY and "开启" or "关闭")
    self.rows["反转Y"] = invertValue
    local body = Panel {
        width = PANEL_WIDTH,
        flexDirection = "column",
        gap = 10,
        padding = 16,
        backgroundColor = { 0, 0, 0, 235 },
        children = {
            Label { text = "设置", fontSize = 17 },
            self:StepRow("灵敏度", string.format("%.2f×", state.sensitivity / 0.0021),
                function() settings:SetSensitivity(settings:GetState().sensitivity - data.sensitivityStep) end,
                function() settings:SetSensitivity(settings:GetState().sensitivity + data.sensitivityStep) end),
            self:StepRow("视野", string.format("%.0f°", state.fov),
                function() settings:SetFov(settings:GetState().fov - data.fovStep) end,
                function() settings:SetFov(settings:GetState().fov + data.fovStep) end),
            Panel {
                flexDirection = "row",
                alignItems = "center",
                justifyContent = "space-between",
                gap = 8,
                children = {
                    Label { text = "反转Y", fontSize = 15 },
                    invertValue,
                    Button { text = "切换", width = 76, height = STEP_BUTTON_HEIGHT, fontSize = 14,
                        variant = "secondary",
                        onClick = function() settings:SetInvertY(not settings:GetState().invertY) end },
                },
            },
            Panel {
                flexDirection = "row",
                justifyContent = "space-between",
                gap = 8,
                children = {
                    Button { text = "重置", width = 92, height = 38, fontSize = 14, variant = "secondary",
                        onClick = function() settings:Reset() end },
                    Button { text = "关闭", width = 92, height = 38, fontSize = 14, variant = "primary",
                        onClick = function() self:SetOpen(false) end },
                },
            },
        },
    }
    return Panel {
        position = "absolute",
        left = 0,
        right = 0,
        top = 0,
        bottom = 0,
        justifyContent = "center",
        alignItems = "center",
        backgroundColor = { 0, 0, 0, 120 },
        children = { body },
    }
end

---@param open boolean
function SettingsPanel:SetOpen(open)
    if self.open == open then return end
    self.open = open
    if open then
        local overlay = self:BuildOverlay()
        local attached = self.root:AddChild(overlay)
        assert(attached ~= false, "SettingsPanel failed to attach the panel")
        self.panel = overlay
        print(string.format("%s[OPEN] -> OK | fov=%.0f sensitivity=%.4f invertY=%s", TAG,
            self.settings:GetState().fov, self.settings:GetState().sensitivity,
            tostring(self.settings:GetState().invertY)))
    else
        local panel = self.panel
        if panel ~= nil then panel:Remove() end
        self.panel = nil
        self.rows = {}
        local saved = self.settings:Save()
        print(string.format("%s[CLOSE] -> %s | saved=%s", TAG, saved and "OK" or "FAIL", tostring(saved)))
    end
end

---@return boolean
function SettingsPanel:IsOpen()
    return self.open
end

function SettingsPanel:Destroy()
    if self.open then
        self:SetOpen(false)
    end
    local entry = self.entry
    if entry ~= nil then entry:Remove() end
    self.entry = nil
    self.root = nil
    self.settings = nil
    print(string.format("%s[DESTROY] -> OK", TAG))
end

return SettingsPanel
