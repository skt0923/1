-- 生命 HUD：左下生命条、低血变色、受伤时的屏幕边缘脉冲。
-- 独立的 NanoVG 上下文（同 WeaponHud），物理像素、DPR 1.0。
-- 生命值只从 Combat/PlayerHealth 读，本文件不改血量。
---@class ShooterStatusHud
---@field nvg NVGContextWrapper
---@field font integer
---@field health M1PlayerHealth
---@field data M1StatusHudData
---@field lastHealth number
---@field lastAlive boolean
local StatusHud = {}
StatusHud.__index = StatusHud

---@type ShooterStatusHud|nil
local activeHud

function ShooterStatusHud_Render(eventType, eventData)
    if activeHud ~= nil then
        activeHud:Render()
    end
end

---@param health M1PlayerHealth
---@param hudData M1StatusHudData
---@return ShooterStatusHud
function StatusHud.Create(health, hudData)
    assert(health ~= nil and type(health.GetSnapshot) == "function", "StatusHud requires the player health")
    assert(hudData ~= nil and hudData.bar ~= nil and hudData.edge ~= nil, "StatusHud requires hud data")

    local nvg = nvgCreate(1)
    assert(nvg ~= nil, "StatusHud failed to create NanoVG context")
    local font = nvgCreateFont(nvg, "statushud", "Fonts/MiSans-Regular.ttf")
    assert(font ~= -1, "StatusHud failed to load font: Fonts/MiSans-Regular.ttf")

---@type ShooterStatusHud
    local hud = setmetatable({
        nvg = nvg,
        font = font,
        health = health,
        data = hudData,
        lastHealth = -1.0,
        lastAlive = true,
    }, StatusHud)
    activeHud = hud
    SubscribeToEvent(nvg, "NanoVGRender", "ShooterStatusHud_Render")
    print(string.format("[HUD][STATUS] -> OK | event=create font=%d", font))
    return hud
end

function StatusHud:Render()
    local cfg = self.data
    local gfx = GetGraphics()
    local width = gfx:GetWidth()
    local height = gfx:GetHeight()
    local snap = self.health:GetSnapshot()

    nvgBeginFrame(self.nvg, width, height, 1.0)

    local pulse = snap.hurtPulse
    if pulse > 0.002 then
        local edge = cfg.edge
        local alpha = math.floor(edge.maxAlpha * math.min(1.0, pulse) + 0.5)
        nvgFillColor(self.nvg, nvgRGBA(edge.color[1], edge.color[2], edge.color[3], alpha))
        nvgBeginPath(self.nvg)
        local t = edge.thickness
        nvgRect(self.nvg, 0, 0, width, t)
        nvgRect(self.nvg, 0, height - t, width, t)
        nvgRect(self.nvg, 0, 0, t, height)
        nvgRect(self.nvg, width - t, 0, t, height)
        nvgFill(self.nvg)
    end

    local bar = cfg.bar
    local x = bar.marginLeft
    local y = height - bar.marginBottom - bar.height
    nvgFillColor(self.nvg, nvgRGBA(bar.bgColor[1], bar.bgColor[2], bar.bgColor[3], bar.bgColor[4]))
    nvgBeginPath(self.nvg)
    nvgRect(self.nvg, x, y, bar.width, bar.height)
    nvgFill(self.nvg)

    local ratio = math.max(0.0, math.min(1.0, snap.ratio))
    local color = bar.fillColor
    if not snap.alive then
        color = bar.deadColor
    elseif ratio <= self.health.data.lowRatio then
        color = bar.lowColor
    end
    if ratio > 0.0 then
        nvgFillColor(self.nvg, nvgRGBA(color[1], color[2], color[3], color[4]))
        nvgBeginPath(self.nvg)
        nvgRect(self.nvg, x, y, bar.width * ratio, bar.height)
        nvgFill(self.nvg)
    end

    nvgFontFace(self.nvg, "statushud")
    nvgFontSize(self.nvg, bar.fontSize)
    nvgTextAlign(self.nvg, NVG_ALIGN_LEFT | NVG_ALIGN_BOTTOM)
    nvgFillColor(self.nvg, nvgRGBA(bar.textColor[1], bar.textColor[2], bar.textColor[3], bar.textColor[4]))
    local label = snap.alive and string.format("生命 %d / %d", math.floor(snap.health + 0.5), math.floor(snap.maxHealth + 0.5))
        or "阵亡"
    nvgText(self.nvg, x, y - bar.textGap, label, nil)

    nvgEndFrame(self.nvg)

    if math.abs(snap.health - self.lastHealth) > 0.5 or snap.alive ~= self.lastAlive then
        print(string.format("[HUD][HEALTH] -> OK | health=%.0f/%.0f alive=%s pulse=%.2f",
            snap.health, snap.maxHealth, tostring(snap.alive), pulse))
        self.lastHealth = snap.health
        self.lastAlive = snap.alive
    end
end

function StatusHud:Destroy()
    if activeHud == self then
        activeHud = nil
    end
    UnsubscribeFromEvent(self.nvg, "NanoVGRender")
    nvgDelete(self.nvg)
    print("[HUD][STATUS] -> OK | event=destroy")
end

return StatusHud
