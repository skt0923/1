-- 第一人称射击触屏操控层：摇杆、跳跃、跑步、蹲下、开火、换弹按钮。
-- 走 GameHUD 的 NanoVG 上下文；武器层见 WeaponHud.lua。
local GameHUD = require("urhox-libs/UI/GameHUD")
local VirtualControls = require("urhox-libs/UI/VirtualControls")

---@class ShooterPlayerHud
---@field rig PlayerRig
---@field camera ShooterFirstPersonCamera
---@field fireButton VirtualButton|nil
---@field reloadButton VirtualButton|nil
---@field reloadQueued boolean
---@field viewToggleQueued boolean
---@field viewButton VirtualButton|nil
---@field interactButton VirtualButton|nil
---@field isThirdPerson boolean
---@field fireOverride boolean Self-test hold: treats fire as held while true.
local PlayerHud = {}
PlayerHud.__index = PlayerHud

---@param rig PlayerRig
---@param camera ShooterFirstPersonCamera
---@param controlsData M1ControlsData
---@return ShooterPlayerHud
function PlayerHud.Create(rig, camera, controlsData)
    GameHUD.Initialize()
    GameHUD.SetControls(rig.character.controls)
    GameHUD.Create({
        enableJump = true,
        enableRun = true,
        enableCrouch = true,
        onCrouch = function()
            rig:ToggleCrouch()
        end,
    })
    GameHUD.EnableTouchLook({camera = camera.node})

---@type ShooterPlayerHud
    local hud = setmetatable({
        rig = rig,
        camera = camera,
        fireButton = nil,
        reloadButton = nil,
        reloadQueued = false,
        fireOverride = false,
        viewToggleQueued = false,
        viewButton = nil,
        interactButton = nil,
        isThirdPerson = false,
    }, PlayerHud)

    local fireData = controlsData.combatButtons.fire
    local fireButton = VirtualControls.CreateButton({
        position = fireData.position,
        alignment = {HA_RIGHT, VA_BOTTOM},
        radius = fireData.radius,
        label = fireData.label,
        opacity = fireData.opacity,
        activeOpacity = fireData.activeOpacity,
        alwaysShow = true,
        color = fireData.color,
        pressedColor = fireData.pressedColor,
    })
    hud.fireButton = fireButton

    local reloadData = controlsData.combatButtons.reload
    local reloadButton = VirtualControls.CreateButton({
        position = reloadData.position,
        alignment = {HA_RIGHT, VA_BOTTOM},
        radius = reloadData.radius,
        label = reloadData.label,
        opacity = reloadData.opacity,
        activeOpacity = reloadData.activeOpacity,
        alwaysShow = true,
        color = reloadData.color,
        pressedColor = reloadData.pressedColor,
        on_press = function()
            hud.reloadQueued = true
            print("[HUD][RELOAD] -> OK | event=press")
        end,
    })
    hud.reloadButton = reloadButton

    local viewData = controlsData.viewButton
    local viewButton = VirtualControls.CreateButton({
        position = viewData.position,
        alignment = {HA_RIGHT, VA_BOTTOM},
        radius = viewData.radius,
        label = viewData.label,
        opacity = viewData.opacity,
        activeOpacity = viewData.activeOpacity,
        alwaysShow = true,
        color = viewData.color,
        pressedColor = viewData.pressedColor,
        on_press = function()
            hud.viewToggleQueued = true
        end,
    })
    hud.viewButton = viewButton

    -- 中继交互键：按住累加进度（原作 E 键的触屏等价物）。
    local interactData = controlsData.interactButton
    local interactButton = VirtualControls.CreateButton({
        position = interactData.position,
        alignment = {HA_RIGHT, VA_BOTTOM},
        radius = interactData.radius,
        label = interactData.label,
        opacity = interactData.opacity,
        activeOpacity = interactData.activeOpacity,
        alwaysShow = true,
        color = interactData.color,
        pressedColor = interactData.pressedColor,
    })
    hud.interactButton = interactButton

    print(string.format("[HUD][CREATE] -> OK | platform=%s", GetNativePlatform()))
    return hud
end

---@return boolean
function PlayerHud:IsFireHeld()
    if self.fireOverride then return true end
    if self.fireButton == nil then return false end
    return self.fireButton.isPressed
end

---@param on boolean
function PlayerHud:SetFireOverride(on)
    self.fireOverride = on == true
    if self.fireOverride then
        print("[HUD][FIRE] -> OK | event=override on=true")
    end
end

function PlayerHud:QueueReload()
    self.reloadQueued = true
    print("[HUD][RELOAD] -> OK | event=queue source=selftest")
end

---@return boolean
function PlayerHud:ConsumeViewToggle()
    local queued = self.viewToggleQueued
    self.viewToggleQueued = false
    return queued
end

---@param on boolean
function PlayerHud:SetThirdPerson(on)
    self.isThirdPerson = on == true
end

---@return boolean
function PlayerHud:IsInteractHeld()
    if self.interactButton == nil then return false end
    return self.interactButton.isPressed
end

---@return boolean
function PlayerHud:ConsumeReload()
    local pressed = self.reloadQueued
    self.reloadQueued = false
    return pressed
end

function PlayerHud:Destroy()
    GameHUD.Shutdown()
    print("[HUD][DESTROY] -> OK")
end

---Apply look settings to the shared GameHUD touch controls (sensitivity and invert Y).
---@param settings M1SettingsState
function PlayerHud.ApplySettings(settings)
    assert(settings ~= nil and type(settings.touchSensitivity) == "number", "PlayerHud.ApplySettings needs a state")
    GameHUD.SetTouchLookSensitivity(settings.touchSensitivity)
    GameHUD.SetTouchLookInvertY(settings.invertY)
    print(string.format("[HUD][LOOK] -> OK | touchSensitivity=%.2f invertY=%s",
        settings.touchSensitivity, tostring(settings.invertY)))
end

return PlayerHud
