-- 武器层 HUD：准星、弹药数字、备弹与状态文本；独立 NanoVG 上下文，物理像素、DPR 1.0。
-- 布局数值来自 modes/M1_Port/Data/WeaponHud.lua（e8）。
---@class ShooterWeaponHud
---@field nvg NVGContextWrapper
---@field font integer
---@field rifle ShooterRifle
---@field name string
---@field data M1WeaponHudData
---@field lastAmmo integer
---@field lastReserve integer
---@field lastState string
local WeaponHud = {}
WeaponHud.__index = WeaponHud

---@type ShooterWeaponHud|nil
local activeHud

local STATE_LABELS = {
    idle = "就绪",
    firing = "射击",
    reloading = "换弹中",
    empty = "空仓",
}

function ShooterWeaponHud_Render(eventType, eventData)
    if activeHud ~= nil then
        activeHud:Render()
    end
end

---@param rifle ShooterRifle
---@param hudData M1WeaponHudData
---@param weaponName string
---@return ShooterWeaponHud
function WeaponHud.Create(rifle, hudData, weaponName)
    assert(rifle ~= nil, "WeaponHud requires rifle")
    assert(hudData ~= nil and hudData.crosshair ~= nil and hudData.ammo ~= nil, "WeaponHud requires hud data")
    assert(type(weaponName) == "string", "WeaponHud requires weapon name")

    local nvg = nvgCreate(1)
    assert(nvg ~= nil, "WeaponHud failed to create NanoVG context")
    local font = nvgCreateFont(nvg, "weaponhud", "Fonts/MiSans-Regular.ttf")
    assert(font ~= -1, "WeaponHud failed to load font: Fonts/MiSans-Regular.ttf")

---@type ShooterWeaponHud
    local hud = setmetatable({
        nvg = nvg,
        font = font,
        rifle = rifle,
        name = weaponName,
        data = hudData,
        lastAmmo = -1,
        lastReserve = -1,
        lastState = "",
    }, WeaponHud)
    activeHud = hud
    SubscribeToEvent(nvg, "NanoVGRender", "ShooterWeaponHud_Render")
    print(string.format("[HUD][WEAPON] -> OK | event=create font=%d", font))
    return hud
end

function WeaponHud:Render()
    local gfx = GetGraphics()
    local width = gfx:GetWidth()
    local height = gfx:GetHeight()
    local hudData = self.data
    local cross = hudData.crosshair
    local ammoCfg = hudData.ammo

    nvgBeginFrame(self.nvg, width, height, 1.0)

    local cx = width * 0.5
    local cy = height * 0.5
    nvgStrokeColor(self.nvg, nvgRGBA(cross.color[1], cross.color[2], cross.color[3], cross.color[4]))
    nvgStrokeWidth(self.nvg, cross.thickness)
    nvgBeginPath(self.nvg)
    nvgMoveTo(self.nvg, cx, cy - cross.gap - cross.size)
    nvgLineTo(self.nvg, cx, cy - cross.gap)
    nvgMoveTo(self.nvg, cx, cy + cross.gap)
    nvgLineTo(self.nvg, cx, cy + cross.gap + cross.size)
    nvgMoveTo(self.nvg, cx - cross.gap - cross.size, cy)
    nvgLineTo(self.nvg, cx - cross.gap, cy)
    nvgMoveTo(self.nvg, cx + cross.gap, cy)
    nvgLineTo(self.nvg, cx + cross.gap + cross.size, cy)
    nvgStroke(self.nvg)
    nvgFillColor(self.nvg, nvgRGBA(cross.color[1], cross.color[2], cross.color[3], cross.color[4]))
    nvgBeginPath(self.nvg)
    nvgCircle(self.nvg, cx, cy, cross.dotRadius)
    nvgFill(self.nvg)

    local ammo, reserve, magSize, state, low = self.rifle:GetHudState()
    local color = ammoCfg.color
    if state == "reloading" then
        color = ammoCfg.reloadColor
    elseif low then
        color = ammoCfg.lowColor
    end

    nvgFontFace(self.nvg, "weaponhud")
    nvgFontSize(self.nvg, ammoCfg.fontSize)
    nvgTextAlign(self.nvg, NVG_ALIGN_RIGHT | NVG_ALIGN_TOP)
    nvgFillColor(self.nvg, nvgRGBA(color[1], color[2], color[3], color[4]))
    local top = ammoCfg.topMargin
    nvgText(self.nvg, width - ammoCfg.rightMargin, top,
        string.format("%02d / %03d", ammo, reserve), nil)

    nvgFontSize(self.nvg, ammoCfg.stateFontSize)
    nvgText(self.nvg, width - ammoCfg.rightMargin, top + ammoCfg.fontSize + 6,
        string.format("%s · %s", self.name, STATE_LABELS[state] or state), nil)

    nvgEndFrame(self.nvg)

    if ammo ~= self.lastAmmo or reserve ~= self.lastReserve or state ~= self.lastState then
        print(string.format("[HUD][AMMO] -> OK | ammo=%d/%d reserve=%d state=%s low=%s",
            ammo, magSize, reserve, state, tostring(low)))
        self.lastAmmo = ammo
        self.lastReserve = reserve
        self.lastState = state
    end
end

function WeaponHud:Destroy()
    if activeHud == self then
        activeHud = nil
    end
    UnsubscribeFromEvent(self.nvg, "NanoVGRender")
    nvgDelete(self.nvg)
    print("[HUD][WEAPON] -> OK | event=destroy")
end

return WeaponHud
