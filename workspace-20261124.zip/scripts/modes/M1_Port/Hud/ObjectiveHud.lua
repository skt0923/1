-- modes/M1_Port/Hud/ObjectiveHud.lua: 任务目标 + 中继进度（原作 18-hud 的 h-obj / h-relays）。
-- 用 urhox-libs/UI；进度用文字「A● B○ C○」，不画圆弧（任务卡 m1-p3a 差异第 2 条）。
---@diagnostic disable-next-line: unresolved-require
local UI = require("urhox-libs/UI")
local TAG = "[M1][OBJ]"

---@class M1ObjectiveHud
---@field panel any
---@field title any
---@field body any
---@field text string
---@field pips string
local ObjectiveHud = {}
ObjectiveHud.__index = ObjectiveHud

---@param parent any 菜单根节点。
---@return M1ObjectiveHud
function ObjectiveHud.Create(parent)
    assert(parent ~= nil, "ObjectiveHud requires a parent widget")
    ---@type any
    local title = UI.Label { text = "任务目标", fontSize = 12, color = "secondary" }
    ---@type any
    local body = UI.Label { text = "", fontSize = 13 }
    ---@type any
    local panel = UI.Panel {
        position = "absolute",
        left = 16,
        top = 56,
        width = 260,
        flexDirection = "column",
        gap = 2,
        pointerEvents = "none",
        children = { title, body },
    }
    local attached = parent:AddChild(panel)
    assert(attached ~= false, "ObjectiveHud panel failed to attach")
    local self = setmetatable({panel = panel, title = title, body = body, text = "", pips = ""}, ObjectiveHud)
    print(string.format("%s[CREATE] -> OK | anchor=top-left", TAG))
    return self
end

---@param text string 目标文字。
---@param done integer
---@param total integer
---@param shorts string[] 中继短标（A/B/C）。
function ObjectiveHud:Set(text, done, total, shorts)
    assert(type(text) == "string", "ObjectiveHud:Set needs text")
    local parts = {}
    for index = 1, #shorts do
        local mark = "○"
        if index <= done then mark = "●" end
        parts[#parts + 1] = shorts[index] .. mark
    end
    local pips = string.format("中继 %d/%d  %s", done, total, table.concat(parts, " "))
    if pips ~= self.pips then
        self.pips = pips
        print(string.format("%s[SET] -> OK | text=%s pips=%s", TAG, text, pips))
    end
    self.text = text
    self.body:SetText(text .. "\n" .. pips)
end

function ObjectiveHud:Destroy()
    self.panel = nil
    self.title = nil
    self.body = nil
    print(string.format("%s -> OK | event=destroy", TAG))
end

return ObjectiveHud
