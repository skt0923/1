-- modes/M1_Port/Hud/MenuScreens.lua: 死亡页与结算页（原作 19-menu 的 setDead / setDebrief）。
-- 字段与原作一致：死亡页「生存时间 / 已切断中继」；结算页「用时 / 命中率 / 摧毁机械 / 重试次数 / 行动评级」。
---@diagnostic disable-next-line: unresolved-require
local UI = require("urhox-libs/UI")
local TAG = "[M1][SCREEN]"

---@class M1Debrief
---@field time string
---@field accuracy string
---@field kills integer
---@field retries integer
---@field rating string

---@class M1MenuScreens
---@field panel any
---@field title any
---@field body any
---@field screen string
local Screens = {}
Screens.__index = Screens

---@param parent any
---@return M1MenuScreens
function Screens.Create(parent)
    assert(parent ~= nil, "MenuScreens requires a parent widget")
    ---@type any
    local title = UI.Label { text = "", fontSize = 22, textAlign = "center" }
    ---@type any
    local body = UI.Label { text = "", fontSize = 14, textAlign = "center" }
    ---@type any
    local panel = UI.Panel {
        position = "absolute",
        left = 0,
        right = 0,
        top = 260,
        flexDirection = "column",
        gap = 8,
        alignItems = "center",
        justifyContent = "center",
        pointerEvents = "none",
        children = { title, body },
    }
    local attached = parent:AddChild(panel)
    assert(attached ~= false, "MenuScreens panel failed to attach")
    local self = setmetatable({panel = panel, title = title, body = body, screen = "none"}, Screens)
    print(string.format("%s[CREATE] -> OK | anchor=center", TAG))
    return self
end

--- 死亡页：生存时间 + 已切断中继（原作 setDead）。
---@param timeText string
---@param done integer
---@param total integer
function Screens:ShowDead(timeText, done, total)
    if self.screen == "dead" then return end
    self.screen = "dead"
    self.title:SetText("阵亡")
    self.body:SetText(string.format("生存时间 %s\n已切断中继 %d/%d\n\n重新部署：右上「菜单」", timeText, done, total))
    print(string.format("%s[DEAD] -> OK | time=%s relays=%d/%d", TAG, timeText, done, total))
end

--- 结算页（原作 setDebrief）。
---@param debrief M1Debrief
function Screens:ShowComplete(debrief)
    if self.screen == "complete" then return end
    self.screen = "complete"
    self.title:SetText("行动简报")
    self.body:SetText(string.format([[行动评级 %s

用时 %s
命中率 %s
摧毁机械 %d
重试次数 %d]], debrief.rating, debrief.time, debrief.accuracy, debrief.kills, debrief.retries))
    print(string.format("%s[COMPLETE] -> OK | rating=%s time=%s acc=%s kills=%d retries=%d", TAG,
        debrief.rating, debrief.time, debrief.accuracy, debrief.kills, debrief.retries))
end

function Screens:Hide()
    if self.screen == "none" then return end
    self.screen = "none"
    self.title:SetText("")
    self.body:SetText("")
    print(string.format("%s[HIDE] -> OK", TAG))
end

function Screens:Destroy()
    self.panel = nil
    self.title = nil
    self.body = nil
    print(string.format("%s -> OK | event=destroy", TAG))
end

return Screens
