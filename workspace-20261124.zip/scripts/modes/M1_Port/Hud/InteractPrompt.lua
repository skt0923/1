-- modes/M1_Port/Hud/InteractPrompt.lua: 交互提示（原作 18-hud 的 h-prompt「按住 交互 · 动作」+ 进度环）。
-- 进度环改成文字百分比（任务卡 m1-p3a 差异第 2 条）。
---@diagnostic disable-next-line: unresolved-require
local UI = require("urhox-libs/UI")
local TAG = "[M1][PROMPT]"

---@class M1InteractPrompt
---@field panel any
---@field label any
---@field text string
local InteractPrompt = {}
InteractPrompt.__index = InteractPrompt

---@param parent any
---@return M1InteractPrompt
function InteractPrompt.Create(parent)
    assert(parent ~= nil, "InteractPrompt requires a parent widget")
    ---@type any
    local label = UI.Label { text = "", fontSize = 14 }
    ---@type any
    local panel = UI.Panel {
        position = "absolute",
        left = 0,
        right = 0,
        bottom = 150,
        justifyContent = "center",
        pointerEvents = "none",
        children = { label },
    }
    local attached = parent:AddChild(panel)
    assert(attached ~= false, "InteractPrompt panel failed to attach")
    local self = setmetatable({panel = panel, label = label, text = ""}, InteractPrompt)
    print(string.format("%s[CREATE] -> OK | anchor=bottom-center", TAG))
    return self
end

---@param text string
---@param percent number 0..100，0 表示未按住。
function InteractPrompt:Show(text, percent)
    local round = math.floor(percent + 0.5)
    local next
    if round <= 0 then
        next = string.format("按住 交互 · %s", text)
    else
        next = string.format("保持按住 · %s %d%%", text, round)
    end
    if next ~= self.text then
        self.text = next
        self.label:SetText(next)
    end
end

function InteractPrompt:Hide()
    if self.text ~= "" then
        self.text = ""
        self.label:SetText("")
    end
end

function InteractPrompt:Destroy()
    self.panel = nil
    self.label = nil
    print(string.format("%s -> OK | event=destroy", TAG))
end

return InteractPrompt
