-- modes/M1_Port/Hud/Radio.lua: 无线电字幕（原作 18-hud 的 comms 元素与 radio(text, secs)）。
-- 一条一条播，播完自动收；同时收到多条时排队。
---@diagnostic disable-next-line: unresolved-require
local UI = require("urhox-libs/UI")
local TAG = "[M1][RADIO]"

---@class M1RadioLine
---@field text string
---@field seconds number

---@class M1RadioHud
---@field panel any
---@field label any
---@field queue M1RadioLine[]
---@field current M1RadioLine|nil
---@field left number
local Radio = {}
Radio.__index = Radio

---@param parent any
---@return M1RadioHud
function Radio.Create(parent)
    assert(parent ~= nil, "Radio requires a parent widget")
    ---@type any
    local label = UI.Label { text = "", fontSize = 14, textAlign = "center" }
    ---@type any
    local panel = UI.Panel {
        position = "absolute",
        left = 0,
        right = 0,
        bottom = 200,
        justifyContent = "center",
        pointerEvents = "none",
        children = { label },
    }
    local attached = parent:AddChild(panel)
    assert(attached ~= false, "Radio panel failed to attach")
    local self = setmetatable({panel = panel, label = label, queue = {}, current = nil, left = 0.0}, Radio)
    print(string.format("%s[CREATE] -> OK | anchor=bottom-center", TAG))
    return self
end

---@param text string
---@param seconds number
function Radio:Say(text, seconds)
    if text == nil or text == "" then return end
    local line = { text = text, seconds = math.max(0.5, seconds or 4.0) }
    if self.current == nil then
        self.current = line
        self.left = line.seconds
        self.label:SetText(text)
        print(string.format("%s[SAY] -> OK | text=%s hold=%.1fs", TAG, text, line.seconds))
    else
        self.queue[#self.queue + 1] = line
        print(string.format("%s[QUEUE] -> OK | text=%s pending=%d", TAG, text, #self.queue))
    end
end

---@param dt number
function Radio:Update(dt)
    if self.current == nil then return end
    self.left = self.left - dt
    if self.left > 0.0 then return end
    self.current = nil
    self.left = 0.0
    local nextLine = table.remove(self.queue, 1)
    if nextLine ~= nil then
        self.current = nextLine
        self.left = nextLine.seconds
        self.label:SetText(nextLine.text)
        print(string.format("%s[SAY] -> OK | text=%s hold=%.1fs", TAG, nextLine.text, nextLine.seconds))
    else
        self.label:SetText("")
    end
end

function Radio:Clear()
    self.queue = {}
    self.current = nil
    self.left = 0.0
    self.label:SetText("")
    print(string.format("%s[CLEAR] -> OK", TAG))
end

function Radio:Destroy()
    self.panel = nil
    self.label = nil
    self.queue = {}
    print(string.format("%s -> OK | event=destroy", TAG))
end

return Radio
