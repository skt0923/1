-- modes/M1_Port/Hud/WorldMarker.lua: 世界目标标记（原作 18-hud 语句 1 的 h-marks）。
-- 原作把世界坐标投影到屏幕，视口外的标记钳到屏幕边缘并加边缘箭头；relay 抬高 +1.9、extract +1.2。
-- 投影在这里自己算（相机前向/右向/上向 + fov + 宽高比），不依赖 WorldToScreenPoint 的屏幕坐标系约定
-- （任务卡 m1-p3c 差异第 3 条）。坐标来源由调用方给定，本模块不读玩法状态。
---@diagnostic disable-next-line: unresolved-require
local UI = require("urhox-libs/UI")
local TAG = "[M1][WMARK]"

---@class M1MarkerData
---@field relayHeight number
---@field extractHeight number
---@field edgeMargin number
---@field maxDistance number
---@field relayFormat string
---@field extractFormat string
---@field leftEdge string
---@field rightEdge string

---@class M1MarkerSlot
---@field id string
---@field panel any
---@field label any
---@field text string
---@field visible boolean

---@class M1MarkerCandidate
---@field id string
---@field text string
---@field pos Vector3
---@field height number 抬高量（米），由调用方按 relay / extract 给定。

---@class M1WorldMarker
---@field data M1MarkerData
---@field root any
---@field slots table<string, M1MarkerSlot>
---@field order string[]
---@field shown integer
---@field shownIds string 上一帧显示的 id 串，id 变了也要打日志
---@field cameraLogged boolean 相机参数只在首帧报一次
---@field autoAspectLogged boolean 相机 aspectRatio 为 0（自动）时只报一次
local WorldMarker = {}
WorldMarker.__index = WorldMarker

local SLOT_WIDTH = 96
local SLOT_HEIGHT = 20

---@param parent any 菜单根节点。
---@param data M1MarkerData
---@return M1WorldMarker
function WorldMarker.Create(parent, data)
    assert(parent ~= nil, "WorldMarker requires a parent widget")
    assert(data ~= nil and data.edgeMargin > 0, "WorldMarker requires marker data")
    ---@type any
    local root = UI.Panel {
        position = "absolute",
        left = 0,
        top = 0,
        right = 0,
        bottom = 0,
        pointerEvents = "none",
    }
    local attached = parent:AddChild(root)
    assert(attached ~= false, "WorldMarker root failed to attach")
    local self = setmetatable({
        data = data,
        root = root,
        slots = {},
        order = {},
        shown = 0,
        shownIds = "",
        cameraLogged = false,
        autoAspectLogged = false,
    }, WorldMarker)
    print(string.format("%s[CREATE] -> OK | relayH=%.1f extractH=%.1f maxDist=%.0f", TAG,
        data.relayHeight, data.extractHeight, data.maxDistance))
    return self
end

--- 按需建槽：先隐藏，第一次出现时再显示。
---@param id string
---@return M1MarkerSlot
function WorldMarker:Slot(id)
    local existing = self.slots[id]
    if existing ~= nil then return existing end
    ---@type any
    local label = UI.Label { text = "", fontSize = 13 }
    ---@type any
    local panel = UI.Panel {
        position = "absolute",
        width = SLOT_WIDTH,
        height = SLOT_HEIGHT,
        justifyContent = "center",
        alignItems = "center",
        pointerEvents = "none",
        children = { label },
    }
    local attached = self.root:AddChild(panel)
    assert(attached ~= false, "WorldMarker slot failed to attach: " .. id)
    panel:Hide()
    ---@type M1MarkerSlot
    local created = { id = id, panel = panel, label = label, text = "", visible = false }
    self.slots[id] = created
    self.order[#self.order + 1] = id
    print(string.format("%s[SLOT] -> OK | id=%s", TAG, id))
    return created
end

---@param eye Vector3 玩家眼位，判最大显示距离用。
---@param camera Camera 当前渲染相机组件。
---@param candidates M1MarkerCandidate[] 本帧应显示的标记，来源由调用方按玩法状态给定。
function WorldMarker:Update(eye, camera, candidates)
    assert(camera ~= nil, "WorldMarker needs the camera component")
    local cameraNode = camera:GetNode()
    assert(cameraNode ~= nil, "WorldMarker: camera component has no node")
    local screenWidth = graphics:GetWidth()
    local screenHeight = graphics:GetHeight()
    local uiScale = UI.GetScale()
    assert(screenWidth > 0 and screenHeight > 0, "WorldMarker: invalid screen size")
    assert(uiScale > 0.0, "WorldMarker: invalid UI scale")
    local fov = camera.fov
    -- Urho3D 的 Camera.fov 是角度（FirstPersonCamera 写入 PlayerData.fov = 74）
    assert(fov > 0.0 and fov < 179.0, string.format("WorldMarker: camera fov invalid=%.2f", fov))
    -- Urho3D：aspectRatio 为 0 表示「按视口自动」，此时用屏幕宽高（1.35 真机实测为 0）
    local aspect = camera.aspectRatio
    local aspectAuto = not (aspect > 0.0)
    if aspectAuto then
        aspect = screenWidth / screenHeight
    end
    if not self.cameraLogged then
        self.cameraLogged = true
        print(string.format("%s[CAM] -> OK | fov=%.1f aspect=%.3f source=%s scale=%.2f size=%dx%d",
            TAG, fov, aspect, aspectAuto and "screen" or "camera", uiScale, screenWidth, screenHeight))
    end

    local camPos = cameraNode.worldPosition
    local forward = cameraNode.worldDirection
    local right = cameraNode.worldRight
    local upVector = cameraNode.worldUp
    local tanHalf = math.tan(math.rad(fov) * 0.5)
    local halfW = screenWidth * 0.5
    local halfH = screenHeight * 0.5
    local uiWidth = screenWidth / uiScale
    local uiHeight = screenHeight / uiScale
    local data = self.data
    local margin = data.edgeMargin

    ---@type table<string, boolean>
    local active = {}
    ---@type string[]
    local activeIds = {}
    local shown = 0
    for index = 1, #candidates do
        local candidate = candidates[index] --[[@as M1MarkerCandidate]]
        local pos = candidate.pos
        local dx = pos.x - eye.x
        local dz = pos.z - eye.z
        local flat = math.sqrt(dx * dx + dz * dz)
        if flat <= data.maxDistance then
            local rel = Vector3(pos.x - camPos.x, pos.y + candidate.height - camPos.y, pos.z - camPos.z)
            local depth = rel:DotProduct(forward)
            local ndcX, ndcY, offscreen
            if depth > 0.05 then
                ndcX = rel:DotProduct(right) / (depth * tanHalf * aspect)
                ndcY = rel:DotProduct(upVector) / (depth * tanHalf)
                offscreen = math.abs(ndcX) > 0.9 or math.abs(ndcY) > 0.82
            else
                -- 相机后方：按水平分量贴到左/右边（原作 oe.z > 1 时翻符号）
                local lateral = rel:DotProduct(right)
                ndcX = lateral >= 0.0 and 1.2 or -1.2
                ndcY = 0.0
                offscreen = true
            end
            if offscreen then
                if ndcX < -1.0 then ndcX = -1.0 elseif ndcX > 1.0 then ndcX = 1.0 end
                if ndcY < -0.9 then ndcY = -0.9 elseif ndcY > 0.9 then ndcY = 0.9 end
            end
            local uiX = (halfW + ndcX * halfW) / uiScale
            local uiY = (halfH - ndcY * halfH) / uiScale
            local text = candidate.text
            if offscreen then
                uiX = math.max(margin, math.min(uiWidth - margin, uiX))
                uiY = math.max(margin, math.min(uiHeight - margin, uiY))
                if ndcX < 0.0 then
                    text = data.leftEdge .. text
                else
                    text = data.rightEdge .. text
                end
            end
            local slot = self:Slot(candidate.id)
            slot.panel:SetStyle({
                left = math.floor(uiX + 0.5) - SLOT_WIDTH // 2,
                top = math.floor(uiY + 0.5) - SLOT_HEIGHT // 2,
            })
            if slot.text ~= text then
                slot.text = text
                slot.label:SetText(text)
            end
            if not slot.visible then
                slot.panel:Show()
                slot.visible = true
            end
            active[candidate.id] = true
            activeIds[#activeIds + 1] = candidate.id
            shown = shown + 1
        end
    end

    for index = 1, #self.order do
        local id = self.order[index] --[[@as string]]
        local slot = self.slots[id]
        if slot ~= nil and active[id] == nil and slot.visible then
            slot.panel:Hide()
            slot.visible = false
        end
    end

    local idsText = table.concat(activeIds, ",")
    if shown ~= self.shown or idsText ~= self.shownIds then
        self.shown = shown
        self.shownIds = idsText
        print(string.format("%s[SHOW] -> %s | count=%d ids=%s", TAG, shown > 0 and "OK" or "NONE",
            shown, idsText))
    end
end

--- 探针：槽位文案与可见状态，自检「标记」按钮用。
---@return string
function WorldMarker:Probe()
    local parts = {}
    for index = 1, #self.order do
        local slot = self.slots[self.order[index]] --[[@as M1MarkerSlot]]
        if slot ~= nil then
            parts[#parts + 1] = string.format("%s=%s/%s", slot.id, slot.text,
                slot.visible and "show" or "hide")
        end
    end
    local text = string.format("%s[PROBE] -> OK | shown=%d slots=%d %s", TAG, self.shown,
        #self.order, table.concat(parts, " "))
    print(text)
    return text
end

--- 全部隐藏（死亡、结算、界面弹层时调用）。
function WorldMarker:HideAll()
    for index = 1, #self.order do
        local slot = self.slots[self.order[index]] --[[@as M1MarkerSlot]]
        if slot ~= nil and slot.visible then
            slot.panel:Hide()
            slot.visible = false
        end
    end
    if self.shown ~= 0 then
        self.shown = 0
        self.shownIds = ""
        print(string.format("%s[SHOW] -> NONE | count=0", TAG))
    end
end

function WorldMarker:Destroy()
    local count = #self.order
    if self.root ~= nil then
        self.root:Remove()
        self.root = nil
    end
    self.slots = {}
    self.order = {}
    self.shown = 0
    print(string.format("%s -> OK | event=destroy slots=%d", TAG, count))
end

return WorldMarker