-- AllModes.lua: 玩法清单的唯一来源。新增玩法只改本文件，main.lua 不动。
-- 只写模块路径，不写 id 字面量（第 22 节：id 的唯一来源是各 Mode.lua 的导出）。
-- 顺序即菜单顺序；hidden = true 的项注册但不进菜单。

---@class AllModeEntry
---@field path string require 路径
---@field name string 菜单显示名
---@field kind? string "page" 表示需要注入 deps 的页面类
---@field exitToPath? string 页面类退出后跳转的模块路径
---@field hidden? boolean 不进菜单

---@type AllModeEntry[]
local AllModes = {
    {path = "modes.M1_Port.Mode", name = "港区"},
    {path = "modes.M2_LootRun.Mode", name = "撤离搜刮生存"},
    {path = "modes.M3_EvolveWild.Mode", name = "沙盒建造生存SOC"},
    {path = "modes.M4_BattleRoyale.Mode", name = "淘汰缩圈竞技"},
    -- 展示页仍在菜单里，但不再作为「返回」的落点（返回按钮已删）
    {path = "Showcase.Mode", name = "展示", kind = "page"},
}

return AllModes
