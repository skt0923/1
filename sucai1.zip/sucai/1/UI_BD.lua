-- ============================================================
-- UI_BD.lua：天赋树面板（横向滚动 · 5 页签）
--
-- 布局：
--   [左侧页签 100px] [右侧主区 flexGrow]
--     主区 = [顶部信息栏] + [节点画布（横向滚动）]
--
-- 交互：
--   · 点击节点 → 弹出详情浮层（节点旁）
--   · 详情浮层内点「加点」→ 加点（浮层保留）
--   · 点击其他节点 → 浮层切换
--   · 点击同一节点 → 浮层关闭
-- ============================================================
local Shared = require("Shared")
local Data   = Shared.Data
local Notify = Shared.Notify

local Core   = require("UI_Core")
local Panels = Core
local BD     = require("BD_Tree")

local QLabel    = Core.QLabel
local QButton   = Core.QButton
local OpenModal = Core.OpenModal

local S = Core.shared

-- 状态（跨面板重开保留）
Panels._bdActivePage   = Panels._bdActivePage   or "war"
Panels._bdPopoverId    = Panels._bdPopoverId    or nil   -- 弹出详情的普通节点 ID
Panels._bdPopoverSlot  = Panels._bdPopoverSlot  or nil   -- 弹出详情的核心槽位（1..BD.MAX_CORES）

-- 页签栏宽度
local SIDEBAR_W = 100

-- 节点画布尺寸
-- CANVAS_W = 16×2 + 10×58 + 80 = 692，CANVAS_H = 12×2 + 24 + 4×56 = 272
-- modal 主区宽约 690 → 画布基本刚好放下，ScrollView 仅作小屏兜底
local NODE_SIZE       = 40       -- 节点圆直径
local COL_W           = 58       -- 列间距
local ROW_H           = 56       -- 行间距
local COL_HEADER_H    = 24       -- 顶部列号行高
local CORE_COL_W      = 80       -- 核心槽位列宽
local CANVAS_PAD_X    = 16
local CANVAS_PAD_Y    = 12

local CANVAS_W = CANVAS_PAD_X * 2 + BD.COLS * COL_W + CORE_COL_W
local CANVAS_H = CANVAS_PAD_Y * 2 + COL_HEADER_H + BD.ROWS * ROW_H

local DIR_COLOR = {}
for _, d in ipairs(BD.DIRECTIONS) do DIR_COLOR[d.id] = d.color end

--- 列 X 坐标（画布内像素）
---@param col integer 0..BD.COLS-1
---@return number
local function ColX(col)
    return CANVAS_PAD_X + col * COL_W + COL_W / 2
end

--- 行 Y 坐标（画布内像素）
---@param row integer 0..BD.ROWS-1
---@return number
local function RowY(row)
    return CANVAS_PAD_Y + COL_HEADER_H + row * ROW_H + ROW_H / 2
end

--- 核心槽位 X（列右侧）
---@return number
local function CoreColX()
    return CANVAS_PAD_X + BD.COLS * COL_W + CORE_COL_W / 2
end

--- 核心槽位 Y 坐标（纵向 2 个居中分布）
---@param slotIdx integer 1..BD.MAX_CORES
---@return number
local function CoreSlotY(slotIdx)
    local totalH = BD.ROWS * ROW_H
    local startY = CANVAS_PAD_Y + COL_HEADER_H
    -- 2 个槽位：1/3 和 2/3 处
    local gap = totalH / 3
    return startY + gap * slotIdx
end

--- 画一条从 (x1,y1) 到 (x2,y2) 的线（旋转的细长 Panel）
local function DrawLine(parent, x1, y1, x2, y2, colorHex)
    local dx, dy = x2 - x1, y2 - y1
    local len = math.sqrt(dx * dx + dy * dy)
    if len < 0.5 then return end
    -- Lua 5.4 没有 math.atan2，两参数版 math.atan 即 atan2
    local ang = math.deg(math.atan(dy, dx))
    parent:AddChild(S.UI.Panel {
        position = "absolute",
        left = (x1 + x2) / 2 - len / 2,
        top  = (y1 + y2) / 2 - 1,
        width = len, height = 2,
        backgroundColor = Shared.HexRGB(colorHex),
        borderRadius = 1,
        rotate = ang,
        pointerEvents = "none",
    })
end

--- 画一个普通节点（节点内显示图标，下方显示 层数/满级）
local function DrawNode(parent, node, tree, cx, cy)
    local lv = BD.GetNodeLevel(tree, node.id)
    local learned = lv > 0
    local unlockable = BD.IsUnlockable(tree, node.id)
    local dirColor = DIR_COLOR[node.dir] or "#888888"

    -- 三档背景：满级 = 方向色；1~2 级 = 中灰；0 级 = 暗
    local bgHex
    if lv >= BD.NODE_MAX_LEVEL then
        bgHex = dirColor
    elseif learned then
        bgHex = "#5a5a5a"
    elseif unlockable then
        bgHex = "#3a3a3a"
    else
        bgHex = "#1a1a1a"
    end

    local borderHex = (lv >= BD.NODE_MAX_LEVEL) and "#ffffff"
        or (learned and dirColor or (unlockable and dirColor or "#2a2a2a"))

    local icon = BD.GetNodeIcon(node)
    local nid = node.id

    local nodeBtn = Panels.Btn {
        text = icon,
        position = "absolute",
        left = cx - NODE_SIZE / 2,
        top  = cy - NODE_SIZE / 2,
        width = NODE_SIZE, height = NODE_SIZE,
        fontSize = 16,
        paddingHorizontal = 0,
        borderRadius = NODE_SIZE / 2,
        variant = "secondary",
        backgroundColor = Shared.HexRGB(bgHex),
        borderColor = Shared.HexRGB(borderHex),
        borderWidth = 2,
        onClick = function()
            if Panels._bdPopoverId == nid then
                Panels._bdPopoverId = nil
            else
                Panels._bdPopoverId = nid
                Panels._bdPopoverSlot = nil
            end
            Panels.OpenBD()
        end,
    }
    parent:AddChild(nodeBtn)

    -- 节点下方："2/3" 格式（当前层数 / 满级）
    parent:AddChild(S.UI.Label {
        text = string.format("%d/%d", lv, BD.NODE_MAX_LEVEL),
        position = "absolute",
        left = cx - 20, top = cy + NODE_SIZE / 2 + 1,
        width = 40, textAlign = "center",
        fontSize = 10,
        fontColor = Shared.HexRGB(lv >= BD.NODE_MAX_LEVEL and "#ffcc66" or "#888888"),
    })
end

--- 画一个核心槽位（图标 + 槽位下标）
local function DrawCoreSlot(parent, tree, dir, slotIdx, cx, cy)
    local unlocked = BD.IsSlotUnlocked(tree, dir, slotIdx)
    local coreId = BD.GetSelectedCore(tree, dir, slotIdx)
    local coreData = coreId and BD.CORE_DATA[coreId] or nil
    local dirColor = DIR_COLOR[dir] or "#888888"

    local bgHex = coreData and dirColor or (unlocked and "#3a3a3a" or "#1a1a1a")
    local borderHex = coreData and "#ffffff" or (unlocked and "#ffcc66" or "#2a2a2a")

    -- 核心有图标用图标；空槽用 ◇；锁用 🔒
    local label
    if coreData then
        label = BD.GetCoreIcon(coreId)
    elseif unlocked then
        label = "◇"
    else
        label = "🔒"
    end

    local slotIdxLocal = slotIdx
    local slotBtn = Panels.Btn {
        text = label,
        position = "absolute",
        left = cx - NODE_SIZE / 2,
        top  = cy - NODE_SIZE / 2,
        width = NODE_SIZE, height = NODE_SIZE,
        fontSize = 16, paddingHorizontal = 0,
        borderRadius = NODE_SIZE / 2,
        backgroundColor = Shared.HexRGB(bgHex),
        borderColor = Shared.HexRGB(borderHex),
        borderWidth = 2,
        onClick = function()
            if Panels._bdPopoverSlot == slotIdxLocal then
                Panels._bdPopoverSlot = nil
            else
                Panels._bdPopoverSlot = slotIdxLocal
                Panels._bdPopoverId = nil
            end
            Panels.OpenBD()
        end,
    }
    parent:AddChild(slotBtn)

    -- 槽位下标（1 / 2），解锁后变金色
    parent:AddChild(S.UI.Label {
        text = tostring(slotIdx),
        position = "absolute",
        left = cx - 20, top = cy + NODE_SIZE / 2 + 1,
        width = 40, textAlign = "center",
        fontSize = 10,
        fontColor = Shared.HexRGB(unlocked and "#ffcc66" or "#555555"),
    })
end

--- 打开天赋树面板
function Panels.OpenBD()
    local modal = OpenModal("bd", "天赋", "xl")

    local tree = Data.value.bdTree
    if not Shared.IsBDTreeValid(tree) then
        tree = Shared.NewBDTree()
        Data.value.bdTree = tree
    end
    -- 老存档清洗
    local removed = BD.SanitizeNodes(tree)
    if removed > 0 then
        print(string.format("[BD] 清洗老存档：移除 %d 条无效节点/核心", removed))
    end

    local activePage = Panels._bdActivePage

    -- ============ 左侧页签栏 ============
    local sidebarChildren = {}

    -- 总览页签（特殊）
    table.insert(sidebarChildren, Panels.Btn {
        text = "总览",
        fontSize = 13, height = 44, width = "100%", paddingHorizontal = 6,
        variant = (activePage == "overview") and "primary" or "secondary",
        onClick = function()
            Panels._bdActivePage = "overview"
            Panels._bdPopoverId = nil
            Panels._bdPopoverSlot = nil
            Panels.OpenBD()
        end,
    })

    -- 4 个方向页签
    -- ⚠️ Button 文本是单行渲染（multiline=false），"\n" 不会换行，保持一行
    for _, d in ipairs(BD.DIRECTIONS) do
        local inv = BD.GetPageInvestment(tree, d.id)
        local slots = BD.GetUnlockedSlotCount(tree, d.id)
        table.insert(sidebarChildren, Panels.Btn {
            text = string.format("%s  %d点·%d槽", d.name, inv, slots),
            fontSize = 11, height = 44, width = "100%", paddingHorizontal = 6,
            variant = (activePage == d.id) and "primary" or "secondary",
            onClick = function()
                Panels._bdActivePage = d.id
                Panels._bdPopoverId = nil
                Panels._bdPopoverSlot = nil
                Panels.OpenBD()
            end,
        })
    end

    local sidebar = S.UI.Panel {
        flexDirection = "column", gap = 6,
        width = SIDEBAR_W,
        paddingHorizontal = 4,
        children = sidebarChildren,
    }

    -- ============ 顶部信息栏 ============
    local spent = BD.TotalSpent(tree)
    local total = BD.GetTotalPoints()
    local remain = total - spent
    local resetCost = BD.GetResetCost(tree)
    local pageSpent = (activePage ~= "overview") and BD.GetPageInvestment(tree, activePage) or 0
    local pageResetCost = pageSpent * BD.RESET_GOLD_PER_POINT

    local resetPageBtn = QButton(
        pageResetCost > 0 and string.format("重置(%d)", pageResetCost) or "重置",
        function()
            if activePage == "overview" then
                Notify.Toast("请先选择一个方向页")
                return
            end
            if pageResetCost <= 0 then
                Notify.Toast("本页未点任何节点")
                return
            end
            Panels.Confirm("重置本页",
                string.format("退还本页 %d 点，消耗 %d 金币。\n\n确定？", pageSpent, pageResetCost),
                function()
                    local ok, reason = BD.ResetPage(tree, activePage)
                    if not ok then Notify.Toast(reason or "重置失败") return end
                    Panels._bdPopoverId = nil
                    Panels._bdPopoverSlot = nil
                    Notify.Toast("已重置本页")
                    Panels.OpenBD()
                end)
        end,
        pageResetCost > 0 and "danger" or "secondary")

    local resetAllBtn = QButton(
        resetCost > 0 and string.format("清空(%d)", resetCost) or "清空",
        function()
            if resetCost <= 0 then
                Notify.Toast("未点任何节点")
                return
            end
            Panels.Confirm("清空全树",
                string.format("退还全部 %d 点，消耗 %d 金币。\n\n确定？", spent, resetCost),
                function()
                    local ok, reason = BD.Reset(tree)
                    if not ok then Notify.Toast(reason or "重置失败") return end
                    Panels._bdPopoverId = nil
                    Panels._bdPopoverSlot = nil
                    Notify.Toast("已清空")
                    Panels.OpenBD()
                end)
        end,
        resetCost > 0 and "danger" or "secondary")

    -- 已选核心汇总（当前页）
    local selectedCores = {}
    if activePage ~= "overview" and tree.cores and tree.cores[activePage] then
        for _, cid in pairs(tree.cores[activePage]) do
            local cd = BD.CORE_DATA[cid]
            if cd then table.insert(selectedCores, cd.name) end
        end
    end
    local coreText = #selectedCores > 0 and table.concat(selectedCores, " · ") or ""

    local topBar = S.UI.Panel {
        flexDirection = "row", alignItems = "center", gap = 10,
        paddingHorizontal = 4,
        children = {
            -- 圆点 + 剩余点数
            S.UI.Panel {
                flexDirection = "row", alignItems = "center", gap = 6,
                paddingHorizontal = 8, paddingVertical = 4,
                backgroundColor = Shared.HexRGB("#3a2a1a"),
                borderRadius = 6,
                children = {
                    S.UI.Label {
                        text = "●", fontSize = 14,
                        fontColor = Shared.HexRGB("#ffcc66"),
                    },
                    S.UI.Label {
                        text = tostring(remain),
                        fontSize = 14, fontColor = Shared.HexRGB("#ffcc66"),
                    },
                },
            },
            -- 文本
            S.UI.Label {
                text = string.format("当前天赋点已加 %d 点天赋（共 %d）", spent, total),
                fontSize = 12, fontColor = Panels.THEME.textPrimary,
                flexGrow = 1, flexBasis = 0,
            },
            -- 已选核心
            coreText ~= "" and S.UI.Label {
                text = "◆ " .. coreText,
                fontSize = 11, fontColor = Shared.HexRGB("#aaffcc"),
                maxLines = 1,
            } or S.UI.Panel { width = 0 },
            -- 重置 / 清空
            resetPageBtn,
            resetAllBtn,
        },
    }

    -- ============ 主内容区 ============
    local contentChildren = { topBar }

    if activePage == "overview" then
        -- 总览：4 个方向卡片
        local cards = {}
        for _, d in ipairs(BD.DIRECTIONS) do
            local inv = BD.GetPageInvestment(tree, d.id)
            local slots = BD.GetUnlockedSlotCount(tree, d.id)
            local cores = {}
            if tree.cores and tree.cores[d.id] then
                for _, cid in pairs(tree.cores[d.id]) do
                    local cd = BD.CORE_DATA[cid]
                    if cd then table.insert(cores, cd.name) end
                end
            end
            table.insert(cards, S.UI.Panel {
                flexDirection = "column", gap = 4,
                flexGrow = 1, flexBasis = 0,
                padding = 10,
                backgroundColor = Panels.THEME.bgCard,
                borderRadius = 8,
                borderWidth = 1,
                borderColor = Shared.HexRGB(DIR_COLOR[d.id] or "#555555"),
                children = {
                    S.UI.Label {
                        text = d.name, fontSize = 15,
                        fontColor = Shared.HexRGB(DIR_COLOR[d.id]),
                    },
                    S.UI.Label {
                        text = string.format("投入 %d 点 · 槽位 %d/%d", inv, slots, BD.MAX_CORES),
                        fontSize = 11, fontColor = Panels.THEME.textSecond,
                    },
                    S.UI.Label {
                        text = #cores > 0 and ("核心：" .. table.concat(cores, "、")) or "未选核心",
                        fontSize = 10, fontColor = Panels.THEME.textDim,
                    },
                },
            })
        end
        table.insert(contentChildren, S.UI.Panel {
            flexDirection = "row", gap = 8, marginTop = 8,
            children = cards,
        })
    else
        -- 方向页：节点画布
        local dirColor = DIR_COLOR[activePage] or "#888888"
        local canvas = S.UI.Panel {
            position = "relative",
            width = CANVAS_W, height = CANVAS_H,
            backgroundColor = Panels.THEME.bgPanelDeep,
            borderRadius = 8,
        }

        -- ① 列号行
        for col = 0, BD.COLS - 1 do
            local x = ColX(col)
            local unlocked = BD.IsColUnlocked(tree, activePage, col)
            -- 未解锁时显示 "N 🔒"，让玩家知道为什么点不了
            local colText = unlocked and tostring(col) or (tostring(col) .. " 🔒")
            canvas:AddChild(S.UI.Label {
                text = colText,
                position = "absolute",
                left = x - 30, top = CANVAS_PAD_Y,
                width = 60, textAlign = "center",
                fontSize = 12,
                fontColor = Shared.HexRGB(unlocked and "#ffcc66" or "#555555"),
            })
            -- 列号下的分隔线
            if col > 0 and unlocked then
                canvas:AddChild(S.UI.Panel {
                    position = "absolute",
                    left = x - 20, top = CANVAS_PAD_Y + 20,
                    width = 40, height = 1,
                    backgroundColor = Shared.HexRGB("#444444"),
                    pointerEvents = "none",
                })
            end
        end

        -- ② 核心槽位列号
        canvas:AddChild(S.UI.Label {
            text = "核心",
            position = "absolute",
            left = CoreColX() - 20, top = CANVAS_PAD_Y,
            width = 40, textAlign = "center",
            fontSize = 13, fontColor = Shared.HexRGB("#ffcc66"),
        })

        -- ③ 连线（先画，节点会覆盖在上面）
        for col = 0, BD.COLS - 1 do
            for row = 0, BD.ROWS - 1 do
                local nodeId = activePage .. "_n" .. col .. "_" .. row
                if BD.NODES[nodeId] then
                    local x, y = ColX(col), RowY(row)
                    -- 列间连线（连到右一列）
                    if col < BD.COLS - 1 then
                        local rightId = activePage .. "_n" .. (col + 1) .. "_" .. row
                        if BD.NODES[rightId] then
                            local rx, ry = ColX(col + 1), RowY(row)
                            local bothLearned = BD.IsLearned(tree, nodeId) and BD.IsLearned(tree, rightId)
                            local colUnlocked = BD.IsColUnlocked(tree, activePage, col + 1)
                            local lineColor = bothLearned and dirColor
                                or (colUnlocked and "#333333" or "#1a1a1a")
                            DrawLine(canvas, x, y, rx, ry, lineColor)
                        end
                    end
                    -- 列内连线（连到下一位）
                    if row < BD.ROWS - 1 then
                        local downId = activePage .. "_n" .. col .. "_" .. (row + 1)
                        if BD.NODES[downId] then
                            local dx, dy = ColX(col), RowY(row + 1)
                            local bothLearned = BD.IsLearned(tree, nodeId) and BD.IsLearned(tree, downId)
                            local lineColor = bothLearned and dirColor or "#222222"
                            DrawLine(canvas, x, y, dx, dy, lineColor)
                        end
                    end
                    -- 最后一列连到核心槽位
                    if col == BD.COLS - 1 then
                        local lastNodeY = RowY(row)
                        for slotIdx = 1, BD.MAX_CORES do
                            local sy = CoreSlotY(slotIdx)
                            if math.abs(lastNodeY - sy) < ROW_H then
                                DrawLine(canvas, x, lastNodeY,
                                    CoreColX(), sy, "#333333")
                            end
                        end
                    end
                end
            end
        end

        -- ④ 节点
        for col = 0, BD.COLS - 1 do
            for row = 0, BD.ROWS - 1 do
                local nodeId = activePage .. "_n" .. col .. "_" .. row
                local node = BD.NODES[nodeId]
                if node then
                    DrawNode(canvas, node, tree, ColX(col), RowY(row))
                end
            end
        end

        -- 核心槽位（纵向 2 个，居中分布）
        for slotIdx = 1, BD.MAX_CORES do
            DrawCoreSlot(canvas, tree, activePage, slotIdx,
                CoreColX(), CoreSlotY(slotIdx))
        end

        -- ⑥ 详情浮层（点击节点/槽位后）
        local popover
        if Panels._bdPopoverId and BD.NODES[Panels._bdPopoverId] then
            local n = BD.NODES[Panels._bdPopoverId]
            local lv = BD.GetNodeLevel(tree, n.id)
            local maxed = lv >= BD.NODE_MAX_LEVEL
            local learned = lv > 0
            local unlockable, reason = BD.IsUnlockable(tree, n.id)

            local curText = BD.FormatBonus(BD.GetNodeBonusAtLevel(n, lv))
            local maxText = BD.FormatBonus(BD.GetNodeBonusAtLevel(n, BD.NODE_MAX_LEVEL))

            -- 浮层定位：节点右下，超出边界则左移
            local px = ColX(n.col) + NODE_SIZE / 2 + 8
            local py = RowY(n.row) - 40
            if px + 220 > CANVAS_W then px = ColX(n.col) - 220 - NODE_SIZE / 2 - 8 end
            if py < CANVAS_PAD_Y then py = CANVAS_PAD_Y end

            -- 按钮：已满 = 只显示降级；未满 = [降级（如果已点）] + 加点
            local btns = {}
            if learned then
                table.insert(btns, Panels.Btn {
                    text = "降级", fontSize = 11, height = 28, paddingHorizontal = 10,
                    variant = "danger",
                    onClick = function()
                        local ok, r = BD.Unlearn(tree, n.id)
                        if not ok then Notify.Toast(r or "降级失败") return end
                        Panels.OpenBD()
                    end,
                })
            end
            if not maxed then
                table.insert(btns, Panels.Btn {
                    text = unlockable and "加点" or "不可点",
                    fontSize = 11, height = 28, paddingHorizontal = 12,
                    variant = unlockable and "primary" or "secondary",
                    onClick = function()
                        local ok, r = BD.Learn(tree, n.id)
                        if not ok then Notify.Toast(r or "加点失败") return end
                        Panels.OpenBD()
                    end,
                })
            end

            popover = S.UI.Panel {
                position = "absolute",
                left = px, top = py,
                width = 220,
                padding = 10,
                backgroundColor = Shared.HexRGB("#1a1a1a"),
                borderRadius = 8,
                borderWidth = 1,
                borderColor = Shared.HexRGB("#555555"),
                flexDirection = "column", gap = 4,
                children = {
                    S.UI.Label {
                        text = string.format("小型天赋 %d/%d", lv, BD.NODE_MAX_LEVEL),
                        fontSize = 12, fontColor = Shared.HexRGB("#ffcc66"),
                    },
                    S.UI.Label {
                        text = "当前：" .. curText,
                        fontSize = 11, fontColor = Panels.THEME.textPrimary,
                    },
                    S.UI.Label {
                        text = string.format("每级：%s",
                            BD.FormatBonus(BD.GetNodeBonusAtLevel(n, 1))),
                        fontSize = 10, fontColor = Panels.THEME.textDim,
                    },
                    (not maxed) and S.UI.Label {
                        text = "满级：" .. maxText,
                        fontSize = 10, fontColor = Panels.THEME.textSecond,
                    } or S.UI.Panel { height = 0 },
                    (not learned and not unlockable and reason)
                        and S.UI.Label {
                            text = "⚠ " .. reason, fontSize = 10,
                            fontColor = Shared.HexRGB("#ff7878"),
                        }
                        or S.UI.Panel { height = 0 },
                    S.UI.Panel {
                        flexDirection = "row", justifyContent = "flex-end", gap = 6,
                        children = btns,
                    },
                },
            }
            canvas:AddChild(popover)
        elseif Panels._bdPopoverSlot then
            -- 核心槽位浮层
            local slotIdx = Panels._bdPopoverSlot
            local unlocked = BD.IsSlotUnlocked(tree, activePage, slotIdx)
            local curCore = BD.GetSelectedCore(tree, activePage, slotIdx)
            local pool = BD.CORE_POOL[activePage] or {}

            local px = CoreColX() - 240 - NODE_SIZE / 2 - 8
            local py = CoreSlotY(slotIdx) - 60
            if py < CANVAS_PAD_Y then py = CANVAS_PAD_Y end

            local popoverChildren = {
                S.UI.Label {
                    text = string.format("核心槽位 %d", slotIdx),
                    fontSize = 12, fontColor = Shared.HexRGB("#ffcc66"),
                },
            }

            -- 未解锁：显示解锁进度（但仍列出核心池，让玩家看到该页有哪些核心可选）
            if not unlocked then
                local th = BD.CORE_SLOT_THRESHOLDS[slotIdx] or 0
                table.insert(popoverChildren, S.UI.Label {
                    text = string.format("未解锁（需 %d 点，当前 %d）",
                        th, BD.GetPageInvestment(tree, activePage)),
                    fontSize = 10, fontColor = Shared.HexRGB("#ff7878"),
                })
            end

            -- 无论解锁与否都列出核心池
            for _, cid in ipairs(pool) do
                local cd = BD.CORE_DATA[cid]
                local isCur = (curCore == cid)
                local icon = BD.GetCoreIcon(cid)
                local btn = Panels.Btn {
                    text = string.format("%s %s%s",
                        icon, cd and cd.name or cid,
                        isCur and " ✓" or ""),
                    fontSize = 10, height = 26, paddingHorizontal = 8,
                    variant = isCur and "primary" or "secondary",
                    onClick = function()
                        if not unlocked then
                            Notify.Toast("槽位未解锁，无法选择")
                            return
                        end
                        local ok, reason = BD.SelectCore(tree, activePage, slotIdx, cid)
                        if not ok then Notify.Toast(reason or "选择失败") return end
                        Notify.Toast("已选：" .. (cd and cd.name or cid))
                        Panels.OpenBD()
                    end,
                }
                if not unlocked then btn:SetDisabled(true) end
                table.insert(popoverChildren, btn)
            end

            popover = S.UI.Panel {
                position = "absolute",
                left = px, top = py,
                width = 240,                     -- 从 220 加宽（核心名较长）
                padding = 10,
                backgroundColor = Shared.HexRGB("#1a1a1a"),
                borderRadius = 8,
                borderWidth = 1,
                borderColor = Shared.HexRGB("#555555"),
                flexDirection = "column", gap = 4,
                children = popoverChildren,
            }
            canvas:AddChild(popover)
        end

        table.insert(contentChildren, S.UI.ScrollView {
            scrollX = true,
            flexGrow = 1, flexBasis = 0, maxHeight = CANVAS_H + 10,
            marginTop = 8,
            children = { canvas },
        })
    end

    -- 点数来源提示
    if total == 0 then
        table.insert(contentChildren, S.UI.Label {
            text = "穿满 8 件装备以获得天赋点数",
            fontSize = 11, fontColor = Panels.THEME.textDim,
        })
    elseif remain <= 0 then
        table.insert(contentChildren, S.UI.Label {
            text = "点数已用尽，换更高品质的装备可获得更多点数",
            fontSize = 11, fontColor = Panels.THEME.textDim,
        })
    end

    local mainArea = S.UI.Panel {
        flexDirection = "column", gap = 6,
        flexGrow = 1, flexBasis = 0,
        children = contentChildren,
    }

    modal:AddContent(S.UI.Panel {
        flexDirection = "row", gap = 10,
        children = { sidebar, mainArea },
    })

    modal:Open()
end

return Panels
