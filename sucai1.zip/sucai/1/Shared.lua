-- ============================================================
-- Shared.lua：跨玩法共享层
--
-- 客户端和服务端都 require 本文件，拿到同一张表。
-- 内容：
--   Util          通用工具函数
--   Shared        常量 / Notify / UIState
--   Protocol      消息协议（C2S / S2C 事件名）
--   ModeRegistry  玩法注册表
--   TapLogin      TapTap 登录
--
-- 不含任何玩法专属逻辑。新增玩法不改本文件。
-- ============================================================
local Shared = {}

-- ============================================================
-- 一、Util：通用工具
-- ============================================================

--- "#rrggbb" → {r,g,b,a}
Shared.HexRGB = function(hex, alpha)
    alpha = alpha or 255
    if type(hex) ~= "string" then return { 255, 255, 255, alpha } end
    if hex:sub(1, 1) == "#" then hex = hex:sub(2) end
    return {
        tonumber(hex:sub(1, 2), 16) or 255,
        tonumber(hex:sub(3, 4), 16) or 255,
        tonumber(hex:sub(5, 6), 16) or 255,
        alpha,
    }
end

--- 普通 table → VariantMap（SendRemoteEvent 需要）
Shared.ToVariantMap = function(tbl)
    local vm = VariantMap()
    for k, v in pairs(tbl) do
        vm[k] = Variant(v)
    end
    return vm
end

--- 安全 JSON 解析
Shared.SafeDecode = function(str)
    if type(str) ~= "string" or str == "" then return nil end
    local ok, result = pcall(cjson.decode, str)
    if ok and type(result) == "table" then return result end
    print("[Shared] ⚠️ JSON 解析失败: " .. tostring(str))
    return nil
end

--- 从数组移除某值
Shared.RemoveFromArray = function(arr, v)
    if type(arr) ~= "table" then return false end
    for i, x in ipairs(arr) do
        if x == v then
            table.remove(arr, i)
            return true
        end
    end
    return false
end

-- ============================================================
-- 二、UI 状态
-- ============================================================

Shared.UIState = {
    modalOpen = false,
}

-- ============================================================
-- 三、通用常量
-- ============================================================

Shared.C = {
    MAX_PLAYERS = 10,
}

-- ============================================================
-- 四、Notify：Toast 接口
-- ============================================================

Shared.Notify = {
    _impl = nil,
}

function Shared.Notify.SetImpl(fn)
    Shared.Notify._impl = fn
end

function Shared.Notify.Toast(text, color)
    print("[Toast] " .. tostring(text))
    if Shared.Notify._impl then
        Shared.Notify._impl(text, color)
    end
end

-- ============================================================
-- 五、Protocol：消息协议
-- ============================================================

Shared.Protocol = {}

-- ============ 上行（客户端 → 服务端）============
Shared.Protocol.C2S = {
    CLIENT_READY     = "C2S_ClientReady",
    ACTION_REQUEST   = "C2S_ActionRequest",
    ENTER_MODE       = "C2S_EnterMode",
    LEAVE_MODE       = "C2S_LeaveMode",
}

-- ============ 下行（服务端 → 客户端）============
Shared.Protocol.S2C = {
    ASSIGN_PLAYER    = "S2C_AssignPlayer",
    ACTION_RESULT    = "S2C_ActionResult",
    STATE_UPDATE     = "S2C_StateUpdate",
    TOAST            = "S2C_Toast",
    ONLINE_COUNT     = "S2C_OnlineCount",
    KICKED           = "S2C_Kicked",
    SERVER_FULL      = "S2C_ServerFull",
    SAVE_FAILED      = "S2C_SaveFailed",
    MODE_BROADCAST   = "S2C_ModeBroadcast",
}

--- 事件名列表
Shared.Protocol.C2S_LIST = {}
for _, v in pairs(Shared.Protocol.C2S) do
    table.insert(Shared.Protocol.C2S_LIST, v)
end
table.sort(Shared.Protocol.C2S_LIST)

Shared.Protocol.S2C_LIST = {}
for _, v in pairs(Shared.Protocol.S2C) do
    table.insert(Shared.Protocol.S2C_LIST, v)
end
table.sort(Shared.Protocol.S2C_LIST)

--- 服务端注册所有上行事件
function Shared.Protocol.RegisterServerEvents()
    for _, name in ipairs(Shared.Protocol.C2S_LIST) do
        network:RegisterRemoteEvent(name)
    end
end

--- 客户端注册所有下行事件
function Shared.Protocol.RegisterClientEvents()
    for _, name in ipairs(Shared.Protocol.S2C_LIST) do
        network:RegisterRemoteEvent(name)
    end
end

--- 网络模式枚举
Shared.Protocol.NetworkMode = {
    TURN_BASED = "turn_based",
}

-- ============================================================
-- 六、ModeRegistry：玩法注册表
-- ============================================================

Shared.ModeRegistry = {}

---@type table<string, table>
local modes_ = {}
---@type string[]
local order_ = {}

function Shared.ModeRegistry.RegisterClient(cfg)
    assert(type(cfg) == "table", "cfg 必须是表")
    assert(type(cfg.id) == "string" and cfg.id ~= "", "cfg.id 必填")
    assert(type(cfg.name) == "string" and cfg.name ~= "", "cfg.name 必填")

    if not modes_[cfg.id] then table.insert(order_, cfg.id) end

    local existing = modes_[cfg.id] or {}
    existing.id          = cfg.id
    existing.name        = cfg.name
    existing.icon        = cfg.icon or existing.icon or "🎮"
    existing.desc        = cfg.desc or existing.desc or ""
    existing.minPlayers  = cfg.minPlayers or existing.minPlayers or 1
    existing.maxPlayers  = cfg.maxPlayers or existing.maxPlayers or 8
    existing.networkMode = cfg.networkMode or existing.networkMode or "turn_based"
    existing.clientScene = cfg.clientScene
        or existing.clientScene
        or ("modes." .. cfg.id .. ".ClientScene")

    modes_[cfg.id] = existing
    print("[ModeRegistry] 客户端已注册：" .. cfg.id .. " (" .. cfg.name .. ")")
end

function Shared.ModeRegistry.RegisterServer(cfg)
    assert(type(cfg) == "table", "cfg 必须是表")
    assert(type(cfg.id) == "string" and cfg.id ~= "", "cfg.id 必填")

    if not modes_[cfg.id] then table.insert(order_, cfg.id) end

    local existing = modes_[cfg.id] or {}
    existing.id          = cfg.id
    existing.name        = cfg.name or existing.name or cfg.id
    existing.minPlayers  = cfg.minPlayers or existing.minPlayers or 1
    existing.maxPlayers  = cfg.maxPlayers or existing.maxPlayers or 8
    existing.networkMode = cfg.networkMode or existing.networkMode or "turn_based"

    modes_[cfg.id] = existing
    print("[ModeRegistry] 服务端已注册：" .. cfg.id)
end

function Shared.ModeRegistry.GetAll()
    local list = {}
    for _, id in ipairs(order_) do
        table.insert(list, modes_[id])
    end
    return list
end

function Shared.ModeRegistry.Get(id)
    return modes_[id]
end

function Shared.ModeRegistry.Exists(id)
    return modes_[id] ~= nil
end

-- ============================================================
-- 七、TapLogin：TapTap 登录
-- ============================================================

Shared.TapLogin = {
    playerId_ = nil,
    nickname_ = nil,
    loggedIn_ = false,
}

function Shared.TapLogin.Login(onDone)
    if Shared.TapLogin.loggedIn_ then
        if onDone then
            onDone(true, Shared.TapLogin.playerId_, Shared.TapLogin.nickname_)
        end
        return
    end

    if not sdk then
        print("[TapLogin] ⚠️ sdk 不可用")
        if onDone then onDone(false, nil, nil) end
        return
    end

    local ok1, uid = pcall(function() return sdk:GetUserID() end)
    local ok2, uname = pcall(function() return sdk:GetUserName() end)

    if not ok1 or not uid then
        print("[TapLogin] ⚠️ 获取 user_id 失败")
        if onDone then onDone(false, nil, nil) end
        return
    end

    Shared.TapLogin.playerId_ = "u" .. tostring(uid)
    Shared.TapLogin.nickname_ = ok2 and tostring(uname) or ("玩家" .. tostring(uid))
    Shared.TapLogin.loggedIn_ = true

    print(string.format("[TapLogin] 登录成功 user_id=%s nickname=%s",
        Shared.TapLogin.playerId_, Shared.TapLogin.nickname_))

    if onDone then
        onDone(true, Shared.TapLogin.playerId_, Shared.TapLogin.nickname_)
    end
end

return Shared
