-- ============================================================
-- Battle_Combat.lua：战斗计算层（客户端）
--
-- 目录
--   Skills   37 个技能（触发 / 层数 / DoT / buff）
--   Combat   属性计算与伤害结算
--
-- 依赖：Shared（含 Data / Notify）。**不依赖 UI，也不依赖 Battle_World**。
--       对敌人 / 特效 / 飘字全部通过 Combat.SetCallbacks 注入的回调完成，
--       因此本文件不需要任何场景对象。
-- 说明：两个模块放在独立的 do...end 作用域里，通过 Battle.<模块名> 互相引用。
--
-- 对外接口：Battle.Skills / Battle.Combat
-- ============================================================
local Shared = require("Shared")

local Data   = Shared.Data

local Battle = {}

-- ===== 模块：Skills =====
do
    -- ============================================================
    -- client/Skills.lua：技能系统（37 个技能）
    -- 触发时机：onHit / onCrit / onKill / onHurt / passive
    -- 依赖 Notify（不依赖 Combat，避免循环引用）
    -- ============================================================

    local Skills = {}

    -- ============ 玩家 Buff ============
    -- 每种 buff 存 {expire, value}，避免原实现里 "xxxUntil / xxxValue" 成对字段易错
    local playerBuffs = {
        boilingBlood = { expire = 0, value = 0 },   -- 攻速加成
        frostFlow    = { expire = 0, value = 0 },   -- 攻速加成
        stoneShield  = { expire = 0, value = 0 },   -- 护甲加成
        scaleGuard   = { expire = 0, value = 0 },   -- 闪避加成
        ironCloth    = { expire = 0, value = 0 },   -- 护甲加成
        lightBody    = { expire = 0, value = 0 },   -- 闪避加成
        swift        = { expire = 0, value = 0 },   -- 移速加成
        bloodthirst  = { expire = 0, value = 0 },   -- 吸血比例
        -- 天赋树-连击核心：命中叠层，stacks 记录当前层数（过期需一并清零）
        bdCombo      = { expire = 0, value = 0, stacks = 0 },
        -- 天赋树-自伤核心：每次攻击叠一层暴击 buff
        bdSelfHarm   = { expire = 0, value = 0, stacks = 0 },
    }

    ---@type table<string, table>
    local enemyDebuffs = {}
    ---@type table<string, {expire:number, value:number}>
    local fissureDebuffs = {}
    local curTime = 0
    local onLifesteal_ = nil
    --- 由 Client 注入：AoE 技能（共鸣 / 反噬 / 魂链）打死敌人后的结算回调。
    --- ⚠️ 必须和 Combat.onEnemyKilled_ 指向同一函数（Client.HandleEnemyKilled）。
    ---    Skills 与 Combat 是两个独立 do 块，Skills 访问不到 Combat 的局部回调，
    ---    所以只能各自持有一份。早期只有 Combat 持有 → AoE 击杀的怪不掉落、
    ---    不给金币、不累计击杀数（表现为"打死了像没死"）。
    ---@type fun(enemy: table)|nil
    local onEnemyKilled_ = nil

    -- 天赋树机制缓存：由 Skills.Update 每帧刷新一次。
    -- ⚠️ 不能每次 GetChance 都去 require + 遍历 nodes（热路径每帧几十次）。
    ---@type table<string, boolean>
    local bdMechsCache_ = {}

    function Skills.SetCallbacks(cbs)
        if cbs then
            onLifesteal_ = cbs.onLifesteal
            onEnemyKilled_ = cbs.onEnemyKilled
        end
    end

    --- 刷新天赋树机制缓存（每帧 Skills.Update 开头调用一次）
    function Skills.RefreshBDMechanisms()
        local okBD, BD = pcall(require, "BD_Tree")
        if okBD and BD and BD.GetMechanisms then
            bdMechsCache_ = BD.GetMechanisms(Data.value.bdTree)
        else
            bdMechsCache_ = {}
        end
    end

    ---@param enemyId string
    ---@return table
    function Skills.GetDebuffs(enemyId)
        local d = enemyDebuffs[enemyId]
        if not d then
            d = {
                atkSpeed = { expire = 0, value = 0 },
                armor    = { expire = 0, value = 0 },
                atk      = { expire = 0, value = 0 },
            }
            enemyDebuffs[enemyId] = d
        end
        return d
    end

    --- 汇总装备上所有技能的层数
    ---@param equipment table<string, table>
    ---@return table<string, integer>
    function Skills.GetStacks(equipment)
        local stacks = {}
        if not equipment then return stacks end
        for _, eq in pairs(equipment) do
            if eq and eq.skills then
                for sid, count in pairs(eq.skills) do
                    if Shared.SKILL_DEFS[sid] then
                        stacks[sid] = (stacks[sid] or 0) + count
                    end
                end
            end
        end
        return stacks
    end

    ---@param sid string
    ---@param stacks table<string, integer>
    ---@return number
    function Skills.GetChance(sid, stacks)
        local def = Shared.SKILL_DEFS[sid]
        if not def or not stacks[sid] then return 0 end
        local base = def.chance * stacks[sid]

        -- 天赋树-灵能：铭刻核心 +0.03、过载核心 +0.02（独立堆叠）
        -- ⚠️ 读缓存而非每次遍历 nodes：本函数在战斗热路径里被高频调用。
        if bdMechsCache_.spiritInscription then base = base + 0.03 end
        if bdMechsCache_.spiritOverload    then base = base + 0.02 end

        return math.min(1, base)
    end

    --- 被动增伤（猎杀 / 压制 / 致命 / 破军 / 精准）
    ---@param baseDmg number
    ---@param target table
    ---@param stacks table<string, integer>
    ---@return number
    function Skills.ApplyPassiveDamageModifiers(baseDmg, target, stacks)
        local mult = 1.0
        local hpRatio = (target.maxHp > 0) and (target.hp / target.maxHp) or 1

        local n = stacks.hunter or 0
        if n > 0 and hpRatio < Shared.SKILL_DEFS.hunter.params.hpThreshold then
            mult = mult * (1 + Shared.SKILL_DEFS.hunter.params.damageBonus * n)
        end
        n = stacks.suppress or 0
        if n > 0 and hpRatio < Shared.SKILL_DEFS.suppress.params.hpThreshold then
            mult = mult * (1 + Shared.SKILL_DEFS.suppress.params.damageBonus * n)
        end
        n = stacks.deadly or 0
        if n > 0 and hpRatio >= 0.999 then
            mult = mult * (1 + Shared.SKILL_DEFS.deadly.params.damageBonus * n)
        end
        return baseDmg * mult
    end

    --- 被动命中率加成
    ---@param stacks table<string, integer>
    ---@return number
    function Skills.GetPassiveHitRate(stacks)
        local n = stacks.precision or 0
        if n <= 0 then return 0 end
        return Shared.SKILL_DEFS.precision.params.hitRateBonus * n
    end

    --- 被动破甲（无视护甲比例）
    ---@param stacks table<string, integer>
    ---@return number
    function Skills.GetPassiveArmorPen(stacks)
        local n = stacks.armorBreak or 0
        if n <= 0 then return 0 end
        return Shared.SKILL_DEFS.armorBreak.params.ignoreArmor * n
    end

    -- ============ onHit ============
    --- 技能触发结果。显式声明字段类型，否则 `0` 会被推断成 integer，
    --- 后续累加浮点伤害时会报 assign-type-mismatch
    ---@class SkillResult
    ---@field bonusDamage number
    ---@field triggeredSkills table[]
    ---@field healAmount number

    --- 玩家命中敌人时触发
    ---@param target table
    ---@param baseDmg number
    ---@param isCrit boolean
    ---@param stacks table<string, integer>
    ---@param allEnemies table[]
    ---@param stats table
    ---@return SkillResult
    function Skills.TriggerOnHit(target, baseDmg, isCrit, stacks, allEnemies, stats)
        ---@type SkillResult
        local result = { bonusDamage = 0.0, triggeredSkills = {}, healAmount = 0.0 }

        -- 弧光链：对周围额外目标造成伤害
        local ch = Skills.GetChance("arcChain", stacks)
        if ch > 0 and math.random() < ch then
            local p = Shared.SKILL_DEFS.arcChain.params
            local count = 0
            for _, e in ipairs(allEnemies) do
                if not e.isDead and e.id ~= target.id then
                    if Shared.Dist2D(e.x, e.z, target.x, target.z) <= p.range and count < p.maxTargets then
                        result.bonusDamage = result.bonusDamage + baseDmg * p.damageRatio * (stacks.arcChain or 1)
                        table.insert(result.triggeredSkills,
                            { skillId = "arcChain", targetId = e.id, x = e.x, z = e.z })
                        count = count + 1
                    end
                end
            end
        end

        -- 月震爆：范围伤害
        ch = Skills.GetChance("moonBurst", stacks)
        if ch > 0 and math.random() < ch then
            local p = Shared.SKILL_DEFS.moonBurst.params
            local n = stacks.moonBurst or 1
            for _, e in ipairs(allEnemies) do
                if not e.isDead and e.id ~= target.id then
                    if Shared.Dist2D(e.x, e.z, target.x, target.z) <= p.range then
                        result.bonusDamage = result.bonusDamage + baseDmg * p.damageRatio * n
                        table.insert(result.triggeredSkills,
                            { skillId = "moonBurst", targetId = e.id, x = e.x, z = e.z })
                    end
                end
            end
        end

        -- 风切：直接附加伤害
        ch = Skills.GetChance("windCut", stacks)
        if ch > 0 and math.random() < ch then
            result.bonusDamage = result.bonusDamage
                + baseDmg * Shared.SKILL_DEFS.windCut.params.damageRatio * (stacks.windCut or 1)
            table.insert(result.triggeredSkills, { skillId = "windCut", targetId = target.id, x = target.x, z = target.z })
        end

        -- 崩裂：目标受到的伤害提高
        ch = Skills.GetChance("fissure", stacks)
        if ch > 0 and math.random() < ch then
            local p = Shared.SKILL_DEFS.fissure.params
            fissureDebuffs[target.id] = { expire = curTime + p.duration, value = p.damageBonus * (stacks.fissure or 1) }
            table.insert(result.triggeredSkills, { skillId = "fissure", targetId = target.id, x = target.x, z = target.z })
        end

        -- 感电：降低目标攻速
        ch = Skills.GetChance("shock", stacks)
        if ch > 0 and math.random() < ch then
            local p = Shared.SKILL_DEFS.shock.params
            local d = Skills.GetDebuffs(target.id)
            d.atkSpeed.expire = curTime + p.duration
            d.atkSpeed.value = math.max(d.atkSpeed.value, p.atkSpeedDebuff * (stacks.shock or 1))
            table.insert(result.triggeredSkills, { skillId = "shock", targetId = target.id, x = target.x, z = target.z })
        end

        -- 破势：降低目标护甲
        ch = Skills.GetChance("armorRend", stacks)
        if ch > 0 and math.random() < ch then
            local p = Shared.SKILL_DEFS.armorRend.params
            local d = Skills.GetDebuffs(target.id)
            d.armor.expire = curTime + p.duration
            d.armor.value = math.max(d.armor.value, p.armorDebuff * (stacks.armorRend or 1))
            table.insert(result.triggeredSkills, { skillId = "armorRend", targetId = target.id, x = target.x, z = target.z })
        end

        -- 持续伤害类（蚀骨 / 血蚀 / 毒牙）：挂 DoT 状态
        local dotSkills = { "boneErode", "bloodErode", "venom" }
        for _, sid in ipairs(dotSkills) do
            ch = Skills.GetChance(sid, stacks)
            if ch > 0 and math.random() < ch then
                local p = Shared.SKILL_DEFS[sid].params
                target.dots = target.dots or {}

                -- 有 maxStacks 的技能（蚀骨=3）达到上限后不再叠
                local maxStacks = p.maxStacks
                local existing = 0
                if maxStacks then
                    for _, d in ipairs(target.dots) do
                        if d.skillId == sid then existing = existing + 1 end
                    end
                end

                if not maxStacks or existing < maxStacks then
                    local ratio = p.dpsRatio or p.tickRatio or 0
                    local dotDamage = baseDmg * ratio * (stacks[sid] or 1)
                    -- 天赋树-灵能 DoT 核心：DoT 伤害 ×1.5
                    -- ⚠️ 用 pcall：BD_Tree 若加载失败不能让技能触发挂掉。
                    local okBD, BD = pcall(require, "BD_Tree")
                    if okBD and BD and BD.GetMechanisms(Data.value.bdTree).spiritDotAmplify then
                        dotDamage = dotDamage * 1.5
                    end
                    table.insert(target.dots, {
                        skillId   = sid,
                        expire     = curTime + p.duration,
                        nextTick  = curTime + (p.tickInterval or 1.0),
                        interval  = p.tickInterval or 1.0,
                        damage    = dotDamage,
                        lifesteal = (sid == "bloodErode"),
                    })
                    table.insert(result.triggeredSkills, { skillId = sid, targetId = target.id, x = target.x, z = target.z })
                end
            end
        end

        -- 吸血 / 回复
        ch = Skills.GetChance("lifesteal", stacks)
        if ch > 0 and math.random() < ch then
            result.healAmount = result.healAmount
                + baseDmg * Shared.SKILL_DEFS.lifesteal.params.healRatio * (stacks.lifesteal or 1)
            table.insert(result.triggeredSkills, { skillId = "lifesteal", x = target.x, z = target.z })
        end

        ch = Skills.GetChance("vitality", stacks)
        if ch > 0 and math.random() < ch then
            result.healAmount = result.healAmount
                + (stats.maxHp or 200) * Shared.SKILL_DEFS.vitality.params.healMaxHpRatio * (stacks.vitality or 1)
            table.insert(result.triggeredSkills, { skillId = "vitality", x = target.x, z = target.z })
        end

        ch = Skills.GetChance("soulSiphon", stacks)
        if ch > 0 and math.random() < ch then
            result.healAmount = result.healAmount
                + (stats.atk or 3) * Shared.SKILL_DEFS.soulSiphon.params.healAtkRatio * (stacks.soulSiphon or 1)
            table.insert(result.triggeredSkills, { skillId = "soulSiphon", x = target.x, z = target.z })
        end

        -- 嗜血期间额外吸血
        if curTime < playerBuffs.bloodthirst.expire then
            result.healAmount = result.healAmount + baseDmg * playerBuffs.bloodthirst.value
        end

        -- 自身增益（铁衣 / 轻身 / 迅捷）
        ch = Skills.GetChance("ironCloth", stacks)
        if ch > 0 and math.random() < ch then
            local p = Shared.SKILL_DEFS.ironCloth.params
            playerBuffs.ironCloth.expire = curTime + p.duration
            playerBuffs.ironCloth.value = p.armorBonus * (stacks.ironCloth or 1)
            table.insert(result.triggeredSkills, { skillId = "ironCloth", x = target.x, z = target.z })
        end

        ch = Skills.GetChance("lightBody", stacks)
        if ch > 0 and math.random() < ch then
            local p = Shared.SKILL_DEFS.lightBody.params
            playerBuffs.lightBody.expire = curTime + p.duration
            playerBuffs.lightBody.value = p.dodgeBonus * (stacks.lightBody or 1)
            table.insert(result.triggeredSkills, { skillId = "lightBody", x = target.x, z = target.z })
        end

        ch = Skills.GetChance("swift", stacks)
        if ch > 0 and math.random() < ch then
            local p = Shared.SKILL_DEFS.swift.params
            playerBuffs.swift.expire = curTime + p.duration
            playerBuffs.swift.value = p.moveSpeedBonus * (stacks.swift or 1)
            table.insert(result.triggeredSkills, { skillId = "swift", x = target.x, z = target.z })
        end

        -- 割裂：仅暴击时触发
        if isCrit then
            ch = Skills.GetChance("bleed", stacks)
            if ch > 0 and math.random() < ch then
                local p = Shared.SKILL_DEFS.bleed.params
                target.dots = target.dots or {}
                table.insert(target.dots, {
                    skillId  = "bleed",
                    expire    = curTime + p.duration,
                    nextTick = curTime + p.tickInterval,
                    interval = p.tickInterval,
                    damage   = baseDmg * p.tickRatio * (stacks.bleed or 1),
                })
                table.insert(result.triggeredSkills, { skillId = "bleed", targetId = target.id, x = target.x, z = target.z })
            end
        end

        return result
    end

    -- ============ onKill ============
    ---@class SkillKillResult
    ---@field triggeredSkills table[]
    ---@field healAmount number

    ---@param deadEnemy table
    ---@param stacks table<string, integer>
    ---@param allEnemies table[]
    ---@param stats table
    ---@param currentHp number
    ---@return SkillKillResult
    function Skills.TriggerOnKill(deadEnemy, stacks, allEnemies, stats, currentHp)
        ---@type SkillKillResult
        local result = { triggeredSkills = {}, healAmount = 0.0 }

        local ch = Skills.GetChance("boilingBlood", stacks)
        if ch > 0 and math.random() < ch then
            local p = Shared.SKILL_DEFS.boilingBlood.params
            playerBuffs.boilingBlood.expire = curTime + p.duration
            playerBuffs.boilingBlood.value = p.atkSpeedBonus * (stacks.boilingBlood or 1)
            table.insert(result.triggeredSkills, { skillId = "boilingBlood", x = deadEnemy.x, z = deadEnemy.z })
        end

        ch = Skills.GetChance("frostFlow", stacks)
        if ch > 0 and math.random() < ch then
            local p = Shared.SKILL_DEFS.frostFlow.params
            playerBuffs.frostFlow.expire = curTime + p.duration
            playerBuffs.frostFlow.value = p.atkSpeedBonus * (stacks.frostFlow or 1)
            table.insert(result.triggeredSkills, { skillId = "frostFlow", x = deadEnemy.x, z = deadEnemy.z })
        end

        ch = Skills.GetChance("lastBreath", stacks)
        if ch > 0 and math.random() < ch then
            result.healAmount = result.healAmount
                + (stats.maxHp or 200) * Shared.SKILL_DEFS.lastBreath.params.healMaxHpRatio * (stacks.lastBreath or 1)
            table.insert(result.triggeredSkills, { skillId = "lastBreath", x = deadEnemy.x, z = deadEnemy.z })
        end

        ch = Skills.GetChance("bloodSurge", stacks)
        if ch > 0 and math.random() < ch then
            local hpRatio = currentHp / (stats.maxHp or 200)
            if hpRatio < Shared.SKILL_DEFS.bloodSurge.params.hpThreshold then
                result.healAmount = result.healAmount
                    + (stats.maxHp or 200) * Shared.SKILL_DEFS.bloodSurge.params.healMaxHpRatio * (stacks.bloodSurge or 1)
                table.insert(result.triggeredSkills, { skillId = "bloodSurge", x = deadEnemy.x, z = deadEnemy.z })
            end
        end

        ch = Skills.GetChance("bloodthirst", stacks)
        if ch > 0 and math.random() < ch then
            local p = Shared.SKILL_DEFS.bloodthirst.params
            playerBuffs.bloodthirst.expire = curTime + p.duration
            playerBuffs.bloodthirst.value = p.lifestealRatio * (stacks.bloodthirst or 1)
            table.insert(result.triggeredSkills, { skillId = "bloodthirst", x = deadEnemy.x, z = deadEnemy.z })
        end

        -- 共鸣：击杀后对周围造成范围伤害
        ch = Skills.GetChance("resonance", stacks)
        if ch > 0 and math.random() < ch then
            local p = Shared.SKILL_DEFS.resonance.params
            for _, e in ipairs(allEnemies) do
                if not e.isDead then
                    if Shared.Dist2D(e.x, e.z, deadEnemy.x, deadEnemy.z) <= p.range then
                        e.hp = math.floor(e.hp - deadEnemy.maxHp * p.aoeRatio * (stacks.resonance or 1))
                        if e.hp <= 0 then
                            e.hp = 0
                            e.isDead = true
                            -- ⚠️ AoE 击杀也要走结算：否则这只怪不掉落、不给金币、不累计击杀
                            if onEnemyKilled_ then onEnemyKilled_(e) end
                        end
                    end
                end
            end
            table.insert(result.triggeredSkills, { skillId = "resonance", x = deadEnemy.x, z = deadEnemy.z })
        end

        return result
    end

    -- ============ onHurt ============
    ---@class SkillHurtResult
    ---@field reduceRatio number
    ---@field reflectDamage number
    ---@field healAmount number
    ---@field triggeredSkills table[]

    --- 玩家受伤时触发（护盾/反伤类）
    ---@param attacker table|nil
    ---@param incomingDmg number
    ---@param stacks table<string, integer>
    ---@param stats table
    ---@param allEnemies table[]
    ---@return SkillHurtResult
    function Skills.TriggerOnHurt(attacker, incomingDmg, stacks, stats, allEnemies)
        ---@type SkillHurtResult
        local result = { reduceRatio = 0.0, reflectDamage = 0.0, healAmount = 0.0, triggeredSkills = {} }
        if not attacker then return result end

        -- 铁壁：直接减伤
        local ch = Skills.GetChance("ironWall", stacks)
        if ch > 0 and math.random() < ch then
            result.reduceRatio = result.reduceRatio
                + Shared.SKILL_DEFS.ironWall.params.reduceRatio * (stacks.ironWall or 1)
            table.insert(result.triggeredSkills, { skillId = "ironWall", x = attacker.x, z = attacker.z })
        end

        -- 磐盾：临时护甲
        ch = Skills.GetChance("stoneShield", stacks)
        if ch > 0 and math.random() < ch then
            local p = Shared.SKILL_DEFS.stoneShield.params
            playerBuffs.stoneShield.expire = curTime + p.duration
            playerBuffs.stoneShield.value = p.armorBonus * (stacks.stoneShield or 1)
            table.insert(result.triggeredSkills, { skillId = "stoneShield", x = attacker.x, z = attacker.z })
        end

        -- 闪鳞：临时闪避
        ch = Skills.GetChance("scaleGuard", stacks)
        if ch > 0 and math.random() < ch then
            local p = Shared.SKILL_DEFS.scaleGuard.params
            playerBuffs.scaleGuard.expire = curTime + p.duration
            playerBuffs.scaleGuard.value = p.dodgeBonus * (stacks.scaleGuard or 1)
            table.insert(result.triggeredSkills, { skillId = "scaleGuard", x = attacker.x, z = attacker.z })
        end

        -- 反伤类：棘甲 / 反弹 / 反噬
        local reflectDefs = { "thornArmor", "reflect", "backlash" }
        for _, sid in ipairs(reflectDefs) do
            ch = Skills.GetChance(sid, stacks)
            if ch > 0 and math.random() < ch then
                local p = Shared.SKILL_DEFS[sid].params
                local ratio = p.reflectRatio * (stacks[sid] or 1)
                if sid == "backlash" then
                    -- 反噬：对范围内敌人反伤
                    for _, e in ipairs(allEnemies) do
                        if not e.isDead and Shared.Dist2D(e.x, e.z, attacker.x, attacker.z) <= (p.range or 3.0) then
                            e.hp = math.floor(e.hp - incomingDmg * ratio)
                            if e.hp <= 0 then
                                e.hp = 0
                                e.isDead = true
                                -- ⚠️ AoE 击杀也要走结算（理由同共鸣）
                                if onEnemyKilled_ then onEnemyKilled_(e) end
                            end
                        end
                    end
                else
                    result.reflectDamage = result.reflectDamage + incomingDmg * ratio
                end
                table.insert(result.triggeredSkills, { skillId = sid, x = attacker.x, z = attacker.z })
            end
        end

        -- 回春：受伤回血
        ch = Skills.GetChance("rejuvenate", stacks)
        if ch > 0 and math.random() < ch then
            result.healAmount = result.healAmount
                + (stats.maxHp or 200) * Shared.SKILL_DEFS.rejuvenate.params.healMaxHpRatio * (stacks.rejuvenate or 1)
            table.insert(result.triggeredSkills, { skillId = "rejuvenate", x = attacker.x, z = attacker.z })
        end

        -- 钝甲 / 迟滞：削弱攻击者
        ch = Skills.GetChance("dullArmor", stacks)
        if ch > 0 and math.random() < ch then
            local p = Shared.SKILL_DEFS.dullArmor.params
            local d = Skills.GetDebuffs(attacker.id)
            d.atk.expire = curTime + p.duration
            d.atk.value = math.max(d.atk.value, p.atkDebuff * (stacks.dullArmor or 1))
            table.insert(result.triggeredSkills, { skillId = "dullArmor", x = attacker.x, z = attacker.z })
        end

        ch = Skills.GetChance("slowStrike", stacks)
        if ch > 0 and math.random() < ch then
            local p = Shared.SKILL_DEFS.slowStrike.params
            local d = Skills.GetDebuffs(attacker.id)
            d.atkSpeed.expire = curTime + p.duration
            d.atkSpeed.value = math.max(d.atkSpeed.value, p.atkSpeedDebuff * (stacks.slowStrike or 1))
            table.insert(result.triggeredSkills, { skillId = "slowStrike", x = attacker.x, z = attacker.z })
        end

        -- 魂链：分裂伤害到周围
        ch = Skills.GetChance("soulChain", stacks)
        if ch > 0 and math.random() < ch then
            local p = Shared.SKILL_DEFS.soulChain.params
            for _, e in ipairs(allEnemies) do
                if not e.isDead and e.id ~= attacker.id then
                    if Shared.Dist2D(e.x, e.z, attacker.x, attacker.z) <= p.range then
                        e.hp = math.floor(e.hp - incomingDmg * p.splitRatio * (stacks.soulChain or 1))
                        if e.hp <= 0 then
                            e.hp = 0
                            e.isDead = true
                            -- ⚠️ AoE 击杀也要走结算（理由同共鸣）
                            if onEnemyKilled_ then onEnemyKilled_(e) end
                        end
                    end
                end
            end
            table.insert(result.triggeredSkills, { skillId = "soulChain", x = attacker.x, z = attacker.z })
        end

        return result
    end

    -- ============ 每帧更新 ============
    --- 天赋树-连击核心：叠加一层连击 buff（命中时由 Combat.PlayerAttack 调用）。
    ---@param perStack number 每层攻速加成（0.05 = 5%）
    ---@param maxStacks integer 最大层数
    ---@param duration number buff 持续时间（秒）
    function Skills.AddComboStack(perStack, maxStacks, duration)
        local b = playerBuffs.bdCombo
        b.stacks = math.min(maxStacks, (b.stacks or 0) + 1)
        b.expire = curTime + duration
        b.value  = b.stacks * perStack
    end

    --- 天赋树-自伤核心：叠加一层自伤 buff（增加暴击率）。
    ---@param perStack number 每层暴击率加成（如 0.05 = 5%）
    ---@param maxStacks integer 最大层数
    ---@param duration number buff 持续时间（秒）
    function Skills.AddSelfHarmStack(perStack, maxStacks, duration)
        local b = playerBuffs.bdSelfHarm
        b.stacks = math.min(maxStacks, (b.stacks or 0) + 1)
        b.expire = curTime + duration
        b.value  = b.stacks * perStack
    end

    --- 推进时间、过期 buff/debuff、结算 DoT
    ---@param dt number
    ---@param enemies table[]
    ---@param onEnemyKilled fun(enemy: table)|nil
    ---@return number 玩家被 DoT 反噬的总伤害（当前为 0，保留接口）
    function Skills.Update(dt, enemies, onEnemyKilled)
        curTime = curTime + dt

        -- 每帧刷新天赋树机制缓存（供 GetChance 热路径读取）
        Skills.RefreshBDMechanisms()

        -- buff 过期
        for _, b in pairs(playerBuffs) do
            if b.expire > 0 and curTime > b.expire then
                b.expire = 0
                b.value = 0
                -- 连击 / 自伤 buff 必须同时清层数，否则下次叠层会从旧层数继续
                if b.stacks then b.stacks = 0 end
            end
        end

        -- 敌人 debuff 过期
        for id, d in pairs(enemyDebuffs) do
            for _, entry in pairs(d) do
                if entry.expire > 0 and curTime > entry.expire then
                    entry.expire = 0
                    entry.value = 0
                end
            end
            -- 该敌人已不存在则清理
            if enemies then
                local alive = false
                for _, e in ipairs(enemies) do
                    if e.id == id and not e.isDead then alive = true break end
                end
                if not alive then enemyDebuffs[id] = nil end
            end
        end

        -- 崩裂过期
        for id, f in pairs(fissureDebuffs) do
            if curTime > f.expire then fissureDebuffs[id] = nil end
        end

        -- DoT 结算
        if enemies then
            for _, e in ipairs(enemies) do
                if not e.isDead and e.dots and #e.dots > 0 then
                    local i = 1
                    while i <= #e.dots do
                        local dot = e.dots[i]
                        if curTime > dot.expire then
                            table.remove(e.dots, i)
                        else
                            if curTime >= dot.nextTick then
                                dot.nextTick = curTime + dot.interval
                                e.hp = math.floor(e.hp - dot.damage)
                                if dot.lifesteal and onLifesteal_ then
                                    onLifesteal_(dot.damage)
                                end
                                if e.hp <= 0 then
                                    e.hp = 0
                                    e.isDead = true
                                    if onEnemyKilled then onEnemyKilled(e) end
                                end
                            end
                            i = i + 1
                        end
                    end
                end
            end
        end

        return 0
    end

    --- 当前 buff 对属性的加成（供 Combat.ComputeStats 调用）
    ---@return table
    function Skills.GetBuffModifiers()
        local m = { atkSpeed = 0, moveSpeed = 0, armor = 0, dodge = 0, critChance = 0 }
        if curTime < playerBuffs.boilingBlood.expire then
            m.atkSpeed = m.atkSpeed + playerBuffs.boilingBlood.value
        end
        if curTime < playerBuffs.frostFlow.expire then
            m.atkSpeed = m.atkSpeed + playerBuffs.frostFlow.value
        end
        if curTime < playerBuffs.swift.expire then
            m.moveSpeed = m.moveSpeed + playerBuffs.swift.value
        end
        if curTime < playerBuffs.stoneShield.expire then
            m.armor = m.armor + playerBuffs.stoneShield.value
        end
        if curTime < playerBuffs.ironCloth.expire then
            m.armor = m.armor + playerBuffs.ironCloth.value
        end
        if curTime < playerBuffs.scaleGuard.expire then
            m.dodge = m.dodge + playerBuffs.scaleGuard.value
        end
        if curTime < playerBuffs.lightBody.expire then
            m.dodge = m.dodge + playerBuffs.lightBody.value
        end
        -- 天赋树-连击核心：攻速加成
        if curTime < playerBuffs.bdCombo.expire then
            m.atkSpeed = m.atkSpeed + playerBuffs.bdCombo.value
        end
        -- 天赋树-自伤核心：暴击率加成
        if curTime < playerBuffs.bdSelfHarm.expire then
            m.critChance = m.critChance + playerBuffs.bdSelfHarm.value
        end
        return m
    end

    --- 敌人当前生效的减益（供伤害计算调用）
    ---@param enemyId string
    ---@return {atkSpeed:number, armor:number, atk:number}
    function Skills.GetEnemyModifiers(enemyId)
        local out = { atkSpeed = 0, armor = 0, atk = 0 }
        local d = enemyDebuffs[enemyId]
        if d then
            out.atkSpeed = d.atkSpeed.value
            out.armor = d.armor.value
            out.atk = d.atk.value
        end
        return out
    end

    --- 目标当前的「崩裂」增伤
    ---@param enemyId string
    ---@return number
    function Skills.GetFissureBonus(enemyId)
        local f = fissureDebuffs[enemyId]
        if f and curTime <= f.expire then return f.value end
        return 0
    end
    Battle.Skills = Skills
end

-- ===== 模块：Combat =====
do
    -- ============================================================
    -- client/Combat.lua：战斗计算
    -- 依赖 Data / Skills / Notify；不依赖 Enemies / UI（用回调解耦）
    -- ============================================================
    local Combat = {}
    local Skills = Battle.Skills
    local bossDamageAccum_ = {}   -- bossId -> { dmg, t0 }
    -- 本模块自维护的累计时间（不依赖 Battle_World 的 Now，保持本文件零场景依赖）
    local combatTime_ = 0

    -- 由 Client.lua 注入：击杀敌人后的处理（掉落/升级/耐久）
    ---@type fun(enemy: table)|nil
    local onEnemyKilled_ = nil
    ---@type fun(skillId: string, x: number, z: number, value: number)|nil
    local playEffect_ = nil
    ---@type fun(x: number, z: number, text: string|number, kind: string)|nil
    local showDamage_ = nil
    --- 命中敌人时的通知（用于脱战计时 + 受击闪烁）
    ---@type fun(enemy: table)|nil
    local onEnemyHit_ = nil
    --- 本地把共享 Boss 打到 0 血时的通知（客户端上报击杀，服务端给首个上报者发奖励）
    ---@type fun(enemy: table)|nil
    local reportBossKilled_ = nil
    --- 上报共享 Boss 伤害（由 Client 注入：内部发网络包）。
    --- 本文件不依赖网络，因此伤害上报走回调。
    ---@type fun(enemy: table, damage: number)|nil
    local reportBossDamage_ = nil
    --- 技能触发弹跳文字（A7）。
    ---@type fun(x: number, z: number, text: string, color: string)|nil
    local showSkillPopup_ = nil
    --- 取玩家当前位置（玩家受到的伤害要飘在自己头顶，而不是怪物身上）
    ---@type fun(): number|nil, number|nil
    local getPlayerPos_ = nil

    function Combat.SetCallbacks(cbs)
        onEnemyKilled_ = cbs.onEnemyKilled
        playEffect_ = cbs.playEffect
        showDamage_ = cbs.showDamage
        onEnemyHit_ = cbs.onEnemyHit
        reportBossDamage_ = cbs.reportBossDamage
        reportBossKilled_ = cbs.reportBossKilled
        showSkillPopup_ = cbs.showSkillPopup
        getPlayerPos_ = cbs.getPlayerPos
    end

    local function Damage(x, z, text, kind)
        if showDamage_ then showDamage_(x, z, text, kind) end
    end

    --- 玩家受到的伤害 / 闪避：飘字挂到玩家自己头顶。
    --- 取不到玩家位置时静默跳过（例如刚进场景、节点还没建好）。
    ---@param text string|number
    ---@param kind string
    local function PlayerDamage(text, kind)
        if not showDamage_ or not getPlayerPos_ then return end
        local px, pz = getPlayerPos_()
        if px then showDamage_(px, pz, text, kind) end
    end

    --- 技能触发时统一播「特效 + 弹跳文字」（A7）。
    --- 三处触发点（onHit / onKill / onHurt）都走这里，避免重复代码。
    ---@param triggered table[]
    local function PlayTriggeredSkills(triggered)
        if not triggered then return end
        local ss = Data.GetSettings()
        local showFx = ss.showSkillEffect ~= false
        local showPopup = ss.showSkillPopup ~= false
        for _, t in ipairs(triggered) do
            if showFx and playEffect_ then playEffect_(t.skillId, t.x or 0, t.z or 0, t.value or 0) end
            if showPopup and showSkillPopup_ then
                local def = Shared.SKILL_DEFS[t.skillId]
                local label = def and (def.icon .. def.name) or t.skillId
                -- 按技能类型给颜色：伤害类偏红、增益类偏绿、减益类偏紫
                local color = "#7affa0"
                if def then
                    if def.type == "onHit" then color = "#ff9a5a"
                    elseif def.type == "onHurt" then color = "#9fd8ff"
                    elseif def.type == "onKill" then color = "#ffd24d"
                    elseif def.type == "passive" then color = "#c2ff6b" end
                end
                showSkillPopup_(t.x or 0, t.z or 0, label, color)
            end
        end
    end

    -- ============ 属性计算 ============
    --- 根据装备 + 等级 + 当前 buff 计算最终属性
    ---@param equipment table<string, table>
    ---@return table
    function Combat.ComputeStats(equipment)
        local stats = {
            maxHp = 200, atk = 2.0, atkSpeed = 2.0, moveSpeed = 5.0,
            critChance = 0.05, critDamage = 1.5,
            armorPen = 0, killHeal = 0, armor = 0,
            damageReduce = 0, dodge = 0, hitRate = 0,
        }

        -- 🔴 宠物加成（2026-10-06 改加算）：
        --    · 固定特性 → 作用于该部位**基础词缀**（由 SLOT_SPEC 决定目标属性）
        --    · 激活属性 → 作用于该部位**随机词缀**中匹配的属性
        --    · 多个宠物的同属性加成**加算**（不再是逐层乘算）
        --    petBaseBonus / petActivated 由 Pet_System 汇总，键是属性名、值是总百分比。
        -- ⚠️ 用 pcall：Pet_System 若加载失败不能让整个属性计算挂掉。
        local petBaseBonus, petActivated = {}, {}
        local okPet, PetSys = pcall(require, "Pet_System")
        if okPet and PetSys and PetSys.CalcPetBonuses then
            local pb = PetSys.CalcPetBonuses()
            petBaseBonus = pb.baseBonus or {}
            petActivated = pb.activated or {}
        end

        for _, slot in ipairs(Shared.SLOT_LIST) do
            local eq = equipment and equipment[slot]
            if eq and (eq.durability or 0) > 0 then
                -- 强化乘数 2%/级
                local em = 1 + (eq.enhanceLevel or 0) * 0.02
                -- 重铸乘数 2%/条
                local rm = 1 + (eq.reforgeLevel or 0) * 0.02
                -- itemLevel 缩放：段位内每级 +1%
                local qualityStart = ({
                    normal = 1, magic = 10, rare = 20, legendary = 30, mythic = 40,
                })[eq.quality] or 1
                local il = eq.itemLevel or qualityStart
                local ilScale = 1 + math.max(0, il - qualityStart) * 0.005

                local specCount = #(Shared.SLOT_SPEC[slot] or {})

                for i, b in ipairs(eq.bonuses or {}) do
                    local v = b.value * em * rm * ilScale
                    local mid = b.modId

                    -- 宠物加成（加算）：基础词缀走 petBaseBonus、随机词缀走 petActivated
                    local petMult = 0
                    if i <= specCount then
                        petMult = petBaseBonus[mid] or 0
                    else
                        petMult = petActivated[mid] or 0
                    end
                    v = v * (1 + petMult)

                    if mid == "atk" then stats.atk = stats.atk + v
                    elseif mid == "maxHp" then stats.maxHp = math.floor(stats.maxHp + v)
                    elseif mid == "critChance" then stats.critChance = stats.critChance + v
                    elseif mid == "critDamage" then stats.critDamage = stats.critDamage + v
                    elseif mid == "atkSpeed" then stats.atkSpeed = stats.atkSpeed * (1 + v)
                    elseif mid == "moveSpeed" then stats.moveSpeed = stats.moveSpeed * (1 + v)
                    elseif mid == "armorPen" then stats.armorPen = stats.armorPen + v
                    elseif mid == "killHeal" then stats.killHeal = stats.killHeal + v
                    elseif mid == "armor" then stats.armor = stats.armor + v
                    elseif mid == "damageReduce" then stats.damageReduce = stats.damageReduce + v
                    elseif mid == "dodge" then stats.dodge = stats.dodge + v
                    elseif mid == "hitRate" then stats.hitRate = stats.hitRate + v
                    end
                end
            end
        end

        -- 技能层数带来的被动加成
        local stacks = Skills.GetStacks(equipment)
        stats.hitRate = stats.hitRate + Skills.GetPassiveHitRate(stacks)
        stats.armorPen = stats.armorPen + Skills.GetPassiveArmorPen(stacks)

        -- 临时 buff
        local buffs = Skills.GetBuffModifiers()
        stats.atkSpeed = stats.atkSpeed * (1 + buffs.atkSpeed)
        stats.moveSpeed = stats.moveSpeed * (1 + buffs.moveSpeed)
        stats.armor = stats.armor + stats.armor * buffs.armor
        stats.dodge = stats.dodge + buffs.dodge
        -- 天赋树-自伤核心：暴击率加成（加法，与 critChance 池同口径，受末尾 clamp 约束）
        stats.critChance = stats.critChance + (buffs.critChance or 0)

        -- ============ 天赋树加成（P4 加算池口径 B-2）============
        -- 🔴 口径：base × (1 + sum(bonus))，同类型各自成池。
        -- ⚠️ 用 pcall：BD_Tree 若加载失败（或未来被裁掉）不能让整个属性计算挂掉。
        -- ⚠️ 天赋树加成必须放在所有 clamp **之前**：否则溢出值会被 clamp 掩盖。
        local okBD, BD = pcall(require, "BD_Tree")
        if okBD and BD and BD.AggregateBonuses then
            local bd = BD.AggregateBonuses(Data.value.bdTree)

            -- 乘法加成（乘法池）
            if bd.atk       then stats.atk       = stats.atk       * (1 + bd.atk)       end
            if bd.maxHp     then stats.maxHp     = stats.maxHp     * (1 + bd.maxHp)     end
            if bd.atkSpeed  then stats.atkSpeed  = stats.atkSpeed  * (1 + bd.atkSpeed)  end
            if bd.moveSpeed then stats.moveSpeed = stats.moveSpeed * (1 + bd.moveSpeed) end
            if bd.armor     then stats.armor     = stats.armor     * (1 + bd.armor)     end

            -- 加法加成（加法池）
            if bd.critChance then stats.critChance = stats.critChance + bd.critChance end
            if bd.critDamage then stats.critDamage = stats.critDamage + bd.critDamage end
            if bd.armorPen   then stats.armorPen   = stats.armorPen   + bd.armorPen   end
            if bd.dodge      then stats.dodge      = stats.dodge      + bd.dodge      end
            if bd.killHeal   then stats.killHeal   = stats.killHeal   + bd.killHeal   end
        end

        stats.critChance   = math.min(1.00, stats.critChance)
        stats.armorPen     = math.min(0.90, stats.armorPen)
        stats.damageReduce = math.min(0.90, stats.damageReduce)
        stats.dodge        = math.min(0.90, stats.dodge)
        stats.maxHp        = math.floor(stats.maxHp)
        return stats
    end

    -- ============ 玩家攻击敌人 ============
    ---@param stats table
    ---@param enemy table
    ---@param allEnemies table[]
    ---@return table
    function Combat.PlayerAttack(stats, enemy, allEnemies)
        local stacks = Skills.GetStacks(Data.value.equipment)

        local effHit = math.max(0, math.min(1, (1 + stats.hitRate) * (1 - (enemy.dodge or 0))))
        if math.random() >= effHit then
            Damage(enemy.x, enemy.z, "MISS", "miss")
            return { hit = false }
        end

        -- 天赋树机制：一次性读取（本函数内共用，避免重复遍历 nodes）
        local okBD, BD = pcall(require, "BD_Tree")
        local mechs = {}
        if okBD and BD and BD.GetMechanisms then
            mechs = BD.GetMechanisms(Data.value.bdTree)
        end

        -- 血祭-自伤核心：攻击时扣 2 点生命，叠一层暴击 buff（+5%/层，最多 3 层，持续 3 秒）。
        -- ⚠️ 与「耗血核心」的差异：耗血是扣最大生命百分比换当次伤害；
        --    自伤是扣固定值换后续暴击（连击性质）。
        -- ⚠️ HP ≤ 5 时不触发：否则低血玩家可以**免费叠层**（扣血被下限卡住），
        --    变成"越危险越强"的免费收益，破坏设计意图。
        if mechs.bloodSelfHarm and Data.value.hp > 5 then
            Data.value.hp = Data.value.hp - 2
            Skills.AddSelfHarmStack(0.05, 3, 3.0)
        end

        -- 血祭-耗血核心：消耗 2% 最大生命，换取 +20% 伤害。
        -- ⚠️ 放在 MISS 之后：MISS 不扣血（避免「打空还掉血」的负反馈）。
        -- ⚠️ 生命 ≤10% 时不触发（防自杀）。
        local hpCostBonus = 0
        if mechs.bloodHpCost then
            local hpRatio = Data.value.hp / (stats.maxHp or 200)
            if hpRatio > 0.10 then
                local cost = math.max(1, math.floor((stats.maxHp or 200) * 0.02))
                Data.value.hp = math.max(1, Data.value.hp - cost)
                hpCostBonus = 0.20
            end
        end

        local isCrit  = math.random() < stats.critChance
        local baseDmg = stats.atk * (isCrit and stats.critDamage or 1.0)

        -- 血祭-耗血核心加成
        if hpCostBonus > 0 then
            baseDmg = baseDmg * (1 + hpCostBonus)
        end

        -- 血祭-低血核心：生命低于 50% 时伤害 +30%
        if mechs.bloodLowHp then
            local hpRatio = Data.value.hp / (stats.maxHp or 200)
            if hpRatio < 0.50 then
                baseDmg = baseDmg * 1.30
            end
        end

        -- 被动增伤
        baseDmg = Skills.ApplyPassiveDamageModifiers(baseDmg, enemy, stacks)
        -- 崩裂：目标受到的伤害提高
        baseDmg = baseDmg * (1 + Skills.GetFissureBonus(enemy.id))

        local hitResult = Skills.TriggerOnHit(enemy, baseDmg, isCrit, stacks, allEnemies, stats)

        local totalDmg = baseDmg + (hitResult.bonusDamage or 0)

        -- 护甲减免（含破甲 + 目标护甲减益）
        local enemyMods = Skills.GetEnemyModifiers(enemy.id)
        local effArmor = math.max(0, (enemy.armor or 0) * (1 - math.min(0.9, enemyMods.armor)))
        local armorReduce = math.min(0.9, effArmor / (effArmor + 300))
        local pen = math.min(0.9, (stats.armorPen or 0) + enemyMods.armor)

        -- 天赋树-战意暴击核心「暴击时无视目标 20% 护甲」
        -- ⚠️ 只在 isCrit 为真时叠加，且与 armorPen 同池封顶 90%
        if isCrit and mechs.critIgnoreArmor20 then
            pen = math.min(0.9, pen + 0.20)
        end

        totalDmg = totalDmg * (1 - armorReduce * (1 - pen))

        -- 灵能-元素核心：所有伤害 ×1.08（元素化，放在护甲减免之后、等级压制之前）
        if mechs.spiritElement then
            totalDmg = totalDmg * 1.08
        end

        -- 等级压制：怪物等级 > 玩家等级时，玩家伤害倍率下降
        -- 压制值 = 怪物等级 - 玩家等级
        local playerLv = Data.GetLevel()
        local enemyLv = enemy.level or 1
        local suppress = math.max(0, enemyLv - playerLv)
        if suppress > 0 then
            local factor = 1 - math.min(Shared.C.SUPPRESS_PLAYER_DMG_MIN,
                suppress * Shared.C.SUPPRESS_PLAYER_DMG_PER_LEVEL)
            totalDmg = totalDmg * factor
        end

        -- 高等级玩家回低段位：怪物减伤
        local levelDiff = math.max(0, playerLv - enemyLv)
        if levelDiff > 0 then
            local reduce = math.min(Shared.C.HIGH_LEVEL_REDUCE_MAX,
                levelDiff * Shared.C.HIGH_LEVEL_REDUCE_PER_LEVEL)
            totalDmg = totalDmg * (1 - reduce)
        end

        -- ⚠️ 最终伤害取整（含技能加成、暴击、护甲减免、等级压制之后）。
        --    这里是唯一收口点：之后所有下游（扣血 / 吸血 / 反伤 / 飘字 / 上报）
        --    拿到的都是整数，避免浮点沿调用链扩散。
        totalDmg = math.floor(totalDmg)

        if enemy.isSharedBoss then
            -- 本地乐观扣血：仅用于血条即时反馈。服务端广播的血量才是权威。
            enemy.hp = math.max(0, math.floor(enemy.hp - totalDmg))
            local acc = bossDamageAccum_[enemy.id]
            if not acc then
                acc = { dmg = 0, t0 = combatTime_ }
                bossDamageAccum_[enemy.id] = acc
            end
            acc.dmg = acc.dmg + totalDmg
            Damage(enemy.x, enemy.z, math.floor(totalDmg), isCrit and "crit" or "")
            if onEnemyHit_ then onEnemyHit_(enemy) end
            -- ⚠️ 绝不能因本地血量归零而停手（会让 Boss 从 GetAliveList 消失，
            --    玩家再也打不到它）。
            -- 共享 Boss 的血量**由本客户端自己维护**（服务端不再校正）。
            -- 本地归零 → 上报「击杀」事件（仅一次），服务端给首个上报者发奖励并移除 Boss。
            -- ⚠️ __killReported 标记必不可少：本地血量归零后会一直停在 0，
            --    若不加标记，之后每一次攻击都会重复上报 BOSS_KILLED，
            --    在服务端广播移除到达前刷出大量重复包。
            -- ⚠️ 清掉累计伤害并跳过伤害上报，避免同一批伤害被计两次
            --    （击杀事件已足以让服务端结算，不需要再走血量增量路径）。
            if enemy.hp <= 0 and not enemy.__killReported then
                enemy.__killReported = true
                bossDamageAccum_[enemy.id] = nil
                if reportBossKilled_ then reportBossKilled_(enemy) end
            end

            -- 天赋树-战意连击核心：共享 Boss 命中同样叠层
            if mechs.warCombo then
                Skills.AddComboStack(0.05, 10, 4.0)
            end

            return { hit = true, damage = totalDmg }
        end

        enemy.hp = math.floor(enemy.hp - totalDmg)
        Damage(enemy.x, enemy.z, math.floor(totalDmg), isCrit and "crit" or "")
        -- 通知 Enemies：刷新脱战计时 + 触发受击闪烁
        if onEnemyHit_ then onEnemyHit_(enemy) end

        -- 天赋树-战意连击核心：命中叠加攻速 buff
        if mechs.warCombo then
            Skills.AddComboStack(0.05, 10, 4.0)
        end

        -- 天赋树-战意溅射核心：对目标周围 3 米造成 30% 溅射伤害
        -- ⚠️ 溅射击杀也必须走 onEnemyKilled_（否则怪不掉落 / 不给金币 / 不计击杀数）
        -- ⚠️ 共享 Boss 分支在上面已 return，不会走到这里
        if mechs.warSplash then
            local splashRange = 3.0
            local splashDmg = math.max(1, math.floor(totalDmg * 0.30))
            for _, e in ipairs(allEnemies) do
                if not e.isDead and e.id ~= enemy.id
                    and Shared.Dist2D(e.x, e.z, enemy.x, enemy.z) <= splashRange then
                    e.hp = math.max(0, math.floor(e.hp - splashDmg))
                    Damage(e.x, e.z, splashDmg, "")
                    if onEnemyHit_ then onEnemyHit_(e) end
                    if e.hp <= 0 then
                        e.isDead = true
                        if onEnemyKilled_ then onEnemyKilled_(e) end
                    end
                end
            end
        end

        -- 治疗
        if (hitResult.healAmount or 0) > 0 then
            local d = Data.value
            d.hp = math.floor(math.min(stats.maxHp, d.hp + hitResult.healAmount))
            Damage(enemy.x, enemy.z, "+" .. math.floor(hitResult.healAmount), "heal")
        end

        -- 技能特效 + 弹跳文字（A7）
        PlayTriggeredSkills(hitResult.triggeredSkills)

        if enemy.hp <= 0 then
            enemy.hp = 0
            enemy.isDead = true
            local killResult = Skills.TriggerOnKill(enemy, stacks, allEnemies, stats, Data.value.hp)
            PlayTriggeredSkills(killResult.triggeredSkills)
            if (killResult.healAmount or 0) > 0 then
                Data.value.hp = math.floor(math.min(stats.maxHp, Data.value.hp + killResult.healAmount))
            end
            -- ⚠️ killHeal（击杀回复）已挪到 Client.HandleEnemyKilled：
            --    这里只能覆盖「普攻直接击杀」，DoT 击杀走 Skills.Update 不经过本函数，
            --    统一放到 onEnemyKilled_ 回调里才能两种击杀都生效（且不会双触发）。
            if onEnemyKilled_ then onEnemyKilled_(enemy) end
            return { hit = true, isCrit = isCrit, damage = totalDmg, killed = true }
        end

        return { hit = true, isCrit = isCrit, damage = totalDmg, killed = false }
    end

    -- ============ 敌人攻击玩家 ============
    ---@param enemy table
    ---@param stats table
    ---@param allEnemies table[]
    ---@return number 实际造成的伤害
    function Combat.EnemyAttack(enemy, stats, allEnemies)
        local stacks = Skills.GetStacks(Data.value.equipment)
        local d = Data.value

        -- 闪避判定
        if math.random() < (stats.dodge or 0) then
            PlayerDamage("闪避", "miss")
            return 0
        end

        -- 天赋树机制：一次性读取（后续本函数内共用）
        local okBD, BD = pcall(require, "BD_Tree")
        local mechs = {}
        if okBD and BD and BD.GetMechanisms then
            mechs = BD.GetMechanisms(Data.value.bdTree)
        end

        -- 铁壁-格挡核心：受击时 20% 概率格挡（伤害减半）
        -- ⚠️ 与「闪避」的差异：闪避是完全免伤；格挡是部分减伤。
        --    判定放在闪避之后，避免两个判定同时触发。
        local blocked = mechs.ironBlock and (math.random() < 0.20)

        -- 敌人攻击力受减益影响
        local mods = Skills.GetEnemyModifiers(enemy.id)
        local atk = enemy.atk * math.max(0, 1 - mods.atk)

        -- 先算技能减伤（铁壁）
        local hurtResult = Skills.TriggerOnHurt(enemy, atk, stacks, stats, allEnemies)
        PlayTriggeredSkills(hurtResult.triggeredSkills)

        -- 反伤
        if (hurtResult.reflectDamage or 0) > 0 then
            enemy.hp = math.floor(enemy.hp - hurtResult.reflectDamage)
            Damage(enemy.x, enemy.z, math.floor(hurtResult.reflectDamage), "crit")
            if enemy.hp <= 0 then
                enemy.hp = 0
                enemy.isDead = true
                if onEnemyKilled_ then onEnemyKilled_(enemy) end
            end
        end

        local armorReduce = math.min(0.9, (stats.armor or 0) / ((stats.armor or 0) + 300))
        local rawDmg = atk * (1 - armorReduce) * (1 - (stats.damageReduce or 0))
        rawDmg = rawDmg * (1 - math.min(0.9, hurtResult.reduceRatio or 0))

        -- 等级压制：怪物等级 > 玩家等级时，怪物伤害倍率上升
        local playerLv = Data.GetLevel()
        local enemyLv = enemy.level or 1
        local suppress = math.max(0, enemyLv - playerLv)
        if suppress > 0 then
            local factor = 1 + math.min(Shared.C.SUPPRESS_MONSTER_DMG_MAX,
                suppress * Shared.C.SUPPRESS_MONSTER_DMG_PER_LEVEL)
            rawDmg = rawDmg * factor
        end

        local finalDmg = math.max(1, math.floor(rawDmg))

        -- 格挡：伤害减半（至少 1 点）
        if blocked then
            finalDmg = math.max(1, math.floor(finalDmg * 0.5))
        end

        local newHp = d.hp - finalDmg
        if newHp <= 0 then
            newHp = 0
            d.isDead = true
        end
        d.hp = newHp

        -- 回春等受伤回复
        if (hurtResult.healAmount or 0) > 0 then
            d.hp = math.floor(math.min(stats.maxHp, d.hp + hurtResult.healAmount))
        end

        -- 天赋树-铁壁荆棘核心：受击反弹 40% 伤害给攻击者。
        -- ⚠️ 与技能 thornArmor（概率反射）不同：本机制**常驻**，不掷骰。
        -- ⚠️ 必须判 not enemy.isDead：上面的技能反伤可能已把怪打死并结算过，
        --    再走一次会重复触发 onEnemyKilled_（重复掉落 / 金币 / 击杀数）。
        --    复用函数开头已读的 mechs，不再重新 require。
        if mechs.ironThorns and not enemy.isDead then
            local reflectDmg = math.max(1, math.floor(finalDmg * 0.40))
            enemy.hp = math.max(0, math.floor(enemy.hp - reflectDmg))
            Damage(enemy.x, enemy.z, reflectDmg, "crit")
            if enemy.hp <= 0 then
                enemy.isDead = true
                if onEnemyKilled_ then onEnemyKilled_(enemy) end
            end
        end

        -- 格挡时飘"格挡"字，与普通伤害视觉区分
        if blocked then
            PlayerDamage("格挡 " .. finalDmg, "miss")
        else
            PlayerDamage(finalDmg, "player")
        end
        return finalDmg
    end

    -- 死亡惩罚已移除：全身每件 -DEATH_DURABILITY_LOSS 的逻辑在
    -- Client.HandleEnemyAttack 里完整实现（含损坏槽位统计），此处是无人调用的死代码。

    -- （升级逻辑已迁到 Client.HandleEnemyKilled：按击杀数升级 + 关卡装备门槛）

    --- 每帧刷新：累积的共享 BOSS 伤害每 5 秒上报一次。
    ---@param dt number
    function Combat.Update(dt)
        combatTime_ = combatTime_ + (dt or 0)
        if not reportBossDamage_ then return end
        for bossId, acc in pairs(bossDamageAccum_) do
            if combatTime_ - acc.t0 >= 5.0 then
                -- 通过 callback 上报（callback 内部需要 enemy 对象，这里只带 id/damage）
                reportBossDamage_({ id = bossId }, acc.dmg)
                bossDamageAccum_[bossId] = nil
            end
        end
    end
    Battle.Combat = Combat
end

return Battle
