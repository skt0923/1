-- ============================================================
-- Battle_Water.lua：湖泊水面（阶段 2.2 批 1）【临时实现】
--
-- 批 1 目标：只验证「位置 / 尺寸 / 高度」三项，不追求好看。
--   步骤 0：地形挖坑（已在 Battle_Terrain.lua 里做）
--   步骤 A：一个纯色圆盘躺在坑里
--
-- ⚠️ 本批**不新建 shader**，材质复用 terrain_toon.shader + 明显的青蓝色，
--    方便肉眼确认圆盘的位置和高度对不对。
--    半透明 / 波纹 / Toon 高光 / 反射属于批 3，等批 2 的 shader 能力探查过了再做。
--
-- 圆盘用 V.revolve 拼：profile 只有两个点（圆心 + 边缘），
-- 所以旋转出来是一个平坦的圆盘，不是碗。
-- ============================================================
local Shared = require("Shared")

local Water = {}

---@type Node|nil
local waterNode_ = nil
---@type Material|nil
local waterMat_ = nil

-- 临时水面色：明显的青蓝色，便于肉眼确认位置
-- ⚠️ 两套表示要分开：
--    WATER_RGB  给 V.tri 用（它要 number[] {r,g,b}，不是 Color 对象）
--    WATER_COLOR 给材质 MatDiffColor 用（它要 Color）
local WATER_RGB   = { 0.25, 0.62, 0.78 }
local WATER_COLOR = Color(WATER_RGB[1], WATER_RGB[2], WATER_RGB[3], 1.0)

--- 构建水面圆盘
---@param scene Scene
---@return Node|nil
function Water.Build(scene)
    if waterNode_ then return waterNode_ end
    if not scene then
        print("[Water] ⚠️ scene 为空，水面未创建")
        return nil
    end

    -- 取地形模块：湖泊信息与水位都由它提供（单一数据源）
    -- ⚠️ 与 Client_Network 相同的取法：require Battle_Visual 拿 Visual.Terrain。
    --    不能 require("Battle")（无此模块）。
    local Visual  = require("Battle_Visual").Visual
    local Terrain = Visual.Terrain
    local cx, cz, lakeR = Terrain.GetLakeInfo()
    local waterY = Terrain.GetWaterY()

    -- 圆盘半径比湖大一圈（湖 120 → 圆盘 135），让边缘盖过地形、
    -- 避免看到圆盘与坑壁之间的缝隙。边缘遮挡（石头/芦苇）是阶段 2.1 的事。
    local DISK_R = lakeR + 15
    local SEGS   = 64      -- 圆周分段；64 段在 135 米半径下每段约 13 米，肉眼已够圆

    waterNode_ = scene:CreateChild("WaterSurface", LOCAL)
    waterNode_.position = Vector3(cx, waterY, cz)

    local geom = waterNode_:CreateComponent("CustomGeometry", LOCAL)
    geom:SetNumGeometries(1)
    geom:BeginGeometry(0, TRIANGLE_LIST)

    -- 🔴 不用 V.revolve 拼平面 —— 它把 profile 两点旋转成「零高度侧面」，
    --    生成的四边形法线是**水平朝外**的，再叠加 cull_back 就会看不见。
    --    这里直接手工拼扇形：圆心 + 相邻两个边缘点，法线朝上。
    --
    -- 绕序（从上方俯视，X 右 Z 上）：
    --    圆心(0,0) → 边缘(a1) → 边缘(a2)，逆时针 → 法线朝 +Y（朝上）
    local Battle = require("Battle_World")
    local V = Battle.V
    local center = Vector3(0, 0, 0)
    for i = 0, SEGS - 1 do
        local a1 = 2 * math.pi * i / SEGS
        local a2 = 2 * math.pi * (i + 1) / SEGS
        local v1 = Vector3(DISK_R * math.cos(a1), 0, DISK_R * math.sin(a1))
        local v2 = Vector3(DISK_R * math.cos(a2), 0, DISK_R * math.sin(a2))
        -- 从上方看逆时针：center → v2 → v1
        -- ⚠️ 第 5 个参数要 number[] {r,g,b}，不是 Color（传 Color 顶点色会写不进去）
        V.tri(geom, center, v2, v1, WATER_RGB)
    end

    -- 🔴 必须 Commit！BeginGeometry + Define* 只是往缓冲区写，
    --    不 Commit 的话几何始终为空 —— boundingBox 全 0、画面上什么都看不到。
    --    （Battle_Visual 的注释也写着「调用方负责调用 geom:Commit()」）
    geom:Commit()
    print(string.format("[Water] 圆盘几何已生成并 Commit：%d 个三角扇形，半径 %.0f",
        SEGS, DISK_R))

    -- 材质：批 2 起改用测试 shader（探查 blend / TIME / worldPos）。
    -- 若 shader 加载失败，回退到纯色 PBR，保证圆盘仍可见。
    waterMat_ = Material:new()
    if waterMat_:SetSurfaceShader("Shaders/BLGL/test_water.shader") then
        geom:SetMaterial(waterMat_)
        print("[Water] 水面材质 = test_water.shader（批 2 探查用）")
    else
        print("[Water] ⚠️ test_water.shader 加载失败，回退纯色 PBR")
        local tech = cache:GetResource("Technique", "Techniques/PBR/PBRNoTexture.xml")
        if tech then
            waterMat_ = Material:new()
            waterMat_:SetTechnique(0, tech)
            waterMat_:SetShaderParameter("MatDiffColor", Variant(WATER_COLOR))
            geom:SetMaterial(waterMat_)
        end
    end

    -- 水面不投影、不接收阴影：批 1 只需要看形状，
    -- 阴影会让半透明的坑看起来更乱，等批 3 再决定
    geom.castShadows = false

    -- ===== 诊断日志：逐项确认，便于定位"看不见"卡在哪一步 =====
    -- ⚠️ 用 GetBoundingBox() 方法，不是 .boundingBox 字段（后者在类型定义里不存在）
    local bb = geom:GetBoundingBox()
    print(string.format("[Water][诊断] 节点 position=(%.1f, %.2f, %.1f)",
        waterNode_.position.x, waterNode_.position.y, waterNode_.position.z))
    print(string.format("[Water][诊断] 几何 boundingBox min=(%.1f,%.1f,%.1f) max=(%.1f,%.1f,%.1f)",
        bb.min.x, bb.min.y, bb.min.z, bb.max.x, bb.max.y, bb.max.z))
    print(string.format("[Water][诊断] 材质=%s 顶点色=%.2f,%.2f,%.2f",
        waterMat_ and "PBRNoTexture" or "无(用默认)",
        WATER_COLOR.r, WATER_COLOR.g, WATER_COLOR.b))
    -- 湖心处的地形高度与水位对照（判断圆盘是否露在地形之上）
    local terrainAtCenter = Terrain.HeightAt(cx, cz)
    local terrainAtEdge   = Terrain.HeightAt(cx, cz + DISK_R)
    print(string.format(
        "[Water][诊断] 湖心地形Y=%.2f 水位Y=%.2f 差值=%+.2f（应为正=水在地形之上）",
        terrainAtCenter, waterY, waterY - terrainAtCenter))
    print(string.format(
        "[Water][诊断] 圆盘边缘处地形Y=%.2f 水位Y=%.2f 差值=%+.2f（应为负=边缘被地形盖住）",
        terrainAtEdge, waterY, waterY - terrainAtEdge))

    print(string.format(
        "[Water] ✅ 水面已创建：湖心(%.0f,%.0f) 湖半径%.0f 圆盘半径%.0f 水位Y=%.2f",
        cx, cz, lakeR, DISK_R, waterY))
    return waterNode_
end

--- 移除水面（调试用）
function Water.Remove()
    if waterNode_ then
        waterNode_:Remove()
        waterNode_ = nil
        print("[Water] 水面已移除")
    end
end

--- 取水面节点（供扫描工具改缩放/位置）。
---@return Node|nil
function Water.GetNode()
    return waterNode_
end

--- 重新加载水面 shader（批 2 探查用：改完 .shader 的 #define 后调用）
function Water.ReloadShader()
    if not waterNode_ then
        print("[Water] ⚠️ 水面未创建，无法重载 shader")
        return
    end
    local mat = Material:new()
    if mat:SetSurfaceShader("Shaders/BLGL/test_water.shader") then
        waterMat_ = mat
        local geom = waterNode_:GetComponent("CustomGeometry")
        if geom then geom:SetMaterial(mat) end
        print("[Water] ✅ 水面 shader 已重载（探查用）")
    else
        print("[Water] ⚠️ shader 重载失败")
    end
end

return Water
