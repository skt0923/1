-- ============================================================
-- Server.lua：服务端框架
--
-- 内容：
--   CloudSave     云存档读写
--   ServerPlayer  玩家生命周期
--   ActionRouter  操作路由（玩法层）
--   RoomManager   房间管理（框架层）
--   ServerNet     网络层
--   ServerMain    入口
--
-- 房间操作（list/create/join/auto_match/leave/ready/unready）由框架层
-- 统一处理；玩法只实现 onRoomStart 回调（初始化自己的对局数据）。
-- ============================================================
local Shared   = require("Shared")
local Protocol = Shared.Protocol
local ModeRegistry = Shared.ModeRegistry

local Server = {}

-- ============================================================
-- 一、CloudSave：云存档
-- ============================================================

local CloudSave = {}

local players_ = {}

function CloudSave.Init(players)
    players_ = players or {}
end

local function UserIdOf(pid)
    local n = tostring(pid):match("^u(%d+)$")
    if not n then return nil end
    local id = tonumber(n)
    if not id then return nil end
    return math.floor(id)
end

local function DecodeSave(raw)
    if type(raw) == "string" then return Shared.SafeDecode(raw) end
    if type(raw) == "table" then return raw end
    return nil
end

function CloudSave.Push(pid, json)
    local uid = UserIdOf(pid)
    if not uid then return end
    serverCloud:Set(uid, CloudSave.SAVE_KEY, json, {
        ok = function() end,
        error = function(code, reason)
            print("[CloudSave] 写入失败 " .. pid
                .. " code=" .. tostring(code)
                .. " reason=" .. tostring(reason))
        end,
    })
end

function CloudSave.Load(pid, cb)
    local uid = UserIdOf(pid)
    if not uid then
        cb(nil, false)
        return
    end

    local done = false
    local function Finish(save, loaded)
        if done then return end
        done = true
        cb(save, loaded)
    end

    serverCloud:Get(uid, CloudSave.SAVE_KEY, {
        ok = function(scores)
            local save = DecodeSave(scores and scores[CloudSave.SAVE_KEY])
            Finish(save, true)
        end,
        error = function(code, reason)
            print("[CloudSave] 读取失败 " .. pid
                .. " code=" .. tostring(code)
                .. " reason=" .. tostring(reason))
            Finish(nil, false)
        end,
    })
end

function CloudSave.Save(pid, snapshot)
    local p = players_[pid]
    if not p then return end
    if not p.saveLoaded then
        print("[CloudSave] " .. pid .. " 云档未读回，跳过落盘")
        return
    end
    CloudSave.Push(pid, snapshot())
end

CloudSave.SAVE_KEY = "player_save_v1"

-- ============================================================
-- 二、ServerPlayer：玩家生命周期
-- ============================================================

local ServerPlayer = {}

local spCtx = {
    players = {},
    connections = {},
    getScene = function() return nil end,
    serverMaxPlayers = 10,
    broadcastOnlineCount = function() end,
}

function ServerPlayer.Init(c)
    for k, v in pairs(c) do spCtx[k] = v end
end

local function NewPlayer(id, userId, nickname)
    return {
        id = id,
        userId = userId,
        node = nil,
        nickname = nickname or "玩家",
        currentMode = nil,
        modeData = nil,
        saveLoaded = false,
    }
end

function ServerPlayer.Snapshot(p)
    return cjson.encode({
        currentMode = p.currentMode or "",
        modeData    = p.modeData or {},
    })
end

function ServerPlayer.ApplySave(p, save)
    if type(save) ~= "table" then save = {} end
    p.currentMode = save.currentMode or nil
    p.modeData    = save.modeData or nil
end

function ServerPlayer.OnClientReady(_, e)
    local c = e["Connection"]:GetPtr("Connection")
    local info = spCtx.connections[tostring(c)]
    if not info then return end

    local myUid = info.userId
    local alreadyIn = false
    if myUid then
        for _, other in pairs(spCtx.players) do
            if other.userId == myUid then
                alreadyIn = true
                break
            end
        end
    end
    if not alreadyIn then
        local n = 0
        for _ in pairs(spCtx.players) do n = n + 1 end
        if n >= spCtx.serverMaxPlayers then
            print(string.format("[ServerPlayer] 服务器已满（%d/%d），拒绝 %s",
                n, spCtx.serverMaxPlayers, tostring(info.userId or "?")))
            c:SendRemoteEvent(Protocol.S2C.SERVER_FULL, true,
                Shared.ToVariantMap({ Max = spCtx.serverMaxPlayers }))
            spCtx.connections[tostring(c)] = nil
            c:Disconnect(0)
            return
        end
    end

    c.scene = spCtx.getScene()

    local pid
    if info.userId then
        pid = "u" .. tostring(info.userId)
    else
        pid = info.fallbackId or ("p" .. tostring(math.random(100000, 999999)))
        info.fallbackId = pid
        print("[ServerPlayer] ⚠️ " .. pid .. " 使用回退 ID")
    end
    info.playerId = pid

    local sc = spCtx.getScene()
    local stale = sc:GetChild("Player_" .. pid, false)
    if stale then
        stale:Remove()
        print("[ServerPlayer] " .. pid .. " 移除残留同名节点")
    end

    local node = sc:CreateChild("Player_" .. pid, REPLICATED)
    node.position = Vector3(0, 0, 0)

    local existing = spCtx.players[pid]
    if existing then
        print("[ServerPlayer] " .. pid .. " 顶号，复用内存状态")
        if existing.node then existing.node:Remove() end
        existing.node = node
        existing.nickname = info.nickname or existing.nickname
        ServerPlayer.SendAssignPlayer(c, existing)
        return
    end

    local p = NewPlayer(pid, info.userId, info.nickname)
    p.node = node
    spCtx.players[pid] = p

    ServerPlayer.SendAssignPlayer(c, p)
    print("[ServerPlayer] " .. pid .. " 上线（本地档）")

    spCtx.broadcastOnlineCount()

    CloudSave.Load(pid, function(save, loaded)
        local live = spCtx.players[pid]
        if not live then return end

        live.saveLoaded = true

        if loaded and type(save) == "table" then
            ServerPlayer.ApplySave(live, save)
            ServerPlayer.SendAssignPlayer(c, live)
            print("[ServerPlayer] " .. pid .. " 云档已恢复")
        elseif loaded then
            print("[ServerPlayer] " .. pid .. " 无历史存档，保持默认")
        else
            print("[ServerPlayer] " .. pid .. " 读档失败")
            c:SendRemoteEvent(Protocol.S2C.SAVE_FAILED, true, Shared.ToVariantMap({}))
        end
    end)
end

function ServerPlayer.SendAssignPlayer(c, p)
    local payload = {
        PlayerId = p.id,
        Nickname = p.nickname or "玩家",
        ModeId   = p.currentMode or "",
        ModeData = cjson.encode(p.modeData or {}),
    }
    c:SendRemoteEvent(Protocol.S2C.ASSIGN_PLAYER, true, Shared.ToVariantMap(payload))
end

--- 玩家断开连接
--- 新增：如果玩家在房间里，先清理房间状态
function ServerPlayer.OnDisconnect(pid)
    local p = spCtx.players[pid]
    if not p then return end

    -- 🔴 兜底：清理房间状态
    local roomMgr = Server.GetRoomManager()
    if roomMgr then
        roomMgr.OnPlayerDisconnect(pid)
    end

    CloudSave.Save(pid, function() return ServerPlayer.Snapshot(p) end)
    if p.node then
        p.node:Remove()
        p.node = nil
    end
    spCtx.players[pid] = nil
    spCtx.broadcastOnlineCount()
    print("[ServerPlayer] " .. pid .. " 下线")
end

function ServerPlayer.FromConnection(c)
    local info = spCtx.connections[tostring(c)]
    if not info then return nil, nil end
    local p = info.playerId and spCtx.players[info.playerId]
    return p, info
end

-- ============================================================
-- 三、ActionRouter：玩法层的操作路由
-- ============================================================

local ActionRouter = {}

local routerModes_ = {}

function ActionRouter.Register(modeId, reg)
    assert(type(modeId) == "string" and modeId ~= "", "modeId 必填")
    assert(type(reg) == "table", "reg 必须是表")
    assert(type(reg.actions) == "table", "reg.actions 必填")

    local n = 0
    for _ in pairs(reg.actions) do n = n + 1 end

    routerModes_[modeId] = {
        actions      = reg.actions,
        onEnter      = reg.onEnter,
        onLeave      = reg.onLeave,
        onDisconnect = reg.onDisconnect,
        onUpdate     = reg.onUpdate,
        canJoin      = reg.canJoin,
        onPlayerJoin = reg.onPlayerJoin,
        onRoomStart  = reg.onRoomStart,
    }
    print("[Router] " .. modeId .. " 已注册（" .. n .. " 个操作）")
end

function ActionRouter.HasMode(modeId)
    return routerModes_[modeId] ~= nil
end

function ActionRouter.Dispatch(player, action, payload)
    if not player then return false, { reason = "player 为空" } end

    local modeId = player.currentMode
    if not modeId or modeId == "" then
        return false, { reason = "未进入任何玩法" }
    end

    local m = routerModes_[modeId]
    if not m then
        print("[Router] ⚠️ 玩法 " .. modeId .. " 未注册")
        return false, { reason = "玩法未注册：" .. modeId }
    end

    local handler = m.actions[action]
    if not handler then
        return false, { reason = "未知操作：" .. action }
    end

    local ok, success, result = pcall(handler, player, payload or {})
    if not ok then
        print("[Router] " .. modeId .. " 操作 " .. action
            .. " 抛错：" .. tostring(success))
        return false, { reason = "服务端处理失败" }
    end

    if success == nil then success = true end
    return success == true, result
end

function ActionRouter.FireEnter(player)
    local modeId = player.currentMode
    if not modeId then return false, { reason = "modeId 为空" } end
    local m = routerModes_[modeId]
    if not m then return false, { reason = "玩法未注册" } end
    if not m.onEnter then return true, nil end

    local ok, success, result = pcall(m.onEnter, player)
    if not ok then
        print("[Router] " .. modeId .. " onEnter 抛错：" .. tostring(success))
        return false, { reason = "进入失败" }
    end
    if success == nil then success = true end
    return success == true, result
end

function ActionRouter.FireLeave(player)
    local modeId = player.currentMode
    if not modeId then return true, nil end
    local m = routerModes_[modeId]
    if not m or not m.onLeave then return true, nil end

    local ok, success, result = pcall(m.onLeave, player)
    if not ok then
        print("[Router] " .. modeId .. " onLeave 抛错：" .. tostring(success))
        return false, { reason = "退出失败" }
    end
    if success == nil then success = true end
    return success == true, result
end

function ActionRouter.FireDisconnect(player)
    local modeId = player and player.currentMode
    if not modeId then return end
    local m = routerModes_[modeId]
    if not m or not m.onDisconnect then return end
    pcall(m.onDisconnect, player)
end

function ActionRouter.Update(dt)
    for _, m in pairs(routerModes_) do
        if m.onUpdate then
            pcall(m.onUpdate, dt)
        end
    end
end

function ActionRouter.FirePlayerJoin(player, modeId, joiner)
    local m = routerModes_[modeId]
    if not m or not m.onPlayerJoin then return end
    pcall(m.onPlayerJoin, player, joiner)
end

--- 新增：房间开局时触发（由 RoomManager 调用）
---@param player table
---@param room table
function ActionRouter.FireRoomStart(player, room)
    local modeId = player and player.currentMode
    if not modeId then return end
    local m = routerModes_[modeId]
    if not m or not m.onRoomStart then return end
    pcall(m.onRoomStart, player, room)
end

-- ============================================================
-- 四、RoomManager：框架层房间管理（占位声明）
-- ============================================================
-- 🔴 关键：这里只声明空表，函数在 ServerNet 之后填充。
--    因为 ServerNet 的部分函数（如 PushState）需要引用 RoomManager，
--    而 RoomManager 的部分函数也需要引用 ServerNet。
--    用"先声明表、后填充函数"的方式解决循环依赖。
-- ============================================================

local RoomManager = {}

-- ============================================================
-- 五、ServerNet：服务端网络层
-- ============================================================

local ServerNet = {}

local snPlayers_ = {}
local snConnections_ = {}
local snScene_ = nil

function ServerNet.Start()
    print("[ServerNet] Starting...")

    snScene_ = Scene()
    snScene_:CreateComponent("Octree", LOCAL)
    print("[ServerNet] 场景已创建")

    Protocol.RegisterServerEvents()

    CloudSave.Init(snPlayers_)
    ServerPlayer.Init({
        players = snPlayers_,
        connections = snConnections_,
        getScene = function() return snScene_ end,
        serverMaxPlayers = _G.SERVER_MAX_PLAYERS or Shared.C.MAX_PLAYERS,
        broadcastOnlineCount = ServerNet.BroadcastOnlineCount,
    })

    SubscribeToEvent("ClientConnected",    "OnConnected")
    SubscribeToEvent("ClientIdentity",     "OnIdentity")
    SubscribeToEvent("ClientDisconnected", "OnDisconnected")
    SubscribeToEvent(Protocol.C2S.CLIENT_READY,     ServerPlayer.OnClientReady)
    SubscribeToEvent(Protocol.C2S.ACTION_REQUEST,   "OnActionRequest")
    SubscribeToEvent(Protocol.C2S.ENTER_MODE,       "OnEnterMode")
    SubscribeToEvent(Protocol.C2S.LEAVE_MODE,       "OnLeaveMode")
    SubscribeToEvent("Update", "OnUpdate")

    print("[ServerNet] 已启动")
end

function OnConnected(_, e)
    local c = e["Connection"]:GetPtr("Connection")
    snConnections_[tostring(c)] = {
        connection = c,
        userId = nil,
        playerId = nil,
        nickname = nil,
    }
end

function OnIdentity(_, e)
    local c = e["Connection"]:GetPtr("Connection")
    local info = snConnections_[tostring(c)]
    if not info then return end

    local identity = c.identity
    local userId = identity and identity["user_id"]
        and identity["user_id"]:GetInt64() or nil
    if userId then info.userId = userId end

    if identity then
        local nk = identity["nick_name"] or identity["nickname"]
        if nk then
            local ok, s = pcall(function()
                if nk.GetString then return nk:GetString() end
                return tostring(nk)
            end)
            if ok and s and s ~= "" then info.nickname = s end
        end
    end
    if not info.nickname then
        info.nickname = userId and ("玩家" .. tostring(userId)) or "玩家"
    end
end

function OnDisconnected(_, e)
    local c = e["Connection"]:GetPtr("Connection")
    local key = tostring(c)
    local info = snConnections_[key]
    if not info then return end

    local pid = info.playerId
    if pid then
        local hasOther = false
        for _, cinfo in pairs(snConnections_) do
            if cinfo.playerId == pid and cinfo.connection ~= c then
                hasOther = true
                break
            end
        end
        if not hasOther then
            local p = snPlayers_[pid]
            if p then
                ActionRouter.FireDisconnect(p)
            end
            ServerPlayer.OnDisconnect(pid)
        end
    end

    snConnections_[key] = nil
    ServerNet.BroadcastOnlineCount()
end

function ServerNet.PushState(p)
    local info = nil
    for _, i in pairs(snConnections_) do
        if i.playerId == p.id then info = i break end
    end
    if not (info and info.connection) then return end

    -- 🔴 查当前房间
    local roomId = ""
    local room = RoomManager.GetPlayerRoom(p.id)
    if room then roomId = room.id end

    info.connection:SendRemoteEvent(Protocol.S2C.STATE_UPDATE, true,
        Shared.ToVariantMap({
            ModeId   = p.currentMode or "",
            ModeData = cjson.encode(p.modeData or {}),
            RoomId   = roomId,
        }))
end

function ServerNet.BroadcastOnlineCount()
    local n = 0
    for _ in pairs(snPlayers_) do n = n + 1 end
    local payload = Shared.ToVariantMap({ Count = n })
    for _, info in pairs(snConnections_) do
        if info.connection then
            info.connection:SendRemoteEvent(Protocol.S2C.ONLINE_COUNT, true, payload)
        end
    end
end

function ServerNet.BroadcastToMode(modeId, eventName, payload)
    if not modeId or modeId == "" then return end
    local vm = Shared.ToVariantMap(payload)
    for _, p in pairs(snPlayers_) do
        if p.currentMode == modeId then
            local info = nil
            for _, i in pairs(snConnections_) do
                if i.playerId == p.id then info = i break end
            end
            if info and info.connection then
                info.connection:SendRemoteEvent(eventName, true, vm)
            end
        end
    end
end

function ServerNet.SendToPlayer(pid, eventName, payload)
    local info = nil
    for _, i in pairs(snConnections_) do
        if i.playerId == pid then info = i break end
    end
    if not (info and info.connection) then return end
    info.connection:SendRemoteEvent(eventName, true, Shared.ToVariantMap(payload))
end

function OnUpdate(_, e)
    local dt = e["TimeStep"]:GetFloat()

    ActionRouter.Update(dt)
end

function ServerNet.GetPlayer(pid) return snPlayers_[pid] end

-- ============================================================
-- 六、RoomManager：框架层房间管理（函数填充）
-- ============================================================

---@type table<string, table>  roomId → room
local rmRooms_ = {}
---@type table<string, string>  pid → roomId
local rmPlayerRoom_ = {}
---@type table<string, integer> modeId → nextRoomId
local rmNextRoomId_ = {}

--- 生成房间号（每玩法独立自增，从 100 开始）
---@param modeId string
---@return string
local function AllocateRoomId(modeId)
    if not rmNextRoomId_[modeId] then
        rmNextRoomId_[modeId] = 100
    end
    local id = tostring(rmNextRoomId_[modeId])
    rmNextRoomId_[modeId] = rmNextRoomId_[modeId] + 1
    return id
end

--- 查找某玩法的某模式定义
---@param modeId string
---@param gameModeId string
---@return table|nil
local function FindGameMode(modeId, gameModeId)
    local ok, SharedMod = pcall(require, "modes." .. modeId .. ".ModeData")
    if not ok or not SharedMod or not SharedMod.GAME_MODES then
        return nil
    end
    for _, gm in ipairs(SharedMod.GAME_MODES) do
        if gm.id == gameModeId then return gm end
    end
    return nil
end

--- 创建房间
---@param modeId string
---@param gameModeId string
---@param ownerPid string
---@return table|nil room, string|nil reason
function RoomManager.Create(modeId, gameModeId, ownerPid)
    if not modeId or modeId == "" then
        return nil, "modeId 为空"
    end
    if not gameModeId or gameModeId == "" then
        return nil, "gameModeId 为空"
    end
    if rmPlayerRoom_[ownerPid] then
        return nil, "已在其他房间"
    end

    local gm = FindGameMode(modeId, gameModeId)
    if not gm then
        return nil, "游戏模式不存在：" .. gameModeId
    end

    local roomId = AllocateRoomId(modeId)
    local room = {
        id = roomId,
        modeId = modeId,
        gameModeId = gameModeId,
        name = gm.name or gameModeId,
        maxPlayers = gm.maxPlayers,
        minPlayers = gm.minPlayers or gm.maxPlayers,
        ownerPid = ownerPid,
        players = { ownerPid },
        readyPlayers = {},
        status = "waiting",
        createdAt = os.time(),
        gameData = {},
    }

    rmRooms_[roomId] = room
    rmPlayerRoom_[ownerPid] = roomId

    print(string.format("[RoomManager] 创建房间 %s (玩法=%s 模式=%s 房主=%s)",
        roomId, modeId, gameModeId, ownerPid))
    return room, nil
end

--- 加入房间
---@param roomId string
---@param pid string
---@return table|nil room, string|nil reason
function RoomManager.Join(roomId, pid)
    if not roomId or roomId == "" then
        return nil, "房间号为空"
    end
    if rmPlayerRoom_[pid] then
        return nil, "已在其他房间"
    end

    local room = rmRooms_[roomId]
    if not room then
        return nil, "房间不存在：" .. roomId
    end
    if room.status ~= "waiting" then
        return nil, "对局已开始"
    end
    if #room.players >= room.maxPlayers then
        return nil, "房间已满"
    end

    table.insert(room.players, pid)
    rmPlayerRoom_[pid] = roomId

    print(string.format("[RoomManager] %s 加入房间 %s (%d/%d)",
        pid, roomId, #room.players, room.maxPlayers))
    return room, nil
end

--- 离开房间
---@param pid string
---@return table|nil room 被更新的房间（nil 表示房间已被销毁）
function RoomManager.Leave(pid)
    local roomId = rmPlayerRoom_[pid]
    if not roomId then return nil end
    local room = rmRooms_[roomId]
    rmPlayerRoom_[pid] = nil
    if not room then return nil end

    Shared.RemoveFromArray(room.players, pid)
    room.readyPlayers[pid] = nil

    print(string.format("[RoomManager] %s 离开房间 %s (%d/%d)",
        pid, roomId, #room.players, room.maxPlayers))

    if #room.players == 0 then
        rmRooms_[roomId] = nil
        print("[RoomManager] 房间 " .. roomId .. " 已销毁（无玩家）")
        return nil
    end

    -- 房主离开 → 转移给房内第一个玩家
    if room.ownerPid == pid then
        room.ownerPid = room.players[1]
        print("[RoomManager] 房间 " .. roomId .. " 房主转移给 " .. room.ownerPid)
    end

    -- 注：玩家离开【不】改变对局状态。
    -- 曾经的 `if room.status == "playing" then room.status = "ended" end`
    -- 会让任何一次掉线/切后台把整局判为结束并广播 room_state(ended)，
    -- 导致所有在线玩家被踢回大厅。对局是否结束由玩法自己决定。

    return room
end

--- 获取房间
---@param roomId string
---@return table|nil
function RoomManager.Get(roomId)
    return rmRooms_[roomId]
end

--- 获取玩家所在房间
---@param pid string
---@return table|nil
function RoomManager.GetPlayerRoom(pid)
    local roomId = rmPlayerRoom_[pid]
    if not roomId then return nil end
    return rmRooms_[roomId]
end

--- 列出某玩法某模式下所有未满且未开局的房间
---@param modeId string
---@param gameModeId string
---@return table[]
function RoomManager.List(modeId, gameModeId)
    local list = {}
    for _, room in pairs(rmRooms_) do
        if room.modeId == modeId
            and room.gameModeId == gameModeId
            and room.status == "waiting"
            and #room.players < room.maxPlayers then
            table.insert(list, room)
        end
    end
    table.sort(list, function(a, b) return a.createdAt < b.createdAt end)
    return list
end

--- 查找一个可加入的房间（自动匹配用）
---@param modeId string
---@param gameModeId string
---@return table|nil
function RoomManager.FindJoinable(modeId, gameModeId)
    local list = RoomManager.List(modeId, gameModeId)
    if #list == 0 then return nil end
    return list[1]
end

--- 设置玩家准备状态
---@param pid string
---@param ready boolean
---@return table|nil room, string|nil reason
function RoomManager.SetReady(pid, ready)
    local room = RoomManager.GetPlayerRoom(pid)
    if not room then return nil, "不在房间内" end
    if room.status ~= "waiting" then return nil, "对局已开始" end

    if ready then
        room.readyPlayers[pid] = true
    else
        room.readyPlayers[pid] = nil
    end

    print(string.format("[RoomManager] %s ready=%s", pid, tostring(ready)))
    return room, nil
end

--- 检查并尝试自动开局
---@param room table
---@return boolean started
function RoomManager.TryAutoStart(room)
    if room.status ~= "waiting" then return false end
    if #room.players < room.minPlayers then return false end

    for _, pid in ipairs(room.players) do
        if not room.readyPlayers[pid] then return false end
    end

    RoomManager.StartGame(room)
    return true
end

--- 开始游戏
---@param room table
function RoomManager.StartGame(room)
    room.status = "playing"
    print(string.format("[RoomManager] 房间 %s 开局（%d 人）",
        room.id, #room.players))

    for _, pid in ipairs(room.players) do
        local player = ServerNet.GetPlayer(pid)
        if player then
            ActionRouter.FireRoomStart(player, room)
        end
    end

    RoomManager.BroadcastRoomState(room)
end

--- 广播房间状态给房内所有玩家
---@param room table
function RoomManager.BroadcastRoomState(room)
    if not room then return end

    local playerInfos = {}
    for _, pid in ipairs(room.players) do
        local player = ServerNet.GetPlayer(pid)
        if player then
            table.insert(playerInfos, {
                pid = pid,
                nickname = player.nickname or "玩家",
                ready = room.readyPlayers[pid] == true,
                isOwner = (room.ownerPid == pid),
            })
        end
    end

    local publicState = {
        roomId = room.id,
        modeId = room.modeId,
        gameModeId = room.gameModeId,
        gameModeName = room.name,
        maxPlayers = room.maxPlayers,
        minPlayers = room.minPlayers,
        ownerPid = room.ownerPid,
        status = room.status,
        players = playerInfos,
    }

    local json = cjson.encode(publicState)
    for _, pid in ipairs(room.players) do
        ServerNet.SendToPlayer(pid, Protocol.S2C.MODE_BROADCAST, {
            ModeId = room.modeId,
            SubEvent = "room_state",
            Data = json,
        })
    end
end

--- 断线时清理
---@param pid string
function RoomManager.OnPlayerDisconnect(pid)
    local room = RoomManager.GetPlayerRoom(pid)
    if not room then return end
    local updated = RoomManager.Leave(pid)
    if updated then
        RoomManager.BroadcastRoomState(updated)
    end
end

-- ============ 框架层 Action 处理 ============

---@type table<string, fun(player: table, payload: table): boolean, table|nil>
local frameworkActions_ = {}

frameworkActions_.list_rooms = function(player, payload)
    local modeId = payload["ModeId"]
    local gameModeId = payload["GameModeId"]
    if not modeId or modeId == "" then
        return false, { reason = "modeId 为空" }
    end
    if not gameModeId or gameModeId == "" then
        return false, { reason = "gameModeId 为空" }
    end

    local list = RoomManager.List(modeId, gameModeId)
    local result = { rooms = {} }
    for _, room in ipairs(list) do
        local owner = ServerNet.GetPlayer(room.ownerPid)
        table.insert(result.rooms, {
            id = room.id,
            gameModeId = room.gameModeId,
            playerCount = #room.players,
            maxPlayers = room.maxPlayers,
            ownerNickname = owner and owner.nickname or "?",
        })
    end
    return true, result
end

frameworkActions_.create_room = function(player, payload)
    local modeId = payload["ModeId"]
    local gameModeId = payload["GameModeId"]

    local room, reason = RoomManager.Create(modeId, gameModeId, player.id)
    if not room then
        return false, { reason = reason }
    end

    RoomManager.BroadcastRoomState(room)
    return true, { roomId = room.id }
end

frameworkActions_.join_room = function(player, payload)
    local roomId = payload["RoomId"]
    local room, reason = RoomManager.Join(roomId, player.id)
    if not room then
        return false, { reason = reason }
    end

    RoomManager.BroadcastRoomState(room)
    return true, { roomId = roomId }
end

frameworkActions_.auto_match = function(player, payload)
    local modeId = payload["ModeId"]
    local gameModeId = payload["GameModeId"]
    if not modeId or modeId == "" then
        return false, { reason = "modeId 为空" }
    end
    if not gameModeId or gameModeId == "" then
        return false, { reason = "gameModeId 为空" }
    end

    local room = RoomManager.FindJoinable(modeId, gameModeId)
    if room then
        local joined, reason = RoomManager.Join(room.id, player.id)
        if not joined then
            return false, { reason = reason }
        end
        RoomManager.BroadcastRoomState(joined)
        return true, { roomId = joined.id, created = false }
    end

    local newRoom, reason = RoomManager.Create(modeId, gameModeId, player.id)
    if not newRoom then
        return false, { reason = reason }
    end
    RoomManager.BroadcastRoomState(newRoom)
    return true, { roomId = newRoom.id, created = true }
end

frameworkActions_.leave_room = function(player, payload)
    local roomId = rmPlayerRoom_[player.id]
    if not roomId then
        return false, { reason = "不在房间内" }
    end

    local updated = RoomManager.Leave(player.id)
    if updated then
        RoomManager.BroadcastRoomState(updated)
    end
    return true, {}
end

frameworkActions_.ready = function(player, payload)
    local room, reason = RoomManager.SetReady(player.id, true)
    if not room then
        return false, { reason = reason }
    end

    RoomManager.BroadcastRoomState(room)
    RoomManager.TryAutoStart(room)
    return true, {}
end

frameworkActions_.unready = function(player, payload)
    local room, reason = RoomManager.SetReady(player.id, false)
    if not room then
        return false, { reason = reason }
    end

    RoomManager.BroadcastRoomState(room)
    return true, {}
end

function RoomManager.IsFrameworkAction(action)
    return frameworkActions_[action] ~= nil
end

function RoomManager.HandleFrameworkAction(player, action, payload)
    local handler = frameworkActions_[action]
    if not handler then
        return false, { reason = "未知框架操作：" .. action }
    end
    local ok, success, result = pcall(handler, player, payload)
    if not ok then
        print("[RoomManager] 框架操作 " .. action .. " 抛错：" .. tostring(success))
        -- 把真实错误带出去（否则只剩笼统的"服务端处理失败"，无法定位）
        return false, { reason = "框架操作 " .. action .. " 失败：" .. tostring(success) }
    end
    if success == nil then success = true end
    return success == true, result
end

-- ============================================================
-- 七、Action 与进入退出玩法的处理
-- ============================================================

--- 安全读取 VariantMap 的字符串字段。
--- VariantMap 缺字段时 `vm[key]` 返回 nil，直接 `:GetString()` 会崩，
--- 所以统一走这个包装：缺字段 / 取错类型都返回 ""。
---@param vm VariantMap
---@param key string
---@return string
local function VmStr(vm, key)
    local v = vm[key]
    if not v then return "" end
    local ok, s = pcall(function() return v:GetString() end)
    if ok and s then return s end
    return ""
end

--- 处理 Action 请求
--- 优先检查是否是框架层的房间操作；否则走 ActionRouter 到玩法层
function OnActionRequest(_, e)
    local c = e["Connection"]:GetPtr("Connection")
    local p = ServerPlayer.FromConnection(c)
    if not p then return end

    -- 🔍 诊断探针：服务端收到请求时，通过 TOAST 回传给客户端。
    -- 服务端 print 写进 server_user_script.log，用户拿不到；必须走 S2C 回传。
    -- 放在业务逻辑之前，这样即使后面崩了，客户端也已收到"服务端已收到"信号。
    local probeAction = "?"
    pcall(function() probeAction = e["Action"]:GetString() end)
    pcall(function()
        c:SendRemoteEvent(Protocol.S2C.TOAST, true, Shared.ToVariantMap({
            Text = "[Srv] 收到 action=" .. tostring(probeAction),
            Color = "#88ff88",
        }))
    end)

    -- 🔴 整个处理流程用 pcall 包住：任一环节抛错都不让服务端崩，
    --    并把错误通过 ACTION_RESULT.Reason 回传给客户端（客户端会 Toast 出来）。
    --    否则回调永不触发，客户端表现为"点按钮没反应、连 Toast 都没有"。
    local seq = 0
    local action = "?"
    local ok2, err = pcall(function()
        action = e["Action"]:GetString()
        seq    = e["Seq"]:GetInt()

        -- ⚠️ 绝不能写 `for k, v in pairs(e)`！
        --    VariantMap 是 tolua++ 绑定的 C++ 对象，没有 Lua 迭代器，
        --    pairs() 会抛：
        --      bad argument #1 to 'for iterator' (table expected, got VariantMap)
        --    它也没有 Keys()/Size() 方法（见 .emmylua/Variant.manual.d.lua）。
        --    只能按已知字段显式取。新增框架操作若需要新字段，必须在这里登记。
        local payload = {
            ModeId     = VmStr(e, "ModeId"),
            GameModeId = VmStr(e, "GameModeId"),
            RoomId     = VmStr(e, "RoomId"),
        }

        local ok, result
        if RoomManager.IsFrameworkAction(action) then
            ok, result = RoomManager.HandleFrameworkAction(p, action, payload)
        else
            ok, result = ActionRouter.Dispatch(p, action, payload)
        end

        c:SendRemoteEvent(Protocol.S2C.ACTION_RESULT, true, Shared.ToVariantMap({
            Seq = seq,
            Ok = ok and 1 or 0,
            Reason = (result and result.reason) or "",
            Result = cjson.encode(result or {}),
        }))

        if ok then
            ServerNet.PushState(p)
            CloudSave.Save(p.id, function() return ServerPlayer.Snapshot(p) end)
        end
    end)

    if not ok2 then
        print("[Server] ⚠️ OnActionRequest 崩溃 action=" .. tostring(action)
            .. " seq=" .. tostring(seq)
            .. " err=" .. tostring(err))

        -- ACTION_RESULT 保留（万一 seq 能匹配上；seq=0 时客户端会静默丢弃）
        pcall(function()
            c:SendRemoteEvent(Protocol.S2C.ACTION_RESULT, true, Shared.ToVariantMap({
                Seq = seq,
                Ok = 0,
                Reason = "服务端处理失败：" .. tostring(err),
                Result = "{}",
            }))
        end)

        -- 🔍 TOAST 回传（不依赖 seq，客户端一定能看到）
        pcall(function()
            c:SendRemoteEvent(Protocol.S2C.TOAST, true, Shared.ToVariantMap({
                Text = "[Srv 崩溃] " .. tostring(err),
                Color = "#ff6666",
            }))
        end)
    end
end

--- 进入玩法（只进入房间列表，不创建/加入房间）
function OnEnterMode(_, e)
    local c = e["Connection"]:GetPtr("Connection")
    local p = ServerPlayer.FromConnection(c)
    if not p then return end

    local modeId = e["ModeId"]:GetString()
    local seq = e["Seq"]:GetInt()

    local function reply(ok, reason)
        c:SendRemoteEvent(Protocol.S2C.ACTION_RESULT, true, Shared.ToVariantMap({
            Seq = seq, Ok = ok and 1 or 0,
            Reason = reason or "", Result = "{}",
        }))
    end

    if not modeId or modeId == "" then
        reply(false, "模式 ID 为空")
        return
    end

    if not ModeRegistry.Exists(modeId) then
        reply(false, "玩法不存在：" .. modeId)
        return
    end

    if not ActionRouter.HasMode(modeId) then
        reply(false, "玩法未就绪：" .. modeId)
        return
    end

    -- 🔴 兜底：如果玩家在某个房间里，先自动离开
    local oldRoom = RoomManager.GetPlayerRoom(p.id)
    if oldRoom then
        local updated = RoomManager.Leave(p.id)
        if updated then
            RoomManager.BroadcastRoomState(updated)
        end
    end

    -- 如果在旧玩法里，先退出旧玩法
    if p.currentMode and p.currentMode ~= "" then
        ActionRouter.FireLeave(p)
    end

    p.currentMode = modeId
    p.modeData = p.modeData or {}

    local ok, result = ActionRouter.FireEnter(p)
    if not ok then
        p.currentMode = nil
        p.modeData = nil
        reply(false, (result and result.reason) or "进入失败")
        return
    end

    reply(true, "")

    for _, other in pairs(snPlayers_) do
        if other.id ~= p.id and other.currentMode == modeId then
            ActionRouter.FirePlayerJoin(other, modeId, p)
        end
    end

    ServerNet.PushState(p)
    CloudSave.Save(p.id, function() return ServerPlayer.Snapshot(p) end)
    print("[ServerNet] " .. p.id .. " 进入玩法 " .. modeId)
end

--- 退出玩法（回大厅）
function OnLeaveMode(_, e)
    local c = e["Connection"]:GetPtr("Connection")
    local p = ServerPlayer.FromConnection(c)
    if not p then return end

    local seq = e["Seq"]:GetInt()
    local oldMode = p.currentMode

    -- 🔴 兜底：如果玩家在房间里，先自动离开
    local oldRoom = RoomManager.GetPlayerRoom(p.id)
    if oldRoom then
        local updated = RoomManager.Leave(p.id)
        if updated then
            RoomManager.BroadcastRoomState(updated)
        end
    end

    if oldMode then
        ActionRouter.FireLeave(p)
    end

    p.currentMode = nil
    p.modeData = nil

    c:SendRemoteEvent(Protocol.S2C.ACTION_RESULT, true, Shared.ToVariantMap({
        Seq = seq, Ok = 1, Reason = "", Result = "{}",
    }))

    ServerNet.PushState(p)
    CloudSave.Save(p.id, function() return ServerPlayer.Snapshot(p) end)
    print("[ServerNet] " .. p.id .. " 退出玩法")
end

-- ============================================================
-- 八、ServerMain：入口
-- ============================================================

local AllModes = require("modes.AllModes")

function Server.Start()
    print("[Server] Starting...")

    AllModes.RegisterAllForServer()

    ServerNet.Start()

    print("[Server] 已启动")
end

function Server.Stop()
    print("[Server] Stopping...")
end

-- ============ 对外接口 ============
function Server.GetRouter()
    return ActionRouter
end

function Server.GetRoomManager()
    return RoomManager
end

return Server
