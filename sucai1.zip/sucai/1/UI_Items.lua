-- ============================================================
-- UI_Items.lua：围绕「物品」的功能域
--
-- 内容：背包 / 装备穿戴 / 物品详情 / 技能详情 / 角色面板
--
-- 依赖：Shared + UI_Core（共享基础设施）。
--       与另一个功能域**不 require**，跨域调用走 Panels.X
--       （三个文件写入同一张表，见 UI_Core 顶部说明）。
-- ============================================================
local Shared = require("Shared")
local Data   = Shared.Data
local Notify = Shared.Notify

local Core = require("UI_Core")

-- 与 UI_Core 共用同一张 Panels 表
local Panels = Core

-- 宠物系统（用于背包里宠物的"放回待选池"操作）
local PetSys = require("Pet_System")

-- 无状态通用控件（加载时捕获即可）
local QLabel           = Core.QLabel
local QButton          = Core.QButton
local OpenModal        = Core.OpenModal
local OpenStackedModal = Core.OpenStackedModal

-- ⚠️ 注入值走稳定容器：Panels.Init / SetStatProvider 在运行时填充，
--    不能在这里取局部量（那会是 nil）。用短别名保持代码可读。
local S = Core.shared


-- ============================================================
-- 背包
-- ============================================================
local invSelectMode_ = false
---@type table<string, boolean>
local invSelected_ = {}

-- ⚠️ 用于区分「重开刷新」与「真正关闭」：
--    点「选择模式」会调 OpenInventory 重开自己，OpenModal 内部先 CloseCurrent
--    会触发上一实例的 onClose —— 若 onClose 无条件重置选择状态，
--    刚置位的选择模式标志立刻被清掉，按钮永远进不了选择态。
local reopeningInventory_ = false

function Panels.OpenInventory()
    reopeningInventory_ = true
    -- ⚠️ headerContentGap = 0：让格子紧贴标题栏。
    --    Modal 内容区的起始 Y 由 Modal.lua 的 RenderHeader 直接算出
    --    （y + headerHeight + (headerContentGap or 16)），**不经过 flex 布局**，
    --    所以靠子节点的 marginTop 是推不动的 —— 必须走这个 props。
    local modal = OpenModal("inventory", "背包", "lg", function()
        -- 只在真正关闭（非重开）时重置选择状态
        if not reopeningInventory_ then
            invSelectMode_ = false
            invSelected_ = {}
        end
    end, {
        headerContentGap = 0,
        -- ⚠️ 属性名是 contentPadding，不是 padding（ModalProps 里没有 padding，
        --    传 padding 会被静默忽略）。
        -- ⚠️ 这里必须显式把 footer 放进 AddContent 的内容里（见下方 children），
        --    所以整个 footer 都算「内容」。Modal 高度 =
        --      contentHeight + cpTop + cpBottom + headerHeight
        --    内容结束到 Modal 底边的空隙 = cpTop + cpBottom（因为 headerContentGap
        --    只控制「标题→内容」，cpTop 在这条路径上只贡献底部空隙）。
        --    默认 16×2 = 32px，缩到 6×2 = 12px 可省 20px 高度。
        contentPadding = 6,
        -- ⚠️ headerHeight 默认 56，而「背包」两个字只有约 26px 高，
        --    垂直居中后上下各留约 15px —— 这段留白 headerContentGap 管不到
        --    （它只控制「header 底部 → 内容顶部」）。
        --    缩到 40：字 26 + 上下各 7，正好贴住；关闭按钮 28px 也放得下
        --    （按钮 Y = (40-28)/2 = 6，底边 34 < 40）。
        --    省 16px 高度。
        headerHeight = 40,
    })
    reopeningInventory_ = false

    -- ⚠️ SimpleGrid 只在构造时处理 props.children，构造后再赋值不会生效，
    --    所以格子必须先组装好，再一次性传进构造函数。
    local slots = {}

    local inv = Data.value.inventory
    -- 格子数跟随服务端下发的背包容量（Data.BagCapacity()），不再硬编码 24。
    -- ⚠️ 服务端向 p.inventory 插入装备时没有上限校验（如邮箱领取、市场购买），
    --    若背包实际超过容量，超出部分在界面上不可见。拾取侧由
    --    Client.lua 的 Data.BagCapacity() 兜底（满了转投邮箱），此处仅控制显示。
    local bagCapacity = Data.BagCapacity()
    for i = 1, bagCapacity do
        local item = inv[i]
        local qcolor = item and (Shared.QUALITY_COLORS[item.quality] or "#dddddd") or "#555555"

        local iconText = ""
        local subText = ""
        if item then
            iconText = item.icon or "?"
            if Data.IsStackable(item) then
                subText = "x" .. (item.count or 1)
            elseif (item.enhanceLevel or 0) > 0 then
                subText = "+" .. item.enhanceLevel
            end
        end

        -- 耐久为 0 的装备：整格标红，一眼可见已损坏（词条与技能失效）
        local broken = item and Shared.IsEquipment(item) and (item.durability or 0) <= 0
        local selected = item and invSelectMode_ and invSelected_[item.id]

        -- 单格布局：左上等级/右上强化 → 图标居中 → 底部名称
        local cornerL = ""
        local cornerR = ""
        local nameText = ""
        if item then
            if Data.IsStackable(item) then
                cornerR = subText
            else
                if (item.requiredLevel or 0) > 1 then cornerL = "Lv." .. item.requiredLevel end
                if (item.enhanceLevel or 0) > 0 then cornerR = "+" .. item.enhanceLevel end
            end
            if Shared.IsEquipment(item) then
                local dur = math.floor(item.durability or 0)
                local durColor = "#aabbcc"
                if dur <= 0 then durColor = "#ff4444"
                elseif dur <= 20 then durColor = "#ffcc44" end
                nameText = (Shared.QUALITY_NAMES[item.quality] or "") .. " " .. (item.slotName or "")
                -- 耐久以右下角小字附加在名称行
                nameText = nameText .. "  " .. dur
            else
                nameText = item.name or ""
            end
        end

        local cellChildren = {
            -- 图标居中
            S.UI.Label { text = iconText, fontSize = 18 },
        }
        if nameText ~= "" then
            table.insert(cellChildren, S.UI.Label {
                text = nameText, fontSize = 7, maxLines = 1,
                fontColor = Shared.HexRGB(item and Shared.IsEquipment(item) and qcolor
                    or Panels.THEME_HEX.textSecond),
            })
        end
        -- 左上等级
        if cornerL ~= "" then
            table.insert(cellChildren, S.UI.Label {
                text = cornerL, fontSize = 7,
                fontColor = Shared.HexRGB("#9fd0ff"),
                position = "absolute", top = 2, left = 4,
            })
        end
        -- 右上强化 / 数量
        if cornerR ~= "" then
            table.insert(cellChildren, S.UI.Label {
                text = cornerR, fontSize = 8,
                fontColor = Shared.HexRGB("#ffd24d"),
                position = "absolute", top = 2, right = 4,
            })
        end
        -- 未鉴定标记（橙色小标签）
        -- ⚠️ 放左下：右下角被「选择模式圆点」占用（同为 bottom=3/right=3），
        --    两者会完全重叠。
        if item and Shared.IsEquipment(item) and item.identified == false then
            table.insert(cellChildren, S.UI.Label {
                text = "未鉴定", fontSize = 8,
                fontColor = Shared.HexRGB("#ffffff"),
                backgroundColor = { 180, 80, 30, 220 },
                paddingHorizontal = 4, paddingVertical = 1,
                borderRadius = 3,
                position = "absolute", bottom = 3, left = 3,
            })
        end

        -- 已上锁：右下角锁图标（上锁物品不可分解 / 不可上架）
        if item and Shared.IsLocked(item) then
            table.insert(cellChildren, S.UI.Label {
                text = "🔒", fontSize = 10,
                fontColor = Shared.HexRGB("#ffd24d"),
                position = "absolute", bottom = 3, right = 3,
            })
        end

        -- 边框色：损坏红 > 上锁金 > 品质色
        local borderColorHex = qcolor
        if item and Shared.IsLocked(item) then borderColorHex = "#ffd24d" end

        local slot = S.UI.Panel {
            -- ⚠️ 48 格（8 列 × 6 行）下格子要缩小：lg 面板宽约 640，
            --    减去内边距后可用约 590。8 × 60 + 7 × 8 = 536，放得下。
            --    保持 72 会溢出到 646，需要把 modal 改成 xl。
            width = 60, height = 60,
            backgroundColor = broken and { 70, 20, 28, 255 }
                or (selected and { 40, 90, 60, 255 } or Panels.THEME.bgCard),
            borderColor = Shared.HexRGB(broken and "#ff3333" or borderColorHex),
            borderWidth = 2,
            borderRadius = 6,
            justifyContent = "center",
            alignItems = "center",
            gap = 2,
            children = cellChildren,
        }

        if item then
            local itemId = item.id
            slot.props.onClick = function()
                Panels.OnInventorySlotClick(itemId, slot)
            end
            slot.props.pointerEvents = "auto"
        end
        table.insert(slots, slot)
    end

    -- 8 列 × 6 行网格（48 格 = 服务端锁死的背包上限）
    local grid = S.UI.SimpleGrid { columns = 8, gap = 8, children = slots }

    -- 按钮段：横排居中、可换行，固定贴底
    local function SmallBtn(label, onClick, variant)
        return Panels.Btn {
            text = label,
            fontSize = 11, height = 40, paddingHorizontal = 12,
            variant = variant or "secondary",
            onClick = onClick,
        }
    end

    local footer = S.UI.Panel {
        flexDirection = "row", flexWrap = "wrap", gap = 12,
        justifyContent = "center", alignItems = "center",
        -- 格子与按钮的间距。外层 gap=4 已经隔开，这里再叠 12 会显得空。
        marginTop = 0,
        children = {
            SmallBtn("全部解锁", function()
                local n = 0
                for _, it in ipairs(Data.value.inventory) do
                    if it.locked then
                        it.locked = nil     -- 不上报 null，删字段即可
                        n = n + 1
                    end
                end
                if n > 0 then
                    Data.MarkDirty("inventory")
                    Notify.Toast("已解锁 " .. n .. " 件物品")
                else
                    Notify.Toast("没有已上锁的物品")
                end
                Panels.OpenInventory()
            end),
            SmallBtn("自动分解", function()
                Panels.OpenAutoDecompose()
            end),
            SmallBtn(
                (Data.value.autoRepair and "✅ " or "") .. "自动维修",
                function()
                    local turningOn = not Data.value.autoRepair
                    Data.value.autoRepair = turningOn
                    Data.value.autoRepairTimer = 0
                    Data.MarkDirty("autoRepair")
                    if turningOn then
                        Notify.Toast("已开启自动维修（每 30 分钟修一次全身）")
                        -- 开启时立即先修一次
                        if S.ctx and S.ctx.autoRepairNow then S.ctx.autoRepairNow() end
                    else
                        Notify.Toast("已关闭自动维修")
                    end
                    Panels.OpenInventory()
                end,
                Data.value.autoRepair and "success" or "secondary"),
            SmallBtn(invSelectMode_ and "取消选择" or "选择分解", function()
                invSelectMode_ = not invSelectMode_
                invSelected_ = {}
                Panels.OpenInventory()
            end),
            SmallBtn("分解选中", function()
                Panels.DoDecompose()
            end, "danger"),
            SmallBtn("一键鉴定", function()
                Panels.DoIdentifyAll()
            end, "primary"),
        },
    }

    modal:AddContent(S.UI.Panel {
        -- 标题栏到内容的间距由 OpenModal 的 headerContentGap = 0 控制（见函数开头），
        -- 这里不要再加 marginTop —— 它推不动内容块，只会把 grid 和 footer 一起上移。
        flexDirection = "column", gap = 4,
        children = {
            grid,
            footer,
        },
    })
    modal:Open()
end

--- 本地背包数据变更后，刷新「背包体系」的界面。
---
--- ⚠️ 格子是构造时一次性生成的（SimpleGrid 只在构造时处理 props.children），
---    物品一旦从 Data.value.inventory 移除，旧格子不会自己消失。
---    而上架表单是叠加在背包之上的栈式 Modal（背包 → 上架），
---    上架成功只关表单不碰背包 —— 背包仍是 currentId_ == "inventory"，
---    却还画着那份已移除的物品快照，必须关掉背包重开才会消失。
---    这里在背包体系可见时重建一次，让格子与数据对齐。
function Panels.RefreshInventoryViews()
    Panels.RefreshIfOpen("inventory", Panels.OpenInventory)
end

---@param itemId string
---@param slot Panel
function Panels.OnInventorySlotClick(itemId, slot)
    if not invSelectMode_ then
        -- 非选择模式：显示背包物品详情（带装备/分解/上架/修理操作）
        local item = Data.FindInventoryItem(itemId)
        if item then Panels.ShowInventoryItemDetail(item) end
        return
    end
    if invSelected_[itemId] then
        invSelected_[itemId] = nil
        slot:SetStyle({ backgroundColor = Panels.THEME.bgCard })
    else
        invSelected_[itemId] = true
        slot:SetStyle({ backgroundColor = { 40, 90, 60, 255 } })
    end
end

function Panels.DoDecompose()
    local ids = {}
    for id in pairs(invSelected_) do table.insert(ids, id) end
    if #ids == 0 then
        Notify.Toast("请先选中装备")
        return
    end
    Panels.DecomposeItems(ids)
    invSelected_ = {}
    invSelectMode_ = false
    Panels.OpenInventory()
end

--- 分解装备：
---   未鉴定 → 随机金币（品质越高越多）
---   已鉴定 → 同品质碎片 ×1
--- 已上锁的装备会被跳过。
---@param itemIds string[]
function Panels.DecomposeItems(itemIds)
    local inv = Data.value.inventory
    local removed, goldGained, lockedSkipped = 0, 0, 0
    local gained = {}

    for i = #inv, 1, -1 do
        local it = inv[i]
        for _, id in ipairs(itemIds) do
            if it.id == id then
                if Shared.IsEquipment(it) then
                    if Shared.IsLocked(it) then
                        lockedSkipped = lockedSkipped + 1
                    else
                        -- 未鉴定 → 折算金币；已鉴定 → 返还同品质碎片 ×1
                        if it.identified == false then
                            goldGained = goldGained + Shared.GetDecomposeGold(it.quality)
                        else
                            gained[it.quality] = (gained[it.quality] or 0) + 1
                        end
                        table.remove(inv, i)
                        removed = removed + 1
                    end
                end
                break
            end
        end
    end

    if removed > 0 then
        for q, n in pairs(gained) do
            Shared.AddFragmentsToInventory(inv, q, n)
        end
        if goldGained > 0 then Data.AddGold(goldGained) end
        Data.MarkDirty("inventory")
        local msg = "分解 " .. removed .. " 件"
        if goldGained > 0 then msg = msg .. "，+" .. goldGained .. "💰" end
        Notify.Toast(msg)
    end
    if lockedSkipped > 0 then
        Notify.Toast(lockedSkipped .. " 件已上锁，未分解")
    end
end

--- 先鉴定再分解：对每件未鉴定装备尝试花金币鉴定，鉴定成功的按已鉴定分解（返碎片）。
--- 金币不足的装备原样保留（不分解、不改动）。
---
--- ⚠️ 与 DecomposeItems 的区别：后者对未鉴定装备"折金币"，本函数则先花钱鉴定、
---    再按已鉴定规则"返碎片"。用户勾选"鉴+分"时的语义。
---@param itemIds string[]
function Panels.IdentifyAndDecomposeItems(itemIds)
    local inv = Data.value.inventory
    local identifiedIds = {}
    local skippedByGold = 0
    local totalCost = 0

    for _, id in ipairs(itemIds) do
        local item = Data.FindInventoryItem(id)
        if item and Shared.IsEquipment(item) and not Shared.IsLocked(item) then
            if item.identified ~= false then
                -- 已经鉴定的，直接纳入（DecomposeItems 会按已鉴定逻辑返碎片）
                table.insert(identifiedIds, id)
            else
                local cost = Shared.GetIdentifyCost(item.quality)
                if (Data.value.gold or 0) < cost then
                    skippedByGold = skippedByGold + 1
                elseif Data.SpendGold(cost) then
                    item.identified = true
                    totalCost = totalCost + cost
                    table.insert(identifiedIds, id)
                end
            end
        end
    end

    if totalCost > 0 then
        Data.MarkDirty("gold")
    end
    if #identifiedIds > 0 then
        Panels.DecomposeItems(identifiedIds)
    end
    if skippedByGold > 0 then
        Notify.Toast(string.format("%d 件因金币不足未鉴定，保持原状", skippedByGold))
    end
end

--- 一键鉴定：按品质收费（普通 1 金 … 传说 5 金），金币不够就停下
function Panels.DoIdentifyAll()
    local inv = Data.value.inventory
    local count, totalCost = 0, 0
    for _, it in ipairs(inv) do
        if Shared.IsEquipment(it) and it.identified == false then
            local cost = Shared.GetIdentifyCost(it.quality)
            if (Data.value.gold or 0) < cost then break end
            Data.SpendGold(cost)
            it.identified = true
            count = count + 1
            totalCost = totalCost + cost
        end
    end
    if count > 0 then
        Data.MarkDirty("inventory")
        Data.MarkDirty("gold")
        Notify.Toast("鉴定 " .. count .. " 件，-" .. totalCost .. " 金币")
        Panels.OpenInventory()
    else
        Notify.Toast("没有未鉴定的装备，或金币不足")
    end
end

--- 把背包里的装备穿上（同部位旧装备退回背包）。
---@param item table
---@return boolean ok
function Panels.DoEquipFromBag(item)
    if not Shared.IsEquipment(item) or not item.slot then return false end

    -- 等级检查
    local reqLv = item.requiredLevel or Shared.QUALITY_WEAR[item.quality] or 1
    if Data.GetLevel() < reqLv then
        Notify.Toast("等级不足，需要 Lv." .. reqLv)
        return false
    end
    -- 未鉴定检查
    if item.identified == false then
        Notify.Toast("未鉴定装备无法穿戴")
        return false
    end

    local inv = Data.value.inventory
    local idx = nil
    for i, it in ipairs(inv) do
        if it.id == item.id then idx = i; break end
    end
    if not idx then
        Notify.Toast("物品已不在背包")
        return false
    end

    local slotKey = item.slot
    local old = Data.value.equipment[slotKey]
    table.remove(inv, idx)
    Data.value.equipment[slotKey] = item
    if old then table.insert(inv, old) end

    Data.MarkDirty("inventory")
    Data.MarkDirty("equipment")
    Notify.Toast("已装备 " .. (item.name or ""))
    Panels.OpenInventory()
    return true
end

--- 脱下某个部位的装备，退回背包（背包满则拒绝）。
---@param slotKey string
---@return boolean ok
function Panels.DoUnequip(slotKey)
    local eq = Data.value.equipment[slotKey]
    if not eq then return false end
    local inv = Data.value.inventory
    if #inv >= Data.BagCapacity() then
        Notify.Toast("背包已满，无法卸下")
        return false
    end
    Data.value.equipment[slotKey] = nil
    table.insert(inv, eq)
    Data.MarkDirty("inventory")
    Data.MarkDirty("equipment")
    Notify.Toast("已卸下 " .. (eq.name or ""))
    return true
end

--- 分解单件装备（带确认框）
---@param item table
function Panels.ConfirmDecomposeSingle(item)
    Panels.Confirm("分解确认",
        "确定分解 " .. (item.name or "该装备") .. " 吗？\n"
            .. (item.identified == false and "未鉴定装备分解后折算金币。" or "已鉴定装备分解后返还同品质碎片。"),
        function()
            Panels.DecomposeItems({ item.id })
            Panels.OpenInventory()
        end)
end

--- 背包物品详情：左右对比 + 装备/分解/上架/修理
---@param item table
function Panels.ShowInventoryItemDetail(item)
    -- ⚠️ 栈式 Modal：从背包打开详情时保留背包面板。
    --    OpenModal 会先 CloseCurrent 把背包关掉，导致玩家看完详情要重新打开背包。
    local modal = OpenStackedModal(item.name or "物品", "xl")

    -- 等级石分支：插在通用流程之前，避免被「装备详情 / 非装备详情」逻辑先捕获。
    if Shared.IsLevelStone(item) then
        modal:AddContent(S.UI.Panel {
            flexDirection = "column", gap = 10,
            children = {
                S.UI.Label {
                    text = "💎 等级石 Lv." .. (item.level or 1),
                    fontSize = 20,
                    fontColor = Shared.HexRGB("#ffdd44"),
                },
                S.UI.Label {
                    text = string.format("装入槽位后，玩家等级 = Lv.%d", item.level or 1),
                    fontSize = 12,
                    fontColor = Panels.THEME.textSecond,
                },
            },
        })

        modal:SetFooter(S.UI.Panel {
            flexDirection = "row", justifyContent = "flex-end", gap = 8,
            children = {
                QButton("装到槽位", function()
                    Panels.Confirm("装到槽位",
                        string.format("将「等级石 Lv.%d」装到槽位？\n\n若当前装备等级要求高于 Lv.%d，装备会被卸下。",
                            item.level or 1, item.level or 1),
                        function()
                            local ok, reason = Panels.EquipLevelStone(item.id)
                            if not ok then Notify.Toast(reason or "操作失败"); return end
                            Notify.Toast("已装备等级石")
                            modal:Close()
                            Panels.OpenInventory()
                        end)
                end, "primary"),
                QButton("上架", function()
                    modal:Close()
                    Panels.ShowSellFormById(item.id)
                end, "secondary"),
                QButton("关闭", function() modal:Close() end),
            },
        })
        modal:Open()
        return
    end

    -- 同部位已装备的物品，用于左右对比
    local equipped = nil
    if item.slot and Data.value.equipment[item.slot] then
        equipped = Data.value.equipment[item.slot]
    end

    local headerChildren = {}
    if Shared.IsEquipment(item) then
        -- 装备：损坏提示 + 完整详情
        if math.floor(item.durability or 0) <= 0 then
            table.insert(headerChildren, S.UI.Label {
                text = "⚠️ 已损坏 · 词条与技能失效",
                fontSize = 12, fontColor = Shared.HexRGB("#ff6666"),
            })
        end
        table.insert(headerChildren, Panels.BuildDetailLayout(item, equipped))
    else
        -- 非装备：简单详情
        table.insert(headerChildren, Panels.BuildItemSummaryLayout(item))
    end

    modal:AddContent(S.UI.Panel {
        flexDirection = "column", gap = 6,
        children = headerChildren,
    })

    -- 按钮区：鉴定 / 装备 / 分解 / 上架 /（耐久未满时）修理
    local btns = {}
    if Shared.IsEquipment(item) then
        local locked = Shared.IsLocked(item)
        local unid = item.identified == false

        -- 上锁 / 解锁（互斥切换）：上锁物品不能分解、不能上架
        -- ⚠️ 解锁分支原来只标了 inventory，物品在装备栏时不会上报，
        --    服务端下次推快照就会把 locked 回滚（"解锁后又自己锁上了"）。
        --    两个字段都标，和修理按钮同样的处理。
        if locked then
            table.insert(btns, QButton("🔓 解锁", function()
                item.locked = nil
                Data.MarkDirty("inventory")
                Data.MarkDirty("equipment")
                Notify.Toast("已解锁")
                modal:Close()
                Panels.ShowInventoryItemDetail(item)
            end, "secondary"))
        else
            table.insert(btns, QButton("🔒 上锁", function()
                item.locked = true
                Data.MarkDirty("inventory")
                Data.MarkDirty("equipment")
                Notify.Toast("已上锁，不会被分解或上架")
                modal:Close()
                Panels.ShowInventoryItemDetail(item)
            end, "secondary"))
        end

        -- 鉴定（未鉴定时才出现）：按品质收费
        if unid then
            local cost = Shared.GetIdentifyCost(item.quality)
            table.insert(btns, QButton("鉴定 (" .. cost .. "💰)", function()
                if Data.SpendGold(cost) then
                    item.identified = true
                    Data.MarkDirty("inventory")
                    Data.MarkDirty("gold")
                    Notify.Toast("鉴定完成")
                    modal:Close()
                    Panels.ShowInventoryItemDetail(item)
                else
                    Notify.Toast("金币不足")
                end
            end, "primary"))
        end

        -- 装备（未鉴定时禁用）
        local equipBtn = QButton("装备", function()
            if unid then Notify.Toast("请先鉴定装备"); return end
            if Panels.DoEquipFromBag(item) then modal:Close() end
        end, "success")
        if unid then equipBtn:SetDisabled(true) end
        table.insert(btns, equipBtn)

        -- 分解（上锁时禁用）
        local decompBtn = QButton("分解", function()
            if locked then Notify.Toast("该物品已上锁，请先在背包解锁"); return end
            Panels.ConfirmDecomposeSingle(item)
        end, "danger")
        if locked then decompBtn:SetDisabled(true) end
        table.insert(btns, decompBtn)

        -- 上架（上锁时禁用）
        local sellBtn = QButton("上架", function()
            if locked then Notify.Toast("该物品已上锁，请先在背包解锁"); return end
            Panels.ShowSellFormById(item.id)
        end, "primary")
        if locked then sellBtn:SetDisabled(true) end
        table.insert(btns, sellBtn)

        local maxDur = math.floor(item.maxDurability or Shared.C.MAX_DURABILITY or 100)
        local curDur = math.floor(item.durability or 0)
        if curDur < maxDur then
            local repairPerDur = Shared.GetRepairCostPerDurability(item.quality)
            local repairOneCost = (maxDur - curDur) * repairPerDur
            table.insert(btns, QButton("🔧 修理 (" .. repairOneCost .. "💰)", function()
                if repairOneCost <= 0 then Notify.Toast("耐久已满"); return end
                if Data.SpendGold(repairOneCost) then
                    item.durability = maxDur
                    -- ⚠️ 背包里的物品必须标 inventory：只标 equipment 时
                    --    这次修理不会被上报，服务端下一次推送就会把耐久回滚（白花钱）
                    Data.MarkDirty("inventory")
                    Data.MarkDirty("equipment")
                    Notify.Toast(string.format("修理完成，消耗 %d 金币", repairOneCost))
                else
                    Notify.Toast("金币不足")
                end
                modal:Close()
            end, "secondary"))
        end
    else
        -- 宠物（作为物品在背包里）：上架 / 放回待选池
        if Shared.IsPetItem(item) then
            table.insert(btns, QButton("放回待选池", function()
                local ok, reason = PetSys.MoveToPool(item.id)
                if not ok then Notify.Toast(reason or "操作失败"); return end
                Notify.Toast("已放回待选池")
                modal:Close()
                Panels.OpenInventory()
            end, "secondary"))
            table.insert(btns, QButton("上架", function()
                modal:Close()
                Panels.ShowSellFormById(item.id)
            end, "primary"))
        else
            -- 召唤卷：可使用（服务端权威 roll + 冷却/距离校验）
            if Shared.IsSummonScroll(item) then
                table.insert(btns, QButton("📜 使用召唤", function()
                    if S.ctx and S.ctx.useSummonScroll then
                        S.ctx.useSummonScroll(item.scrollType)
                    end
                    modal:Close()
                end, "success"))
            end
            -- 非装备（碎片 / 精魄 / 在线卡 / 召唤卷）：可上架
            table.insert(btns, QButton("上架", function()
                modal:Close()
                Panels.ShowSellFormById(item.id)
            end, "primary"))
        end
    end

    modal:SetFooter(S.UI.Panel {
        flexDirection = "row", justifyContent = "space-between", gap = 10,
        children = {
            S.UI.Panel { flexDirection = "row", gap = 10, children = btns },
            QButton("关闭", function() modal:Close() end),
        },
    })
    modal:Open()
end

--- 技能触发概率一览（角色面板「技能概率」按钮）。
--- 从注入的 skillStacksProvider 拿全身技能层数，按概率降序展示。
function Panels.ShowSkillProbability()
    local modal = OpenStackedModal("📊 技能触发概率", "lg")

    local provider = S.skillStacksProvider
    local stacks = (provider and Data.value.equipment) and provider(Data.value.equipment) or {}

    -- 收集有层数且定义存在的技能
    local rows = {}
    for sid, n in pairs(stacks) do
        local def = Shared.SKILL_DEFS[sid]
        if def and (n or 0) > 0 then
            -- 与 Skills.GetChance 同一口径：min(1, chance × 层数)
            local chance = math.min(1, (def.chance or 0) * n)
            table.insert(rows, { sid = sid, def = def, stacks = n, chance = chance })
        end
    end
    -- 概率降序；同概率按层数降序（更稳定的展示顺序）
    table.sort(rows, function(a, b)
        if a.chance ~= b.chance then return a.chance > b.chance end
        return a.stacks > b.stacks
    end)

    if #rows == 0 then
        modal:AddContent(S.UI.Panel {
            flexDirection = "column", gap = 6,
            children = {
                QLabel("当前没有任何技能词条。", Panels.THEME_HEX.textDim, 12),
                QLabel("装备上的技能词条会在此显示触发概率。", Panels.THEME_HEX.textSecond, 10),
            },
        })
        modal:Open()
        return
    end

    local cards = {}
    for _, r in ipairs(rows) do
        local def = r.def
        local pct = r.chance * 100
        -- 概率配色：满概率绿 / 高概率金 / 低概率灰
        local pcolor = (r.chance >= 0.999) and "#88ff88"
            or (r.chance >= 0.5) and "#ffd24d" or "#aabbcc"
        table.insert(cards, S.UI.Panel {
            flexDirection = "row", alignItems = "center", gap = 8,
            height = 40, paddingHorizontal = 10,
            backgroundColor = Panels.THEME.bgCard, borderRadius = 6,
            children = {
                S.UI.Label { text = def.icon or "?", fontSize = 18, width = 26, textAlign = "center" },
                S.UI.Label {
                    text = def.name or r.sid, fontSize = 12,
                    fontColor = Shared.HexRGB("#e0e8ff"),
                    flexGrow = 1, flexShrink = 1, maxLines = 1,
                },
                S.UI.Label {
                    text = "×" .. r.stacks, fontSize = 11, width = 40, textAlign = "center",
                    fontColor = Shared.HexRGB("#9fd8ff"),
                },
                S.UI.Label {
                    text = string.format("%.1f%%", pct), fontSize = 12, width = 64,
                    textAlign = "right", fontColor = Shared.HexRGB(pcolor),
                },
            },
        })
    end

    modal:AddContent(S.UI.Panel {
        flexDirection = "column", gap = 6,
        children = {
            QLabel("概率 = 单层触发率 × 层数（上限 100%）", Panels.THEME_HEX.textSecond, 10),
            S.UI.ScrollView {
                flexGrow = 1, flexBasis = 0, maxHeight = 360,
                children = {
                    S.UI.Panel { flexDirection = "column", gap = 6, width = "100%", children = cards },
                },
            },
        },
    })
    modal:Open()
end

--- 技能详情（点击物品详情里的技能词条时打开）
---@param skillId string
---@param stacks integer
function Panels.ShowSkillDetail(skillId, stacks)
    local def = Shared.SKILL_DEFS[skillId]
    if not def then return end

    local modal = OpenStackedModal(def.icon .. " " .. def.name, "lg")

    local typeMap = {
        onHit = "攻击命中触发", onKill = "击杀触发",
        onHurt = "受击触发", onCrit = "暴击触发", passive = "常驻被动",
    }
    -- 与 Skills.GetChance 保持一致：min(1, chance * stacks)
    local totalChance = math.min(1, (def.chance or 0) * (stacks or 1))

    -- 行式：左标签 / 右数值
    local function SdRow(label, value, valueColor)
        return S.UI.Panel {
            flexDirection = "row", justifyContent = "space-between",
            alignItems = "center",
            children = {
                S.UI.Label { text = label, fontSize = 12, fontColor = Panels.THEME.textSecond },
                S.UI.Label { text = value, fontSize = 12,
                    fontColor = Shared.HexRGB(valueColor or Panels.THEME_HEX.textPrimary) },
            },
        }
    end

    local lines = {
        SdRow("触发类型", typeMap[def.type] or def.type),
        SdRow("基础触发率", string.format("%.0f%%", (def.chance or 0) * 100)),
        SdRow("当前层数", (stacks or 1) .. " 层"),
        SdRow("实际触发率", string.format("%.1f%%", totalChance * 100), "#ffd24d"),
    }

    -- 技能描述（斜体感：用不同颜色 + 独立底框）
    if def.desc then
        table.insert(lines, S.UI.Panel {
            paddingHorizontal = 10, paddingVertical = 8,
            backgroundColor = { 255, 230, 200, 15 },
            borderRadius = 6,
            children = {
                S.UI.Label {
                    text = def.desc, fontSize = 12,
                    fontColor = Panels.THEME.textPrimary, maxLines = 0,
                },
            },
        })
    end

    if def.params then
        table.insert(lines, S.UI.Divider { orientation = "horizontal", marginVertical = 6 })
        table.insert(lines, S.UI.Label { text = "参数明细", fontSize = 12,
            fontColor = Shared.HexRGB("#ffcc66") })
        -- 排序后展示，避免 pairs 顺序不稳定导致每次打开排列不同
        local keys = {}
        for k in pairs(def.params) do keys[#keys + 1] = k end
        table.sort(keys)
        for _, k in ipairs(keys) do
            local v = def.params[k]
            local label = Shared.SKILL_PARAM_LABELS[k] or k
            local txt
            if type(v) == "number" then
                if v > 0 and v < 1 then
                    txt = string.format("%.1f%%", v * 100)
                else
                    txt = tostring(v)
                end
            else
                txt = tostring(v)
            end
            table.insert(lines, SdRow(label, txt, "#9fd8ff"))
        end
    end

    modal:AddContent(S.UI.Panel { flexDirection = "column", gap = 4, children = lines })
    modal:SetFooter(S.UI.Panel {
        flexDirection = "row", justifyContent = "flex-end",
        children = { QButton("关闭", function() modal:Close() end) },
    })
    modal:Open()
end

-- ============================================================
-- 角色
-- ============================================================
function Panels.OpenCharacter()
    local modal = OpenModal("character", "角色", "xl")
    -- 属性由 Client 注入（见 UI.SetStatProvider），UI 层不反向依赖 Battle。
    -- ⚠️ 兜底表必须给全字段：注入缺失时下面 stats.xxx 会直接索引 nil 报错。
    local stats = (S.statProvider and S.statProvider(Data.value.equipment)) or {
        maxHp = 200, atk = 3, atkSpeed = 1.0, moveSpeed = 5.0,
        critChance = 0.05, critDamage = 1.5, armorPen = 0,
        killHeal = 0, armor = 0, damageReduce = 0, dodge = 0, hitRate = 0,
    }

    local slotNodes = {}
    for _, key in ipairs(Shared.SLOT_LIST) do
        local def = Shared.SLOTS[key]
        local eq = Data.value.equipment[key]
        local qcolor = eq and (Shared.QUALITY_COLORS[eq.quality] or "#ffffff") or "#555555"
        local broken = eq and (eq.durability or 1) <= 0

        -- 单格：左上槽位名 / 右上强化徽章 / 图标居中 / 底部名称 / 右下耐久
        -- ⚠️ 图标只在已装备时显示（空槽显示图标会让玩家误以为穿了装备）
        local cellChildren = {}
        if eq then
            table.insert(cellChildren, S.UI.Label { text = def.icon, fontSize = 24 })
        end
        table.insert(cellChildren, S.UI.Label {
            text = eq and (Shared.QUALITY_NAMES[eq.quality] or "") .. " " .. def.name or "空",
            fontSize = 8, maxLines = 1,
            fontColor = Shared.HexRGB(eq and qcolor or Panels.THEME_HEX.textDim),
        })
        table.insert(cellChildren, S.UI.Label {
            text = def.name, fontSize = 8,
            fontColor = Shared.HexRGB("#bbb0a0"),
            position = "absolute", top = 3, left = 5,
        })
        if eq then
            if (eq.enhanceLevel or 0) > 0 then
                table.insert(cellChildren, S.UI.Label {
                    text = "+" .. eq.enhanceLevel, fontSize = 9,
                    fontColor = Shared.HexRGB("#ffd24d"),
                    position = "absolute", top = 3, right = 5,
                })
            end
            local dur = math.floor(eq.durability or 0)
            local durColor = "#aabbcc"
            if dur <= 0 then durColor = "#ff4444"
            elseif dur <= 20 then durColor = "#ffcc44" end
            table.insert(cellChildren, S.UI.Label {
                text = "耐 " .. dur, fontSize = 8,
                fontColor = Shared.HexRGB(durColor),
                position = "absolute", bottom = 3, right = 5,
            })
        end

        local cell = S.UI.Panel {
            width = 110, height = 86,
            backgroundColor = broken and { 70, 20, 28, 255 } or Panels.THEME.bgCard,
            borderColor = Shared.HexRGB(qcolor),
            borderWidth = 2,
            borderRadius = 6,
            justifyContent = "center",
            alignItems = "center",
            gap = 2,
            children = cellChildren,
        }
        -- 已穿戴的格子可点开详情（卸下 / 修理）
        if eq then
            local eqRef = eq
            local keyRef = key
            cell.props.onClick = function()
                Panels.ShowEquippedItemDetail(eqRef, keyRef)
            end
            cell.props.pointerEvents = "auto"
        end
        table.insert(slotNodes, cell)
    end

    local statRows = {
        { "生命", stats.maxHp },
        { "攻击", math.floor(stats.atk) },
        { "攻速", string.format("%.2f", stats.atkSpeed) },
        { "移速", string.format("%.2f", stats.moveSpeed) },
        { "暴击", string.format("%.1f%%", stats.critChance * 100) },
        { "暴伤", string.format("%.0f%%", stats.critDamage * 100) },
        { "破甲", string.format("%.1f%%", stats.armorPen * 100) },
        { "护甲", math.floor(stats.armor) },
        { "减伤", string.format("%.1f%%", stats.damageReduce * 100) },
        { "闪避", string.format("%.1f%%", stats.dodge * 100) },
        { "命中", string.format("%.1f%%", stats.hitRate * 100) },
        { "击杀回复", math.floor(stats.killHeal) },
    }
    -- 属性格：6 列 × 2 行，每格「名称 / 数值」上下两行
    local statLabels = {}
    for _, row in ipairs(statRows) do
        table.insert(statLabels, S.UI.Panel {
            width = 92, height = 40,
            backgroundColor = { 255, 230, 200, 20 },
            borderRadius = 6,
            flexDirection = "column",
            justifyContent = "center", alignItems = "center",
            children = {
                S.UI.Label { text = row[1], fontSize = 10, fontColor = Panels.THEME.textSecond },
                S.UI.Label { text = tostring(row[2]), fontSize = 11, fontColor = Shared.HexRGB("#7ad4ff") },
            },
        })
    end

    -- A5 位置4：技能概率一览（原「一键修理」位置）
    local skillProbBtn = QButton("📊 技能概率", function()
        Panels.ShowSkillProbability()
    end, "secondary")

    -- 天赋点数行
    -- ⚠️ TotalSpent / GetTotalPoints 内部自带结构校验（IsValid / type(eq)=="table"），
    --    老档缺字段时返回 0，无需外部兜底。
    local bdSpent, bdTotal = 0, 0
    do
        local okBD, BD = pcall(require, "BD_Tree")
        if okBD and BD then
            bdSpent = BD.TotalSpent(Data.value.bdTree)
            bdTotal = BD.GetTotalPoints()
        end
    end
    local bdPointsLabel = S.UI.Label {
        text = string.format("天赋点数：%d / %d（剩余 %d）",
            bdSpent, bdTotal, bdTotal - bdSpent),
        fontSize = 12,
        fontColor = Shared.HexRGB(bdSpent >= bdTotal and "#ff7878" or "#9fd8ff"),
    }

    -- ============ 技能概率按钮 ============
    -- 升级 / 降级 / 卸下 已移到上方的「等级石行」。
    skillProbBtn.props.flexGrow = 1
    skillProbBtn.props.flexBasis = 0
    skillProbBtn.props.height = 40

    -- 底部行：技能概率按钮（左）+ 等级石小方块（右）
    local levelStoneBlock
    do
        local stone = Data.value.levelStone
        local hasStone = (type(stone) == "table" and stone.level)
        local iconColor = hasStone and "#ffdd44" or "#888888"
        local labelText = hasStone and ("Lv." .. stone.level) or "未装备"

        local block = S.UI.Panel {
            width = 80, height = 80,
            backgroundColor = Panels.THEME.bgCard,
            borderWidth = 2,
            borderColor = Shared.HexRGB(iconColor),
            borderRadius = 8,
            justifyContent = "center",
            alignItems = "center",
            gap = 2,
            pointerEvents = "auto",
            children = {
                S.UI.Label {
                    text = "💎",
                    fontSize = 24,
                    fontColor = Shared.HexRGB(iconColor),
                },
                S.UI.Label {
                    text = labelText,
                    fontSize = 10,
                    fontColor = Shared.HexRGB(iconColor),
                },
            },
        }
        block.props.onClick = function()
            Panels.ShowLevelStoneDetail()
        end
        levelStoneBlock = block
    end

    modal:AddContent(S.UI.Panel {
        flexDirection = "column", gap = 10,
        children = {
            -- 装备段：4 列 × 2 行
            S.UI.SimpleGrid { columns = 4, gap = 10, children = slotNodes },
            S.UI.Divider { orientation = "horizontal" },
            -- 属性段：6 列 × 2 行
            S.UI.SimpleGrid { columns = 6, gap = 6, children = statLabels },
            S.UI.Divider { orientation = "horizontal" },
            S.UI.Panel {
                flexDirection = "column", gap = 8,
                children = {
                    bdPointsLabel,
                    S.UI.Panel {
                        flexDirection = "row", gap = 8, alignItems = "center",
                        children = {
                            skillProbBtn,
                            S.UI.Panel { flexGrow = 1 },   -- 弹簧
                            levelStoneBlock,
                        },
                    },
                },
            },
        },
    })
    modal:Open()
end

--- 卸下等级石：等级石进背包，玩家等级变 Lv1，8 件装备自动卸下。
function Panels.UnequipLevelStone()
    local d = Data.value
    local stone = d.levelStone

    if type(stone) ~= "table" then
        Notify.Toast("没有装备等级石")
        return
    end

    -- 🔴 预检：最坏情况是 8 件装备全部卸下，需保证背包有 8 格空间
    --    避免"卸一半装备丢失"的中间状态
    local inv = d.inventory
    local freeSlots = Data.BagCapacity() - #inv
    -- 等级石本身占 1 格
    local needSlots = 1 + #Shared.SLOT_LIST  -- 1(等级石) + 8(装备) = 9
    if freeSlots < needSlots then
        Notify.Toast(string.format("背包空间不足（需 %d 格，现有 %d 格）",
            needSlots, freeSlots))
        return
    end

    -- 等级石进背包
    table.insert(inv, stone)
    d.levelStone = nil

    -- 全身装备检查（等级变 Lv1）
    local unequipped = {}
    for _, slotKey in ipairs(Shared.SLOT_LIST) do
        local eq = d.equipment[slotKey]
        if eq then
            local reqLv = eq.requiredLevel or 1
            if reqLv > 1 then
                table.insert(unequipped, eq)
                d.equipment[slotKey] = nil
            end
        end
    end

    -- 卸下的装备进背包/邮件
    local overflow = {}
    for _, eq in ipairs(unequipped) do
        if #inv < Data.BagCapacity() then
            table.insert(inv, eq)
        else
            table.insert(overflow, eq)
        end
    end
    if #overflow > 0 then
        -- 回调存在 → 走邮件兜底
        if S.ctx and S.ctx.notifyOverflowEquip then
            S.ctx.notifyOverflowEquip(overflow)
        else
            -- 无回调 → 拒绝操作（回滚：把已处理的装备塞回装备栏）
            -- ⚠️ 理论上预检已防止此路径，这是双保险
            print("[UI_Items] ⚠️ notifyOverflowEquip 缺失，回滚卸下操作")
            for _, eq in ipairs(unequipped) do
                local slotKey = eq.slot
                if slotKey then
                    d.equipment[slotKey] = eq
                end
            end
            -- 从背包移除已插入的装备
            for i = #inv, 1, -1 do
                for _, eq in ipairs(unequipped) do
                    if inv[i] == eq then
                        table.remove(inv, i)
                        break
                    end
                end
            end
            -- 等级石也塞回槽位
            d.levelStone = stone
            for i = #inv, 1, -1 do
                if inv[i] == stone then
                    table.remove(inv, i)
                    break
                end
            end
            Notify.Toast("操作失败，请重试")
            return
        end
    end

    Data.MarkDirty("inventory")
    Data.MarkDirty("equipment")
    Data.MarkDirty("level")

    Notify.Toast("已卸下等级石，等级变回 Lv.1")

    if Panels.RefreshIfOpen then
        Panels.RefreshIfOpen("character", Panels.OpenCharacter)
    end
end

--- 等级石详情弹窗（点角色面板右下角小方块打开）。
function Panels.ShowLevelStoneDetail()
    local stone = Data.value.levelStone
    local hasStone = (type(stone) == "table" and stone.level)

    local modal = OpenStackedModal("💎 等级石", "md")

    if hasStone then
        local curLv = stone.level
        local isMax = (curLv >= Shared.C.MAX_LEVEL)
        local upCost = isMax and 0 or Shared.GetLevelUpCost(curLv)

        local rows = {
            QLabel("等级石 Lv." .. curLv, "#ffdd44", 18),
            QLabel(string.format("玩家等级：Lv.%d", Data.GetLevel()), "#cccccc", 12),
            S.UI.Divider { orientation = "horizontal", marginVertical = 6 },
        }
        if isMax then
            table.insert(rows, QLabel("已满级", "#88ff88", 12))
        else
            table.insert(rows, QLabel(
                string.format("升级到 Lv.%d 需要：%d 金币", curLv + 1, upCost),
                "#9fd8ff", 12))
        end

        modal:AddContent(S.UI.Panel {
            flexDirection = "column", gap = 6,
            children = rows,
        })

        local btns = {}
        table.insert(btns, QButton(
            isMax and "已满级" or "升级",
            function()
                if isMax then return end
                Panels.Confirm("升级等级石",
                    string.format("将消耗 %d 金币，把等级石升至 Lv.%d。\n\n确定升级？",
                        upCost, curLv + 1),
                    function()
                        if S.ctx and S.ctx.requestLevelUp then
                            S.ctx.requestLevelUp()
                        end
                        modal:Close()
                        Panels.ShowLevelStoneDetail()
                    end)
            end,
            isMax and "secondary" or "success"))
        table.insert(btns, QButton("降级", function()
            if curLv <= 1 then
                Notify.Toast("等级石已是最低等级")
                return
            end
            Panels.Confirm("降级等级石",
                "降级不会返还任何金币，确定要降级吗？",
                function()
                    if S.ctx and S.ctx.requestLevelDown then
                        S.ctx.requestLevelDown()
                    end
                    modal:Close()
                    Panels.ShowLevelStoneDetail()
                end)
        end, "secondary"))
        table.insert(btns, QButton("卸下", function()
            Panels.Confirm("卸下等级石",
                "卸下等级石后，你的等级将变回 Lv.1，\n且全身 8 件装备将被卸下（背包满则进邮件）。\n\n确定卸下？",
                function()
                    Panels.UnequipLevelStone()
                    modal:Close()
                end)
        end, "danger"))
        table.insert(btns, QButton("关闭", function() modal:Close() end))

        modal:SetFooter(S.UI.Panel {
            flexDirection = "row", justifyContent = "flex-end", gap = 8,
            children = btns,
        })
    else
        modal:AddContent(S.UI.Panel {
            flexDirection = "column", gap = 8,
            children = {
                QLabel("未装备等级石", "#888888", 14),
                QLabel("从背包选择等级石装上。", "#aaaaaa", 11),
            },
        })
        modal:SetFooter(S.UI.Panel {
            flexDirection = "row", justifyContent = "flex-end", gap = 8,
            children = {
                QButton("从背包选择", function()
                    modal:Close()
                    Panels.ShowLevelStonePicker()
                end, "primary"),
                QButton("关闭", function() modal:Close() end),
            },
        })
    end

    modal:Open()
end

--- 从背包选择等级石装上（点"从背包选择"打开）。
function Panels.ShowLevelStonePicker()
    local inv = Data.value.inventory
    local candidates = {}
    for _, it in ipairs(inv) do
        if Shared.IsLevelStone(it) then
            table.insert(candidates, it)
        end
    end

    local modal = OpenStackedModal("选择等级石", "md")

    if #candidates == 0 then
        modal:AddContent(QLabel("背包里没有等级石", "#888888", 12))
        modal:SetFooter(S.UI.Panel {
            flexDirection = "row", justifyContent = "flex-end",
            children = { QButton("关闭", function() modal:Close() end) },
        })
        modal:Open()
        return
    end

    local cards = {}
    for _, it in ipairs(candidates) do
        local stoneId = it.id
        local lv = it.level or 1
        local card = S.UI.Panel {
            width = 90, height = 90,
            backgroundColor = Panels.THEME.bgCard,
            borderColor = Shared.HexRGB("#ffdd44"),
            borderWidth = 2,
            borderRadius = 8,
            justifyContent = "center",
            alignItems = "center",
            gap = 2,
            pointerEvents = "auto",
            children = {
                S.UI.Label { text = "💎", fontSize = 26 },
                S.UI.Label {
                    text = "Lv." .. lv,
                    fontSize = 11,
                    fontColor = Shared.HexRGB("#ffdd44"),
                },
            },
        }
        card.props.onClick = function()
            local ok, reason = Panels.EquipLevelStone(stoneId)
            if not ok then Notify.Toast(reason or "装上失败"); return end
            Notify.Toast("已装备等级石")
            modal:Close()
            Panels.RefreshIfOpen("character", Panels.OpenCharacter)
        end
        table.insert(cards, card)
    end

    modal:AddContent(S.UI.ScrollView {
        flexGrow = 1, flexBasis = 0, maxHeight = 400,
        children = { S.UI.SimpleGrid { columns = 4, gap = 10, children = cards } },
    })
    modal:SetFooter(S.UI.Panel {
        flexDirection = "row", justifyContent = "flex-end",
        children = { QButton("取消", function() modal:Close() end) },
    })
    modal:Open()
end

--- 装上新等级石：把背包里的等级石装入槽位。
--- 若槽位已有等级石 → 自动交换（旧的退回背包）。
--- 若新等级石等级低于当前装备的 requiredLevel → 8 件装备自动卸下。
---@param stoneId string 背包中等级石的 id
---@return boolean ok, string|nil reason
function Panels.EquipLevelStone(stoneId)
    local d = Data.value
    local inv = d.inventory

    -- 在背包里找等级石
    local stone, idx = nil, nil
    for i, it in ipairs(inv) do
        if it.id == stoneId and Shared.IsLevelStone(it) then
            stone = it
            idx = i
            break
        end
    end
    if not stone then
        return false, "背包中没有该等级石"
    end

    local oldStone = d.levelStone
    local newLv = stone.level or 1
    local oldLv = (type(oldStone) == "table" and oldStone.level) or 1

    -- 是否需要卸下装备？
    local needUnequip = false
    if newLv < oldLv then
        for _, slotKey in ipairs(Shared.SLOT_LIST) do
            local eq = d.equipment[slotKey]
            if eq then
                local reqLv = eq.requiredLevel or 1
                if newLv < reqLv then
                    needUnequip = true
                    break
                end
            end
        end
    end

    -- 预检：交换后背包空间
    --   1(旧等级石占位，交换后回背包) + 可能卸下的装备
    local freeSlots = Data.BagCapacity() - #inv
    -- 交换时：旧等级石进背包(占 1)，新等级石出背包(释放 1)→ 净 0
    -- 若需卸装备：额外需要 8 格
    if needUnequip and freeSlots < #Shared.SLOT_LIST then
        return false, string.format("背包空间不足（卸装备需 %d 格，现有 %d 格）",
            #Shared.SLOT_LIST, freeSlots)
    end

    -- 卸下 8 件装备（如需）
    local unequipped = {}
    if needUnequip then
        for _, slotKey in ipairs(Shared.SLOT_LIST) do
            local eq = d.equipment[slotKey]
            if eq then
                local reqLv = eq.requiredLevel or 1
                if newLv < reqLv then
                    table.insert(unequipped, eq)
                    d.equipment[slotKey] = nil
                end
            end
        end
    end

    -- 交换等级石
    table.remove(inv, idx)
    if type(oldStone) == "table" then
        table.insert(inv, oldStone)
    end
    d.levelStone = stone

    -- 卸下的装备进背包
    local overflow = {}
    for _, eq in ipairs(unequipped) do
        if #inv < Data.BagCapacity() then
            table.insert(inv, eq)
        else
            table.insert(overflow, eq)
        end
    end
    if #overflow > 0 then
        if S.ctx and S.ctx.notifyOverflowEquip then
            S.ctx.notifyOverflowEquip(overflow)
        end
    end

    Data.MarkDirty("inventory")
    Data.MarkDirty("equipment")
    Data.MarkDirty("level")
    return true, nil
end

--- 已穿戴装备的详情（从角色面板的装备格点入）：可卸下 / 修理。
---@param item table
---@param slotKey string
function Panels.ShowEquippedItemDetail(item, slotKey)
    -- ⚠️ 栈式 Modal：从角色面板点开装备详情时保留角色面板
    local modal = OpenStackedModal(item.name or "装备", "xl")

    modal:AddContent(Panels.BuildDetailLayout(item, nil))

    local maxDur = math.floor(item.maxDurability or Shared.C.MAX_DURABILITY or 100)
    local curDur = math.floor(item.durability or 0)
    local repairPerDur = Shared.GetRepairCostPerDurability(item.quality)
    local repairCost = math.max(0, maxDur - curDur) * repairPerDur

    local btns = {}
    table.insert(btns, QButton("卸下", function()
        modal:Close()
        if Panels.DoUnequip(slotKey) then
            Panels.OpenCharacter()
        end
    end, "secondary"))

    -- 上锁 / 解锁：已穿戴的装备同样可以上锁（防误分解/误上架）
    if Shared.IsLocked(item) then
        table.insert(btns, QButton("🔓 解锁", function()
            item.locked = nil
            Data.MarkDirty("equipment")
            Data.MarkDirty("inventory")
            Notify.Toast("已解锁")
            modal:Close()
            Panels.OpenCharacter()
        end, "secondary"))
    else
        table.insert(btns, QButton("🔒 上锁", function()
            item.locked = true
            Data.MarkDirty("equipment")
            Data.MarkDirty("inventory")
            Notify.Toast("已上锁")
            modal:Close()
            Panels.OpenCharacter()
        end, "secondary"))
    end

    if curDur < maxDur then
        table.insert(btns, QButton("🔧 修理 (" .. repairCost .. "💰)", function()
            if Data.SpendGold(repairCost) then
                item.durability = maxDur
                Data.MarkDirty("equipment")
                Notify.Toast(string.format("修理完成，消耗 %d 金币", repairCost))
                modal:Close()
                Panels.OpenCharacter()
            else
                Notify.Toast("金币不足")
            end
        end, "primary"))
    end

    table.insert(btns, QButton("关闭", function() modal:Close() end))

    modal:SetFooter(S.UI.Panel {
        flexDirection = "row", justifyContent = "flex-end", gap = 12,
        children = btns,
    })
    modal:Open()
end
return Panels
