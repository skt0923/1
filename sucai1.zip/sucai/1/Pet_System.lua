-- ============================================================
-- Pet_System.lua：宠物系统核心逻辑
--
-- 职责：抽卡、宠物创建、保底计数器、（第二批）上阵/升级/加成计算。
--
-- 与 UI_Pet.lua 的关系：
--   · 本文件是纯逻辑，不 require UI、不写 Panels 表
--   · UI_Pet.lua require 本文件
--   · Battle_Combat.lua 将来可能 require 本文件（加成计算）
--
-- 依赖：Shared（含 Data / Notify）。不依赖任何 UI 或战斗模块。
--
-- 客户端权威：宠物创建、抽卡结果全部在客户端生成，与背包/金币/装备的
-- 权威模式一致（见项目现有架构）。
-- ============================================================
local Shared = require("Shared")
local Data   = Shared.Data

local Pet = {}

-- ============ 内部工具 ============

--- 生成宠物 ID
---@return string
local function NewPetId()
    return "pet_" .. Shared.UUID()
end

--- 计算固定特性保底值（品质上限的一半，整数向下取）
---@param quality string
---@return integer
function Pet.FixedTraitFloor(quality)
    local cap = Shared.PET_QUALITY_MAX_LEVEL[quality] or 20
    return math.floor(cap / 2)
end

--- 品质权重归一化：只保留"蛋品质及以下"的权重，再归一化到总和 1
---@param eggQuality string
---@return table<string, number>
local function NormalizeWeights(eggQuality)
    local maxRank = Shared.QUALITY_RANK[eggQuality] or 0
    local weights = Shared.PET_GACHA_QUALITY_WEIGHTS
    local filtered = {}
    local total = 0
    for _, q in ipairs(Shared.QUALITY_LIST) do
        local rank = Shared.QUALITY_RANK[q] or 0
        if rank <= maxRank then
            local w = weights[q] or 0
            filtered[q] = w
            total = total + w
        end
    end
    local result = {}
    if total > 0 then
        for q, w in pairs(filtered) do
            result[q] = w / total
        end
    end
    return result
end

--- 按蛋品质 roll 一个可出的品质（不含保底）
---@param eggQuality string
---@return string
local function RollQualityByEgg(eggQuality)
    local probs = NormalizeWeights(eggQuality)
    local roll = math.random()
    local acc = 0.0   -- 必须是浮点：累加的是归一化概率，整数会被 LSP 判为 integer 目标配 number 来源
    for _, q in ipairs(Shared.QUALITY_LIST) do
        local p = probs[q]
        if p then
            acc = acc + p
            if roll <= acc then return q end
        end
    end
    -- 浮点兜底
    return eggQuality
end

--- 随机一个部位
---@return string
local function RollSlot()
    local list = Shared.SLOT_LIST
    return list[math.random(#list)] --[[@as string]]
end

--- roll 固定特性（[保底, 100] 整数均匀）
---@param quality string
---@return integer
local function RollFixedTrait(quality)
    local floorVal = Pet.FixedTraitFloor(quality)
    return math.random(floorVal, 100)
end

--- roll 激活属性：12 种各 50% 独立判定，保底至少 1 种
---@return table<string, boolean>
local function RollActivatedAttrs()
    local activated = {}
    local count = 0
    for _, attr in ipairs(Shared.MOD_IDS) do
        if math.random() < Shared.C.PET_ATTR_ACTIVATE_CHANCE then
            activated[attr] = true
            count = count + 1
        end
    end
    if count == 0 then
        local forced = Shared.MOD_IDS[math.random(#Shared.MOD_IDS)]
        activated[forced] = true
    end
    return activated
end

-- ============ 宠物创建 ============

--- 创建一只宠物
---@param quality string 品质
---@param slot string    部位
---@return table
function Pet.CreatePet(quality, slot)
    -- maxLevel 随机（品质保底 ~ 品质上限，整数均匀）
    --   保底 = 品质固定上限的一半（PET_QUALITY_MAX_LEVEL[quality] / 2）
    --   上限 = 品质固定上限
    -- 抽到的宠物一律 Lv.1，等级上限决定培养潜力和满级消耗。
    local hardCap = Shared.PET_QUALITY_MAX_LEVEL[quality] or 20
    local floorVal = math.floor(hardCap / 2)
    local maxLevel = math.random(floorVal, hardCap)

    return {
        id             = NewPetId(),
        quality        = quality,
        slot           = slot,
        level          = 1,
        maxLevel       = maxLevel,
        fixedTrait     = RollFixedTrait(quality),
        activatedAttrs = RollActivatedAttrs(),
        createdAt      = os.time(),
    }
end

--- 生成宠物的显示名字
---@param pet table
---@return string
function Pet.GetName(pet)
    local qName = Shared.QUALITY_NAMES[pet.quality] or pet.quality
    local slotName = Shared.SLOTS[pet.slot] and Shared.SLOTS[pet.slot].name or pet.slot
    return qName .. slotName .. "宠物"
end

-- ============ 抽卡 ============

--- 检查待选池是否已满
---@return boolean
local function IsPoolFull()
    local pool = Data.value.pets and Data.value.pets.pool
    if not pool then return false end
    return #pool >= Shared.C.PET_POOL_MAX
end

--- 检查并扣除抽卡消耗（蛋 + 金币 + 可选在线卡）
---@param eggQuality string
---@param useCard boolean
---@return boolean ok, string|nil reason
local function ConsumeCurrency(eggQuality, useCard)
    local inv = Data.value.inventory

    local eggDisp = Shared.PET_EGG_DISPLAY[eggQuality]
    if not eggDisp then return false, "无效的蛋品质" end
    if Shared.CountPetEggsInInventory(inv, eggQuality) < 1 then
        return false, "没有" .. eggDisp.name
    end

    local goldCost = Shared.C.PET_GACHA_COST_GOLD[eggQuality] or 2000
    if (Data.value.gold or 0) < goldCost then
        return false, string.format("金币不足（需要 %d）", goldCost)
    end

    if useCard and Shared.CountTokensInInventory(inv, "online") < 1 then
        return false, "没有在线卡（指定部位需要 1 张）"
    end

    -- 扣蛋
    if not Shared.RemovePetEggsFromInventory(inv, eggQuality, 1) then
        return false, "蛋扣除失败"
    end
    -- 扣金币
    Data.SpendGold(goldCost)
    -- 扣在线卡（可选）
    if useCard then
        Shared.RemoveTokensFromInventory(inv, "online", 1)
    end

    Data.MarkDirty("inventory")
    Data.MarkDirty("gold")
    return true, nil
end

--- 更新保底计数器；达到 50 时返回触发品质（并清零计数器），否则返回 nil
---@param eggQuality string
---@return string|nil
local function UpdatePityCounter(eggQuality)
    local counters = Data.value.petGacha and Data.value.petGacha.counters
    if not counters then return nil end

    counters[eggQuality] = (counters[eggQuality] or 0) + 1
    Data.MarkDirty("petGacha")

    if counters[eggQuality] >= Shared.C.PET_GACHA_PITY_COUNT then
        counters[eggQuality] = 0
        -- 传说池：必出史诗或传说（各 50%）；其余池：必出该池的最高品质
        if eggQuality == "mythic" then
            return math.random() < 0.5 and "legendary" or "mythic"
        end
        return eggQuality
    end
    return nil
end

--- 执行一次抽卡
---@param eggQuality string          蛋品质（决定池子）
---@param specifiedSlot string|nil    指定部位（nil = 随机）
---@return table|nil pet, string|nil reason
function Pet.DoGacha(eggQuality, specifiedSlot)
    if IsPoolFull() then
        return nil, "待选池已满（" .. Shared.C.PET_POOL_MAX .. "），请先清理"
    end

    local useCard = specifiedSlot ~= nil
    local ok, reason = ConsumeCurrency(eggQuality, useCard)
    if not ok then return nil, reason end

    local pityQuality = UpdatePityCounter(eggQuality)
    local quality = pityQuality or RollQualityByEgg(eggQuality)
    local slot = specifiedSlot or RollSlot()

    local pet = Pet.CreatePet(quality, slot)
    table.insert(Data.value.pets.pool, pet)
    Data.MarkDirty("pets")

    return pet, nil
end

--- 在待选池中查找宠物
---@param petId string
---@return table|nil, integer|nil
function Pet.FindPetInPool(petId)
    local pool = Data.value.pets and Data.value.pets.pool
    if not pool then return nil, nil end
    for i, p in ipairs(pool) do
        if p.id == petId then return p, i end
    end
    return nil, nil
end

-- ============ 上阵 / 卸下 ============

--- 把待选池里的宠物装到它对应的槽位。
--- 若槽位已有宠物，旧宠物自动回到池中（不占新格子，池满也可换装）。
---@param petId string
---@return boolean ok, string|nil reason
function Pet.EquipPet(petId)
    local pets = Data.value.pets
    if not pets then return false, "宠物数据不存在" end

    local pet, idx = Pet.FindPetInPool(petId)
    if not pet then return false, "宠物不存在" end

    local slot = pet.slot
    local oldPet = pets.equipped[slot]

    table.remove(pets.pool, idx)
    pets.equipped[slot] = pet
    if oldPet then table.insert(pets.pool, oldPet) end

    Data.MarkDirty("pets")
    return true, nil
end

--- 卸下某槽位的宠物（回待选池）。
--- 池满时拒绝卸下。
---@param slot string
---@return boolean ok, string|nil reason
function Pet.UnequipPet(slot)
    local pets = Data.value.pets
    if not pets then return false, "宠物数据不存在" end

    local pet = pets.equipped[slot]
    if not pet then return false, "该槽位没有宠物" end

    if #pets.pool >= Shared.C.PET_POOL_MAX then
        return false, "待选池已满，无法卸下"
    end

    pets.equipped[slot] = nil
    table.insert(pets.pool, pet)
    Data.MarkDirty("pets")
    return true, nil
end

-- ============ 升级 ============

--- 升级宠物（Lv(N) → Lv(N+1) 需 N 个材料）。
--- 优秀及以上宠物需要"宠物品质及以下"的每种品质各 N 个。
---@param petId string
---@return boolean ok, string|nil reason
function Pet.UpgradePet(petId)
    local pets = Data.value.pets
    if not pets then return false, "宠物数据不存在" end

    -- 先在池中找，再在槽位中找
    local pet = nil
    for _, p in ipairs(pets.pool) do
        if p.id == petId then pet = p; break end
    end
    if not pet then
        for _, p in pairs(pets.equipped) do
            if p and p.id == petId then pet = p; break end
        end
    end
    if not pet then return false, "宠物不存在" end

    -- 满级判定用宠物自身的 maxLevel（老宠物无该字段时回退到品质固定上限）
    local cap = pet.maxLevel or Shared.PET_QUALITY_MAX_LEVEL[pet.quality] or 20
    if pet.level >= cap then return false, "已满级" end

    local need = pet.level
    local petRank = Shared.QUALITY_RANK[pet.quality] or 0

    -- 需要的材料品质：宠物品质及以下的所有品质
    local costMap = {}
    for _, q in ipairs(Shared.QUALITY_LIST) do
        if (Shared.QUALITY_RANK[q] or 0) <= petRank then
            costMap[q] = need
        end
    end

    -- 校验：收集全部不足项，一次性提示（而不是遇到第一个就 return）
    -- ⚠️ 传说宠物需要"5 种材料各 N 个"，只报第一个会让玩家以为只需 1 种。
    --    pairs 遍历顺序不稳定，所以必须用 QUALITY_LIST 保证顺序一致。
    local inv = Data.value.inventory
    local missing = {}
    for _, q in ipairs(Shared.QUALITY_LIST) do
        local n = costMap[q]
        if n then
            local have = Shared.CountPetMaterialsInInventory(inv, q)
            if have < n then
                local disp = Shared.PET_MATERIAL_DISPLAY[q]
                table.insert(missing, string.format("%s %d/%d",
                    disp and disp.name or q, have, n))
            end
        end
    end
    if #missing > 0 then
        return false, "材料不足：" .. table.concat(missing, "，")
    end

    -- 扣材料
    for q, n in pairs(costMap) do
        Shared.RemovePetMaterialsFromInventory(inv, q, n)
    end
    Data.MarkDirty("inventory")

    pet.level = pet.level + 1
    Data.MarkDirty("pets")
    return true, nil
end

-- ============ 转换为材料 ============

--- 把待选池里的宠物转换成对应品质的材料。
--- 槽位上的宠物不能转换（必须先卸下）。
---@param petId string
---@return boolean ok, string|nil reason
function Pet.ConvertPetToMaterial(petId)
    local pets = Data.value.pets
    if not pets then return false, "宠物数据不存在" end

    local pet, idx = Pet.FindPetInPool(petId)
    if not pet then return false, "宠物不在待选池" end

    table.remove(pets.pool, idx)
    Shared.AddPetMaterialsToInventory(Data.value.inventory, pet.quality, 1)

    Data.MarkDirty("pets")
    Data.MarkDirty("inventory")
    return true, nil
end

--- 把待选池或槽位里的宠物放入背包（作为 petItem 物品）。
--- 从槽位放入时**直接跳过待选池**，一步到位——符合玩家"我要卖掉它"的直觉。
---@param petId string
---@return boolean ok, string|nil reason
function Pet.MoveToInventory(petId)
    local pets = Data.value.pets
    if not pets then return false, "宠物数据不存在" end

    -- 先在待选池里找
    local pet, poolIdx = Pet.FindPetInPool(petId)

    -- 不在池里则在槽位里找
    local equippedSlot = nil
    if not pet then
        for slot, p in pairs(pets.equipped) do
            if p and p.id == petId then
                pet = p
                equippedSlot = slot
                break
            end
        end
    end
    if not pet then return false, "宠物不存在" end

    -- 背包检查
    local inv = Data.value.inventory
    if #inv >= Data.BagCapacity() then
        return false, "背包已满，无法放入"
    end

    -- 从原位置移除
    if poolIdx then
        table.remove(pets.pool, poolIdx)
    elseif equippedSlot then
        pets.equipped[equippedSlot] = nil
    end

    -- 构造 petItem 物品（嵌套结构：item.pet）
    local petItem = {
        id      = "petItem_" .. Shared.UUID(),
        type    = "petItem",
        pet     = pet,
        icon    = Shared.SLOTS[pet.slot] and Shared.SLOTS[pet.slot].icon or "?",
        name    = Pet.GetName(pet),
        quality = pet.quality,
    }
    table.insert(inv, petItem)

    Data.MarkDirty("pets")
    Data.MarkDirty("inventory")
    return true, nil
end

--- 把背包里的宠物放回待选池。
---@param petItemId string
---@return boolean ok, string|nil reason
function Pet.MoveToPool(petItemId)
    local pets = Data.value.pets
    if not pets then return false, "宠物数据不存在" end

    -- 待选池检查
    if #pets.pool >= Shared.C.PET_POOL_MAX then
        return false, "待选池已满，无法放回"
    end

    -- 在背包里找
    local inv = Data.value.inventory
    for i, it in ipairs(inv) do
        if it.id == petItemId and Shared.IsPetItem(it) then
            local pet = it.pet
            if not pet then return false, "物品数据损坏" end
            table.remove(inv, i)
            table.insert(pets.pool, pet)
            Data.MarkDirty("pets")
            Data.MarkDirty("inventory")
            return true, nil
        end
    end

    return false, "背包中没有该宠物"
end

-- ============ 加成计算 ============

--- 计算所有宠物的加成汇总（按属性加算）。
---
--- 返回结构：
---   baseBonus = { [attr] = number }     -- 所有宠物固定特性的汇总（作用于该部位基础词缀）
---   activated = { [attr] = number }     -- 所有宠物激活属性的汇总（作用于该部位随机词缀）
---
--- ⚠️ 改动说明（2026-10-06）：从"按槽位返回各自倍数"改成"按属性汇总"，
---    让多个宠物的同属性加成**加算**。
---    例：两个宠物各激活 atk +10% → activated.atk = 0.20 → 该部位随机 atk 词缀 × 1.20。
---    旧版是 × 1.1 × 1.1 = 1.21，要求改成加算。
---
--- ⚠️ 固定特性的目标属性由 SLOT_SPEC 决定（武器是 atk、头盔是 maxHp……），
---    所以跨槽位的固定特性通常作用于不同属性，不会互相叠加。
---    只有激活属性（由 activatedAttrs 决定）才会跨槽位同属性叠加。
---@return {baseBonus: table<string, number>, activated: table<string, number>}
function Pet.CalcPetBonuses()
    local baseBonus = {}
    local activated = {}
    local pets = Data.value.pets
    if not pets or not pets.equipped then
        return { baseBonus = baseBonus, activated = activated }
    end

    for _, slot in ipairs(Shared.SLOT_LIST) do
        local pet = pets.equipped[slot]
        if pet then
            -- 固定特性：作用于该部位的基础词缀属性（由 SLOT_SPEC 决定）
            local trait = (pet.fixedTrait or 0) / 100
            for _, spec in ipairs(Shared.SLOT_SPEC[slot] or {}) do
                local attr = spec[1]
                baseBonus[attr] = (baseBonus[attr] or 0) + trait
            end
            -- 激活属性：作用于该部位的匹配属性词缀
            local lvBonus = (pet.level or 1) / 100
            for attr, _ in pairs(pet.activatedAttrs or {}) do
                activated[attr] = (activated[attr] or 0) + lvBonus
            end
        end
    end

    return { baseBonus = baseBonus, activated = activated }
end

return Pet
