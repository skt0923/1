-- ============================================================
-- lobby_runtime.lua：引擎多人大厅入口（完全自建路径）
--
-- 引擎固定从 .project/settings.json 的 @runtime.multiplayer.lobby_runtime
-- 读这个路径，不能改名。
--
-- 流程（房间制匹配）：
--   主菜单（玩法列表）
--     ↓ 点玩法
--   玩法门户（[开始对战] / [返回]）
--     ↓ 点开始对战
--   房间页（我 + 7 人机，[准备] / [离开]）
--     ↓ 点准备（房主 StartGame）
--   平台分配新服务器 → 连服 → 切到游戏脚本（Client.lua，只剩备战+战斗）
--
-- ⚠️ 本文件运行在「连上游戏服务器之前」，用的是平台大厅 API（ctx.client）。
--    游戏脚本（Client.lua）运行在「已连上服务器之后」，两者职责完全不同。
--
-- 入口契约：return function(ctx)，ctx={client, root}，返回 { stop=fun()|nil }
-- ============================================================

local UI = require("urhox-libs.UI")
local Shared = require("Shared")
local AllModes = require("modes.AllModes")

local function log(msg)
    print("[lobby_runtime] " .. tostring(msg))
end

-- 人机数量：1 真人 + 7 人机 = 8 人
local BOT_COUNT = 7

return function(ctx)
    local client, root = ctx.client, ctx.root

    local input = GetInput and GetInput()
    if input then input.mouseVisible = true end

    if not UI.GetNVGContext() then
        UI.Init({
            theme = "default-dark",
            scale = UI.Scale.DEFAULT,
        })
    end

    -- ================= 状态 =================
    local state = {
        screen = "menu",      -- menu | portal | room | connecting | error
        modeId = nil,         -- 当前选中的玩法
        roomId = nil,
        players = {},         -- 平台返回的真人玩家列表
        masterId = nil,       -- 房主
        progress = 0,         -- 连服进度 0..1
        statusText = "正在进入游戏…",
        errMsg = nil,
        tick = 0,
    }

    local stopping = false
    local render

    -- ================= 渲染 =================

    --- 主菜单：玩法列表
    local function buildMenu()
        local children = {}
        for _, m in ipairs(AllModes.LIST) do
            if not m.hidden then
                children[#children + 1] = UI.Button {
                    text = m.name,
                    fontSize = 28,
                    width = 320,
                    height = 64,
                    variant = "primary",
                    backgroundColor = { 184, 147, 79, 255 },
                    borderRadius = 12,
                    onClick = function()
                        state.modeId = m.id
                        state.screen = "portal"
                        render()
                    end,
                }
            end
        end
        return UI.Panel {
            width = "100%", height = "100%",
            flexDirection = "column",
            justifyContent = "center",
            alignItems = "center",
            gap = 20,
            backgroundColor = { 20, 24, 32, 255 },
            children = children,
        }
    end

    --- 玩法门户
    local function buildPortal()
        local cfg = AllModes.GetConfig(state.modeId)
        local name = cfg and cfg.name or "玩法"
        return UI.Panel {
            width = "100%", height = "100%",
            flexDirection = "column",
            justifyContent = "center",
            alignItems = "center",
            gap = 18,
            backgroundColor = (cfg and cfg.themeColor) or { 20, 24, 32, 255 },
            children = {
                UI.Label { text = name, fontSize = 40,
                           fontColor = { 240, 230, 208, 255 },
                           marginBottom = 24 },
                UI.Button {
                    text = "开始对战", fontSize = 22,
                    width = 260, height = 60,
                    variant = "primary",
                    backgroundColor = { 184, 147, 79, 255 },
                    borderRadius = 30,
                    onClick = function() enterRoom() end,
                },
                UI.Button {
                    text = "返回主页", fontSize = 15,
                    width = 160, height = 42,
                    variant = "secondary",
                    backgroundColor = { 62, 54, 46, 255 },
                    borderRadius = 21,
                    onClick = function()
                        state.screen = "menu"
                        state.modeId = nil
                        render()
                    end,
                },
            },
        }
    end

    --- 房间页：我 + 7 人机
    local function buildRoom()
        local slots = {}

        -- 第 1 格：自己
        slots[#slots + 1] = UI.Panel {
            width = 130, height = 90,
            backgroundColor = { 55, 48, 30, 240 },
            borderWidth = 2,
            borderColor = { 216, 180, 90, 255 },
            borderRadius = 10,
            justifyContent = "center", alignItems = "center",
            children = {
                UI.Label { text = "我", fontSize = 18,
                           fontColor = { 255, 224, 138, 255 } },
            },
        }

        -- 第 2..8 格：人机
        for i = 1, BOT_COUNT do
            slots[#slots + 1] = UI.Panel {
                width = 130, height = 90,
                backgroundColor = { 30, 35, 45, 220 },
                borderWidth = 2,
                borderColor = { 102, 102, 102, 200 },
                borderRadius = 10,
                justifyContent = "center", alignItems = "center",
                children = {
                    UI.Label { text = "人机" .. i, fontSize = 18,
                               fontColor = { 200, 200, 200, 255 } },
                },
            }
        end

        -- 两行各 4 格
        local rows = {}
        for r = 1, 2 do
            local rowChildren = {}
            for c = 1, 4 do
                local idx = (r - 1) * 4 + c
                if slots[idx] then rowChildren[#rowChildren + 1] = slots[idx] end
            end
            rows[#rows + 1] = UI.Panel {
                flexDirection = "row", gap = 12,
                children = rowChildren,
            }
        end

        return UI.Panel {
            width = "100%", height = "100%",
            flexDirection = "column",
            justifyContent = "center",
            alignItems = "center",
            gap = 24,
            backgroundColor = { 20, 24, 32, 255 },
            children = {
                UI.Label { text = "房间 " .. tostring(state.roomId or "…"),
                           fontSize = 22,
                           fontColor = { 240, 230, 208, 255 } },
                UI.Panel {
                    flexDirection = "column", gap = 12,
                    alignItems = "center",
                    children = rows,
                },
                UI.Button {
                    text = "准备", fontSize = 22,
                    width = 220, height = 58,
                    variant = "primary",
                    backgroundColor = { 92, 143, 80, 255 },
                    borderRadius = 29,
                    onClick = function() startGame() end,
                },
                UI.Button {
                    text = "离开房间", fontSize = 15,
                    width = 160, height = 42,
                    variant = "secondary",
                    backgroundColor = { 160, 64, 64, 255 },
                    borderRadius = 21,
                    onClick = function() leaveRoom() end,
                },
            },
        }
    end

    --- 连服中 / 错误
    local function buildConnecting()
        if state.screen == "error" then
            return UI.Panel {
                width = "100%", height = "100%",
                flexDirection = "column",
                justifyContent = "center", alignItems = "center",
                gap = 16,
                backgroundColor = { 20, 24, 32, 255 },
                children = {
                    UI.Label { text = "连接失败：" .. tostring(state.errMsg or "未知错误"),
                               fontSize = 16,
                               fontColor = { 255, 102, 102, 255 } },
                    UI.Button {
                        text = "返回主页", fontSize = 15,
                        width = 160, height = 44,
                        variant = "primary",
                        backgroundColor = { 184, 147, 79, 255 },
                        borderRadius = 22,
                        onClick = function()
                            state.screen = "menu"
                            state.errMsg = nil
                            state.roomId = nil
                            render()
                        end,
                    },
                },
            }
        end

        return UI.Panel {
            width = "100%", height = "100%",
            flexDirection = "column",
            justifyContent = "center", alignItems = "center",
            backgroundColor = { 20, 24, 32, 255 },
            children = {
                UI.Label { text = state.statusText, fontSize = 16,
                           fontColor = { 176, 160, 128, 255 },
                           marginBottom = 12 },
                UI.Label { text = string.format("%d%%",
                               math.floor((state.progress or 0) * 100)),
                           fontSize = 14,
                           fontColor = { 255, 210, 77, 255 } },
                UI.Panel {
                    width = 320, height = 10,
                    marginTop = 16,
                    backgroundColor = { 62, 54, 46, 255 },
                    borderRadius = 5,
                    children = {
                        UI.Panel {
                            width = math.max(2,
                                math.floor(320 * (state.progress or 0))),
                            height = 10,
                            backgroundColor = { 184, 147, 79, 255 },
                            borderRadius = 5,
                        },
                    },
                },
            },
        }
    end

    render = function()
        if stopping then return end
        local view
        if state.screen == "menu" then
            view = buildMenu()
        elseif state.screen == "portal" then
            view = buildPortal()
        elseif state.screen == "room" then
            view = buildRoom()
        else
            view = buildConnecting()
        end
        UI.SetRoot(view)
    end

    -- ================= 平台动作 =================

    --- 进入房间：创建房间 → 收到 onCreated 后进房间页
    function enterRoom()
        log("创建房间 CreateRoom")
        state.screen = "connecting"
        state.statusText = "正在创建房间…"
        state.progress = 0
        render()

        client:CreateRoom {
            onCreated = function(roomId)
                log("房间已创建 roomId=" .. tostring(roomId))
                state.roomId = roomId
                state.screen = "room"
                render()
            end,
            onPlayersChanged = function(players, masterId)
                state.players = players or {}
                state.masterId = masterId
                log("房间人员变化：真人 " .. tostring(#state.players)
                    .. " 人，房主=" .. tostring(masterId))
                if state.screen == "room" then render() end
            end,
            onKicked = function()
                log("房间被解散 / 被踢")
                state.screen = "menu"
                state.roomId = nil
                render()
            end,
            onError = function(code, message)
                log("创建房间失败 code=" .. tostring(code)
                    .. " msg=" .. tostring(message))
                state.screen = "error"
                state.errMsg = message or ("错误码 " .. tostring(code))
                render()
            end,
        }
    end

    --- 点准备：房主开始游戏 → 平台分配新服务器
    function startGame()
        log("开始游戏 StartGame")
        state.screen = "connecting"
        state.statusText = "正在进入游戏…"
        state.progress = 0
        render()

        client:StartGame {
            onMatchFound = function(serverInfo)
                log("匹配成功，开始连服")
                state.progress = 0
                state.statusText = "正在连接服务器…"
                render()
            end,
            onProgress = function(progress, status)
                state.progress = math.max(state.progress or 0, progress or 0)
                if status and status ~= "" then
                    state.statusText = status
                end
                render()
            end,
            onError = function(code, message)
                log("开始失败 code=" .. tostring(code)
                    .. " msg=" .. tostring(message))
                state.screen = "error"
                state.errMsg = message or ("错误码 " .. tostring(code))
                render()
            end,
        }
    end

    --- 离开房间
    function leaveRoom()
        log("离开房间 LeaveRoom")
        client:LeaveRoom {
            onLeft = function()
                state.screen = "portal"
                state.roomId = nil
                state.players = {}
                render()
            end,
            onError = function(code)
                log("离开失败 code=" .. tostring(code))
                state.screen = "portal"
                state.roomId = nil
                render()
            end,
        }
    end

    render()
    return {
        stop = function()
            stopping = true
            -- 🔴 绝不在这里调 CancelMatch / LeaveRoom：
            --    stop() 在「引擎切到游戏脚本」时也会被调用，
            --    此时平台已分配好服务器，取消会让服务端判定客户端放弃连接，
            --    随后下发 Kicked → 被踢回大厅 → 死循环进不了游戏。
            log("已停止")
        end,
    }
end
