-- ============================================================
-- AllModes.lua：玩法清单
--
-- 新增玩法时唯一需要修改的文件。
-- ============================================================
local Shared       = require("Shared")
local ModeRegistry = Shared.ModeRegistry
local Protocol     = Shared.Protocol

local AllModes = {}

-- ============ 玩法清单 ============
---@type table[]
AllModes.LIST = {
    {
        id          = "sanguosha",
        name        = "三国杀",
        hidden      = true,                    -- 暂未开放，大厅不显示
        themeColor  = { 45, 20, 20, 255 },     -- 深红
        minPlayers  = 4,
        maxPlayers  = 8,
        networkMode = Protocol.NetworkMode.TURN_BASED,
        screenOrientation = "landscape",
        menuButtons = {
            { id = "inventory", label = "背包" },
            { id = "friends",   label = "好友" },
            { id = "shop",      label = "商城" },
        },
    },
    {
        id          = "autochess",
        name        = "卡牌自走棋",
        themeColor  = { 26, 20, 45, 255 },     -- 深蓝紫
        minPlayers  = 2,
        maxPlayers  = 8,
        networkMode = Protocol.NetworkMode.TURN_BASED,
        screenOrientation = "portrait",
        soloEnabled = true,                    -- 支持本地单人模式（不走服务端房间）
        menuButtons = {
            { id = "inventory", label = "背包" },
            { id = "friends",   label = "好友" },
            { id = "shop",      label = "商城" },
        },
    },
    {
        id          = "tft",
        name        = "金铲铲",
        hidden      = true,                    -- 暂未开放，大厅不显示
        themeColor  = { 45, 32, 20, 255 },     -- 深金橙
        minPlayers  = 2,
        maxPlayers  = 8,
        networkMode = Protocol.NetworkMode.TURN_BASED,
        screenOrientation = "landscape",
        menuButtons = {
            { id = "inventory", label = "背包" },
            { id = "friends",   label = "好友" },
            { id = "shop",      label = "商城" },
        },
    },
}

-- ============ 客户端注册 ============
function AllModes.RegisterAllForClient()
    for _, m in ipairs(AllModes.LIST) do
        ModeRegistry.RegisterClient({
            id          = m.id,
            name        = m.name,
            minPlayers  = m.minPlayers,
            maxPlayers  = m.maxPlayers,
            networkMode = m.networkMode,
        })
    end
end

-- ============ 服务端注册 ============
function AllModes.RegisterAllForServer()
    for _, m in ipairs(AllModes.LIST) do
        ModeRegistry.RegisterServer({
            id          = m.id,
            name        = m.name,
            minPlayers  = m.minPlayers,
            maxPlayers  = m.maxPlayers,
            networkMode = m.networkMode,
        })
        local ok, Mod = pcall(require, "modes." .. m.id .. ".ServerActions")
        if ok and Mod and Mod.Register then
            local ok2, err = pcall(Mod.Register)
            if not ok2 then
                print("[AllModes] ⚠️ 玩法 " .. m.id
                    .. " Register 失败：" .. tostring(err))
            end
        else
            print("[AllModes] ⚠️ 玩法 " .. m.id
                .. " 服务端处理器加载失败：" .. tostring(Mod))
        end
    end
end

-- ============ 按 id 查配置（客户端门户用）============
---@param modeId string
---@return table|nil
function AllModes.GetConfig(modeId)
    for _, m in ipairs(AllModes.LIST) do
        if m.id == modeId then return m end
    end
    return nil
end

return AllModes
