-- ============================================================
-- BD_Tree.lua：天赋树（BD 树）纯逻辑层
--
-- 结构：
--   4 页（战意 / 血祭 / 铁壁 / 灵能），每页独立一棵树
--   每页 10 列 × 4 行 = 40 节点，每节点最多 3 级、每级 2 点，单页容量 240 点
--   每页右侧 2 个核心槽位，槽位解锁阈值 120 / 240
--   列解锁：列 N 需本页累计投入 ≥ N × 8 点
--
-- 与 UI_BD.lua 的关系：本文件纯逻辑，不 require UI。
-- 依赖：Shared（含 Data / Notify）。
-- ============================================================
local Shared = require("Shared")
local Data   = Shared.Data

local BD = {}

-- ============ 常量 ============

BD.DIRECTIONS = {
    { id = "war",    name = "战意", color = "#ff6b4a" },
    { id = "blood",  name = "血祭", color = "#cc2266" },
    { id = "iron",   name = "铁壁", color = "#4488ff" },
    { id = "spirit", name = "灵能", color = "#a86bff" },
}

BD.COST = { small = 1, medium = 2, large = 3, core = 5 }  -- 兼容旧调用
BD.NODE_COST = 2              -- 每级消耗 2 点
BD.NODE_MAX_LEVEL = 3         -- 每节点最多 3 级
BD.COLS = 10                  -- 10 列
BD.ROWS = 4                   -- 4 行（10×4=40 节点×3 级×2 点=240，单页正好填满）
BD.COL_STEP = 8               -- 列解锁：列 N 需累计 N × 8 点
BD.RESET_GOLD_PER_POINT = 10
BD.MAX_CORES = 2              -- 每页 2 个核心槽位

--- 核心槽位解锁阈值（本页累计投入点数）
--- ⚠️ 单页上限 = 10 列 × 4 行 × 3 级 × 2 点 = 240 点。
---    投满 240 解锁两槽位（120 / 240）。
BD.CORE_SLOT_THRESHOLDS = { 120, 240 }

-- ============ 装备点数池 ============

--- 各品质装备提供的天赋点数。
--- 🔴 用固定值而非随机 roll：
---    · 随机 roll 会让玩家反复刷装备追求满值，与"天赋树是长期养成"的定位冲突
---    · 8 件传说（mythic）× 30 = 240，刚好够"一页 3 槽位全解锁"
--- ⚠️ 不走装备存档字段，运行时按品质查表——这样调数值不需要玩家换装备。
--- ⚠️ 若将来要改成"每件随机 roll"，只需在此处改成从 item.bdPoints 读。
BD.QUALITY_POINTS = {
    normal = 8, magic = 12, rare = 16, legendary = 22, mythic = 30,
}

--- 装备提供的总天赋点数（8 个槽位累加）。
--- 空槽位不提供点数（逼玩家穿满 8 件）。
---@return integer
function BD.GetTotalPoints()
    local eq = Data.value.equipment
    if type(eq) ~= "table" then return 0 end
    local total = 0
    for _, slot in ipairs(Shared.SLOT_LIST) do
        local item = eq[slot]
        if item and item.quality then
            total = total + (BD.QUALITY_POINTS[item.quality] or 0)
        end
    end
    return total
end

--- 剩余可用点数
--- ⚠️ math.max 兜底：老存档（点数口径变更前的投入）可能超支，
---    返回负数会让 UI 显示"剩余 -240"，且后续所有加点校验也会错乱。
---@param tree table
---@return integer
function BD.GetRemainingPoints(tree)
    local remain = BD.GetTotalPoints() - BD.TotalSpent(tree)
    if remain < 0 then remain = 0 end
    return remain
end

-- ============ 核心数据 ============

--- 核心定义（跨页共用 ID 空间，每页独立池）
---@type table<string, {name: string, bonus: table, flags: string[]}>
BD.CORE_DATA = {
    -- 战意 7 个
    war_core_crit     = { name = "暴击核心", bonus = { critChance = 0.15, critDamage = 0.30 },
                          flags = { "critIgnoreArmor20" } },
    war_core_atkspeed = { name = "迅捷核心", bonus = { atkSpeed = 0.25 }, flags = {} },
    war_core_heavy    = { name = "重击核心", bonus = { critDamage = 0.50 }, flags = {} },
    war_core_armorpen = { name = "破甲核心", bonus = { armorPen = 0.20 }, flags = {} },
    war_core_combo    = { name = "连击核心", bonus = { atkSpeed = 0.15, atk = 0.10 },
                          flags = { "warCombo" } },
    war_core_splash   = { name = "溅射核心", bonus = { atk = 0.20 }, flags = { "warSplash" } },
    war_core_pierce   = { name = "穿刺核心", bonus = { armorPen = 0.15, critDamage = 0.20 }, flags = {} },
    -- 血祭 4 个
    blood_core_lifesteal = { name = "吸血核心", bonus = { atk = 0.15, killHeal = 10 },
                             flags = { "bloodLifestealAmplify" } },
    blood_core_hpcost    = { name = "耗血核心", bonus = { atk = 0.25 }, flags = { "bloodHpCost" } },
    blood_core_selfharm  = { name = "自伤核心", bonus = { critChance = 0.05, critDamage = 0.20 },
                             flags = { "bloodSelfHarm" } },
    blood_core_lowhp     = { name = "低血核心", bonus = { atk = 0.15, critDamage = 0.15 },
                             flags = { "bloodLowHp" } },
    -- 铁壁 5 个
    iron_core_armor  = { name = "护甲核心", bonus = { armor = 0.30, damageReduce = 0.05 }, flags = {} },
    iron_core_dodge  = { name = "闪避核心", bonus = { dodge = 0.08 }, flags = {} },
    iron_core_thorns = { name = "荆棘核心", bonus = { armor = 0.15 }, flags = { "ironThorns" } },
    iron_core_immune = { name = "免伤核心", bonus = { damageReduce = 0.10, armor = 0.15 }, flags = {} },
    iron_core_block  = { name = "格挡核心", bonus = { damageReduce = 0.05, maxHp = 0.10 },
                         flags = { "ironBlock" } },
    -- 灵能 4 个
    spirit_core_dot        = { name = "DoT 核心", bonus = { atk = 0.10, armorPen = 0.15 },
                               flags = { "spiritDotAmplify" } },
    spirit_core_inscription = { name = "铭刻核心", bonus = { atk = 0.15, critChance = 0.05 },
                                flags = { "spiritInscription" } },
    spirit_core_element    = { name = "元素核心", bonus = { atk = 0.20 }, flags = { "spiritElement" } },
    spirit_core_overload   = { name = "过载核心", bonus = { atkSpeed = 0.15, atk = 0.10 },
                               flags = { "spiritOverload" } },
}

--- 每页核心池（玩家在池中选 1 个放入已解锁的槽位）
BD.CORE_POOL = {
    war    = { "war_core_crit", "war_core_atkspeed", "war_core_heavy", "war_core_armorpen",
               "war_core_combo", "war_core_splash", "war_core_pierce" },
    blood  = { "blood_core_lifesteal", "blood_core_hpcost", "blood_core_selfharm", "blood_core_lowhp" },
    iron   = { "iron_core_armor", "iron_core_dodge", "iron_core_thorns", "iron_core_immune",
               "iron_core_block" },
    spirit = { "spirit_core_dot", "spirit_core_inscription", "spirit_core_element",
               "spirit_core_overload" },
}

-- ============ 节点生成 ============

--- 每页的加成池（按列数循环）
local BONUS_POOL = {
    war = {
        { atk = 0.020 }, { critChance = 0.010 }, { atkSpeed = 0.030 }, { critDamage = 0.040 },
        { armorPen = 0.020 }, { atk = 0.030 }, { critChance = 0.015 }, { atkSpeed = 0.040 },
        { critDamage = 0.060 }, { atk = 0.040 },
    },
    blood = {
        { atk = 0.025 }, { killHeal = 2 }, { atkSpeed = 0.020 }, { critDamage = 0.050 },
        { atk = 0.030 }, { killHeal = 3 }, { critChance = 0.010 }, { atkSpeed = 0.030 },
        { critDamage = 0.050 }, { atk = 0.040 },
    },
    iron = {
        { armor = 0.030 }, { maxHp = 0.030 }, { damageReduce = 0.010 }, { dodge = 0.010 },
        { armor = 0.040 }, { maxHp = 0.030 }, { damageReduce = 0.010 }, { dodge = 0.010 },
        { armor = 0.050 }, { maxHp = 0.040 },
    },
    spirit = {
        { atk = 0.025 }, { critChance = 0.015 }, { armorPen = 0.020 }, { atkSpeed = 0.030 },
        { critDamage = 0.040 }, { atk = 0.030 }, { armorPen = 0.025 }, { critChance = 0.020 },
        { atkSpeed = 0.040 }, { atk = 0.040 },
    },
}

--- 每页名字池
local NAME_POOL = {
    war    = { "锋利", "精准", "迅击", "致命", "洞穿", "锐爪", "锐眼", "暴走", "疾风", "屠戮" },
    blood  = { "战血", "嗜血", "血涌", "血怒", "血饮", "血祭", "血约", "血偿", "血誓", "血魂" },
    iron   = { "守御", "坚毅", "稳固", "磐石", "铁意", "不屈", "铁皮", "不倒", "铁壁", "守护" },
    spirit = { "灵动", "灵觉", "灵犀", "灵韵", "灵泉", "灵心", "灵息", "灵涌", "灵光", "灵慧" },
}

--- 节点坐标系统（单位：格）
BD.NODE_COL_SPACING = 1.5
BD.NODE_ROW_SPACING = 1.2
BD.CORE_COL_X = 15

---@class BDNode
---@field id string
---@field dir string
---@field cost string
---@field name string
---@field bonus table<string, number>
---@field col integer
---@field row integer
---@field x number
---@field y number

---@type table<string, BDNode>
BD.NODES = {}

-- 生成所有节点
do
    for _, dir in ipairs(BD.DIRECTIONS) do
        local did = dir.id
        local pool = BONUS_POOL[did]
        local names = NAME_POOL[did]
        for col = 0, BD.COLS - 1 do
            for row = 0, BD.ROWS - 1 do
                local idx = col * BD.ROWS + row
                local id = did .. "_n" .. col .. "_" .. row
                -- ⚠️ bonus 表示「满级 3 级」时的总加成；
                --    实际生效按 level / NODE_MAX_LEVEL 分摊（见 AggregateBonuses）。
                local bonus = pool[(idx % #pool) + 1] --[[@as table<string, number>]]
                BD.NODES[id] = {
                    id    = id,
                    dir   = did,
                    cost  = "medium",
                    name  = names[(idx % #names) + 1] .. (row + 1),
                    bonus = bonus,
                    col   = col,
                    row   = row,
                    x     = col * BD.NODE_COL_SPACING,
                    y     = row * BD.NODE_ROW_SPACING,
                }
            end
        end
    end
end

-- ============ 槽位 key 规范化 ============

--- 🔴 cores 的存档结构为 { [dir] = { [slotIdx] = coreId } }。
---    但 bdTree 经 cjson.encode/decode 往返后，数字 key 会变成字符串 key（"1"），
---    若混用数字与字符串两种 key，编码时会产生重复键 → cjson 直接报错，上传失败。
---    因此统一以字符串 form 存储槽位 key，读写全部走这里。
---@param slotIdx integer
---@return string
local function SlotKey(slotIdx)
    return tostring(slotIdx)
end

-- ============ 查询 API ============

---@param id string
---@return BDNode|nil
function BD.GetNode(id)
    return BD.NODES[id]
end

--- 节点消耗
---@param id string
---@return integer
function BD.CostOf(id)
    local n = BD.NODES[id]
    return n and BD.NODE_COST or 0
end

--- 取节点当前层数（0~NODE_MAX_LEVEL）
--- ⚠️ 老存档 tree.nodes[id] = true（旧布尔值）视为 1 级。
---@param tree table
---@param id string
---@return integer 0..BD.NODE_MAX_LEVEL
function BD.GetNodeLevel(tree, id)
    if not BD.IsValid(tree) then return 0 end
    local v = tree.nodes[id]
    if v == true then return 1 end
    if type(v) == "number" then
        return math.max(0, math.min(BD.NODE_MAX_LEVEL, math.floor(v)))
    end
    return 0
end

--- 本页累计投入点数（按 level 累加，每级 NODE_COST 点）
---@param tree table
---@param dir string
---@return integer
function BD.GetPageInvestment(tree, dir)
    if not BD.IsValid(tree) then return 0 end
    local n = 0
    for id in pairs(tree.nodes) do
        local node = BD.NODES[id]
        if node and node.dir == dir then
            n = n + BD.GetNodeLevel(tree, id) * BD.NODE_COST
        end
    end
    return n
end

--- 列是否解锁
---@param tree table
---@param dir string
---@param col integer
---@return boolean
function BD.IsColUnlocked(tree, dir, col)
    if col <= 0 then return true end
    return BD.GetPageInvestment(tree, dir) >= col * BD.COL_STEP
end

--- 节点是否已点亮（任意层数 > 0）
---@param tree table
---@param id string
---@return boolean
function BD.IsLearned(tree, id)
    return BD.GetNodeLevel(tree, id) > 0
end

--- 节点能否升级（层数 < 上限 + 列解锁 + 余额足）
---@param tree table
---@param id string
---@return boolean ok, string|nil reason
function BD.IsUnlockable(tree, id)
    if not BD.IsValid(tree) then return false, "树数据无效" end
    local node = BD.NODES[id]
    if not node then return false, "节点不存在" end
    local lv = BD.GetNodeLevel(tree, id)
    if lv >= BD.NODE_MAX_LEVEL then return false, "已满级" end
    if not BD.IsColUnlocked(tree, node.dir, node.col) then
        local need = node.col * BD.COL_STEP
        return false, string.format("需本页累计投入 %d 点（当前 %d）",
            need, BD.GetPageInvestment(tree, node.dir))
    end
    local remain = BD.GetRemainingPoints(tree)
    if remain < BD.NODE_COST then
        return false, string.format("点数不足（剩余 %d，需 %d）", remain, BD.NODE_COST)
    end
    return true, nil
end

--- 已解锁的核心槽位数
---@param tree table
---@param dir string
---@return integer
function BD.GetUnlockedSlotCount(tree, dir)
    local inv = BD.GetPageInvestment(tree, dir)
    local n = 0
    for _, th in ipairs(BD.CORE_SLOT_THRESHOLDS) do
        if inv >= th then n = n + 1 end
    end
    return n
end

--- 槽位是否解锁
---@param tree table
---@param dir string
---@param slotIdx integer 1-based
---@return boolean
function BD.IsSlotUnlocked(tree, dir, slotIdx)
    local th = BD.CORE_SLOT_THRESHOLDS[slotIdx]
    if not th then return false end
    return BD.GetPageInvestment(tree, dir) >= th
end

--- 取某页某槽位已选核心 ID
---@param tree table
---@param dir string
---@param slotIdx integer
---@return string|nil
function BD.GetSelectedCore(tree, dir, slotIdx)
    if not BD.IsValid(tree) or not tree.cores then return nil end
    local pageCores = tree.cores[dir]
    if not pageCores then return nil end
    return pageCores[SlotKey(slotIdx)]
end

-- ============ 操作 API ============

--- 升级节点（+1 级）
---@param tree table
---@param id string
---@return boolean ok, string|nil reason
function BD.Learn(tree, id)
    local ok, reason = BD.IsUnlockable(tree, id)
    if not ok then return false, reason end
    local lv = BD.GetNodeLevel(tree, id)
    tree.nodes[id] = lv + 1
    Data.MarkDirty("bdTree")
    return true, nil
end

--- 降级节点（-1 级）
--- ⚠️ 降到 0 时删除 key（保持存档干净）。
--- ⚠️ 后置保护：降级后所有已点节点仍需满足列解锁。
---@param tree table
---@param id string
---@return boolean ok, string|nil reason
function BD.Unlearn(tree, id)
    if not BD.IsValid(tree) then return false, "树数据无效" end
    local lv = BD.GetNodeLevel(tree, id)
    if lv <= 0 then return false, "该节点未点亮" end

    if lv - 1 <= 0 then
        tree.nodes[id] = nil
    else
        tree.nodes[id] = lv - 1
    end

    -- 检查所有已点节点是否仍满足列解锁
    for otherId in pairs(tree.nodes) do
        local otherNode = BD.NODES[otherId]
        if otherNode and not BD.IsColUnlocked(tree, otherNode.dir, otherNode.col) then
            tree.nodes[id] = lv   -- 回滚
            return false, string.format("取消会导致「%s」失去前置条件", otherNode.name)
        end
    end

    Data.MarkDirty("bdTree")
    return true, nil
end

--- 全树已花点数（按 level 累加）。
--- ⚠️ 只统计当前 BD.NODES 里存在的节点：老存档的残留 ID 会经此过滤，
---    否则会出现「重置按钮显示要扣几百金币，但加成里根本没有这些点」。
---    口径必须与 GetPageInvestment / AggregateBonuses 保持一致。
---@param tree table
---@return integer
function BD.TotalSpent(tree)
    if not BD.IsValid(tree) then return 0 end
    local n = 0
    for id in pairs(tree.nodes) do
        if BD.NODES[id] then
            n = n + BD.GetNodeLevel(tree, id) * BD.NODE_COST
        end
    end
    return n
end

--- 清洗存档：删掉无效节点 ID + 老布尔值 true 转 1 级。
---@param tree table
---@return integer removed
function BD.SanitizeNodes(tree)
    if not BD.IsValid(tree) then return 0 end
    local removed = 0
    for id in pairs(tree.nodes) do
        if not BD.NODES[id] then
            tree.nodes[id] = nil
            removed = removed + 1
        elseif tree.nodes[id] == true then
            tree.nodes[id] = 1   -- 老存档布尔 true → 1 级
        end
    end
    -- cores 同理：清掉不在 CORE_DATA 里的核心 ID
    if type(tree.cores) == "table" then
        for _, slots in pairs(tree.cores) do
            if type(slots) == "table" then
                for k, cid in pairs(slots) do
                    if not BD.CORE_DATA[cid] then
                        slots[k] = nil
                        removed = removed + 1
                    end
                end
            end
        end
    end
    if removed > 0 then
        Data.MarkDirty("bdTree")
    end
    return removed
end

--- 重置成本
---@param tree table
---@return integer
function BD.GetResetCost(tree)
    return BD.TotalSpent(tree) * BD.RESET_GOLD_PER_POINT
end

--- 全树重置
---@param tree table
---@return boolean ok, string|nil reason
function BD.Reset(tree)
    if not BD.IsValid(tree) then return false, "树数据无效" end
    local spent = BD.TotalSpent(tree)
    if spent == 0 then return false, "未点任何节点" end
    local cost = spent * BD.RESET_GOLD_PER_POINT
    if not Data.SpendGold(cost) then
        return false, string.format("金币不足（需 %d）", cost)
    end
    tree.nodes = {}
    tree.cores = {}
    Data.MarkDirty("bdTree")
    return true, nil
end

--- 重置单页（退还该页所有点数 + 清空该页核心）
---@param tree table
---@param dir string
---@return boolean ok, string|nil reason
function BD.ResetPage(tree, dir)
    if not BD.IsValid(tree) then return false, "树数据无效" end
    local spent = BD.GetPageInvestment(tree, dir)
    if spent == 0 then return false, "本页未点任何节点" end
    local cost = spent * BD.RESET_GOLD_PER_POINT
    if not Data.SpendGold(cost) then
        return false, string.format("金币不足（需 %d）", cost)
    end
    for id in pairs(tree.nodes) do
        local node = BD.NODES[id]
        if node and node.dir == dir then
            tree.nodes[id] = nil
        end
    end
    if tree.cores then
        tree.cores[dir] = nil
    end
    Data.MarkDirty("bdTree")
    return true, nil
end

--- 选择核心（免费切换）
---@param tree table
---@param dir string
---@param slotIdx integer
---@param coreId string
---@return boolean ok, string|nil reason
function BD.SelectCore(tree, dir, slotIdx, coreId)
    if not BD.IsValid(tree) then return false, "树数据无效" end
    if not BD.IsSlotUnlocked(tree, dir, slotIdx) then
        local th = BD.CORE_SLOT_THRESHOLDS[slotIdx]
        return false, string.format("槽位未解锁（需本页投入 %d 点）", th or 0)
    end

    local pool = BD.CORE_POOL[dir] or {}
    local found = false
    for _, cid in ipairs(pool) do
        if cid == coreId then found = true break end
    end
    if not found then return false, "核心不属于本页" end

    -- 同页互斥：同一核心不能被两个槽位选
    local pageCores = (tree.cores and tree.cores[dir]) or {}
    for _, cid in pairs(pageCores) do
        if cid == coreId then
            return false, "该核心已被其他槽位选择"
        end
    end

    tree.cores = tree.cores or {}
    tree.cores[dir] = tree.cores[dir] or {}
    tree.cores[dir][SlotKey(slotIdx)] = coreId
    Data.MarkDirty("bdTree")
    return true, nil
end

--- 清空某槽位
---@param tree table
---@param dir string
---@param slotIdx integer
---@return boolean
function BD.ClearCore(tree, dir, slotIdx)
    if not BD.IsValid(tree) or not tree.cores then return false end
    if not tree.cores[dir] then return false end
    tree.cores[dir][SlotKey(slotIdx)] = nil
    Data.MarkDirty("bdTree")
    return true
end

-- ============ 汇总 API ============

--- 汇总加成（普通节点按 level/MAX 分摊 + 已选核心全额）
---@param tree table
---@return table<string, number>
function BD.AggregateBonuses(tree)
    local out = {}
    if not BD.IsValid(tree) then return out end

    -- 普通节点：bonus 是满级值，实际生效 = bonus × (level / MAX)
    for id in pairs(tree.nodes) do
        local node = BD.NODES[id]
        if node and node.bonus then
            local lv = BD.GetNodeLevel(tree, id)
            local ratio = lv / BD.NODE_MAX_LEVEL
            for attr, v in pairs(node.bonus) do
                out[attr] = (out[attr] or 0) + v * ratio
            end
        end
    end

    -- 已选核心
    if tree.cores then
        for _, slots in pairs(tree.cores) do
            for _, coreId in pairs(slots) do
                local core = BD.CORE_DATA[coreId]
                if core and core.bonus then
                    for attr, v in pairs(core.bonus) do
                        out[attr] = (out[attr] or 0) + v
                    end
                end
            end
        end
    end
    return out
end

--- 汇总机制 flag（只来自已选核心）
---@param tree table
---@return table<string, boolean>
function BD.GetMechanisms(tree)
    local out = {}
    if not BD.IsValid(tree) or not tree.cores then return out end
    for _, slots in pairs(tree.cores) do
        for _, coreId in pairs(slots) do
            local core = BD.CORE_DATA[coreId]
            if core and core.flags then
                for _, f in ipairs(core.flags) do
                    out[f] = true
                end
            end
        end
    end
    return out
end

---@param tree table
---@param flag string
---@return boolean
function BD.HasFlag(tree, flag)
    return BD.GetMechanisms(tree)[flag] == true
end

-- ============ 兼容 API ============

---@return table
function BD.NewTree()
    return Shared.NewBDTree()
end

---@param tree any
---@return boolean
function BD.IsValid(tree)
    return Shared.IsBDTreeValid(tree)
end

--- 取节点在指定 level 下的加成（用于 UI 显示"每级 X / 满级 3X"）
---@param node BDNode
---@param level integer
---@return table<string, number>
function BD.GetNodeBonusAtLevel(node, level)
    local out = {}
    if not node or not node.bonus then return out end
    local ratio = math.max(0, math.min(1, level / BD.NODE_MAX_LEVEL))
    for attr, v in pairs(node.bonus) do
        out[attr] = v * ratio
    end
    return out
end

-- ============ 节点图标 ============

--- 属性 → 图标映射
--- ⚠️ 用纯符号（非 emoji）保证跨字体环境渲染一致；
---    若某符号在目标设备显示为方框，替换为相邻备选即可。
BD.NODE_ICONS = {
    atk          = "⚔",
    maxHp        = "❤",
    critChance   = "✦",
    critDamage   = "★",
    atkSpeed     = "⚡",
    moveSpeed    = "➤",
    armorPen     = "⚒",
    killHeal     = "✚",
    armor        = "⛨",
    damageReduce = "◈",
    dodge        = "≋",
    hitRate      = "◎",
}

--- 取节点的显示图标（取 bonus 里按 MOD_IDS 顺序第一个属性的图标）
---@param node BDNode
---@return string
function BD.GetNodeIcon(node)
    if not node or not node.bonus then return "●" end
    for _, attr in ipairs(Shared.MOD_IDS) do
        if node.bonus[attr] then
            return BD.NODE_ICONS[attr] or "●"
        end
    end
    return "●"
end

--- 取核心的显示图标（取 bonus 里按 MOD_IDS 顺序第一个属性的图标）
---@param coreId string
---@return string
function BD.GetCoreIcon(coreId)
    local core = BD.CORE_DATA[coreId]
    if not core or not core.bonus then return "◆" end
    for _, attr in ipairs(Shared.MOD_IDS) do
        if core.bonus[attr] then
            return BD.NODE_ICONS[attr] or "◆"
        end
    end
    return "◆"
end

--- 格式化加成（UI 用）
---@param bonus table<string, number>
---@return string
function BD.FormatBonus(bonus)
    if not bonus or next(bonus) == nil then return "（无加成）" end
    local keys = {}
    for k in pairs(bonus) do table.insert(keys, k) end
    table.sort(keys)
    local parts = {}
    for _, k in ipairs(keys) do
        local v = bonus[k]
        local def = Shared.MOD_DEFS[k]
        local label = def and def.name or k
        if k == "killHeal" then
            parts[#parts + 1] = string.format("%s +%d", label, math.floor(v))
        else
            local s = string.format("%.2f", v * 100)
            s = s:gsub("%.?0+$", "")
            parts[#parts + 1] = string.format("%s +%s%%", label, s)
        end
    end
    return table.concat(parts, "  ")
end

return BD
