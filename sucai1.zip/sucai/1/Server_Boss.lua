-- ============================================================
-- Server_Boss.lua：共享 Boss 系统（Server.lua 的兄弟文件）
--
-- 职责：共享 Boss 的生成 / 广播 / 移除 / 伤害累计 / 击杀奖励 / 召唤卷。
--
-- 与 Server.lua 的关系：
--   · 本模块持有自己的状态（sharedBosses 表）
--   · 通过 Boss.Init 注入 Server.lua 的 players / connections /
--     MarkPlayerDirty / SaveToCloud / Sys
--   · 事件订阅由 Server.Start 调 Boss.RegisterEvents() 完成
--   · 主循环每秒调 Boss.Update(dt)（在线人数归零时清空 Boss）
--
-- 依赖：Shared。**不 require Server.lua**（避免循环）。
-- ============================================================
local Shared = require("Shared")

local Boss = {}

-- ============ 注入 ============
--- ⚠️ 默认空表 / 空实现：Init 前若真有事件进来（不该发生），
---    只会退化成「什么都不做」，不会因为 nil 调用崩掉。
---@type table
local ctx = {
    ---@type table<string, ServerPlayer>
    players         = {},
    ---@type table<string, ConnectionInfo>
    connections     = {},
    MarkPlayerDirty = function(_) end,
    SaveToCloud     = function(_) end,
    ---@type table|nil  Server_System 模块（用 AddMail / NotifyMail / PushInventory / FindConnectionByPlayerId）
    Sys             = nil,
}

--- 注入核心状态与服务（Server.lua 在 Start 里调用一次）
---@param c table
function Boss.Init(c)
    for k, v in pairs(c) do ctx[k] = v end
end

-- ============ 状态 ============
--- 共享 Boss 表：key = monsterId
--- 伤害与击杀完全以客户端上报为准（服务端不校正血量），首个上报击杀者拿奖励。
---@type table<string, table>
local sharedBosses = {}

-- ============ 事件订阅 ============
function Boss.RegisterEvents()
    SubscribeToEvent(Shared.EVENTS.REPORT_LOCAL_KILL, Boss.OnReportLocalKill)
    SubscribeToEvent(Shared.EVENTS.USE_SUMMON_SCROLL, Boss.OnUseSummonScroll)
    SubscribeToEvent(Shared.EVENTS.ATTACK_BOSS,       Boss.OnAttackBoss)
    SubscribeToEvent(Shared.EVENTS.BOSS_KILLED,       Boss.OnBossKilled)
    SubscribeToEvent(Shared.EVENTS.PLAYER_DEATH,      Boss.OnPlayerDeath)
end

-- ============ 主循环 ============
--- 由 Server.OnUpdate 每秒调用一次。
--- 在线人数归零 → 清空所有共享 Boss（没人在线，没客户端需要通知）。
function Boss.Update(_)
    if next(ctx.players) == nil and next(sharedBosses) ~= nil then
        for bossId in pairs(sharedBosses) do
            sharedBosses[bossId] = nil
        end
        print("[Server] 在线人数归零，已清空全部共享 Boss")
    end
end

-- ============ 广播 ============
--- 广播一只共享 Boss 给所有连接（新增或血量更新都走这里）
---@param monsterId string
---@param isNew boolean|nil
function Boss.BroadcastSharedBoss(monsterId, isNew)
    local boss = sharedBosses[monsterId]
    if not boss then return end
    local payload = Shared.ToVariantMap({
        MonsterId = boss.id,
        BossType  = boss.type,
        Hp        = boss.hp,
        MaxHp     = boss.maxHp,
        X         = boss.x,
        Z         = boss.z,
        IsNew     = isNew and 1 or 0,
    })
    for _, info in pairs(ctx.connections) do
        if info.connection then
            info.connection:SendRemoteEvent(Shared.EVENTS.SHARED_BOSS_UPDATE, true, payload)
        end
    end
end

--- 广播移除一只共享 Boss（目前只有「被击杀」一种原因）。
---@param monsterId string
---@param reason string|nil
function Boss.BroadcastRemoveBoss(monsterId, reason)
    local payload = Shared.ToVariantMap({
        MonsterId = monsterId,
        Reason    = reason or "dead",
    })
    for _, info in pairs(ctx.connections) do
        if info.connection then
            info.connection:SendRemoteEvent(Shared.EVENTS.SHARED_BOSS_REMOVE, true, payload)
        end
    end
end

--- 把当前所有存活的共享 Boss 单独推给某一个连接。
--- 中途加入的玩家上线时补推一次，消除「最长 60 秒看不到已有 Boss」的空窗。
---@param c Connection
function Boss.PushSharedBossesTo(c)
    for _, boss in pairs(sharedBosses) do
        c:SendRemoteEvent(Shared.EVENTS.SHARED_BOSS_UPDATE, true, Shared.ToVariantMap({
            MonsterId = boss.id,
            BossType  = boss.type,
            Hp        = boss.hp,
            MaxHp     = boss.maxHp,
            X         = boss.x,
            Z         = boss.z,
            IsNew     = 1,
        }))
    end
end

-- ============ 击杀奖励 ============
--- 发放共享 Boss 击杀奖励（走邮件，背包满也不丢件）。
---@param winnerId string
---@param boss table
function Boss.GrantBossReward(winnerId, boss)
    local Sys = ctx.Sys
    if not Sys then
        print("[Server] ⚠️ Boss.GrantBossReward 未注入 Sys，无法发放奖励")
        return
    end

    local winner = ctx.players[winnerId]
    if not winner then
        print("[Server] Boss 奖励发放失败：玩家 " .. tostring(winnerId) .. " 已离线")
        return
    end

    local q = boss.quality or Shared.QualityOfMonsterLevel(boss.level or 9)
    local rewardMap = {
        normal    = { gold = 200,  frag = 20,  spirit = 3  },
        magic     = { gold = 400,  frag = 40,  spirit = 6  },
        rare      = { gold = 800,  frag = 80,  spirit = 12 },
        legendary = { gold = 1600, frag = 160, spirit = 24 },
        mythic    = { gold = 3200, frag = 320, spirit = 48 },
    }
    local r = rewardMap[q] or rewardMap.normal

    local items = {}
    if r.frag > 0 then
        local disp = Shared.FRAGMENT_DISPLAY[q] or { name = q.."碎片", icon = "⬜" }
        table.insert(items, {
            id = "frag_" .. Shared.UUID(),
            type = "fragment",
            fragmentType = q,
            count = r.frag,
            icon = disp.icon,
            name = disp.name,
            quality = q,
        })
    end
    if r.spirit > 0 then
        local disp = Shared.SPIRIT_DISPLAY[q] or { name = q.."精魄", icon = "⚪" }
        table.insert(items, {
            id = "sp_" .. Shared.UUID(),
            type = "spirit",
            spiritType = q,
            count = r.spirit,
            icon = disp.icon,
            name = disp.name,
            quality = q,
        })
    end

    Sys.AddMail(winner, "boss_reward", {
        title = string.format("Boss击杀奖励（%s）", Shared.QUALITY_NAMES[q] or q),
        gold  = r.gold,
        items = items,
    })
    Sys.NotifyMail(winner)
    Sys.PushInventory(winner, true)
    ctx.MarkPlayerDirty(winner.id)     -- ⚠️ 用注入的 MarkPlayerDirty，不走 Sys

    local info = Sys.FindConnectionByPlayerId(winner.id)
    if info and info.connection then
        info.connection:SendRemoteEvent(Shared.EVENTS.TOAST, true, Shared.ToVariantMap({
            Text = string.format("🎁 Boss击杀奖励已发放至邮箱（%d 金币 + %d 碎片 + %d 精魄）",
                r.gold, r.frag, r.spirit),
        }))
    end

    print(string.format("[Server] 共享 Boss %s 被 %s 击杀，奖励 %d 金币 + %d 碎片 + %d 精魄（%s）",
        boss.id, winner.id, r.gold, r.frag, r.spirit, q))
end

-- ============ 事件处理 ============
--- 从事件里取出「上报者」。
--- ⚠️ 本模块自己的副本：不依赖 Server.PlayerOf（那是全局函数）。
---@param e VariantMap
---@return ServerPlayer|nil, Connection|nil
local function PlayerOf(e)
    local c = e["Connection"]:GetPtr("Connection")
    local info = ctx.connections[tostring(c)]
    local p = info and info.playerId and ctx.players[info.playerId]
    return p, c
end

--- 客户端上报：本地累计击杀达标，roll 是否发召唤卷。
function Boss.OnReportLocalKill(_, e)
    local p, c = PlayerOf(e)
    if not p then return end

    local killType = e["KillType"]:GetString()
    if killType ~= "boss" then return end

    local spawnX = e["X"]:GetFloat()
    local spawnZ = e["Z"]:GetFloat()

    local lv = Shared.MonsterLevelOf(spawnX, spawnZ) or 1
    local q  = Shared.QualityOfMonsterLevel(lv)

    local got = math.random() < 0.5
    if got then
        Shared.AddSummonScrollToInventory(p.inventory, q, 1)
        ctx.MarkPlayerDirty(p.id)
        ctx.Sys.PushInventory(p, true)
        ctx.SaveToCloud(p.id)
    end
    print(string.format("[Server] %s 击杀达标，roll=%s（品质 %s）",
        p.id, got and "中" or "未中", q))

    c:SendRemoteEvent(Shared.EVENTS.SUMMON_SCROLL_RESULT, true, Shared.ToVariantMap({
        Success    = got and 1 or 0,
        Reason     = got and ("恭喜获得 " .. ((Shared.SUMMON_SCROLL[q] or {}).name or "召唤卷"))
                            or "本次未获得召唤卷",
        ScrollType = q,
    }))
end

--- 客户端请求：使用召唤卷（服务端权威：冷却 / 距离 / 区域 / 扣卷）。
function Boss.OnUseSummonScroll(_, e)
    local p, c = PlayerOf(e)
    if not p then return end

    local scrollType = e["ScrollType"]:GetString()
    if not Shared.SUMMON_SCROLL[scrollType] then return end

    local function Reject(reason)
        c:SendRemoteEvent(Shared.EVENTS.SUMMON_SCROLL_RESULT, true, Shared.ToVariantMap({
            Success = 0, Reason = reason, ScrollType = scrollType,
        }))
    end

    local now = os.time()

    p.__lastScrollUseAt = p.__lastScrollUseAt or 0
    local elapsed = now - p.__lastScrollUseAt
    if elapsed < Shared.SUMMON_SCROLL_COOLDOWN then
        Reject(string.format("召唤冷却中，还需 %d 秒", Shared.SUMMON_SCROLL_COOLDOWN - elapsed))
        return
    end

    local px = (p.save and p.save.x) or 0
    local pz = (p.save and p.save.z) or 0
    local minD = Shared.SUMMON_SCROLL_MIN_DIST
    if px * px + pz * pz < minD * minD then
        Reject("距离出生点太近，无法使用召唤卷")
        return
    end

    local zoneQ = Shared.ZoneQualityAt(px, pz)
    if zoneQ == nil then
        Reject("此处为区域缓冲区，无法使用召唤卷")
        return
    end
    if zoneQ ~= scrollType then
        local zoneName = (Shared.QUALITY_NAMES[zoneQ] or zoneQ)
        local scrollName = (Shared.SUMMON_SCROLL[scrollType] or {}).name or "召唤卷"
        Reject(string.format("此处是%s区域，无法使用%s", zoneName, scrollName))
        return
    end

    if not Shared.RemoveSummonScrollFromInventory(p.inventory, scrollType, 1) then
        Reject("没有该召唤卷")
        return
    end

    p.__lastScrollUseAt = now

    local q      = scrollType
    local bossLv = Shared.C.TIER_MAX_LEVEL[q] or 9
    local maxHp  = (Shared.C.BOSS_STATS[q] or Shared.C.BOSS_STATS.normal).hp
    local monsterId = "boss_" .. Shared.UUID()

    sharedBosses[monsterId] = {
        id           = monsterId,
        type         = "boss",
        quality      = q,
        level        = bossLv,
        hp           = maxHp,
        maxHp        = maxHp,
        x            = px,
        z            = pz,
        damageMap    = {},
        lastAttacker = nil,
        spawnAt      = now,
    }
    print(string.format("[Server] %s 使用召唤卷，生成共享 Boss %s (HP=%d, Lv=%d, Q=%s)",
        p.id, monsterId, maxHp, bossLv, q))
    Boss.BroadcastSharedBoss(monsterId, true)

    c:SendRemoteEvent(Shared.EVENTS.SUMMON_SCROLL_RESULT, true, Shared.ToVariantMap({
        Success    = 1,
        Reason     = "召唤成功！",
        ScrollType = scrollType,
    }))

    ctx.MarkPlayerDirty(p.id)
    ctx.Sys.PushInventory(p, true)
    ctx.SaveToCloud(p.id)
end

--- 客户端上报：对共享 Boss 造成的伤害（只累计，不扣血不判死）。
function Boss.OnAttackBoss(_, e)
    local p = PlayerOf(e)
    if not p then return end

    local monsterId = e["MonsterId"]:GetString()
    local damage = e["Damage"]:GetFloat()
    local boss = sharedBosses[monsterId]
    if not boss then
        print(string.format("[Server] 收到 %s 对 %s 的伤害上报，但该 Boss 已不存在（可能已被击杀）",
            p.id, tostring(monsterId)))
        return
    end

    if damage <= 0 then return end

    boss.lastAttacker = p.id
    boss.damageMap = boss.damageMap or {}
    boss.damageMap[p.id] = (boss.damageMap[p.id] or 0) + damage
end

--- 客户端上报：本地把 Boss 打到 0 血 → 直接结算奖励并移除。
--- 🔴 完全信任客户端：不做血量校验，首个上报者即击杀者。
function Boss.OnBossKilled(_, e)
    local p = PlayerOf(e)
    if not p then return end

    local monsterId = e["MonsterId"]:GetString()
    if not monsterId or monsterId == "" then return end
    local boss = sharedBosses[monsterId]
    if not boss then return end

    print(string.format("[Server] 共享 Boss %s 由 %s 上报击杀，直接发放奖励（不做血量校验）",
        monsterId, p.id))

    Boss.GrantBossReward(p.id, boss)
    Boss.BroadcastRemoveBoss(monsterId, "dead")
    sharedBosses[monsterId] = nil
end

--- 玩家死亡：清除其对各 Boss 的仇恨记录。
function Boss.OnPlayerDeath(_, e)
    local p = PlayerOf(e)
    if not p then return end
    for _, boss in pairs(sharedBosses) do
        if boss.lastAttacker == p.id then
            boss.lastAttacker = nil
        end
    end
end

return Boss
