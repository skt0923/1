-- ============================================================
-- Server_System.lua：服务端业务子系统（经济 / 通信 / 离线任务）
--
-- 内容：拍卖行（挂单 / 购买 / 过期 / 落盘）· 邮件（发放 / 领取 / 分页 / 溢出转邮件）
--       · 每日赠送 · 离线存档串行队列 · 离线卖家结算
--
-- 与 Server.lua 的边界：
--   ➜ 核心状态表（players / connections）与核心服务（MarkPlayerDirty /
--     SaveToCloud / LoadSaveAsync / ApplySaveToPlayer / PushCloud）
--     由 Server.lua 在 Sys.Init 时**注入**（表按引用、函数按闭包）。
--   ➜ 本模块自己的状态（挂单表 / 队列 / 计时器）留在本文件。
--   ➜ 事件订阅由 Server.Start 调用 Sys.RegisterEvents() 完成；
--     主循环每秒调用 Sys.Update(dt)。
--
-- 钱庄（存款 / 利息结算 / 税池）已拆到 Server_Bank.lua：本文件通过
-- Sys.Init 注入的同一份 ctx 副本转交给 Bank.Init，并用 Bank.AddTax 记账。
--
-- 依赖：Shared + Server_Bank。
-- ============================================================
local Shared = require("Shared")
local Bank   = require("Server_Bank")

-- 与 Server.lua 共享的类型（注释形式，两端各自声明一份供 LSP 使用）
---@class ServerPlayer
---@field id string
---@field gold integer
---@field level integer
---@field inventory table[]
---@field equipment table<string, table>
---@field bagPageCount integer
---@field mails table[]
---@field nextMailId integer
---@field onlineTokenMinutes integer

---@class MarketListing
---@field id string
---@field sellerId string
---@field item table
---@field price integer
---@field createdAt integer
---@field expiresAt integer|nil 过期时间戳（7 天后自动下架退回）

---@class ConnectionInfo
---@field connection Connection
---@field userId integer|nil
---@field playerId string|nil

local Sys = {}

-- ============ 本模块状态 ============
---@type table<string, MarketListing>
local marketListings = {}
local nextListingId  = 1
local marketExpireTimer = 0
local marketSaveTimer   = 0

-- 最近处理过的上架请求缓存：clientId → { ok, reason, listingId, ts }
-- 用途：防"部分处理 + 客户端重发"导致的物品复制
local recentListingResults = {}
local LISTING_CACHE_TTL = 1800   -- 30 分钟

-- 离线存档串行队列：pid → { running, pending }
-- ⚠️ 同一玩家的离线存档操作（结算货款 / 退回挂单）必须串行。
--    LoadSaveAsync 是「读-改-写」，并发执行会互相覆盖（后写者丢掉先写者的改动）。
---@type table<string, {running: boolean, pending: fun(done: fun())[]}>
local offlineSaveQueue_ = {}

--- 单个离线存档任务的兜底超时（秒）。
--- ⚠️ LoadSaveAsync 没有超时：云存档既不回调 ok 也不回调 error 时，
---    任务会永远不调 done()，队列卡死、该玩家后续所有离线结算全部积压。
---    所以由 Sys.Update 的 PumpStaleOfflineQueues 强制推进。
local OFFLINE_TASK_TIMEOUT = 10.0

--- 当前正在跑的任务的「强制推进」函数：pid → fun()
---@type table<string, fun()>
local offlineStaleAdvance_ = {}

--- 拍卖行挂单的云变量键。
--- 🔴 与玩家存档同理：改键名 = 全服挂单清空（挂单表是全局的，uid 固定为 0）。
---    当前与 SAVE_KEY 同步切到 v4，属于**刻意清档**（见 Server.lua 清档历史）。
---    想回滚：把 MARKET_KEY 改回 "market_listings_v3"，旧挂单仍在那个键下。
---@see Server.lua 的 SAVE_KEY
local MARKET_KEY = "market_listings_v4"

--- 拍卖行挂单是否已从云端读回（含「确认云端无挂单」）。
---
--- 🔴 读回之前禁止 SaveMarket。
---    否则 Sys.Update 的 600 秒定时落盘会把**空表**写回云端，
---    把全服挂单永久抹掉（挂单自我销毁，且不可恢复）。
---    ⚠️ 必须声明在这里（模块状态区）：Sys.SaveMarket 定义在文件更靠前的位置，
---       声明在末尾会让它读到全局 nil，守卫失效。
local marketLoaded_ = false

--- 把一份（可能来自旧版本的）存档转成「写回云端」用的完整结构。
---
--- ⚠️ 离线存档是**整份覆盖**：调用方逐个字段重建存档时，任何一个没写进去的
---    字段都会被抹掉（历史上 settings / bankDeposits 就各踩过一次）。
---    所以这里改成「以云端存档为基底，只覆盖调用方明确要改的字段」，
---    新字段自动透传，不需要每次加字段都回来补一遍。
---@param save table|nil 云端读回的存档（可为 nil = 新玩家）
---@param overrides table 要覆盖/新增的字段
---@return table
local function BuildOfflineSave(save, overrides)
    local base = Shared.NewPlayerSave()
    local out = {}
    if type(save) == "table" then
        for k, v in pairs(save) do out[k] = v end
    end
    -- 用默认值补齐老存档缺失的字段（新字段也因此拿到正确默认值）
    for k, v in pairs(base) do
        if out[k] == nil then out[k] = v end
    end
    for k, v in pairs(overrides or {}) do out[k] = v end
    out.saveVersion = Shared.SAVE_VERSION
    return out
end

-- ============ 核心注入 ============
--- ⚠️ 默认实现是空操作 / 空表：Sys.Init 之前若真有事件进来（不该发生），
---    只会退化成「不做任何持久化」，不会因为 nil 调用崩掉。
---@type table
local ctx = {
    ---@type table<string, ServerPlayer>
    players        = {},
    ---@type table<string, ConnectionInfo>
    connections    = {},
    MarkPlayerDirty = function(_) end,
    SaveToCloud     = function(_) end,
    ---@param pid string
    ---@param cb fun(save: table|nil)
    LoadSaveAsync   = function(_, cb) if cb then cb(nil) end end,
    ApplySaveToPlayer = function() end,
    ---@param pid string
    ---@param json string
    PushCloud       = function(_, _) end,
    ---@return ServerPlayer|nil, Connection|nil
    PlayerOf        = function(_) return nil, nil end,
}

--- 注入核心状态与服务（Server.lua 在 Start 里调用一次）
---@param c table
function Sys.Init(c)
    for k, v in pairs(c) do ctx[k] = v end
    ctx.Sys = Sys

    -- 给 Bank 传一份含 Sys 引用的副本（不改调用方原表）
    local bankCtx = {}
    for k, v in pairs(c) do bankCtx[k] = v end
    bankCtx.Sys = Sys
    Bank.Init(bankCtx)
end

--- 订阅本模块负责的服务端事件（Server.Start 里调用）
function Sys.RegisterEvents()
    SubscribeToEvent(Shared.EVENTS.REQUEST_MARKET,      Sys.OnMarket)
    SubscribeToEvent(Shared.EVENTS.REQUEST_MARKET_PAGE, Sys.OnMarketPage)
    SubscribeToEvent(Shared.EVENTS.MAIL_CLAIM,          Sys.OnMailClaim)
    SubscribeToEvent(Shared.EVENTS.REQUEST_MAIL_PAGE,   Sys.OnRequestMailPage)
    SubscribeToEvent(Shared.EVENTS.BAG_OVERFLOW,        Sys.OnBagOverflowToMail)
    -- 升级 / 降级
    SubscribeToEvent(Shared.EVENTS.LEVEL_UP,            Sys.OnLevelUp)
    SubscribeToEvent(Shared.EVENTS.LEVEL_DOWN,          Sys.OnLevelDown)
    -- 钱庄（迁到 Server_Bank.lua）
    Bank.RegisterEvents()
end

-- ============ 每帧驱动 ============
--- 系统域定时任务：挂单过期 / 离线队列兜底 / 拍卖行落盘
--- （原 Server.OnUpdate 里的对应几段）
---@param dt number
function Sys.Update(dt)
    -- 离线存档队列超时兜底（每秒一次，防止云回调缺失卡死队列）
    Sys.PumpStaleOfflineQueues(os.time())

    -- 钱庄结算队列推进 + 看门狗已迁至 Bank.Update（见下方调用点）

    -- 挂单过期扫描（660 秒）
    marketExpireTimer = marketExpireTimer + dt
    if marketExpireTimer >= 660 then
        marketExpireTimer = 0
        local now = os.time()
        for lid, l in pairs(marketListings) do
            if l.expiresAt and now > l.expiresAt then
                local seller = ctx.players[l.sellerId]
                if seller then
                    Sys.AddMail(seller, "market_expire", {
                        title = "挂单过期退回：" .. ((l.item and l.item.name) or "装备"),
                        items = { l.item },
                    })
                    Sys.NotifyMail(seller)
                    ctx.MarkPlayerDirty(seller.id)
                else
                    Sys.ExpireToOfflineMail(l)
                end
                marketListings[lid] = nil
            end
        end
    end

    -- 清理过期 clientId 缓存
    local nowTs = os.time()
    for cid, entry in pairs(recentListingResults) do
        if nowTs - entry.ts >= LISTING_CACHE_TTL then
            recentListingResults[cid] = nil
        end
    end

    -- 拍卖行落盘（600 秒）
    marketSaveTimer = marketSaveTimer + dt
    if marketSaveTimer >= 600 then
        marketSaveTimer = 0
        Sys.SaveMarket()
    end

    -- 钱庄（跨日结算 / 到期扫描 / 定期落盘 + 结算队列推进）
    Bank.Update(dt)
end

--- 遍历玩家邮件，统计待领取金币总额和物品总件数。
---@param p ServerPlayer
---@return integer goldTotal, integer itemTotal
function Sys.CalcMailTotals(p)
    local g, c = 0, 0
    for _, m in ipairs(p.mails or {}) do
        g = g + (m.gold or 0)
        c = c + #(m.items or {})
    end
    return g, c
end

--- 超时兜底：把卡住超过 OFFLINE_TASK_TIMEOUT 的队列强制推进（由 OnUpdate 每秒调用）
---@param now number
function Sys.PumpStaleOfflineQueues(now)
    for pid, q in pairs(offlineSaveQueue_) do
        if q.running and q.startedAt and (now - q.startedAt) >= OFFLINE_TASK_TIMEOUT then
            local advance = offlineStaleAdvance_[pid]
            print("[Server] 离线存档任务超时，强制推进 " .. pid)
            if advance then advance() end
        end
    end
end

--- 串行执行某玩家的离线存档任务（同一 pid 内排队，不同 pid 互不阻塞）
---@param pid string
---@param fn fun(done: fun())
function Sys.RunOfflineSaveTask(pid, fn)
    local q = offlineSaveQueue_[pid]
    if q and q.running then
        table.insert(q.pending, fn)
        return
    end
    q = { running = true, pending = {}, startedAt = os.time() }
    offlineSaveQueue_[pid] = q
    table.insert(q.pending, fn)

    local function Next()
        local cur = offlineSaveQueue_[pid]
        if not cur then return end
        if #cur.pending == 0 then
            offlineSaveQueue_[pid] = nil
            offlineStaleAdvance_[pid] = nil
            return
        end
        local task = table.remove(cur.pending, 1)
        cur.startedAt = os.time()

        -- 每个任务只允许推进一次：done() 重复调用（超时后又收到云回调）不再影响队列
        local advanced = false
        local function Advance()
            if advanced then return end
            advanced = true
            Next()
        end
        offlineStaleAdvance_[pid] = Advance

        task(Advance)
    end
    Next()
end

-- ============ 拍卖行 ============
function Sys.OnMarket(_, e)
    local p, c = ctx.PlayerOf(e)
    if not p then return end
    local act = e["Action"]:GetString()

    -- ⚠️ 本事件只承载写操作（buy / cancel）。
    --    读列表已改走 REQUEST_MARKET_PAGE（服务端分页），
    --    原来的 "list" 分支已删除 —— 不要再加回来。
    if act == "buy" then
        Sys.HandleMarketBuy(c, p, e)

    elseif act == "cancel" then
        local l = marketListings[e["ListingId"]:GetString()]
        if l and l.sellerId == p.id then
            Sys.AddMail(p, "market_cancel", {
                title = "下架退回：" .. (l.item.name or "装备"),
                items = { l.item },
            })
            Sys.NotifyMail(p)
            marketListings[l.id] = nil
            ctx.MarkPlayerDirty(p.id)
            ctx.SaveToCloud(p.id)
            Sys.SaveMarket()
        end
    end
end

--- 从 SYNC_REQUEST 的 PendingListings 处理上架（客户端权威模式）。
--- 幂等两层：
---   ① 缓存层：同一 clientId 在 LISTING_CACHE_TTL 内处理过 → 直接返回缓存结果
---   ② 挂单层：同一 clientId 已成功建单 → 返回原挂单 ID
---@param p ServerPlayer
---@param c Connection
---@param pl table  { ClientId, ItemId, Price, Quantity }
---@return boolean ok, string|nil reason, string|nil listingId
function Sys.HandleMarketSellFromSync(p, c, pl)
    local clientId = pl.ClientId
    local itemId = pl.ItemId

    -- 缓存命中：直接返回历史结果
    if clientId and clientId ~= "" then
        local cached = recentListingResults[clientId]
        if cached and (os.time() - cached.ts) < LISTING_CACHE_TTL then
            return cached.ok, cached.reason, cached.listingId
        end
    end

    local function record(ok, reason, listingId)
        if clientId and clientId ~= "" then
            recentListingResults[clientId] = {
                ok = ok, reason = reason, listingId = listingId, ts = os.time(),
            }
        end
        return ok, reason, listingId
    end

    if not itemId or itemId == "" then
        return record(false, "bad_item", nil)
    end

    -- 挂单层幂等：同一 clientId 已成功建单
    if clientId and clientId ~= "" then
        for _, l in pairs(marketListings) do
            if l.clientId == clientId and l.sellerId == p.id then
                return record(true, nil, l.id)
            end
        end
    end

    local price = math.floor(tonumber(pl.Price) or 0)
    if price < 1 then
        return record(false, "bad_price", nil)
    end
    -- 上限校验：防止 1e+23 这类溢出值进市场（客户端也可能被绕过）
    if price > Shared.C.MARKET_PRICE_MAX then
        return record(false, "bad_price", nil)
    end

    -- 🔴 上架格子上限（固定 12 格）。
    --
    -- 按 marketListings 里该卖家的挂单数判断：卖家离线时挂单仍在表里，
    -- 所以这条对在线 / 离线卖家同样有效。
    local maxSlots = Shared.C.MARKET_SLOT_MAX or 12
    local myCount = 0
    for _, l in pairs(marketListings) do
        if l.sellerId == p.id then myCount = myCount + 1 end
    end
    if myCount >= maxSlots then
        return record(false, "slot_full", nil)
    end

    -- 全服挂单总量上限：分页解决「传输爆包」，这条解决「内存/存储爆」。
    -- ⚠️ 与 MARKET_SLOT_MAX（单玩家上限）是两回事，不要混。
    local globalCount = 0
    for _ in pairs(marketListings) do globalCount = globalCount + 1 end
    if globalCount >= (Shared.C.MARKET_GLOBAL_MAX or 10000) then
        return record(false, "market_full", nil)
    end

    -- 优先用客户端上报的 Item 快照：
    -- 客户端为防重发已把物品从本地背包移除，重发时服务端背包里可能已找不到，
    -- 此时靠快照仍能正确建单（否则会误判 not_found 让玩家物品消失）。
    local item = pl.Item
    local idx = nil
    if not item then
        for i, it in ipairs(p.inventory) do
            if it.id == itemId then idx = i; item = it; break end
        end
        if not item then
            return record(false, "not_found", nil)
        end
    end

    -- 可堆叠物（碎片/精魄/令牌/召唤卷）：需要按 Quantity 裁剪
    -- ⚠️ 必须用 Data.IsStackable（单一事实来源）：曾因这里漏列召唤卷，
    --    导致快照路径不裁剪数量 —— 上架 10 张却挂出整堆 60 张（复制 bug）。
    local isStackable = Shared.Data.IsStackable(item)
    if idx then
        -- 来自背包：按原逻辑扣除
        if isStackable then
            local qty = math.floor(tonumber(pl.Quantity) or (item.count or 1))
            if qty <= 0 then qty = item.count or 1 end
            if (item.count or 1) < qty then
                return record(false, "bad_quantity", nil)
            end
            item.count = item.count - qty
            local listingItem = {}
            for k, v in pairs(item) do listingItem[k] = v end
            listingItem.count = qty
            if item.count <= 0 then table.remove(p.inventory, idx) end
            item = listingItem
        else
            table.remove(p.inventory, idx)
        end
    else
        -- 快照路径：可堆叠物按 Quantity 裁剪，装备原样建单
        if isStackable then
            local qty = math.floor(tonumber(pl.Quantity) or (item.count or 1))
            if qty <= 0 then qty = item.count or 1 end
            -- ⚠️ 复制一份再改：item 是 pl.Item 的引用，直接改会污染
            --    待重发的 pendingListing（重发时数量已被裁过，语义错乱）。
            local listingItem = {}
            for k, v in pairs(item) do listingItem[k] = v end
            listingItem.count = qty
            item = listingItem
        end
    end

    local lid = "L" .. nextListingId
    nextListingId = nextListingId + 1
    marketListings[lid] = {
        id        = lid,
        sellerId  = p.id,
        item      = item,
        price     = price,
        createdAt = os.time(),
        expiresAt = os.time() + 7 * 24 * 3600,
        clientId  = clientId,
    }

    ctx.MarkPlayerDirty(p.id)
    Sys.PushInventory(p)

    ctx.SaveToCloud(p.id)
    Sys.SaveMarket()

    return record(true, nil, lid)
end

function Sys.HandleMarketBuy(c, p, e)
    local l = marketListings[e["ListingId"]:GetString()]
    if not l then return end
    if l.sellerId == p.id then
        c:SendRemoteEvent(Shared.EVENTS.TOAST, true, Shared.ToVariantMap({ Text = "不能购买自己的商品" }))
        return
    end
    if p.gold < l.price then
        c:SendRemoteEvent(Shared.EVENTS.TOAST, true, Shared.ToVariantMap({ Text = "金币不足" }))
        return
    end

    p.gold = p.gold - l.price
    ctx.MarkPlayerDirty(p.id)

    -- 卖家离线也要结算：直接进卖家邮箱（原实现卖家离线时货款凭空消失）
    local fee = math.max(0, math.floor(l.price * Shared.C.MARKET_TAX_RATE))
    local proceeds = l.price - fee
    -- 累加到今日市场税池（用于钱庄利息，接口在 Server_Bank.lua）
    Bank.AddTax(fee)
    local seller = ctx.players[l.sellerId]
    if seller then
        seller.gold = seller.gold + proceeds
        Sys.AddMail(seller, "market_sale", {
            title = "售出：" .. (l.item.name or "装备"),
            gold  = proceeds,
            items = {},
        })
        Sys.NotifyMail(seller)
        Sys.PushInventory(seller, true)
        ctx.MarkPlayerDirty(seller.id)
    else
        -- 卖家不在线：读其存档 → 追加货款邮件 → 写回（原实现直接丢弃货款）
        Sys.SettleOfflineSeller(l, proceeds)
    end

    -- ⚠️ 深拷贝：挂单里的 item 是共享引用，直接塞给买家会让
    --    「买家的背包」和「市场挂单」指向同一张表，后续改任一方都会串味。
    --    并购入的**装备**自动上锁：防止误分解/误上架。
    --    ⚠️ 只对装备加锁 —— 蛋/材料/碎片等可堆叠物品加锁会在背包里显示锁图标，
    --       且它们本身不可分解，加锁无意义。
    local purchasedItem = {}
    for k, v in pairs(l.item) do purchasedItem[k] = v end
    if Shared.IsEquipment(purchasedItem) then
        purchasedItem.locked = true
    end

    Sys.AddMail(p, "market_purchase", {
        title = "购买：" .. (purchasedItem.name or "物品"),
        items = { purchasedItem },
    })
    Sys.NotifyMail(p)
    Sys.PushInventory(p, true)
    ctx.MarkPlayerDirty(p.id)

    marketListings[l.id] = nil

    -- 立即落盘，防止套现
    ctx.SaveToCloud(p.id)
    if seller then ctx.SaveToCloud(seller.id) end
    Sys.SaveMarket()
end

-- ============ 拍卖行分页 ============
-- 挂单全量存在服务端，客户端按页拉取（一页最多 MARKET_PAGE_SIZE 条）。
-- 筛选条件由客户端一并上报 —— 只在客户端过滤会导致分页错乱
-- （先本地筛掉一半再分页，页码与总数对不上）。
local MARKET_PAGE_SIZE = 100

--- 判断一条挂单是否命中筛选条件。
---@param l MarketListing
---@param p ServerPlayer
---@param f table { category, subCat, quality, tab }
---@return boolean
local function ListingMatches(l, p, f)
    if f.tab == "mysell" and l.sellerId ~= p.id then return false end

    local it = l.item or {}
    local cat = Shared.MarketCategoryOf(it)

    if f.category ~= "" and f.category ~= "all" and cat ~= f.category then
        return false
    end

    if f.subCat ~= "" then
        -- 召唤卷子分类 "scroll_<quality>"（在 consume 一级分类下）
        local scrollQ = f.subCat:match("^scroll_(.+)$")
        if scrollQ then
            if not Shared.IsSummonScroll(it) or it.scrollType ~= scrollQ then return false end
        else
            if cat == "equip"    and it.slot         ~= f.subCat then return false end
            if cat == "fragment" and it.fragmentType ~= f.subCat then return false end
            if cat == "spirit"   and it.spiritType   ~= f.subCat then return false end
            if cat == "token"    and it.tokenType    ~= f.subCat then return false end
            -- 宠物类二级：egg / material / pet（对应三种物品类型）
            if cat == "pet" then
                if f.subCat == "egg"      and not Shared.IsPetEgg(it)      then return false end
                if f.subCat == "material" and not Shared.IsPetMaterial(it) then return false end
                if f.subCat == "pet"      and not Shared.IsPetItem(it)     then return false end
            end
            -- 等级石类无二级分类（一级已足够）
            -- （无需额外筛选）
        end
    end

    if f.quality ~= "" and it.quality ~= f.quality then return false end
    return true
end

--- 按筛选条件分页下发挂单（OnMarketPage 与 OnMarket 的 list 分支共用）。
---@param p ServerPlayer
---@param c Connection
---@param f table { category, subCat, quality, tab }
---@param page integer 0-based
---@param pageSize integer|nil 省略则用 MARKET_PAGE_SIZE
function Sys.SendMarketPage(p, c, f, page, pageSize)
    page     = math.max(0, page or 0)
    pageSize = math.min(MARKET_PAGE_SIZE, math.max(1, pageSize or MARKET_PAGE_SIZE))

    -- 全量遍历筛选（marketListings 是 map，必须 pairs）
    -- ⚠️ myTotal 必须在筛选**之前**独立累加：它表示「我在售的挂单总数」，
    --    与当前 Tab/分类筛选无关。若放在筛选里，切分类时这个数字会跟着跳。
    local filtered = {}
    local myTotal = 0
    for _, l in pairs(marketListings) do
        if l.sellerId == p.id then myTotal = myTotal + 1 end
        if ListingMatches(l, p, f) then table.insert(filtered, l) end
    end

    -- 新上架的在前
    table.sort(filtered, function(a, b)
        return (a.createdAt or 0) > (b.createdAt or 0)
    end)

    local total      = #filtered
    local totalPages = math.max(1, math.ceil(total / pageSize))
    if page >= totalPages then page = totalPages - 1 end

    local startIdx = page * pageSize + 1
    local slice = {}
    for i = startIdx, math.min(startIdx + pageSize - 1, total) do
        table.insert(slice, filtered[i])
    end

    c:SendRemoteEvent(Shared.EVENTS.MARKET_PAGE_RESULT, true, Shared.ToVariantMap({
        Page       = page,
        Total      = total,
        TotalPages = totalPages,
        MyTotal    = myTotal,
        Listings   = cjson.encode(slice),
    }))
end

--- 客户端请求：拉取一页挂单（含筛选）。
function Sys.OnMarketPage(_, e)
    local p, c = ctx.PlayerOf(e)
    if not p then return end

    local f = {
        category = e["Category"] and e["Category"]:GetString() or "all",
        subCat   = e["SubCat"]   and e["SubCat"]:GetString()   or "",
        quality  = e["Quality"]  and e["Quality"]:GetString()  or "",
        tab      = e["Tab"]      and e["Tab"]:GetString()      or "buy",
    }
    local page     = math.max(0, e["Page"]:GetInt())
    local pageSize = e["PageSize"] and e["PageSize"]:GetInt() or nil

    Sys.SendMarketPage(p, c, f, page, pageSize)
end

-- ============ 邮件 ============
function Sys.AddMail(player, type_, payload)
    if not player then return end
    local id = player.nextMailId or 1
    player.nextMailId = id + 1
    table.insert(player.mails, 1, {
        id        = "M" .. id,
        type      = type_,
        title     = payload.title or "邮件",
        gold      = payload.gold or 0,
        items     = payload.items or {},
        createdAt = os.time(),
    })
    ctx.MarkPlayerDirty(player.id)
end

--- 发放新手礼包。
--- 幂等：starterGiftReceived 为 true 时跳过。
--- 新玩家（lastDailyGiftDate 为空）→ 各 24 小时在线/战斗时长 + 8 件装备
--- 老玩家（lastDailyGiftDate 有值）→ 只发 8 件装备
---@param p ServerPlayer
---@return boolean granted
function Sys.GrantStarterGift(p)
    if p.starterGiftReceived == true then return false end

    -- 判定是否新玩家：lastDailyGiftDate 从未写过 = 新玩家
    local isNewPlayer = (p.lastDailyGiftDate == nil or p.lastDailyGiftDate == "")

    -- 新玩家：直接给时长，不再发 24 张卡。
    -- ⚠️ 给的是「时长」不是「卡」：卡是消耗品（用一张加 30 分钟），
    --    24 张卡会堆在背包里占格子，还要玩家手动一张张点。
    --    直接补 24 小时，开局即用，语义也更清楚。
    local STARTER_TOKEN_HOURS = 24
    if isNewPlayer then
        p.onlineTokenMinutes = (p.onlineTokenMinutes or 0) + STARTER_TOKEN_HOURS * 60
    end

    -- 8 件基础装备：空槽位**直接穿上**，不再走邮件让玩家手动领。
    --
    -- ⚠️ 已有装备的槽位不能直接覆盖：那会让玩家攒的装备凭空消失
    --    （旧装备既不进背包也没提示）。这类槽位退回邮件，行为与改动前一致。
    --    新玩家 8 个槽全空 → 8 件全部直接穿上；老玩家通常已满 → 全走邮件。
    local items = Shared.GenStarterGear()
    local toMail = {}
    for _, item in ipairs(items) do
        local slot = item.slot
        if slot and p.equipment[slot] == nil then
            p.equipment[slot] = item
        else
            table.insert(toMail, item)
        end
    end

    -- 邮件只作为通知 / 兜底渠道：
    --   · 全部穿上 → 空邮件，仅告知「已穿戴」
    --   · 有没穿上的 → 那些装备放进邮件待领
    -- ⚠️ 标题在邮件列表里是单行渲染（maxLines = 1），保持紧凑。
    local equippedCount = #items - #toMail
    local title
    if #toMail > 0 then
        title = string.format("新手礼包：%d 件装备待领取", #toMail)
    else
        title = string.format("新手礼包：%d 件装备已穿戴", equippedCount)
    end
    Sys.AddMail(p, "starter_gift", {
        title = title,
        gold  = 0,
        items = toMail,
    })

    p.starterGiftReceived = true
    -- 兼容字段：lastDailyGiftDate 原为「上次领每日赠送的日期」，
    -- 每日赠送删除后，本字段改为「上次领新手礼包的日期」标记。
    -- 同时承担「是否为新玩家」判定：有值 = 之前领过东西的老玩家。
    -- 写入后，即使 starterGiftReceived 因云档异常丢失，也不会重复发卡。
    p.lastDailyGiftDate = Shared.TodayString()
    ctx.MarkPlayerDirty(p.id)
    return true
end

--- 每日礼包：每天发在线卡 1 张。
--- 幂等：靠 p.dailyGiftDate 判定（跨日才发）。
--- ⚠️ 只在上线时调用（存档读取完成之后），不做每秒检查。
--- 发放方式：进邮箱，由玩家到邮件面板自行领取（不再直接塞背包、不再弹顶部提示）。
---@param p ServerPlayer
---@return boolean granted, integer onlineCount
function Sys.GrantDailyGift(p)
    local today = Shared.TodayString()
    if p.dailyGiftDate == today then return false, 0 end

    p.dailyGiftDate = today

    -- 走邮箱：玩家在邮件面板「全部领取」时由 ClaimOneMail 发到背包
    local onlineDisp = Shared.TOKEN_TYPES["online"] or { icon = "🎟️", name = "在线卡" }
    Sys.AddMail(p, "daily_gift", {
        title = "每日礼包：在线卡 ×1",
        gold  = 0,
        items = {
            { type = "onlineToken", tokenType = "online", count = 1,
              icon = onlineDisp.icon, name = onlineDisp.name, quality = "normal" },
        },
    })

    ctx.MarkPlayerDirty(p.id)
    return true, 1
end

function Sys.NotifyMail(player)
    local info = Sys.FindConnectionByPlayerId(player.id)
    if info and info.connection then
        -- 汇总数字一起推：MailGoldTotal / MailItemTotal 客户端算不出来（要遍历求和），
        -- 只靠 Sys.PushInventory 顺带推是隐式耦合，让 Sys.NotifyMail 自包含更稳。
        local mg, mi = Sys.CalcMailTotals(player)
        info.connection:SendRemoteEvent(Shared.EVENTS.MAIL_UPDATE, true, Shared.ToVariantMap({
            Mails         = cjson.encode(player.mails),
            MailTotal     = #player.mails,
            MailGoldTotal = mg,
            MailItemTotal = mi,
        }))
    end
end

function Sys.FindConnectionByPlayerId(playerId)
    for _, info in pairs(ctx.connections) do
        if info.playerId == playerId then return info end
    end
    return nil
end

function Sys.OnMailClaim(_, e)
    local p, c = ctx.PlayerOf(e)
    if not p then return end

    local mailId = e["MailId"]:GetString()
    local claimedMails, claimedGold, claimedItems, keptItems = 0, 0, 0, 0

    if mailId == "__ALL__" then
        -- 一键领取：服务端一次处理，避免客户端发 N 个包 + N 次全量回包。
        -- 背包满的物品保留在原邮件里，不能整封删除（否则玩家资产消失）
        local i = 1
        while i <= #p.mails do
            local m = p.mails[i]
            local r = Sys.ClaimOneMail(p, m)
            claimedGold  = claimedGold  + r.gold
            claimedItems = claimedItems + r.claimedItems
            if #r.keptItems == 0 then
                table.remove(p.mails, i)
                claimedMails = claimedMails + 1
            else
                m.items = r.keptItems
                -- ⚠️ 金币已发过，必须清零：邮件因背包满而保留时，
                --    下次「一键领取」会再次进入本分支，不清零就会重复发金币。
                m.gold = 0
                keptItems = keptItems + #r.keptItems
                i = i + 1
            end
        end
    else
        for i, m in ipairs(p.mails) do
            if m.id == mailId then
                local r = Sys.ClaimOneMail(p, m)
                claimedGold  = claimedGold  + r.gold
                claimedItems = claimedItems + r.claimedItems
                if #r.keptItems == 0 then
                    table.remove(p.mails, i)
                    claimedMails = 1
                else
                    -- 还有物品没装下，邮件保留（已领的金币不重复发放）
                    m.items = r.keptItems
                    m.gold = 0
                    keptItems = #r.keptItems
                end
                break
            end
        end
    end

    Sys.NotifyMail(p)
    Sys.PushInventory(p, true)
    ctx.MarkPlayerDirty(p.id)
    ctx.SaveToCloud(p.id)

    -- 汇总回包：客户端用它弹一条「领取了 N 封 / 金币 +N / 物品 +N」的提示
    local mg, mi = Sys.CalcMailTotals(p)
    c:SendRemoteEvent(Shared.EVENTS.MAIL_CLAIM_RESULT, true, Shared.ToVariantMap({
        ClaimedMails  = claimedMails,
        ClaimedGold   = claimedGold,
        ClaimedItems  = claimedItems,
        KeptItems     = keptItems,
        MailGoldTotal = mg,
        MailItemTotal = mi,
    }))
end

--- 把一封邮件的奖励发放到玩家身上（不负责从邮件列表移除）。
--- 返回 { gold = 已发金币, claimedItems = 实际收下的件数, keptItems = 因背包满而留在邮件里的物品 }，
--- 调用方据此决定是否真的删除这封邮件。
---@param p ServerPlayer
---@param m table
---@return {gold: integer, claimedItems: integer, keptItems: table[]}
function Sys.ClaimOneMail(p, m)
    local result = { gold = 0, claimedItems = 0, keptItems = {} }
    if not m then return result end

    if (m.gold or 0) > 0 then
        p.gold = p.gold + m.gold
        result.gold = m.gold
    end

    local cap = Shared.C.MAX_INVENTORY
    for _, item in ipairs(m.items or {}) do
        if Shared.IsFragment(item) then
            Shared.AddFragmentsToInventory(p.inventory, item.fragmentType, item.count or 1)
            result.claimedItems = result.claimedItems + 1
        elseif Shared.IsSpirit(item) then
            -- 精魄：可堆叠，不受背包容量限制（堆叠上限 SPIRIT_STACK_MAX）
            Shared.AddSpiritsToInventory(p.inventory, item.spiritType, item.count or 1)
            result.claimedItems = result.claimedItems + 1
        elseif Shared.IsToken(item) then
            Shared.AddTokenToInventory(p.inventory, item.tokenType or "online", item.count or 1)
            result.claimedItems = result.claimedItems + 1
        elseif Shared.IsSummonScroll(item) then
            -- 召唤卷：可堆叠，不受背包容量限制
            Shared.AddSummonScrollToInventory(p.inventory, item.scrollType, item.count or 1)
            result.claimedItems = result.claimedItems + 1
        elseif Shared.IsPetEgg(item) then
            -- 宠物蛋：可堆叠，不受背包容量限制
            Shared.AddPetEggsToInventory(p.inventory, item.eggQuality, item.count or 1)
            result.claimedItems = result.claimedItems + 1
        elseif Shared.IsPetMaterial(item) then
            -- 宠物精粹：可堆叠，不受背包容量限制
            Shared.AddPetMaterialsToInventory(p.inventory, item.materialQuality, item.count or 1)
            result.claimedItems = result.claimedItems + 1
        else
            if #p.inventory < cap then
                table.insert(p.inventory, item)
                result.claimedItems = result.claimedItems + 1
            else
                -- 背包满：物品留在邮件里，等玩家腾出空间再领
                table.insert(result.keptItems, item)
            end
        end
    end
    return result
end

--- 全量背包/金币推送（邮件领取、广告发奖、市场成交后调用）
---@param p ServerPlayer
---@param force boolean|nil true = 带 Force 标记，客户端即使本地 dirty 也接受这份快照
function Sys.PushInventory(p, force)
    local info = Sys.FindConnectionByPlayerId(p.id)
    if not (info and info.connection) then return end
    local mg, mi = Sys.CalcMailTotals(p)

    -- ============ 服务端权威字段（不受门控）============
    local payload = {
        Mails         = cjson.encode(Sys.MailPageSlice(p, 0)),
        MailTotal     = #p.mails,
        MailGoldTotal = mg,
        MailItemTotal = mi,
        Force         = force and 1 or 0,
    }

    -- ============ 客户端权威字段（仅在数据可信时下发）============
    -- 🔴 读档失败时**不带**这些字段，客户端保持本地数据
    --    （与 SendAssignPlayer 同一套门控逻辑）。
    if p.__hasValidClientData then
        payload.Inventory          = cjson.encode(p.inventory)
        payload.Equipment          = cjson.encode(p.equipment)
        payload.Gold               = p.gold
        payload.Level              = p.level
        payload.BagPageCount       = p.bagPageCount
        payload.OnlineTokenMinutes = p.onlineTokenMinutes or 0
        -- 宠物系统：结构走 Shared 单一事实来源
        payload.Pets               = cjson.encode(
            Shared.IsPetDataValid(p.pets) and p.pets or Shared.NewPetData())
        payload.PetGacha           = cjson.encode(
            (type(p.petGacha) == "table" and type(p.petGacha.counters) == "table")
            and p.petGacha or Shared.NewPetGachaData())
        -- 等级石（客户端权威）
        payload.LevelStone             = cjson.encode(p.levelStone or {})
        payload.LevelStoneGiftReceived = p.levelStoneGiftReceived and 1 or 0
    end

    info.connection:SendRemoteEvent(Shared.EVENTS.INV_SYNC, true,
        Shared.ToVariantMap(payload))
end

-- ============ 邮件分页 ============
--- 取第 page 页邮件（每页 50 封）
---@param p ServerPlayer
---@param page integer 从 0 开始
---@return table[]
function Sys.MailPageSlice(p, page)
    local size = 50
    local mails = p.mails or {}
    local startIdx = page * size + 1
    local endIdx = math.min(startIdx + size - 1, #mails)
    local out = {}
    for i = startIdx, endIdx do
        out[#out + 1] = mails[i]
    end
    return out
end

--- 客户端翻页请求
function Sys.OnRequestMailPage(_, e)
    local p, c = ctx.PlayerOf(e)
    if not p then return end

    local page = e["Page"] and e["Page"]:GetInt() or 0
    if page < 0 then page = 0 end
    local totalPages = math.max(1, math.ceil(#(p.mails or {}) / 50))
    if page >= totalPages then page = totalPages - 1 end
    local mg, mi = Sys.CalcMailTotals(p)
    c:SendRemoteEvent(Shared.EVENTS.MAIL_PAGE_RESULT, true, Shared.ToVariantMap({
        Page          = page,
        Total         = #(p.mails or {}),
        MailGoldTotal = mg,
        MailItemTotal = mi,
        Mails         = cjson.encode(Sys.MailPageSlice(p, page)),
    }))
end

-- ============ 背包溢出转邮件 ============
--- 拾取时背包已满，装备转为邮件发放（避免掉落凭空消失）
function Sys.OnBagOverflowToMail(_, e)
    local p, c = ctx.PlayerOf(e)
    if not p then return end

    local item = Shared.SafeDecode(e["ItemJson"]:GetString())
    if type(item) ~= "table" or not item.id then return end
    -- 只接受装备（碎片/精魄/令牌/召唤卷可堆叠，不存在背包满的问题，客户端也不该发）
    if Shared.Data.IsStackable(item) then return end
    if type(item.slot) ~= "string" or type(item.quality) ~= "string" then return end

    Sys.AddMail(p, "bag_overflow", {
        title = "背包已满退回：" .. (item.name or "装备"),
        items = { item },
    })
    Sys.NotifyMail(p)
    ctx.MarkPlayerDirty(p.id)
end


--- 过期挂单退回离线卖家的存档
---@param listing MarketListing
function Sys.ExpireToOfflineMail(listing)
    local pid = listing.sellerId
    local title = "挂单过期退回：" .. ((listing.item and listing.item.name) or "装备")
    Sys.RunOfflineSaveTask(pid, function(done)
        ctx.LoadSaveAsync(pid, function(save)
            local base = Shared.NewPlayerSave()

            local mails = (type(save) == "table" and save.mails) or {}
            local nextId = (type(save) == "table" and save.nextMailId) or base.nextMailId
            table.insert(mails, 1, {
                id        = "M" .. nextId,
                type      = "market_expire",
                title     = title,
                gold      = 0,
                items     = { listing.item },
                createdAt = os.time(),
            })

            -- ⚠️ 只覆盖「本次操作真正要改的字段」，其余原样透传
            --    （含 settings / bankDeposits / saveVersion，以及以后新增的任何字段）。
            local offline = BuildOfflineSave(save, {
                nextMailId = nextId + 1,
                mails      = mails,
            })
            Sys.WriteOfflineSave(pid, offline)
            print("[Server] 挂单退回，物品已退回 " .. pid .. " 的存档：" .. title)
            done()
        end)
    end)
end

--- 给「不在线玩家」写存档（例如离线卖家收到货款）
---@param pid string
---@param save table
function Sys.WriteOfflineSave(pid, save)
    ctx.PushCloud(pid, cjson.encode(save))
end

--- 离线卖家结算：把货款作为邮件并入其存档
---@param listing MarketListing
---@param proceeds integer
function Sys.SettleOfflineSeller(listing, proceeds)
    local pid = listing.sellerId
    Sys.RunOfflineSaveTask(pid, function(done)
        ctx.LoadSaveAsync(pid, function(save)
            local base = Shared.NewPlayerSave()

            local mails = (type(save) == "table" and save.mails) or {}
            local nextId = (type(save) == "table" and save.nextMailId) or base.nextMailId
            table.insert(mails, 1, {
                id        = "M" .. nextId,
                type      = "market_sale",
                title     = "售出：" .. (listing.item.name or "装备"),
                gold      = proceeds,
                items     = {},
                createdAt = os.time(),
            })

            -- ⚠️ 只覆盖「本次操作真正要改的字段」，其余原样透传
            --    （含 settings / bankDeposits / saveVersion，以及以后新增的任何字段）。
            local offline = BuildOfflineSave(save, {
                gold       = (type(save) == "table" and save.gold or base.gold) + proceeds,
                nextMailId = nextId + 1,
                mails      = mails,
            })
            Sys.WriteOfflineSave(pid, offline)
            print("[Server] 卖家 " .. pid .. " 离线，货款 " .. proceeds .. " 已写入其存档")
            done()
        end)
    end)
end

-- ============ 升级 / 降级 ============
--- 升级请求：需要检查金币 + 段位门槛
-- 🔴 升级已改为**客户端本地权威**（2026-10-04）：
--    突破判定（全身 8 部位毕业 + 金币）与扣费全部在客户端完成，
--    不再发 LEVEL_UP 请求，服务端也不做门槛校验。
--    等级靠客户端 Data.MarkDirty("level") 被动同步（见 Server.lua 的 `e["Level"]`）。
--
-- ⚠️ 本函数保留为空壳，是为了不改动 Start() 里已注册的事件订阅
--    （删订阅需要同步改 SubscribeToEvent 列表，收益不大）。
--    若确认 LEVEL_UP 事件不再使用，可连同 Shared.EVENTS.LEVEL_UP 一起清理。
function Sys.OnLevelUp(_, e)
    -- 空实现：升级不再走服务端
end

--- 等级石降级：已改为客户端本地权威，服务端不再处理。
--- 保留此空壳只为不破坏已有的事件订阅（见 Sys.RegisterEvents）。
function Sys.OnLevelDown(_, e)
    -- 空实现
end

-- ---------- 拍卖行持久化 ----------
function Sys.SaveMarket()
    -- 🔴 云端挂单还没读回来之前不落盘：
    --    否则会把空表写回云端，全服挂单被永久抹掉。
    --    （SaveMarket 在买/卖/下架/过期时都会被调用，启动早期也可能触发。）
    if not marketLoaded_ then
        print("[Server] 拍卖行尚未从云端读回，跳过本次落盘（防清空全服挂单）")
        return
    end
    local list = {}
    for _, l in pairs(marketListings) do table.insert(list, l) end
    serverCloud:Set(0, MARKET_KEY, cjson.encode(list), {
        ok = function() end,
        error = function(code, reason)
            print("[Server] 拍卖行存档失败 code=" .. tostring(code)
                .. " reason=" .. tostring(reason))
        end,
    })
end

--- 把云变量回调里的原始值解析成挂单数组
---@param raw any
---@return table|nil
local function DecodeListingList(raw)
    if type(raw) == "string" then return Shared.SafeDecode(raw) end
    if type(raw) == "table" then return raw end
    return nil
end

function Sys.LoadMarket()
    -- 只读 V3，失败重试 3 次
    local retries = 0
    local MAX_RETRIES = 3

    local function TryRead()
        serverCloud:Get(0, MARKET_KEY, {
            ok = function(scores)
                -- 读到空表也算「已确认」：云端确实没有挂单
                marketLoaded_ = true
                local list = DecodeListingList(scores and scores[MARKET_KEY])
                if not list then return end
                local n = 0
                local now = os.time()
                for _, l in ipairs(list) do
                    if l.id then
                        -- 兼容旧存档：没有 expiresAt 的按 createdAt 补一个
                        if not l.expiresAt then
                            local base = l.createdAt or now
                            l.expiresAt = base + 7 * 24 * 3600
                        end
                        -- 已过期的挂单不再载入（其物品由离线邮件流程处理）
                        if l.expiresAt > now then
                            marketListings[l.id] = l
                            local num = tonumber((l.id):sub(2)) or 0
                            if num >= nextListingId then nextListingId = num + 1 end
                            n = n + 1
                        end
                    end
                end
                print("[Server] 拍卖行已恢复 " .. n .. " 条挂单")
            end,
            error = function(code, reason)
                retries = retries + 1
                print("[Server] 拍卖行读取失败 code=" .. tostring(code)
                    .. " reason=" .. tostring(reason)
                    .. " (" .. retries .. "/" .. MAX_RETRIES .. ")")
                if retries < MAX_RETRIES then
                    TryRead()
                else
                    -- 重试 3 次仍失败 → 保持 marketLoaded_ = false（不放开落盘）
                    print("[Server] ⚠️ 拍卖行读取连续失败 " .. MAX_RETRIES
                        .. " 次，本次会话不落盘挂单（防清空）")
                end
            end,
        })
    end

    TryRead()
end

--- 加载钱庄全部持久化状态（Server.Start 里调用一次）。
function Sys.LoadBankState()
    Bank.LoadBankPool()
    Bank.LoadBankIndex()
    Bank.LoadBankSnapshot()
end

return Sys
