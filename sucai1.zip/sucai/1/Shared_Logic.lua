-- ============================================================
-- Shared_Logic.lua：Shared 的纯函数层（被 Shared.lua 末尾 require 进来）
--
-- ⚠️ 本文件**不要** require("Shared")：Shared.lua 在文件末尾 require 本文件，
--    反过来 require 会形成循环依赖。Shared 是全局表（Shared.lua 里无 local 声明），
--    这里直接访问即可。
-- 内容：工具函数 / 费用 / 装备生成 / 掉落 / 消耗 / 重铸 / 存档 / 配置
-- Data / Notify 模块见 Shared_Data.lua（本文件末尾 require 加载）
-- ============================================================

-- ============ 配置下发 ============
--- 服务端打包给客户端的所有配置
--- 客户端收到后用 Shared.ApplyServerConfig 覆盖本地表，
--- 保证「品质权重 / 技能池 / 强化率」等数值永远以服务端为准。
---@return table
function Shared.BuildConfigPayload()
    return {
        Constants            = Shared.C,
        Skills               = Shared.SKILL_DEFS,
        QualityColors        = Shared.QUALITY_COLORS,
        QualityRank          = Shared.QUALITY_RANK,
        QualityNames         = Shared.QUALITY_NAMES,
        QualityMaxEnhance    = Shared.QUALITY_MAX_ENHANCE,
        QualityWear          = Shared.QUALITY_WEAR,
        QualityMult          = Shared.QUALITY_MULT,
        ModDefs              = Shared.MOD_DEFS,
        ModBaseMax           = Shared.MOD_BASE_MAX,
        SlotSpec             = Shared.SLOT_SPEC,
        FragmentDisplay      = Shared.FRAGMENT_DISPLAY,
        Slots                = Shared.SLOTS,
        EnhanceRates         = Shared.ENHANCE_RATES,
        QualityBonusMax      = Shared.QUALITY_BONUS_MAX,
        QualityMaxReforge    = Shared.C.QUALITY_MAX_REFORGE,
        QualityDurability    = Shared.C.QUALITY_DURABILITY,
        ReforgeBaseChance    = Shared.C.REFORGE_BASE_CHANCE,
        SpiritDisplay        = Shared.SPIRIT_DISPLAY,
        TierMaxLevel         = Shared.C.TIER_MAX_LEVEL,
        BossStats            = Shared.C.BOSS_STATS,
    }
end

-- ============ 升级费用 ============
--- 等级石升级费用（从 currentLevel 升到 currentLevel + 1）。
---
--- 规则：基础 1000 金币起，每级 +1000。
---       每 9→10 / 19→20 / 29→30 / 39→40 时，该次费用 ×3，
---       之后从翻倍值继续 +1000。
---@param currentLevel integer
---@return integer
function Shared.GetLevelUpCost(currentLevel)
    local counter = 0
    local lv = math.max(1, math.floor(currentLevel or 1))
    for i = 1, lv do
        counter = counter + 1000
        if i == 9 or i == 19 or i == 29 or i == 39 then
            counter = counter * 3
        end
    end
    return counter
end

--- ⚠️ 已废弃：等级石系统上线后，降级不再消耗金币。
--- 保留此函数供未来可能回滚。
---@param currentLevel integer
---@return integer
function Shared.GetLevelDownCost(currentLevel)
    return (currentLevel or 1) * 10
end

-- ============ 工具 ============
function Shared.Clamp(v, lo, hi)
    if v < lo then return lo end
    if v > hi then return hi end
    return v
end

-- ============ 费用 / 消耗（统一按品质档位算，两端共用）============

--- 鉴定费用（金币）
---@param quality string
---@return integer
function Shared.GetIdentifyCost(quality)
    return ((Shared.QUALITY_RANK[quality] or 0) + 1) * 2
end

--- 修理费用（每点耐久）
---@param quality string
---@return integer
function Shared.GetRepairCostPerDurability(quality)
    return (Shared.QUALITY_RANK[quality] or 0) + 1
end

--- 死亡耐久损失（每件装备）
---@param quality string
---@return integer
function Shared.GetDeathDurabilityLoss(quality)
    return (Shared.QUALITY_RANK[quality] or 0) + 1
end

--- 分解得到金币（已鉴定装备适用）
---@param quality string
---@return integer
function Shared.GetDecomposeGold(quality)
    local rank = Shared.QUALITY_RANK[quality] or 0
    return math.random(1, 2 + rank * 2)
end

--- 强化金币费用
---@param quality string
---@return integer
function Shared.GetEnhanceGoldCost(quality)
    return (Shared.QUALITY_RANK[quality] or 0) + 1
end

--- 锻造金币费用
--- normal: 25, magic: 200, rare: 800, legendary: 3000, mythic: 12000
---@param quality string
---@return integer
function Shared.GetForgeGoldCost(quality)
    local map = { normal = 25, magic = 200, rare = 800, legendary = 3000, mythic = 12000 }
    return map[quality] or 25
end

--- 重铸金币费用
--- normal: 5, magic: 50, rare: 200, legendary: 800, mythic: 3000
---@param quality string
---@return integer
function Shared.GetReforgeGoldCost(quality)
    local map = { normal = 5, magic = 50, rare = 200, legendary = 800, mythic = 3000 }
    return map[quality] or 5
end

--- 怪物等级：按距离分带（已砍半：每级占 25 米）
--- 段位紧贴、无缓冲区：
--- normal: 0~225 (Lv1~9), magic: 225~475, rare: 475~725,
--- legendary: 725~975, mythic: 975~1225, 1225+ 封顶 Lv49
---@param x number
---@param z number
---@return integer 等级（连续覆盖全距离，不再返回 nil）
function Shared.MonsterLevelOf(x, z)
    local dist = math.sqrt(x * x + z * z)
    local bandW = Shared.C.MONSTER_BAND_WIDTH

    -- 段位紧贴，无缓冲区（已砍半：每段 250 米）
    ---@type integer[][]
    local tiers = {
        { 0,    1,  9  },  -- normal: 0~225
        { 225,  10, 10 },  -- magic: 225~475
        { 475,  20, 10 },  -- rare: 475~725
        { 725,  30, 10 },  -- legendary: 725~975
        { 975,  40, 10 },  -- mythic: 975~1225
    }

    for _, t in ipairs(tiers) do
        local startDist = t[1]
        local startLv   = t[2]
        local lvCount   = t[3]
        local tierSpan = bandW * lvCount
        local tierEnd = startDist + tierSpan

        if dist >= startDist and dist < tierEnd then
            local lvOffset = math.floor((dist - startDist) / bandW)
            ---@type integer
            local lv = math.min(startLv + lvOffset, startLv + lvCount - 1)
            return lv
        end
    end

    -- 超过 mythic 段末（1225+），封顶 Lv49
    if dist >= 1225 then return Shared.C.MONSTER_MAX_LEVEL end
    return 1
end

--- 某等级区域刷新共享 Boss 所需的击杀小怪数。
---
--- 按段位递增：lv1~9 → 100，lv10~19 → 200，lv20~29 → 300，
--- lv30~39 → 400，lv40~49 → 500。
--- 越高级的区域，攒出 Boss 的代价越大（那里的掉落和奖励也更好）。
---@param monsterLevel integer|nil
---@return integer
function Shared.BossKillThreshold(monsterLevel)
    local lv = math.max(1, math.floor(monsterLevel or 1))
    local tier = math.floor(lv / 10)              -- lv1~9 → 0, lv10~19 → 1, ...
    return Shared.C.KILL_THRESHOLD_PER_TIER * (tier + 1)
end

--- 某坐标所在区域的品质（召唤卷区域校验用）。
--- 缓冲区内返回 nil —— 该处不刷怪，不允许召唤。
---@param x number
---@param z number
---@return string|nil
function Shared.ZoneQualityAt(x, z)
    local lv = Shared.MonsterLevelOf(x, z)
    if not lv then return nil end
    return Shared.QualityOfMonsterLevel(lv)
end

--- 怪物等级对应的掉落品质
---@param monsterLevel integer
---@return string
function Shared.QualityOfMonsterLevel(monsterLevel)
    local lv = monsterLevel or 1
    if lv >= 40 then return "mythic"
    elseif lv >= 30 then return "legendary"
    elseif lv >= 20 then return "rare"
    elseif lv >= 10 then return "magic"
    else return "normal" end
end

--- 是否已上锁（上锁物品：不可分解 / 不可上架）
---@param item table|nil
---@return boolean
function Shared.IsLocked(item)
    return item ~= nil and item.locked == true
end

--- 秒数 → "HH:MM:SS"。
--- 放在 Shared 而非 UI，是为了让 HUD 与 Panels 都能直接用，
--- 避免两者互相 require（UI.lua 拆分后 HUD/Panels 是独立文件）。
---@param seconds number|nil
---@return string
function Shared.FormatTime(seconds)
    seconds = math.max(0, math.floor(seconds or 0))
    return string.format("%02d:%02d:%02d",
        math.floor(seconds / 3600),
        math.floor(seconds % 3600 / 60),
        seconds % 60)
end

function Shared.Dist2D(x1, z1, x2, z2)
    local dx, dz = x1 - x2, z1 - z2
    return math.sqrt(dx * dx + dz * dz)
end

function Shared.UUID()
    local t = {}
    for i = 1, 9 do t[i] = string.char(math.random(97, 122)) end
    return table.concat(t)
end

---@param hex string|nil
---@return Color
function Shared.HexColor(hex)
    if type(hex) ~= "string" then return Color(1, 1, 1) end
    if hex:sub(1, 1) == "#" then hex = hex:sub(2) end
    local r = (tonumber(hex:sub(1, 2), 16) or 255) / 255
    local g = (tonumber(hex:sub(3, 4), 16) or 255) / 255
    local b = (tonumber(hex:sub(5, 6), 16) or 255) / 255
    return Color(r, g, b)
end

--- 把普通 Lua 表转成 VariantMap，供 SendRemoteEvent 使用。
--- ⚠️ SendRemoteEvent 的 eventData 形参类型是 VariantMap，不是普通 table。
---    直接传 table 虽然运行时不报错（tolua 会尝试转换），但值类型不可控，
---    显式用 Variant() 包一层才能保证 int/float/string 在两端一致。
---@param tbl table<string, any>
---@return VariantMap
function Shared.ToVariantMap(tbl)
    local vm = VariantMap()
    for k, v in pairs(tbl) do
        vm[k] = Variant(v)
    end
    return vm
end

--- 把 "#rrggbb" 转成 urhox-libs/UI 需要的 {r,g,b,a} 表
--- ⚠️ 返回类型必须是「记录」而非 integer[]：库的 RGBAColor 是
---    {[1]:number,[2]:number,[3]:number,[4]:number?}，变长数组不被视为兼容。
---@param hex string|nil
---@param alpha? integer
---@return {[1]: integer, [2]: integer, [3]: integer, [4]: integer}
function Shared.HexRGB(hex, alpha)
    alpha = alpha or 255
    if type(hex) ~= "string" then return { 255, 255, 255, alpha } end
    if hex:sub(1, 1) == "#" then hex = hex:sub(2) end
    return {
        tonumber(hex:sub(1, 2), 16) or 255,
        tonumber(hex:sub(3, 4), 16) or 255,
        tonumber(hex:sub(5, 6), 16) or 255,
        alpha,
    }
end

--- 物品的「类型判别」只需 type 字段；用最小接口而非 table，
--- 否则 it.type 会被推断成 unknown，函数返回值也跟着变成 unknown。
---@class SharedItemLike
---@field type string|nil

---@param it SharedItemLike|nil
---@return boolean
function Shared.IsFragment(it) return it ~= nil and it.type == "fragment" end
---@param it SharedItemLike|nil
---@return boolean
function Shared.IsSpirit(it) return it ~= nil and it.type == "spirit" end
---@param it SharedItemLike|nil
---@return boolean
function Shared.IsToken(it)
    -- "battleToken" 是已删除的战斗卡的旧存档类型，保留识别是为了让老档里的
    -- 存量战斗卡仍能被正常渲染/出售。新增物品只会是 "onlineToken"。
    return it ~= nil and (it.type == "onlineToken" or it.type == "battleToken")
end

---@param it SharedItemLike|nil
---@return boolean
function Shared.IsSummonScroll(it) return it ~= nil and it.type == "summonScroll" end

---@param it SharedItemLike|nil
---@return boolean
function Shared.IsPetEgg(it) return it ~= nil and it.type == "petEgg" end

---@param it SharedItemLike|nil
---@return boolean
function Shared.IsPetMaterial(it) return it ~= nil and it.type == "petMaterial" end

---@param it SharedItemLike|nil
---@return boolean
function Shared.IsPetItem(it) return it ~= nil and it.type == "petItem" end

---@param it SharedItemLike|nil
---@return boolean
function Shared.IsLevelStone(it) return it ~= nil and it.type == "levelStone" end

--- 宠物数据的空结构。
--- 🔴 单一事实来源：NewPlayerSave / 客户端默认档 / 结构校验 / 服务端默认档
---    全部走这里，避免「某处漏了子字段」导致 UI 读 pets.equipped 崩溃。
---@return table
function Shared.NewPetData()
    return {
        equipped = {
            weapon = nil, helmet = nil, chest = nil, gloves = nil,
            boots = nil, ring = nil, necklace = nil, belt = nil,
        },
        pool = {},
    }
end

--- 抽卡保底计数器的空结构。
---@return table
function Shared.NewPetGachaData()
    return {
        counters = { normal = 0, magic = 0, rare = 0, legendary = 0, mythic = 0 },
    }
end

--- 天赋树的空结构。
--- 🔴 单一事实来源：NewPlayerSave / 客户端默认档 / 结构校验 / 服务端默认档
---    全部走这里，避免「某处漏了子字段」导致 UI 读 bdTree.nodes 崩溃。
---@return table
function Shared.NewBDTree()
    return {
        nodes = {},   -- { [nodeId] = true } 已点节点集合
        cores = {},   -- { [dir] = { [slotIdx] = coreId } } 各页已选核心
    }
end

--- 校验天赋树结构是否完整。
--- ⚠️ cores 允许为 nil（老存档），读取时兜底。
---@param tree any
---@return boolean
function Shared.IsBDTreeValid(tree)
    if type(tree) ~= "table" then return false end
    if type(tree.nodes) ~= "table" then return false end
    if tree.cores ~= nil and type(tree.cores) ~= "table" then return false end
    return true
end

--- 校验宠物数据结构是否完整（含 equipped 与 pool 子表）。
--- ⚠️ 用途：服务端可能下发空表 `{}`（旧版默认档缺字段 → `p.pets or {}` 编码），
---    空表是真值，直接用会覆盖掉本地默认结构，之后 UI 读 pets.equipped 崩溃。
---@param pets any
---@return boolean
function Shared.IsPetDataValid(pets)
    return type(pets) == "table"
        and type(pets.equipped) == "table"
        and type(pets.pool) == "table"
end

---@param it SharedItemLike|nil
---@return boolean
function Shared.IsEquipment(it) return it ~= nil and it.type == nil end

-- ============ 召唤卷堆叠 ============
---@param inventory table[]
---@param scrollType string 品质 key
---@param count integer
function Shared.AddSummonScrollToInventory(inventory, scrollType, count)
    local remaining = count
    for _, it in ipairs(inventory) do
        if Shared.IsSummonScroll(it) and it.scrollType == scrollType then
            local add = math.min(Shared.C.SUMMON_SCROLL_STACK_MAX - (it.count or 1), remaining)
            it.count = (it.count or 1) + add
            remaining = remaining - add
            if remaining <= 0 then return end
        end
    end
    while remaining > 0 do
        local add = math.min(Shared.C.SUMMON_SCROLL_STACK_MAX, remaining)
        local disp = Shared.SUMMON_SCROLL[scrollType] or { name = "召唤卷", icon = "📜" }
        table.insert(inventory, {
            id = "scr_" .. Shared.UUID(),
            type = "summonScroll",
            scrollType = scrollType,
            count = add,
            icon = disp.icon,
            name = disp.name,
            quality = scrollType,
        })
        remaining = remaining - add
    end
end

---@param inventory table[]
---@param scrollType string
---@return integer
function Shared.CountSummonScrollsInInventory(inventory, scrollType)
    local total = 0
    for _, it in ipairs(inventory) do
        if Shared.IsSummonScroll(it) and it.scrollType == scrollType then
            total = total + (it.count or 1)
        end
    end
    return total
end

---@param inventory table[]
---@param scrollType string
---@param count integer
---@return boolean
function Shared.RemoveSummonScrollFromInventory(inventory, scrollType, count)
    local total = Shared.CountSummonScrollsInInventory(inventory, scrollType)
    if total < count then return false end
    local need = count
    for i = #inventory, 1, -1 do
        local it = inventory[i]
        if Shared.IsSummonScroll(it) and it.scrollType == scrollType then
            local take = math.min(it.count or 1, need)
            it.count = (it.count or 1) - take
            need = need - take
            if it.count <= 0 then table.remove(inventory, i) end
            if need <= 0 then break end
        end
    end
    return true
end

function Shared.TodayString()
    -- 北京时间日期字符串
    local t = os.time() + 8 * 3600
    return os.date("!%Y-%m-%d", t)
end

-- ============ 技能生成 ============
---@param quality string
---@return table<string, integer>
function Shared.GenSkillsForge(quality)
    local skills = {}
    local maxTotal = Shared.SKILL_MAX_BY_QUALITY[quality] or 6
    for _ = 1, maxTotal do
        if math.random() < Shared.C.SKILL_FORGE_CHANCE then
            local sid = Shared.SKILL_IDS[math.random(#Shared.SKILL_IDS)]
            skills[sid] = (skills[sid] or 0) + 1
        end
    end
    return skills
end

-- ============ 装备生成 ============
---@param monsterLevel integer
---@return table
function Shared.GenerateItem(monsterLevel)
    -- 品质严格按怪物段位
    local q = Shared.QualityOfMonsterLevel(monsterLevel)
    local slot = Shared.SLOT_LIST[math.random(#Shared.SLOT_LIST)]
    local t = Shared.SLOTS[slot]

    -- 掉落装备：按品质独立 roll 是否给技能/属性
    local hasSkill, hasAttr = Shared.RollDropSkillAttr(q)

    -- 基础词条（必带）
    local specList = Shared.SLOT_SPEC[slot] or {}
    local bonuses = {}
    for _, spec in ipairs(specList) do
        local mult = Shared.QUALITY_MULT[q] or 1.0
        local v = math.random() * spec[2] * mult
        if v < 1 and Shared.MOD_DEFS[spec[1]] and Shared.MOD_DEFS[spec[1]].type ~= "percent" then v = 1 end
        table.insert(bonuses, { modId = spec[1], value = v })
    end

    -- 🔴 属性与技能**各自独立上限**，互不占额度（基础词条不计入）。
    local maxAttr = Shared.MaxAttrAffixes(q)

    -- 属性词条（命中才给）
    if hasAttr then
        local mult = Shared.QUALITY_MULT[q] or 1.0
        local randCount = math.random(1, maxAttr)
        for _ = 1, randCount do
            local mid = Shared.MOD_IDS[math.random(#Shared.MOD_IDS)]
            local baseMax = Shared.MOD_BASE_MAX[mid]
            local v = math.random() * baseMax * mult
            local def = Shared.MOD_DEFS[mid]
            if def and def.type == "percent" then
                if v < 0.0001 then v = 0.0001 end
            else
                if v < 1 then v = 1 end
            end
            table.insert(bonuses, { modId = mid, value = v })
        end
    end

    -- 技能词条（命中才给）
    local skills = {}
    if hasSkill then
        local sid = Shared.SKILL_IDS[math.random(#Shared.SKILL_IDS)]
        skills[sid] = 1
    end

    local maxDur = Shared.C.QUALITY_DURABILITY[q] or 1000

    return {
        id            = Shared.UUID(),
        slot          = slot,
        slotName      = t.name,
        icon          = t.icon,
        quality       = q,
        qualityName   = Shared.QUALITY_NAMES[q],
        -- itemLevel = 怪物等级
        itemLevel     = monsterLevel,
        name          = Shared.QUALITY_NAMES[q] .. " " .. t.name,
        bonuses       = bonuses,
        skills        = skills,
        identified    = false,
        forged        = false,
        requiredLevel = Shared.QUALITY_WEAR[q],
        enhanceLevel  = 0,
        reforgeLevel  = 0,
        maxEnhance    = Shared.QUALITY_MAX_ENHANCE[q] or 20,
        durability    = maxDur,
        maxDurability = maxDur,
    }
end

-- ============ 技能/属性词条投放概率 ============
--- 掉落装备时，是否给技能词条和属性词条（各 50% 独立概率，每品质递减 20%）
---@param quality string
---@return boolean hasSkill, boolean hasAttr
function Shared.RollDropSkillAttr(quality)
    local idx = Shared.QUALITY_RANK[quality] or 0
    local chance = 0.5 * (0.8 ^ idx)
    return math.random() < chance, math.random() < chance
end

--- 锻造装备时，是否给技能词条和属性词条（100% 独立概率，每品质递减 20%）
---@param quality string
---@return boolean hasSkill, boolean hasAttr
function Shared.RollForgeSkillAttr(quality)
    local idx = Shared.QUALITY_RANK[quality] or 0
    local chance = 1.0 * (0.8 ^ idx)
    return math.random() < chance, math.random() < chance
end

-- ============ 掉落 ============
--- 掉落：金币（60% 概率，范围按段位）+ 装备（掉率按段位递减）+ 精魄（概率按段位）
---@param monsterLevel integer
---@return table[] drops, integer gold, string[] spirits
function Shared.RollDrops(monsterLevel)
    local drops, gold = {}, 0
    local spirits = {}
    local lv = monsterLevel or 1
    local q = Shared.QualityOfMonsterLevel(lv)

    -- 金币：60% 概率掉落，范围按段位 2 倍递增
    if math.random() < 0.60 then
        local goldMap = {
            normal = {1, 3}, magic = {2, 6}, rare = {4, 12},
            legendary = {8, 24}, mythic = {16, 48},
        }
        local range = goldMap[q] or {1, 3}
        gold = math.random(range[1], range[2])
    end

    -- 装备：按段位递减 50% / 45% / 40% / 35% / 30%
    local equipChance = ({
        normal = 0.50, magic = 0.45, rare = 0.40,
        legendary = 0.35, mythic = 0.30,
    })[q] or 0.50
    if math.random() < equipChance then
        table.insert(drops, Shared.GenerateItem(lv))
    end

    -- 精魄：按段位概率
    local spiritChance = Shared.C.SPIRIT_DROP_CHANCE[q] or 0
    if math.random() < spiritChance then
        table.insert(spirits, q)  -- 只带品质，由 Client 决定掉几个
    end

    return drops, gold, spirits
end

-- ============ 碎片堆叠 ============
---@param inventory table[]
---@param fragmentType string
---@param count integer
function Shared.AddFragmentsToInventory(inventory, fragmentType, count)
    local remaining = count
    for _, it in ipairs(inventory) do
        if Shared.IsFragment(it) and it.fragmentType == fragmentType then
            local add = math.min(Shared.C.FRAGMENT_STACK_MAX - it.count, remaining)
            it.count = it.count + add
            remaining = remaining - add
            if remaining <= 0 then return end
        end
    end
    while remaining > 0 do
        local add = math.min(Shared.C.FRAGMENT_STACK_MAX, remaining)
        local disp = Shared.FRAGMENT_DISPLAY[fragmentType] or { name = fragmentType, icon = "⬜" }
        table.insert(inventory, {
            id = "frag_" .. Shared.UUID(),
            type = "fragment",
            fragmentType = fragmentType,
            count = add,
            icon = disp.icon,
            name = disp.name,
            quality = fragmentType,
        })
        remaining = remaining - add
    end
end

---@param inventory table[]
---@param fragmentType string
---@return integer
function Shared.CountFragmentsInInventory(inventory, fragmentType)
    local total = 0
    for _, it in ipairs(inventory) do
        if Shared.IsFragment(it) and it.fragmentType == fragmentType then
            total = total + it.count
        end
    end
    return total
end

---@param inventory table[]
---@param fragmentType string
---@param count integer
---@return boolean
function Shared.RemoveFragmentsFromInventory(inventory, fragmentType, count)
    local total = Shared.CountFragmentsInInventory(inventory, fragmentType)
    if total < count then return false end
    local need = count
    for i = #inventory, 1, -1 do
        local it = inventory[i]
        if Shared.IsFragment(it) and it.fragmentType == fragmentType then
            local take = math.min(it.count, need)
            it.count = it.count - take
            need = need - take
            if it.count <= 0 then table.remove(inventory, i) end
            if need <= 0 then break end
        end
    end
    return true
end

-- ============ 令牌堆叠 ============
--- 只有在线卡一种令牌；参数保留是为了兼容既有调用点的签名。
---@param tokenType string
---@return string
function Shared.TokenTypeKey(tokenType)
    return "onlineToken"
end

---@param inventory table[]
---@param tokenType string
---@param count integer
function Shared.AddTokenToInventory(inventory, tokenType, count)
    local typeKey = Shared.TokenTypeKey(tokenType)
    local remaining = count
    for _, it in ipairs(inventory) do
        if it.type == typeKey then
            local add = math.min(Shared.C.TOKEN_STACK_MAX - (it.count or 1), remaining)
            it.count = (it.count or 1) + add
            remaining = remaining - add
            if remaining <= 0 then return end
        end
    end
    while remaining > 0 do
        local add = math.min(Shared.C.TOKEN_STACK_MAX, remaining)
        local disp = Shared.TOKEN_TYPES[tokenType] or { icon = "🎟️", name = "在线卡" }
        table.insert(inventory, {
            id = "tok_" .. Shared.UUID(),
            type = typeKey,
            tokenType = tokenType,
            count = add,
            icon = disp.icon,
            name = disp.name,
            quality = "normal",
        })
        remaining = remaining - add
    end
end

---@param inventory table[]
---@param tokenType string
---@return integer
function Shared.CountTokensInInventory(inventory, tokenType)
    local typeKey = Shared.TokenTypeKey(tokenType)
    local total = 0
    for _, it in ipairs(inventory) do
        if it.type == typeKey then total = total + (it.count or 1) end
    end
    return total
end

---@param inventory table[]
---@param tokenType string
---@param count integer
---@return boolean
function Shared.RemoveTokensFromInventory(inventory, tokenType, count)
    local typeKey = Shared.TokenTypeKey(tokenType)
    local total = Shared.CountTokensInInventory(inventory, tokenType)
    if total < count then return false end
    local need = count
    for i = #inventory, 1, -1 do
        local it = inventory[i]
        if it.type == typeKey then
            local take = math.min(it.count or 1, need)
            it.count = (it.count or 1) - take
            need = need - take
            if it.count <= 0 then table.remove(inventory, i) end
            if need <= 0 then break end
        end
    end
    return true
end

-- ============ 强化消耗 ============
---@param quality string
---@param enhanceLevel integer
---@return table<string, integer>
function Shared.GetEnhanceCostMap(quality, enhanceLevel)
    local L = enhanceLevel or 0
    local n
    if quality == "normal" then
        n = 1 + math.floor(L / 4)   -- 砍半
    else
        n = 1 + math.floor(L / 2)
    end
    return { [quality] = n }
end

---@param inventory table[]
---@param map table<string, integer>
---@return boolean
function Shared.CanPayFragmentMap(inventory, map)
    for q, n in pairs(map) do
        if Shared.CountFragmentsInInventory(inventory, q) < n then return false end
    end
    return true
end

---@param inventory table[]
---@param map table<string, integer>
function Shared.PayFragmentMap(inventory, map)
    for q, n in pairs(map) do
        Shared.RemoveFragmentsFromInventory(inventory, q, n)
    end
end

---@param quality string
---@return table<string, integer>
function Shared.GetForgeCostMap(quality)
    local map = {}
    if quality == "normal" then
        map.normal = 25
    elseif quality == "magic" then
        map.normal = 100; map.magic = 100
    elseif quality == "rare" then
        map.normal = 200; map.magic = 200; map.rare = 200
    elseif quality == "legendary" then
        map.normal = 400; map.magic = 400; map.rare = 400; map.legendary = 400
    elseif quality == "mythic" then
        map.normal = 800; map.magic = 800; map.rare = 800; map.legendary = 800; map.mythic = 800
    end
    return map
end

--- 重铸碎片消耗：消耗全部「当前品质及以下」的碎片，每种 base 个。
--- 锁定不增加消耗，只降成功率。
---@param quality string
---@param lockCount integer|nil 保留参数以兼容旧调用，不参与计算
---@return table<string, integer>
function Shared.GetReforgeCostMap(quality, lockCount)
    local base
    if quality == "normal" then
        base = 2
    elseif quality == "magic" then
        base = 10
    elseif quality == "rare" then
        base = 20
    elseif quality == "legendary" then
        base = 40
    elseif quality == "mythic" then
        base = 80
    else
        base = 2
    end

    local curRank = Shared.QUALITY_RANK[quality] or 0
    local map = {}
    for _, q in ipairs(Shared.QUALITY_LIST) do
        if (Shared.QUALITY_RANK[q] or 0) <= curRank then
            map[q] = base
        end
    end
    return map
end

--- 锻造精魄消耗：只消耗当前品质精魄，数量 = 2^品质排名（1/2/4/8/16）
---@param quality string
---@return table<string, integer>
function Shared.GetForgeSpiritCostMap(quality)
    local rank = Shared.QUALITY_RANK[quality] or 0
    return { [quality] = 2 ^ rank }
end

--- 重铸精魄消耗：只消耗当前品质精魄，数量 = 2^品质排名（1/2/4/8/16）
---@param quality string
---@return table<string, integer>
function Shared.GetReforgeSpiritCostMap(quality)
    local rank = Shared.QUALITY_RANK[quality] or 0
    return { [quality] = 2 ^ rank }
end

-- ============ 属性重铸（金币重铸属性词条） ============

--- 属性重铸的基础成本（金币）
--- 20 / 80 / 320 / 1280 / 5120（每品质 ×4）
---@param quality string
---@return integer
function Shared.GetAttrReforgeGoldCost(quality)
    local rank = Shared.QUALITY_RANK[quality] or 0
    -- ⚠️ 不能用 4 ^ rank：Lua 的 ^ 走浮点运算，返回值是 number 而非 integer，
    --    与 @return integer 不符（LSP 报 return-type-mismatch）。
    --    逐级 ×4 保持纯整数运算，数值与原来完全一致。
    local cost = 20
    for _ = 1, rank do cost = cost * 4 end
    return cost
end

--- 属性重铸的基础概率（与技能重铸共用 REFORGE_BASE_CHANCE）
---@param quality string
---@return number
function Shared.GetAttrReforgeBaseChance(quality)
    return Shared.C.REFORGE_BASE_CHANCE[quality] or 1.0
end

--- 计算属性重铸的实际概率（含锁定惩罚）
---@param quality string
---@param lockCount integer
---@return number
function Shared.CalcAttrReforgeChance(quality, lockCount)
    local base = Shared.GetAttrReforgeBaseChance(quality)
    return base * (Shared.C.REFORGE_LOCK_PENALTY ^ math.max(0, lockCount or 0))
end

--- 属性重铸：对装备进行属性词条重铸。
--- 规则：
---   · 基础词条（原特化）独立保留，不参与重铸
---   · 锁定的随机词条保留（按对象引用）
---   · 未锁定的随机词条 100% 消失
---   · 每次最多新增 1 条（按概率）
---   · 新增属性从 12 种里随机，数值 1~最大值
--- 修改 item.bonuses（原地）。
---@param item table
---@param lockedSet table 锁定的 bonus 对象集合 { [bonus] = true }
---@return boolean added 本次是否新增了一条
function Shared.DoAttrReforge(item, lockedSet)
    local quality = item.quality
    local specCount = #(Shared.SLOT_SPEC[item.slot] or {})

    -- 统计锁定数
    local lockCount = 0
    if lockedSet then
        for _ in pairs(lockedSet) do lockCount = lockCount + 1 end
    end
    local chance = Shared.CalcAttrReforgeChance(quality, lockCount)

    local newBonuses = {}
    -- 保留基础词条 + 锁定的随机词条
    for i, b in ipairs(item.bonuses or {}) do
        if i <= specCount then
            table.insert(newBonuses, b)
        elseif lockedSet and lockedSet[b] then
            table.insert(newBonuses, b)
        end
    end

    -- 按概率新增 1 条（🔴 只看**属性**上限，与技能额度互不影响）
    local added = false
    local maxAttr = Shared.MaxAttrAffixes(quality)
    local randAttr = #newBonuses - specCount     -- 排除基础词条
    if randAttr < 0 then randAttr = 0 end
    if randAttr >= maxAttr then
        -- 已达总条数上限：只重排不新增（否则会突破上限）
    elseif math.random() < chance then
        local mid = Shared.MOD_IDS[math.random(#Shared.MOD_IDS)]
        local baseMax = Shared.MOD_BASE_MAX[mid]
        local mult = Shared.QUALITY_MULT[quality] or 1.0
        local v = math.random() * baseMax * mult
        local def = Shared.MOD_DEFS[mid]
        if def and def.type == "percent" then
            if v < 0.0001 then v = 0.0001 end
        else
            if v < 1 then v = 1 end
        end
        table.insert(newBonuses, { modId = mid, value = v })
        added = true
    end

    item.bonuses = newBonuses
    return added
end

-- ============ 技能重铸 ============

--- 技能重铸：对装备进行技能词条重铸。
--- 规则：
---   · 锁定的技能保留
---   · 未锁定的技能 100% 消失
---   · 每次最多新增 1 条（按概率，固定 1 层）
--- 修改 item.skills（原地，新表）。
---@param item table
---@param lockedSet table 锁定的技能集合 { [skillId] = true }
---@return boolean added 本次是否新增了一条
function Shared.DoSkillReforge(item, lockedSet)
    local quality = item.quality
    local lockCount = 0
    if lockedSet then
        for _ in pairs(lockedSet) do lockCount = lockCount + 1 end
    end
    local chance = Shared.CalcAttrReforgeChance(quality, lockCount)

    -- 保留锁定的技能（层数也保留）
    local newSkills = {}
    if lockedSet then
        for sid, _ in pairs(lockedSet) do
            if item.skills and item.skills[sid] then
                newSkills[sid] = item.skills[sid]
            end
        end
    end

    -- 按概率新增 1 层（固定 1 层）。
    -- 🔴 只看**技能**上限，与属性额度互不影响。
    --    ⚠️ 按**层数**计（1 层 = 1 条），不是种类数。
    local added = false
    local maxSkill = Shared.MaxSkillAffixes(quality)
    local skillCount = Shared.CountSkillLayers(newSkills)
    if skillCount >= maxSkill then
        -- 已达总条数上限：只重排不新增
    elseif math.random() < chance then
        local sid = Shared.SKILL_IDS[math.random(#Shared.SKILL_IDS)]
        newSkills[sid] = (newSkills[sid] or 0) + 1
        added = true
    end

    item.skills = newSkills
    -- 更新 reforgeLevel（= 技能总层数 = 技能条数，不是种类数）
    item.reforgeLevel = Shared.CountSkillLayers(newSkills)
    return added
end

--- 精魄数量检查
---@param inventory table[]
---@param spiritType string
---@return integer
function Shared.CountSpiritsInInventory(inventory, spiritType)
    local total = 0
    for _, it in ipairs(inventory) do
        if it.type == "spirit" and it.spiritType == spiritType then
            total = total + (it.count or 1)
        end
    end
    return total
end

--- 添加精魄到背包
---@param inventory table[]
---@param spiritType string
---@param count integer
function Shared.AddSpiritsToInventory(inventory, spiritType, count)
    local remaining = count
    for _, it in ipairs(inventory) do
        if it.type == "spirit" and it.spiritType == spiritType then
            local add = math.min(Shared.C.SPIRIT_STACK_MAX - (it.count or 1), remaining)
            it.count = (it.count or 1) + add
            remaining = remaining - add
            if remaining <= 0 then return end
        end
    end
    while remaining > 0 do
        local add = math.min(Shared.C.SPIRIT_STACK_MAX, remaining)
        local disp = Shared.SPIRIT_DISPLAY[spiritType] or { name = spiritType, icon = "⚪" }
        table.insert(inventory, {
            id = "sp_" .. Shared.UUID(),
            type = "spirit",
            spiritType = spiritType,
            count = add,
            icon = disp.icon,
            name = disp.name,
            quality = spiritType,
        })
        remaining = remaining - add
    end
end

--- 移除精魄
---@param inventory table[]
---@param spiritType string
---@param count integer
---@return boolean
function Shared.RemoveSpiritsFromInventory(inventory, spiritType, count)
    local total = Shared.CountSpiritsInInventory(inventory, spiritType)
    if total < count then return false end
    local need = count
    for i = #inventory, 1, -1 do
        local it = inventory[i]
        if it.type == "spirit" and it.spiritType == spiritType then
            local take = math.min(it.count or 1, need)
            it.count = (it.count or 1) - take
            need = need - take
            if it.count <= 0 then table.remove(inventory, i) end
            if need <= 0 then break end
        end
    end
    return true
end

-- ============ 宠物蛋堆叠 ============
---@param inventory table[]
---@param eggQuality string
---@param count integer
function Shared.AddPetEggsToInventory(inventory, eggQuality, count)
    local remaining = count
    for _, it in ipairs(inventory) do
        if Shared.IsPetEgg(it) and it.eggQuality == eggQuality then
            local add = math.min(Shared.C.PET_MATERIAL_STACK_MAX - (it.count or 1), remaining)
            it.count = (it.count or 1) + add
            remaining = remaining - add
            if remaining <= 0 then return end
        end
    end
    while remaining > 0 do
        local add = math.min(Shared.C.PET_MATERIAL_STACK_MAX, remaining)
        local disp = Shared.PET_EGG_DISPLAY[eggQuality] or { name = "宠物蛋", icon = "🥚" }
        table.insert(inventory, {
            id = "egg_" .. Shared.UUID(),
            type = "petEgg",
            eggQuality = eggQuality,
            count = add,
            icon = disp.icon,
            name = disp.name,
            quality = eggQuality,
        })
        remaining = remaining - add
    end
end

---@param inventory table[]
---@param eggQuality string
---@return integer
function Shared.CountPetEggsInInventory(inventory, eggQuality)
    local total = 0
    for _, it in ipairs(inventory) do
        if Shared.IsPetEgg(it) and it.eggQuality == eggQuality then
            total = total + (it.count or 1)
        end
    end
    return total
end

---@param inventory table[]
---@param eggQuality string
---@param count integer
---@return boolean
function Shared.RemovePetEggsFromInventory(inventory, eggQuality, count)
    local total = Shared.CountPetEggsInInventory(inventory, eggQuality)
    if total < count then return false end
    local need = count
    for i = #inventory, 1, -1 do
        local it = inventory[i]
        if Shared.IsPetEgg(it) and it.eggQuality == eggQuality then
            local take = math.min(it.count or 1, need)
            it.count = (it.count or 1) - take
            need = need - take
            if it.count <= 0 then table.remove(inventory, i) end
            if need <= 0 then break end
        end
    end
    return true
end

-- ============ 宠物材料堆叠 ============
---@param inventory table[]
---@param materialQuality string
---@param count integer
function Shared.AddPetMaterialsToInventory(inventory, materialQuality, count)
    local remaining = count
    for _, it in ipairs(inventory) do
        if Shared.IsPetMaterial(it) and it.materialQuality == materialQuality then
            local add = math.min(Shared.C.PET_MATERIAL_STACK_MAX - (it.count or 1), remaining)
            it.count = (it.count or 1) + add
            remaining = remaining - add
            if remaining <= 0 then return end
        end
    end
    while remaining > 0 do
        local add = math.min(Shared.C.PET_MATERIAL_STACK_MAX, remaining)
        local disp = Shared.PET_MATERIAL_DISPLAY[materialQuality] or { name = "宠物精粹", icon = "🟢" }
        table.insert(inventory, {
            id = "pmat_" .. Shared.UUID(),
            type = "petMaterial",
            materialQuality = materialQuality,
            count = add,
            icon = disp.icon,
            name = disp.name,
            quality = materialQuality,
        })
        remaining = remaining - add
    end
end

---@param inventory table[]
---@param materialQuality string
---@return integer
function Shared.CountPetMaterialsInInventory(inventory, materialQuality)
    local total = 0
    for _, it in ipairs(inventory) do
        if Shared.IsPetMaterial(it) and it.materialQuality == materialQuality then
            total = total + (it.count or 1)
        end
    end
    return total
end

---@param inventory table[]
---@param materialQuality string
---@param count integer
---@return boolean
function Shared.RemovePetMaterialsFromInventory(inventory, materialQuality, count)
    local total = Shared.CountPetMaterialsInInventory(inventory, materialQuality)
    if total < count then return false end
    local need = count
    for i = #inventory, 1, -1 do
        local it = inventory[i]
        if Shared.IsPetMaterial(it) and it.materialQuality == materialQuality then
            local take = math.min(it.count or 1, need)
            it.count = (it.count or 1) - take
            need = need - take
            if it.count <= 0 then table.remove(inventory, i) end
            if need <= 0 then break end
        end
    end
    return true
end

--- 检查精魄地图是否足够
---@param inventory table[]
---@param map table<string, integer>
---@return boolean
function Shared.CanPaySpiritMap(inventory, map)
    for q, n in pairs(map) do
        if Shared.CountSpiritsInInventory(inventory, q) < n then return false end
    end
    return true
end

--- 扣除精魄
---@param inventory table[]
---@param map table<string, integer>
function Shared.PaySpiritMap(inventory, map)
    for q, n in pairs(map) do
        Shared.RemoveSpiritsFromInventory(inventory, q, n)
    end
end

-- ============ 锻造产出生成 ============
--- 由底材生成一件新的锻造装备（部位随机、词条重随、技能按锻造概率生成、满耐久）。
---@param sourceItem table
---@return table
function Shared.GenerateForgedItem(sourceItem)
    local quality = sourceItem.quality
    local slot    = Shared.SLOT_LIST[math.random(#Shared.SLOT_LIST)]
    local t       = Shared.SLOTS[slot]

    -- 锻造装备：普通必满条，其他按独立概率
    local isNormal = (quality == "normal")
    local hasSkill, hasAttr = true, true
    if not isNormal then
        hasSkill, hasAttr = Shared.RollForgeSkillAttr(quality)
    end

    -- 基础词条（必带）
    local specList = Shared.SLOT_SPEC[slot] or {}
    local bonuses = {}
    local mult = Shared.QUALITY_MULT[quality] or 1.0
    for _, spec in ipairs(specList) do
        local v = math.random() * spec[2] * mult
        if v < 1 and Shared.MOD_DEFS[spec[1]] and Shared.MOD_DEFS[spec[1]].type ~= "percent" then v = 1 end
        table.insert(bonuses, { modId = spec[1], value = v })
    end

    -- 🔴 属性与技能**各自独立上限**，互不占额度（基础词条不计入）。
    --    毕业形态（普通）：1 基础 + 6 属性 + 6 技能。
    local maxAttr  = Shared.MaxAttrAffixes(quality)
    local maxSkill = Shared.MaxSkillAffixes(quality)

    -- 属性词条（普通必满，其他随机 1~上限）
    if hasAttr then
        ---@type integer
        local maxBonus = Shared.QUALITY_BONUS_MAX[quality] or 6
        local randCount = isNormal and maxAttr or math.random(1, math.min(maxBonus, maxAttr))
        for _ = 1, randCount do
            local mid = Shared.MOD_IDS[math.random(#Shared.MOD_IDS)]
            local baseMax = Shared.MOD_BASE_MAX[mid]
            local v = math.random() * baseMax * mult
            local def = Shared.MOD_DEFS[mid]
            if def and def.type == "percent" then
                if v < 0.0001 then v = 0.0001 end
            else
                if v < 1 then v = 1 end
            end
            table.insert(bonuses, { modId = mid, value = v })
        end
    end

    -- 技能词条（🔴 独立上限 maxSkill，不受属性条数影响）
    --    普通品质：填满 maxSkill 层（允许重复技能堆叠，符合"不校验唯一性"的规则）
    local skills = {}
    if hasSkill then
        if isNormal then
            for _ = 1, maxSkill do
                local sid = Shared.SKILL_IDS[math.random(#Shared.SKILL_IDS)]
                skills[sid] = (skills[sid] or 0) + 1
            end
        else
            -- 其他品质：走原有 GenSkillsForge（按 SKILL_FORGE_CHANCE 概率），再按上限截断
            skills = Shared.GenSkillsForge(quality)
            local layers = Shared.CountSkillLayers(skills)
            if layers > maxSkill then
                local ids = {}
                for sid in pairs(skills) do ids[#ids + 1] = sid end
                table.sort(ids)
                local kept, left = {}, maxSkill
                for _, sid in ipairs(ids) do
                    if left <= 0 then break end
                    local take = math.min(skills[sid] or 1, left)
                    kept[sid] = take
                    left = left - take
                end
                skills = kept
            end
        end
    end

    local maxDur = Shared.C.QUALITY_DURABILITY[quality] or 1000

    return {
        id            = Shared.UUID(),
        slot          = slot,
        slotName      = t.name,
        icon          = t.icon,
        quality       = quality,
        qualityName   = Shared.QUALITY_NAMES[quality],
        -- itemLevel 继承当前品质底材
        itemLevel     = sourceItem.itemLevel,
        name          = Shared.QUALITY_NAMES[quality] .. " " .. t.name,
        bonuses       = bonuses,
        skills        = skills,
        identified    = false,
        forged        = true,
        requiredLevel = sourceItem.requiredLevel or Shared.QUALITY_WEAR[quality] or 1,
        enhanceLevel  = 0,
        reforgeLevel  = 0,
        maxEnhance    = Shared.QUALITY_MAX_ENHANCE[quality] or 20,
        durability    = maxDur,
        maxDurability = maxDur,
    }
end

--- 生成 8 件新手装备（8 部位各一件，普通品质，上锁）
--- 与掉落装备的区别：
---   · 已鉴定（identified = true）——新手开箱即可直接看词条、可重铸
---   · 固定带 STARTER_GEAR_SKILLS 个随机技能（不重复），不走 50% 概率
---   · 固定带 STARTER_GEAR_ATTRS 条随机属性词条，不走 50% 概率
---@return table[]
function Shared.GenStarterGear()
    local items = {}
    for _, slot in ipairs(Shared.SLOT_LIST) do
        local t = Shared.SLOTS[slot]

        -- 基础词条
        local specList = Shared.SLOT_SPEC[slot] or {}
        local bonuses = {}
        for _, spec in ipairs(specList) do
            local v = math.random() * spec[2] * 1.0
            if v < 1 and Shared.MOD_DEFS[spec[1]] and Shared.MOD_DEFS[spec[1]].type ~= "percent" then v = 1 end
            table.insert(bonuses, { modId = spec[1], value = v })
        end

        -- 🔴 属性与技能**各自独立上限**（基础词条不计入）。
        local maxAttr  = Shared.MaxAttrAffixes("normal")
        local maxSkill = Shared.MaxSkillAffixes("normal")

        -- 属性词条：固定 STARTER_GEAR_ATTRS 条（受各自上限限制）
        local attrCount = math.min(Shared.C.STARTER_GEAR_ATTRS or 6, maxAttr)
        for _ = 1, attrCount do
            local mid = Shared.MOD_IDS[math.random(#Shared.MOD_IDS)]
            local baseMax = Shared.MOD_BASE_MAX[mid]
            local v = math.random() * baseMax * 1.0
            local def = Shared.MOD_DEFS[mid]
            if def and def.type == "percent" then
                if v < 0.0001 then v = 0.0001 end
            else
                if v < 1 then v = 1 end
            end
            table.insert(bonuses, { modId = mid, value = v })
        end

        -- 技能词条：独立上限 maxSkill，且互不重复。
        -- 从候选池里随机抽取后剔除，避免同一技能叠层（新手装备给不同技能更实用）。
        local skills = {}
        local pool = {}
        for i = 1, #Shared.SKILL_IDS do pool[i] = Shared.SKILL_IDS[i] end
        local want = math.min(Shared.C.STARTER_GEAR_SKILLS, #pool, maxSkill)
        for _ = 1, want do
            local idx = math.random(#pool)
            local sid = pool[idx]
            skills[sid] = 1
            table.remove(pool, idx)
        end

        local maxDur = Shared.C.QUALITY_DURABILITY["normal"] or 1000
        table.insert(items, {
            id            = Shared.UUID(),
            slot          = slot,
            slotName      = t.name,
            icon          = t.icon,
            quality       = "normal",
            qualityName   = Shared.QUALITY_NAMES["normal"],
            itemLevel     = 1,
            name          = Shared.QUALITY_NAMES["normal"] .. " " .. t.name,
            bonuses       = bonuses,
            skills        = skills,
            identified    = true,
            forged        = false,
            requiredLevel = 1,
            enhanceLevel  = 0,
            reforgeLevel  = 0,
            maxEnhance    = Shared.QUALITY_MAX_ENHANCE["normal"] or 20,
            durability    = maxDur,
            maxDurability = maxDur,
            locked        = true,
        })
    end
    return items
end

-- ============ 技能详情 / 市场分类（UI 辅助） ============
--- 技能参数的中文名映射（覆盖 SKILL_DEFS 里 params 的全部 key）
Shared.SKILL_PARAM_LABELS = {
    range = "范围(米)", duration = "持续(秒)", maxTargets = "最大目标",
    maxStacks = "最大叠层", damageRatio = "伤害倍率", splitRatio = "分摊比例",
    atkSpeedBonus = "攻速加成", moveSpeedBonus = "移速加成",
    healRatio = "回复伤害占比", healMaxHpRatio = "回复最大生命占比",
    healAtkRatio = "回复攻击占比", hpThreshold = "触发血量阈值",
    reduceRatio = "减伤幅度", armorBonus = "护甲加成", reflectRatio = "反伤比例",
    dodgeBonus = "闪避加成", atkDebuff = "攻击削弱", atkSpeedDebuff = "攻速削弱",
    damageBonus = "伤害加成", ignoreArmor = "无视护甲",
    tickRatio = "每秒伤害占比", hitRateBonus = "命中加成",
    armorDebuff = "护甲削弱", aoeRatio = "范围伤害占比",
    dpsRatio = "每秒伤害占比", tickInterval = "伤害间隔(秒)",
    lifestealRatio = "吸血占比",
}

--- 市场一级分类
Shared.MARKET_CATEGORIES = {
    -- ⚠️ id 是存档/分类判断用，**不要改**；name 是显示名，统一加"类"后缀。
    --    "全部" 不加"类"（语义上它不是一个分类，是聚合视图）。
    { id = "all",        name = "全部" },
    { id = "equip",      name = "装备类" },
    { id = "fragment",   name = "碎片类" },
    { id = "spirit",     name = "精魄类" },
    { id = "token",      name = "在线卡类" },
    { id = "consume",    name = "消耗类" },
    -- 宠物蛋 / 宠物精粹 / 宠物本体合并为一个一级分类
    { id = "pet",        name = "宠物类" },
    -- 等级石（无二级分类）
    { id = "levelStone", name = "等级石类" },
}

--- 判断物品属于哪个市场分类
---@param item table
---@return string
function Shared.MarketCategoryOf(item)
    if Shared.IsFragment(item) then return "fragment" end
    if Shared.IsSpirit(item) then return "spirit" end
    if Shared.IsToken(item) then return "token" end
    if Shared.IsSummonScroll(item) then return "consume" end
    if Shared.IsPetEgg(item) or Shared.IsPetMaterial(item) or Shared.IsPetItem(item) then
        return "pet"
    end
    if Shared.IsLevelStone(item) then return "levelStone" end
    return "equip"
end


--- 服务器与客户端共用的「空存档」定义，避免两端字段默认值漂移
---@return table
function Shared.NewPlayerSave()
    local equip = {}
    for _, s in ipairs(Shared.SLOT_LIST) do equip[s] = nil end

    local inventory = {}
    -- 新玩家不再赠送任何令牌（每日赠送机制处理）
    return {
        saveVersion       = Shared.SAVE_VERSION,
        gold              = Shared.C.INIT_GOLD,
        level             = 1,
        inventory         = inventory,
        equipment         = equip,
        bagPageCount      = 1,
        -- 自动分解开关：已鉴定 / 未鉴定 各一套（见 Panels.OpenAutoDecompose）
        autoDecompose     = {
            normal = false, magic = false, rare = false, legendary = false, mythic = false,
        },
        autoDecomposeUnid = {
            normal = false, magic = false, rare = false, legendary = false, mythic = false,
        },
        autoRepair        = false,
        mails             = {},
        nextMailId        = 1,
        onlineTokenMinutes= 0,
        -- 新玩家不再预送时长：开局靠首次登录的新手礼包（8 件基础装备，
        -- 见 Server_System.GrantStarterGift）
        adCountToday      = 0,
        adLastTime        = 0,
        lastResetDate     = Shared.TodayString(),
        -- 新手礼包幂等键 + 新老玩家判定（"" = 未领过礼包的新玩家）。
        -- 原为「每日赠送幂等键」，每日赠送删除后语义改为「上次领新手礼包的日期」。
        -- ⚠️ 不复用 lastResetDate：后者会被 ApplySaveToPlayer 无条件刷成今天
        --    （广告次数重置用），拿它判赠送会导致「当天永远发不出赠送」。
        lastDailyGiftDate = "",
        -- 每日礼包幂等键（"" = 今天还没领）。跟 lastDailyGiftDate 独立。
        dailyGiftDate = "",
        settings          = Shared.NewDefaultSettings(),
        -- 钱庄：存款列表（每笔 { amount, term, depositAt, expiresAt }）
        bankDeposits      = {},
        -- 新手礼包装备是否已补发（幂等键，见 Server_System.GrantStarterGift）
        starterGiftReceived = false,
        -- 等级石：穿在槽位上的等级石（nil = 未装备）
        levelStone = nil,
        -- 等级石礼包幂等键（false = 未领过，true = 已发放）
        levelStoneGiftReceived = false,
        -- ============ 宠物系统 ============
        -- 8 个装备槽位 + 待选池（上限 PET_POOL_MAX）
        pets = Shared.NewPetData(),
        -- 5 个池子各一个保底计数器（跨会话持久化）
        petGacha = Shared.NewPetGachaData(),
        -- ============ 天赋树 ============
        -- { nodes = { [nodeId] = true } }，客户端权威（见 BD_Tree.lua）
        bdTree = Shared.NewBDTree(),
    }
end

-- ============ JSON 安全解析 ============
--- 安全解析 JSON，防止服务器因坏包崩溃。
--- ⚠️ 只用于 decode；encode 依然用原生 cjson.encode（编码不会失败，无需包 pcall）。
---@param str string|nil
---@return table|nil
function Shared.SafeDecode(str)
    if type(str) ~= "string" or str == "" then return nil end
    local ok, result = pcall(cjson.decode, str)
    if ok and type(result) == "table" then return result end
    print("[Shared] ⚠️ JSON 解析失败: " .. tostring(str))
    return nil
end

-- ============ 应用服务器配置 ============
--- 应用服务器下发的配置，覆盖客户端 Shared 表。
--- 客户端 Start() 收到 AssignPlayer 时调用，之后所有数值以服务端为准。
---@param cfg table
function Shared.ApplyServerConfig(cfg)
    if type(cfg) ~= "table" then return end
    if cfg.Constants then
        for k, v in pairs(cfg.Constants) do Shared.C[k] = v end
    end
    if cfg.Skills              then Shared.SKILL_DEFS          = cfg.Skills end
    if cfg.QualityColors       then Shared.QUALITY_COLORS      = cfg.QualityColors end
    if cfg.QualityRank         then Shared.QUALITY_RANK        = cfg.QualityRank end
    if cfg.QualityNames        then Shared.QUALITY_NAMES       = cfg.QualityNames end
    if cfg.QualityMaxEnhance   then Shared.QUALITY_MAX_ENHANCE = cfg.QualityMaxEnhance end
    if cfg.QualityWear         then Shared.QUALITY_WEAR        = cfg.QualityWear end
    if cfg.QualityMult         then Shared.QUALITY_MULT        = cfg.QualityMult end
    if cfg.ModDefs             then Shared.MOD_DEFS            = cfg.ModDefs end
    if cfg.ModBaseMax          then Shared.MOD_BASE_MAX        = cfg.ModBaseMax end
    if cfg.SlotSpec            then Shared.SLOT_SPEC           = cfg.SlotSpec end
    if cfg.FragmentDisplay     then Shared.FRAGMENT_DISPLAY    = cfg.FragmentDisplay end
    if cfg.Slots               then Shared.SLOTS               = cfg.Slots end
    if cfg.QualityBonusMax     then Shared.QUALITY_BONUS_MAX   = cfg.QualityBonusMax end
    if cfg.QualityMaxReforge   then Shared.C.QUALITY_MAX_REFORGE   = cfg.QualityMaxReforge end
    if cfg.QualityDurability   then Shared.C.QUALITY_DURABILITY    = cfg.QualityDurability end
    if cfg.ReforgeBaseChance   then Shared.C.REFORGE_BASE_CHANCE   = cfg.ReforgeBaseChance end
    if cfg.SpiritDisplay       then Shared.SPIRIT_DISPLAY          = cfg.SpiritDisplay end
    if cfg.TierMaxLevel        then Shared.C.TIER_MAX_LEVEL        = cfg.TierMaxLevel end
    if cfg.BossStats           then Shared.C.BOSS_STATS            = cfg.BossStats end
    -- cjson 会把整数 key 序列化成字符串，解码回来后要用 tonumber 还原
    if cfg.EnhanceRates then
        local r = {}
        for k, v in pairs(cfg.EnhanceRates) do
            r[tonumber(k) or k] = v
        end
        Shared.ENHANCE_RATES = r
    end
    print("[Shared] 服务器配置已应用")
end


-- ============================================================
-- 数据层模块（Data / Notify）已拆到 Shared_Data.lua
--
-- ⚠️ 必须在**本文件全部纯函数都定义好之后**才 require：
--    Shared_Data 里的 Data 模块会调用 Shared.SafeDecode（定义在本文件内），
--    Shared.Notify.Toast 也会被 Data 的方法调用。
-- ============================================================
require("Shared_Data")
