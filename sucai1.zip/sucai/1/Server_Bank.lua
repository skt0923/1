-- ============================================================
-- Server_Bank.lua：钱庄（Server_System.lua 的兄弟文件）
--
-- 职责：存款 / 取款 / 每日利息结算 / 税池与索引持久化 / 到期扫描。
--
-- 与 Server_System.lua 的关系：
--   · 本模块持有自己的状态（税池 / 索引 / 结算队列 / 计时器）
--   · 通过 Bank.Init(ctx) 注入核心状态与服务
--   · 事件订阅由 Server_System.Sys.RegisterEvents 调 Bank.RegisterEvents() 完成
--   · 主循环每秒由 Server_System.Sys.Update 调 Bank.Update(dt)
--
-- 依赖：Shared + 注入的 Sys（用其 AddMail / NotifyMail / PushInventory /
--       RunOfflineSaveTask / WriteOfflineSave / FindConnectionByPlayerId）。
--       通过 ctx 注入避免循环 require。
-- ============================================================
local Shared = require("Shared")

local Bank = {}

-- ============ 注入 ============
--- ⚠️ 默认空实现 / 空表：Init 前若真有事件进来（不该发生），
---    只会退化成「什么都不做」，不会因 nil 调用崩掉。
---@type table
local ctx = {
    players         = {},
    MarkPlayerDirty = function(_) end,
    SaveToCloud     = function(_) end,
    LoadSaveAsync   = function(_, cb) if cb then cb(nil) end end,
    PushCloud       = function(_, _) end,
    PlayerOf        = function(_) return nil, nil end,
    ---@type table|nil  Server_System 模块（AddMail / PushInventory / RunOfflineSaveTask …）
    Sys             = nil,
}

function Bank.Init(c)
    for k, v in pairs(c) do ctx[k] = v end
end

-- ============ 状态 ============
local dailyTaxPool_ = 0
local lastBankSettleDate_ = ""
local bankCheckTimer_ = 0
local bankExpireTimer_ = 0
local bankSaveTimer_ = 0

local BANK_POOL_KEY = "bank_pool_v4"
local BANK_INDEX_KEY = "bank_index_v4"
local BANK_SNAPSHOT_KEY = "bank_snapshot_v4"

local bankPoolLoaded_ = false
local bankIndexLoaded_ = false

--- 存款索引（内存镜像）：pid → {totalWeight, depositCount}
---@type table<string, {totalWeight: number, depositCount: integer}>
local bankIndex_ = {}

--- 全服结算单队列
---@type { running: boolean, queue: string[], snapshot: table|nil,
---        busy: boolean, currentPid: string|nil, busySince: integer|nil }
local bankSettleState_ = {
    running = false, queue = {}, snapshot = nil,
    busy = false, currentPid = nil, busySince = nil,
}

--- 单个玩家结算步骤的超时（秒）。离线玩家走 LoadSaveAsync，云回调可能永不返回，
--- 超时后强制推进，否则 busy 会永久为真、整个结算队列卡死。
local BANK_SETTLE_STEP_TIMEOUT = 15

-- ============ 事件订阅 ============
function Bank.RegisterEvents()
    SubscribeToEvent(Shared.EVENTS.BANK_DEPOSIT,        Bank.OnBankDeposit)
    SubscribeToEvent(Shared.EVENTS.BANK_WITHDRAW,       Bank.OnBankWithdraw)
    SubscribeToEvent(Shared.EVENTS.BANK_STATE_REQUEST,  Bank.OnBankStateRequest)
end

-- ============ 市场税接口 ============
--- 累加一笔市场税到今日税池（Server_System 的市场成交调用）。
---@param fee integer
function Bank.AddTax(fee)
    if fee and fee > 0 then
        dailyTaxPool_ = dailyTaxPool_ + fee
    end
end

-- ============ 主循环 ============
--- 由 Server_System.Sys.Update 每秒调用。
---@param dt number
function Bank.Update(dt)
    -- 结算队列推进（含卡死看门狗）
    if bankSettleState_.running then
        local st = bankSettleState_
        if st.busy and st.busySince
            and (os.time() - st.busySince) >= BANK_SETTLE_STEP_TIMEOUT then
            Bank.PumpBankSettleQueue(true)
        elseif not st.busy then
            Bank.PumpBankSettleQueue()
        end
    end

    -- 跨日检查（每 10 分钟一次）
    bankCheckTimer_ = bankCheckTimer_ + dt
    if bankCheckTimer_ >= 600 then
        bankCheckTimer_ = 0
        local today = Shared.TodayString()
        if lastBankSettleDate_ ~= today then
            Bank.SettleBankDaily()
        end
    end

    -- 存款到期扫描（660 秒）
    bankExpireTimer_ = bankExpireTimer_ + dt
    if bankExpireTimer_ >= 660 then
        bankExpireTimer_ = 0
        Bank.ScanBankExpired()
    end

    -- 税池 + 索引定期落盘（30 秒）
    bankSaveTimer_ = bankSaveTimer_ + dt
    if bankSaveTimer_ >= 30 then
        bankSaveTimer_ = 0
        Bank.SaveBankPool()
        Bank.SaveBankIndex()
    end
end

-- ============ 状态推送 ============
function Bank.SendBankState(p, c)
    local myWeight = 0
    for _, dep in ipairs(p.bankDeposits or {}) do
        local days = dep.term
        myWeight = myWeight + dep.amount * (days ^ 1.5)
    end

    local totalWeight = 0
    for _, entry in pairs(bankIndex_) do
        if entry.totalWeight then totalWeight = totalWeight + entry.totalWeight end
    end

    local todayEarnings = p.bankTodayEarnings or 0
    local forecast = 0
    if totalWeight > 0 and dailyTaxPool_ > 0 then
        forecast = math.floor(dailyTaxPool_ * myWeight / totalWeight)
    end

    local totalInterest = 0
    for _, dep in ipairs(p.bankDeposits or {}) do
        totalInterest = totalInterest + (dep.accumulatedInterest or 0)
    end

    c:SendRemoteEvent(Shared.EVENTS.BANK_STATE, true, Shared.ToVariantMap({
        Deposits         = cjson.encode(p.bankDeposits or {}),
        DailyTaxPool     = dailyTaxPool_,
        MyWeight         = math.floor(myWeight),
        TotalWeight      = math.floor(totalWeight),
        TodayEarnings    = todayEarnings,
        ForecastTomorrow = forecast,
        TotalInterest    = math.floor(totalInterest),
        Today            = Shared.TodayString(),
    }))
end

function Bank.OnBankStateRequest(_, e)
    local p, c = ctx.PlayerOf(e)
    if not p then return end
    Bank.SendBankState(p, c)
end

-- ============ 存款 / 取款 ============
function Bank.OnBankDeposit(_, e)
    local p, c = ctx.PlayerOf(e)
    if not p then return end

    local amount = e["Amount"] and e["Amount"]:GetInt() or 0
    local term   = e["Term"] and e["Term"]:GetInt() or 7

    if term ~= 7 and term ~= 30 then
        c:SendRemoteEvent(Shared.EVENTS.BANK_RESULT, true, Shared.ToVariantMap({
            Ok = 0, Reason = "期限必须是 7 天或 30 天",
        }))
        return
    end
    if amount < 1000 then
        c:SendRemoteEvent(Shared.EVENTS.BANK_RESULT, true, Shared.ToVariantMap({
            Ok = 0, Reason = "存款金额最少 1000 金币",
        }))
        return
    end
    if p.gold < amount then
        c:SendRemoteEvent(Shared.EVENTS.BANK_RESULT, true, Shared.ToVariantMap({
            Ok = 0, Reason = "金币不足",
        }))
        return
    end

    p.gold = p.gold - amount
    ctx.MarkPlayerDirty(p.id)

    p.bankDeposits = p.bankDeposits or {}
    table.insert(p.bankDeposits, {
        amount    = amount,
        term      = term,
        depositAt = os.time(),
        expiresAt = os.time() + term * 24 * 3600,
        accumulatedInterest = 0,
    })
    local entry = bankIndex_[p.id]
    if not entry then
        entry = { totalWeight = 0, depositCount = 0 }
        bankIndex_[p.id] = entry
    end
    entry.totalWeight = entry.totalWeight + amount * (term ^ 1.5)
    entry.depositCount = entry.depositCount + 1

    ctx.Sys.PushInventory(p, true)
    Bank.SendBankState(p, c)
    c:SendRemoteEvent(Shared.EVENTS.BANK_RESULT, true, Shared.ToVariantMap({
        Ok = 1, Reason = string.format("已存入 %d 金币（%d 天）", amount, term),
    }))
    ctx.SaveToCloud(p.id)
end

function Bank.OnBankWithdraw(_, e)
    local p, c = ctx.PlayerOf(e)
    if not p then return end

    local idx = e["Index"] and e["Index"]:GetInt() or 0
    local dep = p.bankDeposits and p.bankDeposits[idx + 1]
    if not dep then
        c:SendRemoteEvent(Shared.EVENTS.BANK_RESULT, true, Shared.ToVariantMap({
            Ok = 0, Reason = "存款不存在",
        }))
        return
    end
    if os.time() < dep.expiresAt then
        c:SendRemoteEvent(Shared.EVENTS.BANK_RESULT, true, Shared.ToVariantMap({
            Ok = 0, Reason = "存款未到期，无法取出",
        }))
        return
    end

    local totalRefund = (dep.amount or 0) + math.floor(dep.accumulatedInterest or 0)
    p.gold = p.gold + totalRefund
    ctx.MarkPlayerDirty(p.id)
    local entry = bankIndex_[p.id]
    if entry and dep.amount then
        local w = dep.amount * ((dep.term or 7) ^ 1.5)
        entry.totalWeight = math.max(0, entry.totalWeight - w)
        entry.depositCount = math.max(0, entry.depositCount - 1)
    end
    table.remove(p.bankDeposits, idx + 1)

    ctx.Sys.PushInventory(p, true)
    Bank.SendBankState(p, c)
    c:SendRemoteEvent(Shared.EVENTS.BANK_RESULT, true, Shared.ToVariantMap({
        Ok = 1, Reason = string.format("已取出本金 %d 金币", dep.amount),
    }))
    ctx.SaveToCloud(p.id)
end

-- ============ 每日结算 ============
function Bank.SettleBankDaily()
    local today = Shared.TodayString()
    if lastBankSettleDate_ == today then return end
    if bankSettleState_.running then return end

    local totalWeight = 0
    local pids = {}
    for pid, entry in pairs(bankIndex_) do
        if entry.totalWeight and entry.totalWeight > 0 then
            totalWeight = totalWeight + entry.totalWeight
            table.insert(pids, pid)
        end
    end

    if totalWeight <= 0 then
        lastBankSettleDate_ = today
        dailyTaxPool_ = 0
        Bank.SaveBankPool()
        print("[Server] 钱庄结算：无存款人，税池清零")
        return
    end

    local taxPool = dailyTaxPool_
    local snapshot = {
        date          = today,
        taxPool       = taxPool,
        totalWeight   = totalWeight,
        pids          = pids,
        failedPids    = {},
    }
    bankSettleState_.snapshot = snapshot
    bankSettleState_.queue = pids
    bankSettleState_.running = true

    lastBankSettleDate_ = today
    dailyTaxPool_ = 0
    Bank.SaveBankPool()
    Bank.SaveBankSnapshot(snapshot)

    print(string.format("[Server] 钱庄结算开始：%d 个玩家，税池 %d 金币，总权重 %d",
        #pids, taxPool, totalWeight))

    Bank.PumpBankSettleQueue()
end

function Bank.PumpBankSettleQueue(force)
    local st = bankSettleState_
    if not st.running then return end
    if st.busy and not force then return end

    if force and st.busy and st.currentPid and st.snapshot then
        print("[Server] 钱庄结算：玩家 " .. st.currentPid .. " 处理超时，跳过（份额保留）")
        table.insert(st.snapshot.failedPids, st.currentPid)
    end

    st.busy = false
    st.currentPid = nil
    st.busySince = nil

    if #st.queue == 0 then
        Bank.FinishBankSettle()
        return
    end

    local pid = table.remove(st.queue, 1)
    st.busy = true
    st.currentPid = pid
    st.busySince = os.time()

    local finished = false
    local function Finish(ok)
        if finished then return end
        finished = true
        if st.currentPid ~= pid then return end   -- 已被看门狗判超时并推进，丢弃本次结果
        if not ok and st.snapshot then
            table.insert(st.snapshot.failedPids, pid)
        end
        if st.snapshot then Bank.SaveBankSnapshot(st.snapshot) end
        st.busy = false
        st.currentPid = nil
        st.busySince = nil
    end

    Bank.SettleOnePlayer(pid, st.snapshot, Finish)
end

function Bank.SettleOnePlayer(pid, snapshot, onDone)
    local entry = bankIndex_[pid]
    if not entry or not entry.totalWeight or snapshot.totalWeight <= 0 then
        onDone(true)
        return
    end
    local share = math.floor(snapshot.taxPool * entry.totalWeight / snapshot.totalWeight)

    local onlineP = ctx.players[pid]
    if onlineP then
        if onlineP.bankLastSettledDate == snapshot.date then
            onDone(true)
            return
        end
        local ok = Bank.ApplyInterestToPlayer(onlineP, share, snapshot.date)
        if ok then
            ctx.MarkPlayerDirty(pid)
            ctx.SaveToCloud(pid)
        end
        onDone(ok)
        return
    end

    ctx.Sys.RunOfflineSaveTask(pid, function(done)
        ctx.LoadSaveAsync(pid, function(save)
            if type(save) ~= "table" then
                done()
                onDone(false)
                return
            end
            if save.bankLastSettledDate == snapshot.date then
                done()
                onDone(true)
                return
            end
            save.bankDeposits = save.bankDeposits or {}
            local myWeight = entry.totalWeight
            for _, dep in ipairs(save.bankDeposits) do
                if dep.amount and dep.amount > 0 then
                    local depWeight = dep.amount * ((dep.term or 7) ^ 1.5)
                    local depShare = (myWeight > 0) and math.floor(share * depWeight / myWeight) or 0
                    dep.accumulatedInterest = (dep.accumulatedInterest or 0) + depShare
                end
            end
            save.bankTodayEarnings = share
            save.bankLastSettledDate = snapshot.date

            ctx.Sys.WriteOfflineSave(pid, save)
            done()
            onDone(true)
        end)
    end)
end

function Bank.ApplyInterestToPlayer(p, share, date)
    p.bankDeposits = p.bankDeposits or {}
    local entry = bankIndex_[p.id]
    local myWeight = entry and entry.totalWeight or 0
    for _, dep in ipairs(p.bankDeposits) do
        if dep.amount and dep.amount > 0 then
            local depWeight = dep.amount * ((dep.term or 7) ^ 1.5)
            local depShare = (myWeight > 0) and math.floor(share * depWeight / myWeight) or 0
            dep.accumulatedInterest = (dep.accumulatedInterest or 0) + depShare
        end
    end
    p.bankTodayEarnings = share
    p.bankLastSettledDate = date
    return true
end

function Bank.FinishBankSettle()
    local st = bankSettleState_
    st.running = false
    st.queue = {}
    st.busy = false
    st.currentPid = nil
    st.busySince = nil

    local failed = st.snapshot and st.snapshot.failedPids or {}
    local addBack = 0
    for _, pid in ipairs(failed) do
        local entry = bankIndex_[pid]
        if entry and entry.totalWeight and st.snapshot.totalWeight > 0 then
            addBack = addBack + math.floor(st.snapshot.taxPool * entry.totalWeight / st.snapshot.totalWeight)
        end
    end
    if addBack > 0 then
        dailyTaxPool_ = dailyTaxPool_ + addBack
        print("[Server] 钱庄结算：失败玩家 " .. #failed .. " 个，份额 " .. addBack .. " 加回税池")
    end

    st.snapshot = nil
    Bank.ClearBankSnapshot()
    Bank.SaveBankPool()

    print("[Server] 钱庄结算完成")
end

-- ============ 税池 / 索引 / 快照持久化 ============
function Bank.SaveBankPool()
    if not bankPoolLoaded_ then
        print("[Server] 税池尚未读回，跳过落盘")
        return
    end
    local payload = {
        pool = dailyTaxPool_,
        lastSettledDate = lastBankSettleDate_,
    }
    serverCloud:Set(0, BANK_POOL_KEY, cjson.encode(payload), {
        ok = function() end,
        error = function(code, reason)
            print("[Server] 税池写入失败 code=" .. tostring(code) .. " reason=" .. tostring(reason))
        end,
    })
end

function Bank.LoadBankPool()
    local retries = 0
    local function TryRead()
        serverCloud:Get(0, BANK_POOL_KEY, {
            ok = function(scores)
                bankPoolLoaded_ = true
                local raw = scores and scores[BANK_POOL_KEY]
                local data = Shared.SafeDecode(raw)
                if type(data) == "table" then
                    dailyTaxPool_ = data.pool or 0
                    lastBankSettleDate_ = data.lastSettledDate or ""
                    print(string.format("[Server] 税池已恢复：%d 金币，上次结算 %s",
                        dailyTaxPool_, lastBankSettleDate_))
                else
                    print("[Server] 税池无历史记录，从零开始")
                end
            end,
            error = function(code, reason)
                retries = retries + 1
                print("[Server] 税池读取失败 code=" .. tostring(code)
                    .. " reason=" .. tostring(reason) .. " (" .. retries .. "/3)")
                if retries < 3 then TryRead()
                else bankPoolLoaded_ = true end
            end,
        })
    end
    TryRead()
end

function Bank.SaveBankIndex()
    if not bankIndexLoaded_ then
        print("[Server] 存款索引尚未读回，跳过落盘")
        return
    end
    serverCloud:Set(0, BANK_INDEX_KEY, cjson.encode(bankIndex_), {
        ok = function() end,
        error = function(code, reason)
            print("[Server] 存款索引写入失败 code=" .. tostring(code) .. " reason=" .. tostring(reason))
        end,
    })
end

function Bank.LoadBankIndex()
    local retries = 0
    local function TryRead()
        serverCloud:Get(0, BANK_INDEX_KEY, {
            ok = function(scores)
                bankIndexLoaded_ = true
                local raw = scores and scores[BANK_INDEX_KEY]
                local data = Shared.SafeDecode(raw)
                if type(data) == "table" then
                    bankIndex_ = data
                    local n = 0
                    for _ in pairs(bankIndex_) do n = n + 1 end
                    print("[Server] 存款索引已恢复：" .. n .. " 个玩家")
                else
                    print("[Server] 存款索引无历史记录，从零开始")
                end
            end,
            error = function(code, reason)
                retries = retries + 1
                print("[Server] 存款索引读取失败 code=" .. tostring(code)
                    .. " reason=" .. tostring(reason) .. " (" .. retries .. "/3)")
                if retries < 3 then TryRead()
                else bankIndexLoaded_ = true end
            end,
        })
    end
    TryRead()
end

function Bank.SaveBankSnapshot(snapshot)
    serverCloud:Set(0, BANK_SNAPSHOT_KEY, cjson.encode(snapshot), {
        ok = function() end,
        error = function(code, reason)
            print("[Server] 结算快照写入失败 code=" .. tostring(code) .. " reason=" .. tostring(reason))
        end,
    })
end

function Bank.ClearBankSnapshot()
    serverCloud:Set(0, BANK_SNAPSHOT_KEY, "", {
        ok = function() end,
        error = function() end,
    })
end

function Bank.LoadBankSnapshot()
    serverCloud:Get(0, BANK_SNAPSHOT_KEY, {
        ok = function(scores)
            local raw = scores and scores[BANK_SNAPSHOT_KEY]
            local data = Shared.SafeDecode(raw)
            if type(data) ~= "table" or not data.date then return end
            print("[Server] 发现未完成的结算快照（" .. data.date .. "），继续处理")
            bankSettleState_.snapshot = data
            bankSettleState_.queue = data.pids or {}
            bankSettleState_.running = true
            Bank.PumpBankSettleQueue()
        end,
        error = function() end,
    })
end

-- ============ 到期扫描 ============
function Bank.ScanBankExpired()
    local now = os.time()
    for pid, p in pairs(ctx.players) do
        if p.bankDeposits and #p.bankDeposits > 0 then
            local i = 1
            while i <= #p.bankDeposits do
                local dep = p.bankDeposits[i]
                if dep.expiresAt and now >= dep.expiresAt then
                    local total = (dep.amount or 0) + math.floor(dep.accumulatedInterest or 0)
                    ctx.Sys.AddMail(p, "bank_expire", {
                        title = string.format("存款到期：本金 %d + 利息 %d",
                            dep.amount or 0, math.floor(dep.accumulatedInterest or 0)),
                        gold  = total,
                        items = {},
                    })
                    local entry = bankIndex_[pid]
                    if entry and entry.totalWeight and dep.amount then
                        local w = dep.amount * ((dep.term or 7) ^ 1.5)
                        entry.totalWeight = math.max(0, entry.totalWeight - w)
                        entry.depositCount = math.max(0, (entry.depositCount or 1) - 1)
                    end
                    table.remove(p.bankDeposits, i)
                else
                    i = i + 1
                end
            end
            ctx.MarkPlayerDirty(pid)
            ctx.Sys.NotifyMail(p)
        end
    end
end

return Bank
