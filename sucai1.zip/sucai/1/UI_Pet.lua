-- ============================================================
-- UI_Pet.lua：宠物面板（宠物系统 UI 层）
--
-- 职责：主面板（8 槽位 / 抽卡设置 / 待选池入口）、待选池弹窗、
--       宠物详情、抽卡结果、概率公示。
--
-- 与 Pet_System.lua 的关系：
--   · Pet_System 是纯逻辑（抽卡/升级/装/卸/加成计算）
--   · 本文件负责所有界面渲染与交互
--
-- 依赖：Shared + UI_Core + Pet_System。
-- ============================================================
local Shared = require("Shared")
local Data   = Shared.Data
local Notify = Shared.Notify

local Core   = require("UI_Core")
local Panels = Core
local PetSys = require("Pet_System")

local QLabel           = Core.QLabel
local QButton          = Core.QButton
local OpenModal        = Core.OpenModal
local OpenStackedModal = Core.OpenStackedModal

local S = Core.shared

-- ============================================================
-- 抽卡设置（模块级状态，跨面板重开保持）
-- ============================================================
local gachaState_ = {
    count      = 1,       -- 1 或 10
    eggQuality = nil,     -- 当前选中的蛋品质（nil = 无）
    useCard    = false,   -- 是否消耗在线卡指定部位
    slot       = "weapon",-- 指定部位
}

--- 确保 eggQuality 有效（无蛋时自动选第一个持有的；全无则置 nil）
local function EnsureEggQualityValid()
    local inv = Data.value.inventory
    if gachaState_.eggQuality then
        if Shared.CountPetEggsInInventory(inv, gachaState_.eggQuality) > 0 then
            return
        end
    end
    for _, q in ipairs(Shared.QUALITY_LIST) do
        if Shared.CountPetEggsInInventory(inv, q) > 0 then
            gachaState_.eggQuality = q
            return
        end
    end
    gachaState_.eggQuality = nil
end

--- 切换某个勾选项后重开面板（简单可靠）
local function RefreshPanel()
    Panels.OpenPet()
end

-- ============================================================
-- 主面板
-- ============================================================
function Panels.OpenPet()
    EnsureEggQualityValid()

    local modal = OpenModal("pet", "宠物", "xl")

    local pets = Data.value.pets or { equipped = {}, pool = {} }
    local inv = Data.value.inventory

    local body = S.UI.Panel { flexDirection = "column", gap = 8, marginTop = 6 }

    -- ============ 8 槽位（缩小版） ============
    body:AddChild(S.UI.Label {
        text = "出战槽位", fontSize = 12,
        fontColor = Shared.HexRGB("#ffcc66"),
    })

    local slotCards = {}
    for _, slotKey in ipairs(Shared.SLOT_LIST) do
        local slotDef = Shared.SLOTS[slotKey]
        local pet = pets.equipped[slotKey]

        local borderHex = "#555555"
        local qualityText = "空"
        local qualityColor = Panels.THEME_HEX.textDim
        local levelText = ""

        if pet then
            borderHex = Shared.QUALITY_COLORS[pet.quality] or "#ffffff"
            qualityText = Shared.QUALITY_NAMES[pet.quality] or pet.quality
            qualityColor = borderHex
            levelText = "Lv." .. pet.level
        end

        -- 品质行：横向布局 [品质名] [装备图标]（图标仅在已装备时显示）
        local qualityRowChildren = {
            S.UI.Label {
                text = qualityText, fontSize = 9,
                fontColor = Shared.HexRGB(qualityColor),
            },
        }
        if pet then
            table.insert(qualityRowChildren, S.UI.Label {
                text = slotDef.icon, fontSize = 11,
            })
        end

        local card = S.UI.Panel {
            width = 80, height = 48,
            backgroundColor = Panels.THEME.bgCard,
            borderColor = Shared.HexRGB(borderHex),
            borderWidth = 2,
            borderRadius = 5,
            justifyContent = "center",
            alignItems = "center",
            gap = 1,
            pointerEvents = "auto",
            children = {
                -- 槽位名（左上角）
                S.UI.Label {
                    text = slotDef.name, fontSize = 8,
                    fontColor = Shared.HexRGB("#bbb0a0"),
                    position = "absolute", top = 2, left = 4,
                },
                -- 品质行：品质名 + 装备图标
                S.UI.Panel {
                    flexDirection = "row", gap = 3, alignItems = "center",
                    children = qualityRowChildren,
                },
                -- 等级（下方）
                S.UI.Label {
                    text = levelText, fontSize = 8,
                    fontColor = Panels.THEME.textSecond,
                },
            },
        }
        local slotRef = slotKey
        if pet then
            card.props.onClick = function() Panels.ShowPetDetail(pet, slotRef) end
        else
            card.props.onClick = function() Panels.ShowPetPicker(slotRef) end
        end
        table.insert(slotCards, card)
    end

    body:AddChild(S.UI.SimpleGrid { columns = 4, gap = 8, children = slotCards })

    -- ============ 抽卡区 ============
    body:AddChild(S.UI.Divider { orientation = "horizontal", marginVertical = 6 })

    -- 标题行 + 待选池按钮
    local poolCount = #(pets.pool or {})
    body:AddChild(S.UI.Panel {
        flexDirection = "row", justifyContent = "space-between", alignItems = "center",
        children = {
            S.UI.Label {
                text = "抽卡", fontSize = 12,
                fontColor = Shared.HexRGB("#ffcc66"),
            },
            S.UI.Panel {
                flexDirection = "row", gap = 8,
                children = {
                    Panels.Btn {
                        text = "ⓘ 概率公示", fontSize = 11, height = 28, paddingHorizontal = 10,
                        variant = "secondary",
                        onClick = function() Panels.ShowPetGachaRates() end,
                    },
                    Panels.Btn {
                        text = string.format("查看待选池 (%d/%d)", poolCount, Shared.C.PET_POOL_MAX),
                        fontSize = 11, height = 28, paddingHorizontal = 10,
                        variant = "primary",
                        onClick = function() Panels.ShowPetPool() end,
                    },
                },
            },
        },
    })

    -- 数量勾选
    body:AddChild(S.UI.Panel {
        flexDirection = "row", gap = 6, alignItems = "center",
        children = {
            S.UI.Label { text = "数量：", fontSize = 11, fontColor = Panels.THEME.textSecond },
            Panels.Btn {
                text = "×1", fontSize = 11, height = 26, paddingHorizontal = 12,
                variant = (gachaState_.count == 1) and "primary" or "secondary",
                onClick = function()
                    gachaState_.count = 1
                    RefreshPanel()
                end,
            },
            Panels.Btn {
                text = "×10", fontSize = 11, height = 26, paddingHorizontal = 12,
                variant = (gachaState_.count == 10) and "primary" or "secondary",
                onClick = function()
                    gachaState_.count = 10
                    RefreshPanel()
                end,
            },
        },
    })

    -- 蛋品质勾选（只显示持有的）
    local eggBtns = {
        S.UI.Label { text = "品质：", fontSize = 11, fontColor = Panels.THEME.textSecond },
    }
    local anyEgg = false
    for _, q in ipairs(Shared.QUALITY_LIST) do
        local have = Shared.CountPetEggsInInventory(inv, q)
        if have > 0 then
            anyEgg = true
            local eggQ = q
            table.insert(eggBtns, Panels.Btn {
                text = string.format("%s ×%d", Shared.QUALITY_NAMES[q] or q, have),
                fontSize = 11, height = 26, paddingHorizontal = 10,
                variant = (gachaState_.eggQuality == q) and "primary" or "secondary",
                onClick = function()
                    gachaState_.eggQuality = eggQ
                    RefreshPanel()
                end,
            })
        end
    end
    if not anyEgg then
        table.insert(eggBtns, S.UI.Label {
            text = "没有宠物蛋", fontSize = 11,
            fontColor = Shared.HexRGB("#ff8080"),
        })
    end
    body:AddChild(S.UI.Panel {
        flexDirection = "row", gap = 6, flexWrap = "wrap", alignItems = "center",
        children = eggBtns,
    })

    -- 在线卡勾选
    local tokenCount = Shared.CountTokensInInventory(inv, "online")
    body:AddChild(S.UI.Panel {
        flexDirection = "row", gap = 6, alignItems = "center",
        children = {
            Panels.Btn {
                text = gachaState_.useCard and "☑ 消耗在线卡指定部位" or "☐ 消耗在线卡指定部位",
                fontSize = 11, height = 26, paddingHorizontal = 12,
                variant = gachaState_.useCard and "primary" or "secondary",
                onClick = function()
                    gachaState_.useCard = not gachaState_.useCard
                    RefreshPanel()
                end,
            },
            S.UI.Label {
                text = string.format("（持有 %d 张）", tokenCount),
                fontSize = 10,
                fontColor = (tokenCount > 0) and Panels.THEME.textSecond
                    or Shared.HexRGB("#ff8080"),
            },
        },
    })

    -- 部位勾选（仅在线卡勾选时显示）
    if gachaState_.useCard then
        local slotBtns = {
            S.UI.Label { text = "部位：", fontSize = 11, fontColor = Panels.THEME.textSecond },
        }
        for _, slotKey in ipairs(Shared.SLOT_LIST) do
            local sk = slotKey
            table.insert(slotBtns, Panels.Btn {
                text = Shared.SLOTS[slotKey].name,
                fontSize = 11, height = 26, paddingHorizontal = 10,
                variant = (gachaState_.slot == slotKey) and "primary" or "secondary",
                onClick = function()
                    gachaState_.slot = sk
                    RefreshPanel()
                end,
            })
        end
        body:AddChild(S.UI.Panel {
            flexDirection = "row", gap = 6, flexWrap = "wrap", alignItems = "center",
            children = slotBtns,
        })
    end

    -- 机制说明小字
    body:AddChild(S.UI.Label {
        text = "每只宠物等级上限随机（普通 10~20 … 传说 50~100）",
        fontSize = 10,
        fontColor = Panels.THEME.textDim,
    })

    -- 抽卡按钮（唯一）
    local eggQ = gachaState_.eggQuality
    local haveEgg = eggQ and Shared.CountPetEggsInInventory(inv, eggQ) > 0
    local haveToken = (not gachaState_.useCard) or tokenCount > 0
    local canGacha = haveEgg and haveToken

    -- 本次抽卡总消耗 = 单价 × 次数（count = 1 或 10）
    local unitCost = (eggQ and Shared.C.PET_GACHA_COST_GOLD[eggQ]) or 0
    local totalCost = unitCost * gachaState_.count

    -- 无蛋时按钮文案特殊处理（避免显示"0 金币"造成"免费"误解）
    local btnText
    if not haveEgg then
        btnText = "没有宠物蛋"
    else
        btnText = string.format("抽卡 ×%d（%d 金币）", gachaState_.count, totalCost)
    end

    local gachaBtn = Panels.Btn {
        text = btnText,
        fontSize = 14, height = 44, width = "100%",
        variant = canGacha and "primary" or "secondary",
        onClick = function()
            if not haveEgg then
                Notify.Toast("没有宠物蛋")
                return
            end
            if not haveToken then
                Notify.Toast("没有在线卡（指定部位需要 1 张）")
                return
            end
            Panels.DoPetGachaBatch()
        end,
    }
    body:AddChild(gachaBtn)

    modal:AddContent(body)
    modal:Open()
end

-- ============================================================
-- 待选池弹窗
-- ============================================================
function Panels.ShowPetPool()
    local pets = Data.value.pets or { pool = {} }
    local pool = pets.pool or {}

    local modal = OpenStackedModal(
        string.format("待选池 (%d/%d)", #pool, Shared.C.PET_POOL_MAX), "xl")

    if #pool == 0 then
        modal:AddContent(QLabel("待选池为空", "#888888", 12))
        modal:SetFooter(S.UI.Panel {
            flexDirection = "row", justifyContent = "flex-end",
            children = { QButton("关闭", function() modal:Close() end) },
        })
        modal:Open()
        return
    end

    local cards = {}
    for _, pet in ipairs(pool) do
        local qcolor = Shared.QUALITY_COLORS[pet.quality] or "#ffffff"
        local card = S.UI.Panel {
            width = 72, height = 72,
            backgroundColor = Panels.THEME.bgCard,
            borderColor = Shared.HexRGB(qcolor),
            borderWidth = 2,
            borderRadius = 6,
            justifyContent = "center",
            alignItems = "center",
            gap = 2,
            pointerEvents = "auto",
            children = {
                S.UI.Label { text = Shared.SLOTS[pet.slot].icon, fontSize = 20 },
                S.UI.Label {
                    text = Shared.QUALITY_NAMES[pet.quality] or pet.quality,
                    fontSize = 8,
                    fontColor = Shared.HexRGB(qcolor),
                },
                S.UI.Label {
                    text = "上限 " .. (pet.maxLevel or "?") .. " · Lv." .. pet.level,
                    fontSize = 8,
                    fontColor = Panels.THEME.textSecond,
                },
            },
        }
        local petRef = pet
        card.props.onClick = function() Panels.ShowPetDetail(petRef, nil) end
        table.insert(cards, card)
    end

    modal:AddContent(S.UI.ScrollView {
        flexGrow = 1, flexBasis = 0, maxHeight = 400,
        children = {
            S.UI.SimpleGrid { columns = 8, gap = 8, children = cards },
        },
    })
    modal:SetFooter(S.UI.Panel {
        flexDirection = "row", justifyContent = "flex-end",
        children = { QButton("关闭", function() modal:Close() end) },
    })
    modal:Open()
end

-- ============================================================
-- 宠物详情弹窗
-- ============================================================
---@param pet table
---@param equippedSlot string|nil 若在槽位上，传入槽位 key；nil 表示在池中
function Panels.ShowPetDetail(pet, equippedSlot)
    local modal = OpenStackedModal(PetSys.GetName(pet), "lg")

    local qcolor = Shared.QUALITY_COLORS[pet.quality] or "#ffffff"
    local cap = pet.maxLevel or Shared.PET_QUALITY_MAX_LEVEL[pet.quality] or 20

    -- 激活属性列表
    local attrTexts = {}
    for attr, _ in pairs(pet.activatedAttrs or {}) do
        local def = Shared.MOD_DEFS[attr]
        if def then table.insert(attrTexts, def.name) end
    end
    table.sort(attrTexts)

    local rows = {
        QLabel("品质：" .. (Shared.QUALITY_NAMES[pet.quality] or pet.quality), qcolor, 13),
        QLabel("部位：" .. (Shared.SLOTS[pet.slot].name or pet.slot), "#dddddd", 12),
        QLabel(string.format("等级：Lv.%d / 上限 %d", pet.level, cap), "#dddddd", 12),
        QLabel(string.format("固定特性：+%d%%（作用于基础词缀）", pet.fixedTrait),
            "#9fd8ff", 12),
        QLabel(string.format("激活属性加成：+%d%%（作用于随机词缀）", pet.level),
            "#9fd8ff", 12),
        QLabel("激活属性：" .. (#attrTexts > 0 and table.concat(attrTexts, " / ") or "无"),
            "#aaffcc", 11),
    }

    modal:AddContent(S.UI.Panel {
        flexDirection = "column", gap = 6,
        children = rows,
    })

    -- 按钮区
    local btns = {}
    if equippedSlot then
        table.insert(btns, QButton("卸下", function()
            local ok, reason = PetSys.UnequipPet(equippedSlot)
            if not ok then Notify.Toast(reason or "卸下失败"); return end
            modal:Close()
            Panels.OpenPet()
        end, "secondary"))
    else
        table.insert(btns, QButton("装上", function()
            local ok, reason = PetSys.EquipPet(pet.id)
            if not ok then Notify.Toast(reason or "装上失败"); return end
            modal:Close()
            -- 若在待选池弹窗内，重开它；否则开主面板
            Panels.ShowPetPool()
        end, "primary"))

        table.insert(btns, QButton("转换为材料", function()
            Panels.Confirm("转换为材料",
                string.format("将 %s 转换为 1 个%s？\n此操作不可撤销。",
                    PetSys.GetName(pet),
                    (Shared.PET_MATERIAL_DISPLAY[pet.quality] or {}).name or "材料"),
                function()
                    local ok, reason = PetSys.ConvertPetToMaterial(pet.id)
                    if not ok then Notify.Toast(reason or "转换失败"); return end
                    Notify.Toast("已转换为材料")
                    Panels.ShowPetPool()
                end)
        end, "danger"))
    end

    -- 放入背包（池中或槽位都支持；从槽位放入时直接跳过待选池）
    table.insert(btns, QButton("📦 放入背包", function()
        Panels.Confirm("放入背包",
            string.format("将「%s」放入背包？\n\n放入后可上架交易行。",
                PetSys.GetName(pet)),
            function()
                local ok, reason = PetSys.MoveToInventory(pet.id)
                if not ok then Notify.Toast(reason or "放入失败"); return end
                Notify.Toast("已放入背包")
                modal:Close()
                -- 根据来源返回对应面板
                if equippedSlot then
                    Panels.OpenPet()
                else
                    Panels.ShowPetPool()
                end
            end)
    end, "secondary"))

    -- 升级按钮（带确认弹窗）
    local upCost = pet.level
    local canUp = pet.level < cap
    -- 需要的材料种数 = 品质 rank + 1（普通 1 种、优秀 2 种、……、传说 5 种）
    local materialKinds = (Shared.QUALITY_RANK[pet.quality] or 0) + 1

    table.insert(btns, QButton(
        canUp and string.format("升级（需 %d 种材料 ×%d）", materialKinds, upCost)
              or "已满级",
        function()
            if not canUp then return end

            -- 组装消耗明细
            local petRank = Shared.QUALITY_RANK[pet.quality] or 0
            local lines = {
                string.format("升级 Lv.%d → Lv.%d（上限 %d）",
                    pet.level, pet.level + 1, cap),
                "",
                "需要以下材料：",
            }
            for _, q in ipairs(Shared.QUALITY_LIST) do
                if (Shared.QUALITY_RANK[q] or 0) <= petRank then
                    local disp = Shared.PET_MATERIAL_DISPLAY[q]
                    local have = Shared.CountPetMaterialsInInventory(Data.value.inventory, q)
                    local enough = have >= upCost
                    table.insert(lines, string.format("· %s ×%d（持有 %d）%s",
                        disp and disp.name or q, upCost, have,
                        enough and "" or " ⚠️"))
                end
            end

            Panels.Confirm("确认升级", table.concat(lines, "\n"), function()
                local ok, reason = PetSys.UpgradePet(pet.id)
                if not ok then Notify.Toast(reason or "升级失败"); return end
                Notify.Toast("升级成功")
                modal:Close()
                Panels.ShowPetDetail(pet, equippedSlot)
            end)
        end,
        canUp and "success" or "secondary"))

    modal:SetFooter(S.UI.Panel {
        flexDirection = "row", justifyContent = "flex-end", gap = 8,
        children = btns,
    })
    modal:Open()
end

-- ============================================================
-- 选择宠物装入槽位（从空槽位进入）
-- ============================================================
---@param slotKey string
function Panels.ShowPetPicker(slotKey)
    local pets = Data.value.pets or { pool = {} }
    local candidates = {}
    for _, p in ipairs(pets.pool) do
        if p.slot == slotKey then table.insert(candidates, p) end
    end

    local modal = OpenStackedModal("选择 " .. Shared.SLOTS[slotKey].name .. " 宠物", "lg")

    if #candidates == 0 then
        modal:AddContent(QLabel("待选池中没有该部位的宠物", "#888888", 12))
        modal:SetFooter(S.UI.Panel {
            flexDirection = "row", justifyContent = "flex-end",
            children = { QButton("关闭", function() modal:Close() end) },
        })
        modal:Open()
        return
    end

    local cards = {}
    for _, p in ipairs(candidates) do
        local qcolor = Shared.QUALITY_COLORS[p.quality] or "#ffffff"
        local card = S.UI.Panel {
            -- 高度从 80 加到 92：容纳 4 行信息（图标 / 品质 / 上限·等级 / 固定特性）
            width = 80, height = 92,
            backgroundColor = Panels.THEME.bgCard,
            borderColor = Shared.HexRGB(qcolor),
            borderWidth = 2,
            borderRadius = 6,
            justifyContent = "center",
            alignItems = "center",
            gap = 2,
            pointerEvents = "auto",
            children = {
                S.UI.Label { text = Shared.SLOTS[p.slot].icon, fontSize = 20 },
                S.UI.Label {
                    text = Shared.QUALITY_NAMES[p.quality] or p.quality,
                    fontSize = 9, fontColor = Shared.HexRGB(qcolor),
                },
                S.UI.Label {
                    text = "上限 " .. (p.maxLevel or "?") .. " · Lv." .. p.level,
                    fontSize = 8, fontColor = Panels.THEME.textSecond,
                },
                S.UI.Label {
                    text = "固定 +" .. p.fixedTrait .. "%",
                    fontSize = 8, fontColor = Shared.HexRGB("#9fd8ff"),
                },
            },
        }
        local petRef = p
        card.props.onClick = function()
            local ok, reason = PetSys.EquipPet(petRef.id)
            if not ok then Notify.Toast(reason or "装上失败"); return end
            modal:Close()
            Panels.OpenPet()
        end
        table.insert(cards, card)
    end

    modal:AddContent(S.UI.ScrollView {
        flexGrow = 1, flexBasis = 0, maxHeight = 360,
        children = { S.UI.SimpleGrid { columns = 6, gap = 8, children = cards } },
    })
    modal:SetFooter(S.UI.Panel {
        flexDirection = "row", justifyContent = "flex-end",
        children = { QButton("取消", function() modal:Close() end) },
    })
    modal:Open()
end

-- ============================================================
-- 批量抽卡
-- ============================================================
function Panels.DoPetGachaBatch()
    local eggQ = gachaState_.eggQuality
    local count = gachaState_.count
    local slot = gachaState_.useCard and gachaState_.slot or nil

    local results = {}
    for i = 1, count do
        local pet, reason = PetSys.DoGacha(eggQ, slot)
        if not pet then
            if i == 1 then
                Notify.Toast(reason or "抽卡失败")
                return
            else
                Notify.Toast("第 " .. i .. " 抽失败：" .. (reason or ""))
                break
            end
        end
        table.insert(results, pet)
    end
    if #results == 0 then return end
    Panels.ShowGachaResult(results)
end

-- ============================================================
-- 抽卡结果弹窗
-- ============================================================
---@param results table[]
function Panels.ShowGachaResult(results)
    local modal = OpenStackedModal(string.format("抽卡结果 ×%d", #results), "lg")

    local cards = {}
    for _, pet in ipairs(results) do
        local qcolor = Shared.QUALITY_COLORS[pet.quality] or "#ffffff"
        local isHighQuality = (pet.quality == "legendary" or pet.quality == "mythic")
        local card = S.UI.Panel {
            width = 90, height = 100,
            backgroundColor = Panels.THEME.bgCard,
            borderColor = Shared.HexRGB(isHighQuality and "#ffdd44" or qcolor),
            borderWidth = isHighQuality and 3 or 2,
            borderRadius = 8,
            justifyContent = "center",
            alignItems = "center",
            gap = 3,
            children = {
                S.UI.Label { text = Shared.SLOTS[pet.slot].icon, fontSize = 26 },
                S.UI.Label {
                    text = Shared.QUALITY_NAMES[pet.quality] or pet.quality,
                    fontSize = 10, fontColor = Shared.HexRGB(qcolor),
                },
                -- 上限是抽卡的核心惊喜点，用金色突出显示
                S.UI.Label {
                    text = "上限 " .. (pet.maxLevel or "?"),
                    fontSize = 9, fontColor = Shared.HexRGB("#ffdd44"),
                },
                -- 等级 + 固定特性合并成一行，节省空间
                S.UI.Label {
                    text = "Lv." .. pet.level .. " · 固定 +" .. pet.fixedTrait .. "%",
                    fontSize = 8, fontColor = Panels.THEME.textSecond,
                },
            },
        }
        table.insert(cards, card)
    end

    modal:AddContent(S.UI.Panel {
        flexDirection = "column", gap = 8,
        children = {
            S.UI.Label {
                text = "已放入待选池", fontSize = 11,
                fontColor = Panels.THEME.textSecond,
            },
            S.UI.SimpleGrid { columns = 5, gap = 8, children = cards },
        },
    })
    modal:SetFooter(S.UI.Panel {
        flexDirection = "row", justifyContent = "flex-end",
        children = {
            QButton("确认", function()
                modal:Close()
                if Panels.GetCurrentId() == "pet" then
                    Panels.OpenPet()
                end
            end, "primary"),
        },
    })
    modal:Open()
end

-- ============================================================
-- 概率公示
-- ============================================================
function Panels.ShowPetGachaRates()
    local modal = OpenStackedModal("抽卡概率公示", "md")

    local lines = {
        "每个池子独立保底（50 连必出保底品质）",
        "",
        "普通池：普通 100%（1000 金币/次）",
        "优秀池：普通 64.3% / 优秀 35.7%（2000 金币/次）",
        "精良池：普通 51.1% / 优秀 28.4% / 精良 11.4%（3000 金币/次）",
        "史诗池：普通 54.9% / 优秀 30.4% / 精良 12.2% / 史诗 2.5%（4000 金币/次）",
        "传说池：普通 54% / 优秀 30% / 精良 12% / 史诗 2% / 传说 2%（5000 金币/次）",
        "",
        "【等级上限】",
        "所有宠物抽到时都是 Lv.1，等级上限随机，决定培养潜力和满级消耗。",
        "",
        "普通：10~20    优秀：20~40    精良：30~60",
        "史诗：40~80    传说：50~100",
        "",
        "【保底规则】",
        "· 每个池子独立计数",
        "· 累计 50 抽必出保底品质（含更高品质）",
        "· 传说池的保底为：史诗或传说（各 50%）",
        "· 出保底品质后计数器清零",
    }

    modal:AddContent(S.UI.Panel {
        flexDirection = "column", gap = 3,
        children = {
            S.UI.Label {
                text = table.concat(lines, "\n"),
                fontSize = 11,
                fontColor = Panels.THEME.textPrimary,
                maxLines = 0,
                whiteSpace = "normal",
            },
        },
    })
    modal:SetFooter(S.UI.Panel {
        flexDirection = "row", justifyContent = "flex-end",
        children = { QButton("关闭", function() modal:Close() end) },
    })
    modal:Open()
end

return Panels
