-- ============================================================
-- Client_Ad.lua：激励广告（Client.lua 的兄弟文件）
--
-- 职责：请求 / 播放激励视频广告，发奖或弹错；含加载弹窗与无回调兜底。
--
-- 与 Client.lua 共享：广告流程只依赖三个单例模块（require 即得同一实例），
--   因此不需要额外的注入容器：
--     · Shared      （Data / Notify / UIState / AddTokenToInventory / C）
--     · Client_Network（Net.ForceSyncNow）
--     · UI_Core     （Panels.RefreshIfOpen / OpenOnline）
--     · urhox-libs/UI（加载弹窗控件）
--
-- ⚠️ rewardType 目前只有 "online"（奖励在线卡）。
--
-- 跨文件调用走 Ad.*：
--   Ad.Request(rewardType)   ← Client.lua 的 RequestAd 别名（面板回调入口）
--   Ad.PlayRewardAd(rewardType)
--   Ad.Tick(dt)              ← Client.lua 主循环每帧调用（无回调兜底倒计时）
--
-- 依赖：Shared + Client_Network + UI_Core + urhox-libs/UI。
--       **不 require Client.lua**（避免循环）。
-- ============================================================
local Shared = require("Shared")
local Net    = require("Client_Network")
local Panels = require("UI_Core")
local UI     = require("urhox-libs/UI")

local Data   = Shared.Data
local Notify = Shared.Notify

local Ad = {}

-- ============ 广告兜底状态 ============
-- （原声明在 Client.lua 顶部，随广告逻辑一并迁入）
-- 广告无回调兜底（主循环倒计时，声明须早于 Update 使用点）
-- SDK 既没返回 false 也一直不回调时（宿主异常/被系统回收）用它收尾，
-- 避免按钮永久卡在「加载中」。只作失败收尾、绝不推断成功。
local AD_WATCHDOG_SECONDS = 90
local adWatchdog_ = 0        -- 剩余秒数，> 0 表示正在等待回调
local adTimeoutFn_ = nil     -- 超时后调用的收尾函数

--- 每帧驱动无回调兜底倒计时（由 Client.lua 主循环调用）。
--- SDK 既没返回 false 也一直不回调时（宿主异常/被系统回收）用它收尾，
--- 避免按钮永久卡在「加载中」。只作失败收尾、绝不推断成功。
---@param dt number
function Ad.Tick(dt)
    if adWatchdog_ > 0 then
        adWatchdog_ = adWatchdog_ - dt
        if adWatchdog_ <= 0 then
            adWatchdog_ = 0
            local fn = adTimeoutFn_
            adTimeoutFn_ = nil
            if fn then fn() end
        end
    end
end

-- ============ 激励广告 ============
-- 模块级「进行中」标志：跨调用防重入。
-- 之前每次调用各自持有局部 completed，连点两次会发起两次广告请求，
-- 两次都成功时 adCountToday 会 +2 且重复发奖。
local adInFlight_ = false
-- 兜底状态 adWatchdog_ / adTimeoutFn_ / AD_WATCHDOG_SECONDS 声明在文件顶部全局状态区

-- 广告加载弹窗（点击后立刻显示，等 SDK 回调）
---@type Modal|nil
local adLoadingModal_ = nil
local adLoadingPrevModalOpen_ = false   -- 弹窗出现前的 modalOpen，关闭时还原

--- 把 SDK 原始错误翻译成玩家能看懂的话。
--- 原始 msg 只写日志：直接弹给玩家会暴露英文错误码和内部配置项
--- （例如 "embed ad_id not configured"）。
---@param msg string|nil
---@return string
local function AdFailText(msg)
    local s = tostring(msg or "")
    if s:find("manual close", 1, true) then
        return "需完整观看广告才能领取奖励"
    end
    if s:find("unsupported", 1, true) then
        return "当前设备暂不支持广告"
    end
    return "广告暂时不可用，请稍后再试"
end

--- 显示「正在加载广告」弹窗（点击后立即调用）
local function ShowAdLoading()
    if adLoadingModal_ then return end
    -- 记住原状态：玩家多半是开着某个面板点的广告，关弹窗时要还回去
    adLoadingPrevModalOpen_ = Shared.UIState.modalOpen
    adLoadingModal_ = UI.Modal {
        title = "加载广告",
        size = "sm",
        closeOnOverlay = false,
        closeOnEscape  = false,
        showCloseButton = false,
    }
    adLoadingModal_:AddContent(UI.Panel {
        flexDirection = "column", gap = 6, alignItems = "center",
        children = {
            UI.Label { text = "正在加载广告，请稍候…", fontSize = 13 },
            UI.Label {
                text = "加载完成后将自动播放",
                fontSize = 11,
                fontColor = "#999999",
            },
        },
    })
    adLoadingModal_:Open()
    -- 加载期间屏蔽摇杆 / 视角拖动，避免玩家在广告弹出前跑位
    Shared.UIState.modalOpen = true
end

--- 关闭加载弹窗并还原 modalOpen
local function HideAdLoading()
    if not adLoadingModal_ then return end
    adLoadingModal_:Close()
    adLoadingModal_ = nil
    Shared.UIState.modalOpen = adLoadingPrevModalOpen_
end

---@param rewardType string
function Ad.PlayRewardAd(rewardType)
    if adInFlight_ then
        -- 此时加载弹窗已经开着，不再叠一条 Toast
        return
    end

    -- 非内嵌宿主（预览/PC/Web）可能没有 sdk，直接调用会抛 Lua 错误并让按钮看起来「点了没反应」
    ---@type table
    local sdkApi = sdk
    if not (sdkApi and sdkApi.ShowRewardVideoAd) then
        HideAdLoading()
        Notify.Toast("当前环境暂不支持广告")
        return
    end

    adInFlight_ = true
    local completed = false
    local callbackFired = false
    print("[Client] 发起激励广告请求，rewardType=" .. tostring(rewardType))

    -- 立刻给玩家反馈：广告 SDK 冷启动要几秒，期间界面不能毫无动静
    ShowAdLoading()

    local function Finish(result)
        if completed then return end
        completed = true
        adInFlight_ = false
        -- 任何收尾路径（回调 / 同步拒绝 / 异常 / 超时）都要停掉兜底倒计时并收起弹窗
        adWatchdog_ = 0
        adTimeoutFn_ = nil
        HideAdLoading()
        print(string.format("[Client] 广告回调：success=%s msg=%s",
            tostring(result and result.success), tostring(result and result.msg)))
        if result and result.success then
            Shared.AddTokenToInventory(Data.value.inventory, rewardType, 1)
            Data.value.adCountToday = Data.value.adCountToday + 1
            Data.value.adCooldownLeft = Shared.C.AD_COOLDOWN_SECONDS
            Data.value.adLastTime = os.time()
            Data.MarkDirty("inventory")
            -- ⚠️ 必须标脏 ad：否则 adCountToday 只活在客户端内存里，
            --    每次重连服务端都会下发 AdCountToday=0 把它清零 → 每日 20 次限制形同虚设。
            Data.MarkDirty("ad")
            Net.ForceSyncNow()
            -- ⚠️ 面板上的卡数是打开时算好的一次性快照，发奖后不重建就停在旧数字，
            --    玩家看到「26 张」而背包里其实已经 27 张 → 会误以为奖励没到账。
            Panels.RefreshIfOpen("online", Panels.OpenOnline)
            Notify.Toast("奖励已发放到背包")
        else
            -- 原始 SDK 错误只进日志，玩家看到的是人话（见 AdFailText）
            Notify.Toast(AdFailText(result and result.msg))
        end
    end

    -- pcall 兜底：SDK 抛错时也必须走 Finish 复位 adInFlight_，否则按钮会永久卡住
    local ok, accepted = pcall(function()
        return sdkApi:ShowRewardVideoAd(function(result)
            callbackFired = true
            Finish(result)
        end)
    end)

    if not ok then
        print("[Client] ShowRewardVideoAd 调用异常：" .. tostring(accepted))
        Finish({ success = false, msg = "广告调用失败" })
        return
    end

    if accepted == false and not callbackFired then
        Finish({ success = false, msg = "广告暂不可用，请稍后重试" })
        return
    end

    -- 走到这里说明请求已被受理、正在等回调 → 启动兜底。
    -- 回调若在当前调用栈内已同步触发，completed 已为 true，上面会提前 return，
    -- 这里再判一次是为了防御「同步触发但 accepted 恰好不是 false」的情形。
    if not completed then
        adWatchdog_ = AD_WATCHDOG_SECONDS
        adTimeoutFn_ = function()
            print("[Client] 广告等待回调超时，判定为失败并复位按钮")
            Finish({ success = false, msg = "广告响应超时，请稍后重试" })
        end
    end
end

-- ============ 广告请求 ============
---@param rewardType string
function Ad.Request(rewardType)
    local d = Data.value
    -- 每日重置检查
    local today = Shared.TodayString()
    if d.lastResetDate ~= today then
        d.adCountToday = 0
        d.adLastTime = 0
        d.lastResetDate = today
    end
    if d.adCooldownLeft > 0 then
        Notify.Toast(string.format("广告冷却中，还需 %.0f 秒", d.adCooldownLeft))
        return
    end
    if d.adCountToday >= Shared.C.AD_DAILY_LIMIT then
        Notify.Toast("今日广告次数已用完")
        return
    end
    Ad.PlayRewardAd(rewardType)
end

return Ad
