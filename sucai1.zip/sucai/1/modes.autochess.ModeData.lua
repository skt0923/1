-- ============================================================
-- 卡牌自走棋：玩法内共享数据
--
-- 只放静态数据，不放逻辑。
-- ============================================================
local AcShared = {}

-- ============ 游戏模式 ============
AcShared.GAME_MODES = {
    { id = "duel",  name = "双人对决", maxPlayers = 2, minPlayers = 2 },
    { id = "squad", name = "四人乱斗", maxPlayers = 4, minPlayers = 4 },
    { id = "full",  name = "八人排位", maxPlayers = 8, minPlayers = 8 },
}

return AcShared
