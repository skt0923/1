-- ============================================================
-- Main.lua：引擎入口
--
-- 引擎固定按这个名字找 Start / Stop，不能改名、不能合并。
-- 这里只做模式分发，不包含任何业务逻辑。
-- ============================================================
local Module = nil

function Start()
    if IsServerMode() then
        Module = require("Server")
    elseif IsClientMode() then
        Module = require("Client")
    else
        print("[Main] ⚠️ 既非服务器模式也非客户端模式，未启动任何逻辑")
        return
    end

    if Module and Module.Start then
        Module.Start()
    end
end

function Stop()
    if Module and Module.Stop then
        Module.Stop()
    end
end
