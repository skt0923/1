-- ============================================================
-- UI_Enhance.lua：围绕「装备强化」的功能域
--
-- 内容：强化 / 锻造 / 技能重铸 / 属性重铸
--
-- 依赖：Shared + UI_Core（共享基础设施）。
--       与另一个功能域**不 require**，跨域调用走 Panels.X
--       （三个文件写入同一张表，见 UI_Core 顶部说明）。
-- ============================================================
local Shared = require("Shared")
local Data   = Shared.Data
local Notify = Shared.Notify

local Core = require("UI_Core")

-- 与 UI_Core 共用同一张 Panels 表
local Panels = Core

-- 无状态通用控件（加载时捕获即可）
local QLabel           = Core.QLabel
local QButton          = Core.QButton
local OpenModal        = Core.OpenModal

-- ⚠️ 注入值走稳定容器：Panels.Init / SetStatProvider 在运行时填充，
--    不能在这里取局部量（那会是 nil）。用短别名保持代码可读。
local S = Core.shared


-- ============================================================
-- 强化 / 锻造 / 重铸
-- ============================================================
local enhanceTab_ = "enhance"

-- 重铸锁定状态：模块级保存，重建 Modal 时不会丢失。
-- key 用 itemId，value 是 { [skillId] = true }。
-- ⚠️ 不能用「技能列表索引」做 key —— 重铸后技能构成变化，索引会错位锁到别的技能。
---@type table<string, table<string, boolean>>
local reforgeLocks_ = {}

--- 按物品所在位置标脏：装备栏 → "equipment"，背包 → "inventory"。
--- ⚠️ 强化/锻造/重铸的对象可能是已穿戴的装备，只标 "inventory" 会导致
---    装备栏改动不上报（服务端与本地脱节）。
--- ⚠️ 必须定义在 _BuildReforgeLockBody / DoEnhance / DoForge / DoReforge 之前：
---    Lua 的 local 作用域从声明处开始，定义在后面会让前面的调用解析成全局 nil。
---@param item table|nil
local function MarkItemDirty(item)
    if not item or not item.id then return end
    local _, slot = Data.FindEquipmentItem(item.id)
    if slot then
        Data.MarkDirty("equipment")
    else
        Data.MarkDirty("inventory")
    end
end

--- 清理已不在背包/装备栏的重铸锁定记录（物品被分解/上架后释放）
--- ⚠️ 必须定义在 OpenEnhance 之前：Lua 的 local 作用域从声明处开始，
---    定义在后面会让前面的调用解析成全局 nil。
local function GCReforgeLocks()
    local valid = {}
    for _, it in ipairs(Data.value.inventory or {}) do
        if it.id then valid[it.id] = true end
    end
    for _, eq in pairs(Data.value.equipment or {}) do
        if eq and eq.id then valid[eq.id] = true end
    end
    for id in pairs(reforgeLocks_) do
        if not valid[id] then reforgeLocks_[id] = nil end
    end
end

--- 指定标签页打开强化面板（HUD 三个入口分别落到对应页）
---@param tab string  "enhance" | "forge" | "reforge"
function Panels.OpenEnhanceTab(tab)
    enhanceTab_ = tab
    Panels.OpenEnhance()
end

function Panels.OpenEnhance()
    GCReforgeLocks()
    local modal = OpenModal("enhance", "强化 / 锻造 / 重铸", "lg")

    local tabs = {}
    local function Tab(id, label)
        table.insert(tabs, Panels.Btn {
            text = label, fontSize = 13, height = 40, paddingHorizontal = 16,
            variant = (enhanceTab_ == id) and "primary" or "secondary",
            onClick = function()
                enhanceTab_ = id
                Panels.OpenEnhance()
            end,
        })
    end
    Tab("enhance", "强化")
    Tab("forge", "锻造")
    Tab("reforge", "技能重铸")
    Tab("attrreforge", "属性重铸")

    -- 各标签页的说明文字
    local hint = ""
    if enhanceTab_ == "enhance" then
        hint = "消耗同品质碎片与金币，提升装备强化等级（有失败概率）。"
    elseif enhanceTab_ == "forge" then
        hint = "消耗两件满强化底材（上一品质 + 当前品质各一件）"
            .. "以及对应碎片/精魄，产出随机部位的当前品质锻造装备。"
            .. "材料会按 1%~100% 随机比例返还。"
    elseif enhanceTab_ == "attrreforge" then
        hint = "消耗金币重铸属性词条。未锁定的词条将 100% 消失，"
            .. "每次最多新增 1 条。锁定条数越多，新增成功率越低。"
    else
        hint = "仅限锻造装备。重铸会清空未锁定的技能词条并重新随机填充，"
            .. "每次最多新增 1 条，锁定条数越多成功率越低。"
    end

    local body = S.UI.Panel { flexDirection = "column", gap = 6, marginTop = 6 }

    if enhanceTab_ == "enhance" then
        Panels.BuildEnhanceList(body)
    elseif enhanceTab_ == "forge" then
        Panels.BuildForgeList(body)
    elseif enhanceTab_ == "attrreforge" then
        Panels.BuildAttrReforgeList(body)
    else
        Panels.BuildReforgeList(body)
    end

    modal:AddContent(S.UI.Panel {
        flexDirection = "column", gap = 6,
        children = {
            S.UI.Panel { flexDirection = "row", gap = 8, children = tabs },
            QLabel(hint, Panels.THEME_HEX.textSecond, 10),
            S.UI.ScrollView { flexGrow = 1, flexBasis = 0, maxHeight = 340, children = { body } },
        },
    })
    modal:Open()
end

--- 收集候选装备（装备栏 + 背包）
---@param filter? fun(item: table): boolean
---@return table[]
local function CollectEquipment(filter)
    local list = {}
    for _, eq in pairs(Data.value.equipment) do
        if eq and (not filter or filter(eq)) then table.insert(list, eq) end
    end
    for _, it in ipairs(Data.value.inventory) do
        if Shared.IsEquipment(it) and (not filter or filter(it)) then table.insert(list, it) end
    end
    return list
end

--- 装备图标：优先物品自带 icon，退回槽位默认图标
---@param it table
---@return string
local function EquipIcon(it)
    if it.icon then return it.icon end
    local def = Shared.SLOTS[it.slot]
    return (def and def.icon) or "?"
end

--- 碎片消耗摘要，形如 "⬜12/3 🟦8/3"（现有/需要）
---@param costMap table<string, integer>
---@return string
local function FragmentCostText(costMap)
    local parts = {}
    for _, q in ipairs(Shared.QUALITY_LIST) do
        local n = costMap[q]
        if n then
            local disp = Shared.FRAGMENT_DISPLAY[q]
            local have = Shared.CountFragmentsInInventory(Data.value.inventory, q)
            parts[#parts + 1] = string.format("%s%d/%d", disp and disp.icon or "⬜", have, n)
        end
    end
    return table.concat(parts, " ")
end

--- 精魄消耗摘要，形如 "⚪2/1 🔵5/5"（现有/需要）。
--- ⚠️ 不能用 FragmentCostText：它用碎片图标和碎片库存查询，套在精魄表上会显示错数据。
---@param costMap table<string, integer>
---@return string
local function SpiritCostText(costMap)
    local parts = {}
    for _, q in ipairs(Shared.QUALITY_LIST) do
        local n = costMap[q]
        if n then
            local disp = Shared.SPIRIT_DISPLAY[q]
            local have = Shared.CountSpiritsInInventory(Data.value.inventory, q)
            parts[#parts + 1] = string.format("%s%d/%d", disp and disp.icon or "⚪", have, n)
        end
    end
    return table.concat(parts, " ")
end

---@param parent Panel
function Panels.BuildEnhanceList(parent)
    -- 只列「未满强化」的装备：满强化的强化无意义，且下面第二行显示的是
    -- 「下一级预览」，满强化时 +1 会渲染成 maxEnhance+1，看起来像突破上限。
    local candidates = CollectEquipment(function(it)
        local cap = it.maxEnhance or Shared.QUALITY_MAX_ENHANCE[it.quality] or 20
        return (it.enhanceLevel or 0) < cap
    end)
    if #candidates == 0 then
        parent:AddChild(QLabel("没有可强化的装备", Panels.THEME_HEX.textDim))
        return
    end

    local cards = {}
    for i, it in ipairs(candidates) do
        if i > 12 then break end
        local rate = Shared.ENHANCE_RATES[it.enhanceLevel or 0] or 0.5
        local rateColor = rate >= 0.9 and "#80ff80" or (rate >= 0.7 and "#ffd24d" or "#ff8080")
        local costText = FragmentCostText(Shared.GetEnhanceCostMap(it.quality, it.enhanceLevel or 0))
        local qcolor = Shared.QUALITY_COLORS[it.quality] or "#ffffff"
        -- 金币消耗：不够时整行标红（优先于成功率配色）
        local goldCost = Shared.GetEnhanceGoldCost(it.quality)
        local haveGold = Data.value.gold or 0
        local goldText = "💰 " .. haveGold .. "/" .. goldCost
        if haveGold < goldCost then rateColor = "#ff6666" end

        table.insert(cards, S.UI.Panel {
            flexDirection = "row", alignItems = "center",
            height = 56, paddingHorizontal = 8, gap = 8,
            backgroundColor = Panels.THEME.bgCard, borderRadius = 6,
            children = {
                -- 图标
                S.UI.Label { text = EquipIcon(it), fontSize = 20, width = 32, textAlign = "center" },
                -- 信息
                S.UI.Panel {
                    flexDirection = "column", flexGrow = 1, flexShrink = 1, gap = 2,
                    children = {
                        S.UI.Label {
                            text = (it.name or "?") .. " +" .. (it.enhanceLevel or 0)
                                .. "/" .. (it.maxEnhance or 20),
                            fontSize = 11, fontColor = Shared.HexRGB(qcolor), maxLines = 1,
                        },
                        S.UI.Label {
                            -- 下一级预览：夹到上限内，避免满强化时显示成 maxEnhance+1
                            text = "+" .. math.min((it.enhanceLevel or 0) + 1, it.maxEnhance or 20)
                                .. "/" .. (it.maxEnhance or 20)
                                .. " | " .. costText .. " | " .. goldText
                                .. " | 成功率 " .. string.format("%.1f%%", rate * 100),
                            fontSize = 9, fontColor = Shared.HexRGB(rateColor), maxLines = 1,
                        },
                    },
                },
                -- 按钮
                QButton("强化", function() Panels.DoEnhance(it) end, "success"),
            },
        })
    end
    parent:AddChild(S.UI.SimpleGrid { columns = 2, gap = 8, children = cards })
end

---@param parent Panel
function Panels.BuildForgeList(parent)
    -- 收集所有满强化未锻造的装备
    local allCandidates = CollectEquipment(function(it)
        return (it.enhanceLevel or 0) >= (it.maxEnhance or 20) and not it.forged
    end)

    -- 按品质分类
    local byQuality = {}
    for _, it in ipairs(allCandidates) do
        byQuality[it.quality] = byQuality[it.quality] or {}
        table.insert(byQuality[it.quality], it)
    end

    -- 收集可锻造的品质。
    -- ⚠️ 只要该品质本身有满强化底材，就把它的 tab 列出来（哪怕上一品质暂时缺货），
    --    缺配对件时在栏内明确提示。旧实现要求「上一品质 + 当前品质」都齐才出现 tab，
    --    一旦缺一件整组就消失，玩家会以为「装备不能当底材」。
    local forgeable = {}
    for qi, q in ipairs(Shared.QUALITY_LIST) do
        if #(byQuality[q] or {}) > 0 then
            table.insert(forgeable, {
                quality = q,
                prev = (qi == 1) and nil or Shared.QUALITY_LIST[qi - 1],
            })
        end
    end

    if #forgeable == 0 then
        -- 空状态：列出各品质满强化底材数量，帮助定位为什么没有候选
        local detail = {}
        for _, q in ipairs(Shared.QUALITY_LIST) do
            table.insert(detail, string.format("%s×%d",
                Shared.QUALITY_NAMES[q] or q, #(byQuality[q] or {})))
        end
        parent:AddChild(QLabel("没有可锻造的底材（需满强化且未锻造）", Panels.THEME_HEX.textDim, 10))
        parent:AddChild(QLabel("各品质满强化数量：" .. table.concat(detail, " "),
            Panels.THEME_HEX.textDim, 10))
        return
    end

    -- 找当前选中的品质组合
    -- ⚠️ 用 found 标志而不是 `if not activePrev`：
    --    普通品质的 prev 就是 nil，用 prev 判空会误判为「未找到」，
    --    导致选普通时被强制跳回 forgeable[1]。
    local activeQ = Panels._forgeSelectedQuality or forgeable[1].quality
    local activePrev = nil
    local found = false
    for _, f in ipairs(forgeable) do
        if f.quality == activeQ then
            activePrev = f.prev
            found = true
            break
        end
    end
    if not found then
        activeQ = forgeable[1].quality
        activePrev = forgeable[1].prev
    end
    Panels._forgeSelectedQuality = activeQ

    -- 品质选择栏
    local qualityTabs = {}
    for _, f in ipairs(forgeable) do
        table.insert(qualityTabs, Panels.Btn {
            text = Shared.QUALITY_NAMES[f.quality] or f.quality,
            fontSize = 11, height = 32, paddingHorizontal = 10,
            variant = (activeQ == f.quality) and "primary" or "secondary",
            onClick = function()
                Panels._forgeSelectedQuality = f.quality
                Panels._forgeSelIds = nil
                Panels.OpenEnhance()
            end,
        })
    end
    parent:AddChild(S.UI.Panel {
        flexDirection = "row", gap = 6, flexWrap = "wrap", marginBottom = 6,
        children = qualityTabs,
    })

    -- 本品质需要的底材组合：普通 1 件；其他品质「上一品质 + 当前品质」各 1 件
    local needQualities = {}
    if activePrev then
        table.insert(needQualities, { quality = activePrev, count = 1 })
        table.insert(needQualities, { quality = activeQ,    count = 1 })
    else
        table.insert(needQualities, { quality = activeQ, count = 1 })
    end

    -- 选中集合：只保留仍在本品质候选里的 id，避免切换品质后残留旧选择
    local sel = {}
    if type(Panels._forgeSelIds) == "table" then
        for _, id in ipairs(Panels._forgeSelIds) do sel[id] = true end
    end
    local validIds = {}
    for _, nq in ipairs(needQualities) do
        for _, it in ipairs(byQuality[nq.quality] or {}) do validIds[it.id] = true end
    end
    for id in pairs(sel) do
        if not validIds[id] then sel[id] = nil end
    end
    local function SelCount(q)
        local n = 0
        for _, it in ipairs(byQuality[q] or {}) do
            if sel[it.id] then n = n + 1 end
        end
        return n
    end
    local function RefreshSelIds()
        local ids = {}
        for _, it in ipairs(allCandidates) do
            if sel[it.id] then table.insert(ids, it.id) end
        end
        Panels._forgeSelIds = (#ids > 0) and ids or nil
    end

    -- 每个需要的品质渲染一栏，卡片为多选（同品质最多选 count 件）
    for _, nq in ipairs(needQualities) do
        local q = nq.quality
        local list = byQuality[q] or {}
        local qcolor = Shared.QUALITY_COLORS[q] or "#ffffff"
        local isPrev = (q ~= activeQ)
        local cells = {}
        for _, it in ipairs(list) do
            local selected = sel[it.id] == true
            local cell = S.UI.Panel {
                flexDirection = "row", alignItems = "center", gap = 6,
                height = 36, paddingHorizontal = 6,
                -- 选中绿 { 60, 90, 40, 255 } 是语义色（选中态），保留
                backgroundColor = selected and { 60, 90, 40, 255 } or Panels.THEME.bgCard,
                borderWidth = 1,
                borderColor = Shared.HexRGB(selected and "#88ff88" or qcolor),
                borderRadius = 6,
                pointerEvents = "auto",
                children = {
                    S.UI.Label { text = EquipIcon(it), fontSize = 16, width = 24, textAlign = "center" },
                    S.UI.Label {
                        text = (it.name or "?") .. " +" .. (it.enhanceLevel or 0),
                        fontSize = 10, fontColor = Shared.HexRGB(qcolor), maxLines = 1,
                        flexGrow = 1, flexShrink = 1,
                    },
                },
            }
            cell.props.onClick = function()
                if sel[it.id] then
                    sel[it.id] = nil
                else
                    if SelCount(q) >= nq.count then
                        Notify.Toast(string.format("%s底材最多选 %d 件",
                            Shared.QUALITY_NAMES[q] or q, nq.count))
                        return
                    end
                    sel[it.id] = true
                end
                RefreshSelIds()
                Panels.OpenEnhance()
            end
            table.insert(cells, cell)
        end
        if #cells == 0 then
            table.insert(cells, QLabel(
                string.format("缺少满强化未锻造的%s底材", Shared.QUALITY_NAMES[q] or q),
                "#ff8080", 10))
        end
        parent:AddChild(S.UI.Panel {
            flexDirection = "column", gap = 4, marginBottom = 6,
            children = {
                QLabel(isPrev
                        and ("上一品质：" .. (Shared.QUALITY_NAMES[q] or q) .. "（选 1 件）")
                        or ((Shared.QUALITY_NAMES[q] or q) .. "（选 1 件）"),
                    isPrev and "#aaddff" or "#ffcc66", 11),
                S.UI.Panel { flexDirection = "column", gap = 4, children = cells },
            },
        })
    end

    -- 选择进度提示
    local needDesc = {}
    for _, nq in ipairs(needQualities) do
        table.insert(needDesc, string.format("%s %d/%d",
            Shared.QUALITY_NAMES[nq.quality] or nq.quality, SelCount(nq.quality), nq.count))
    end
    parent:AddChild(QLabel("已选：" .. table.concat(needDesc, "  ·  "), "#aaddff", 10))

    -- 消耗预览 + 确认按钮
    local prevItem, curItem
    if activePrev then
        for _, it in ipairs(byQuality[activePrev] or {}) do
            if sel[it.id] then
                prevItem = it
                break
            end
        end
        for _, it in ipairs(byQuality[activeQ] or {}) do
            if sel[it.id] then
                curItem = it
                break
            end
        end
    else
        for _, it in ipairs(byQuality[activeQ] or {}) do
            if sel[it.id] then
                curItem = it
                break
            end
        end
    end

    local costText = "请选择底材"
    local canForge = false
    local ready = activePrev and (prevItem ~= nil and curItem ~= nil) or (curItem ~= nil)

    if ready then
        local costMap = Shared.GetForgeCostMap(activeQ)
        local spiritMap = Shared.GetForgeSpiritCostMap(activeQ)
        local goldCost = Shared.GetForgeGoldCost(activeQ)
        costText = string.format("需要：金币 %d，碎片 %s，精魄 %s",
            goldCost,
            FragmentCostText(costMap),
            SpiritCostText(spiritMap)
        )
        canForge = (Data.value.gold or 0) >= goldCost
            and Shared.CanPayFragmentMap(Data.value.inventory, costMap)
            and Shared.CanPaySpiritMap(Data.value.inventory, spiritMap)
    end

    parent:AddChild(S.UI.Panel {
        flexDirection = "column", gap = 6, marginTop = 8,
        children = {
            QLabel(costText, canForge and "#88ff88" or Panels.THEME_HEX.textSecond, 10),
            QButton("确认锻造", function()
                -- ⚠️ 普通品质传 nil 作 prevItem（不是 false、不是空表）：
                --    DoForge 用 `prevItem ~= nil` 判定是否为双底材流程。
                if activePrev then
                    if not prevItem or not curItem then
                        Notify.Toast(string.format("需要 %s 和 %s 底材各 1 件",
                            Shared.QUALITY_NAMES[activePrev] or activePrev,
                            Shared.QUALITY_NAMES[activeQ] or activeQ))
                        return
                    end
                    Panels.Confirm("确认锻造",
                        string.format("将消耗：\n%s\n%s\n产出随机部位的 %s 装备",
                            prevItem.name, curItem.name,
                            Shared.QUALITY_NAMES[activeQ] or activeQ),
                        function()
                            Panels.DoForge(prevItem, curItem)
                        end)
                else
                    if not curItem then
                        Notify.Toast("请选择 1 件底材")
                        return
                    end
                    Panels.Confirm("确认锻造",
                        string.format("将消耗：\n%s\n产出随机部位的 %s 装备",
                            curItem.name,
                            Shared.QUALITY_NAMES[activeQ] or activeQ),
                        function()
                            Panels.DoForge(nil, curItem)
                        end)
                end
            end, "primary"),
        },
    })
end

---@param parent Panel
function Panels.BuildReforgeList(parent)
    local candidates = CollectEquipment(function(it) return it.forged end)
    if #candidates == 0 then
        parent:AddChild(QLabel("没有已锻造的装备", Panels.THEME_HEX.textDim))
        return
    end

    local cards = {}
    for i, it in ipairs(candidates) do
        if i > 12 then break end
        -- 🔴 显示口径（2026-10-04 二次定稿）：属性、技能**各自独立上限**。
        local skillKinds = 0
        for _ in pairs(it.skills or {}) do skillKinds = skillKinds + 1 end
        local curAttr  = Shared.CountAttrAffixes(it)
        local curSkill = Shared.CountSkillLayers(it.skills)
        local maxAttr  = Shared.MaxAttrAffixes(it.quality)
        local maxSkill = Shared.MaxSkillAffixes(it.quality)
        local qcolor = Shared.QUALITY_COLORS[it.quality] or "#ffffff"
        local goldCost = Shared.GetReforgeGoldCost(it.quality)
        local haveGold = Data.value.gold or 0
        local infoColor = (haveGold >= goldCost) and Panels.THEME_HEX.textSecond or "#ff6666"

        table.insert(cards, S.UI.Panel {
            flexDirection = "row", alignItems = "center",
            height = 56, paddingHorizontal = 8, gap = 8,
            backgroundColor = Panels.THEME.bgCard, borderRadius = 6,
            children = {
                S.UI.Label { text = EquipIcon(it), fontSize = 20, width = 32, textAlign = "center" },
                S.UI.Panel {
                    flexDirection = "column", flexGrow = 1, flexShrink = 1, gap = 2,
                    children = {
                        S.UI.Label {
                            text = (it.name or "?") .. " +" .. (it.enhanceLevel or 0),
                            fontSize = 11, fontColor = Shared.HexRGB(qcolor), maxLines = 1,
                        },
                        S.UI.Label {
                            text = "属性 " .. curAttr .. "/" .. maxAttr
                                .. " · 技能 " .. curSkill .. "/" .. maxSkill
                                .. "（" .. skillKinds .. " 种）"
                                .. " | 💰 " .. haveGold .. "/" .. goldCost,
                            fontSize = 9, fontColor = Shared.HexRGB(infoColor), maxLines = 1,
                        },
                    },
                },
                QButton("重铸/锁定", function() Panels.OpenReforgeLock(it) end, "secondary"),
            },
        })
    end
    parent:AddChild(S.UI.SimpleGrid { columns = 2, gap = 8, children = cards })
end

-- ============ 属性重铸（金币重铸属性词条） ============

--- 收集所有有属性词条的装备（装备栏 + 背包）
---@param parent Panel
function Panels.BuildAttrReforgeList(parent)
    local candidates = CollectEquipment()
    if #candidates == 0 then
        parent:AddChild(QLabel("没有可重铸的装备", Panels.THEME_HEX.textDim))
        return
    end

    local cards = {}
    for i, it in ipairs(candidates) do
        if i > 12 then break end
        local specCount = #(Shared.SLOT_SPEC[it.slot] or {})
        local randCount = 0
        for j = specCount + 1, #(it.bonuses or {}) do
            if it.bonuses[j] then randCount = randCount + 1 end
        end
        local maxRand = Shared.QUALITY_BONUS_MAX[it.quality] or 6
        local qcolor = Shared.QUALITY_COLORS[it.quality] or "#ffffff"
        local goldCost = Shared.GetAttrReforgeGoldCost(it.quality)
        local haveGold = Data.value.gold or 0
        local infoColor = (haveGold >= goldCost) and Panels.THEME_HEX.textSecond or "#ff6666"

        table.insert(cards, S.UI.Panel {
            flexDirection = "row", alignItems = "center",
            height = 56, paddingHorizontal = 8, gap = 8,
            backgroundColor = Panels.THEME.bgCard, borderRadius = 6,
            children = {
                S.UI.Label { text = EquipIcon(it), fontSize = 20, width = 32, textAlign = "center" },
                S.UI.Panel {
                    flexDirection = "column", flexGrow = 1, flexShrink = 1, gap = 2,
                    children = {
                        S.UI.Label {
                            text = (it.name or "?") .. " +" .. (it.enhanceLevel or 0),
                            fontSize = 11, fontColor = Shared.HexRGB(qcolor), maxLines = 1,
                        },
                        S.UI.Label {
                            text = "随机属性 " .. randCount .. "/" .. maxRand
                                .. " | 💰 " .. haveGold .. "/" .. goldCost,
                            fontSize = 9, fontColor = Shared.HexRGB(infoColor), maxLines = 1,
                        },
                    },
                },
                QButton("属性重铸", function() Panels.OpenAttrReforgeLock(it) end, "secondary"),
            },
        })
    end
    parent:AddChild(S.UI.SimpleGrid { columns = 2, gap = 8, children = cards })
end

-- 重铸面板每次点击锁定都会重开自己来刷新高亮。
-- 若每次都走 OpenStackedModal，父引用会层层套自己，关闭后会回到已废弃的旧面板。
-- 这里只在「首次打开」时记录真正的父级，重开时复用它。
---@type any
local reforgeParentModal_ = nil
---@type string|nil
local reforgeParentId_ = nil
local reforgeOpen_ = false

--- 构造重铸锁定面板并打开（首次打开 / 重开共用同一套构造）
---@param item table
local function BuildReforgeModal(item)
    local modal = S.UI.Modal {
        title = "重铸 - 锁定词条",
        size = "lg",
        onClose = function(self)
            if Panels.GetCurrentModal() == self then
                Panels.SetCurrentModal(reforgeParentModal_, reforgeParentId_)
                Shared.UIState.modalOpen = (reforgeParentModal_ ~= nil)
            end
            reforgeOpen_ = false
            reforgeParentModal_ = nil
            reforgeParentId_ = nil
        end,
    }
    Panels.SetCurrentModal(modal, "reforgelock")
    Shared.UIState.modalOpen = true
    Panels._BuildReforgeLockBody(modal, item)
    modal:Open()
end

--- 打开重铸锁定面板
---@param item table
function Panels.OpenReforgeLock(item)
    if reforgeOpen_ then
        -- 重开：先关掉上一个重铸实例。
        -- ⚠️ 必须显式 Close：旧实例留在 Modal 栈里会与新实例叠层，
        --    且它的 onClose 会把 current 指针回写成已废弃的父级。
        local old = Panels.GetCurrentModal()
        if old then old:Close() end
        reforgeOpen_ = false
        reforgeParentModal_ = nil
        reforgeParentId_ = nil
        BuildReforgeModal(item)
        return
    end

    reforgeParentModal_ = Panels.GetCurrentModal()
    reforgeParentId_ = Panels.GetCurrentId()
    reforgeOpen_ = true
    BuildReforgeModal(item)
end

--- 构建重铸锁定面板内容（拆出来供重开时复用）
---@param modal Modal
---@param item table
function Panels._BuildReforgeLockBody(modal, item)

    -- 本物品当前锁定的技能集合
    local locks = reforgeLocks_[item.id]
    if not locks then
        locks = {}
        reforgeLocks_[item.id] = locks
    end

    -- 技能上限（重铸只看技能额度，属性额度独立）
    local maxLock = Shared.MaxSkillAffixes(item.quality)
    local lockCount = 0
    for _ in pairs(locks) do lockCount = lockCount + 1 end

    -- 当前技能条数（= 总层数，1 层 = 1 条）
    local curReforge = Shared.CountSkillLayers(item.skills)

    -- 本次重铸单条新增概率
    local baseChance = Shared.C.REFORGE_BASE_CHANCE[item.quality] or 1.0
    local chance = baseChance * (Shared.C.REFORGE_LOCK_PENALTY ^ lockCount)

    -- 按 skillId 聚合层数（同技能多层的合成一条，避免重复按钮）
    local skillIds = {}
    for sid in pairs(item.skills or {}) do
        if Shared.SKILL_DEFS[sid] then skillIds[#skillIds + 1] = sid end
    end
    table.sort(skillIds)

    local rows = {}
    for _, sid in ipairs(skillIds) do
        local def = Shared.SKILL_DEFS[sid]
        local n = item.skills[sid] or 1
        local locked = locks[sid] == true
        table.insert(rows, Panels.Btn {
            text = (locked and "🔒 " or "🔓 ") .. def.icon .. def.name .. " x" .. n,
            fontSize = 11, height = 28, paddingHorizontal = 10,
            variant = locked and "success" or "secondary",
            onClick = function()
                if locks[sid] then
                    locks[sid] = nil
                else
                    -- ⚠️ 必须现算当前锁定数：闭包捕获的 lockCount 是构建时的快照，
                    --    连续点击时它不会更新，会导致上限判断失效。
                    local cur = 0
                    for _ in pairs(locks) do cur = cur + 1 end
                    if cur >= maxLock then
                        Notify.Toast("最多锁定 " .. maxLock .. " 条技能")
                        return
                    end
                    locks[sid] = true
                end
                -- 重开面板刷新高亮（锁定状态存在模块级，不会丢）
                Panels.OpenReforgeLock(item)
            end,
        })
    end
    if #rows == 0 then
        table.insert(rows, QLabel("该装备没有技能词条", Panels.THEME_HEX.textDim, 11))
    end

    -- 消耗展示：碎片（全部低级+当前）+ 精魄（当前品质）+ 金币
    local costMap = Shared.GetReforgeCostMap(item.quality, lockCount)
    local spiritMap = Shared.GetReforgeSpiritCostMap(item.quality)
    local goldCost = Shared.GetReforgeGoldCost(item.quality)

    local costParts = {}
    for _, q in ipairs(Shared.QUALITY_LIST) do
        local n = costMap[q]
        if n then
            local disp = Shared.FRAGMENT_DISPLAY[q]
            local have = Shared.CountFragmentsInInventory(Data.value.inventory, q)
            local color = have >= n and "" or "⚠ "
            costParts[#costParts + 1] = string.format("%s%s×%d(%d/%d)",
                color, disp and disp.name or q, n, have, n)
        end
    end
    for q, n in pairs(spiritMap) do
        local disp = Shared.SPIRIT_DISPLAY[q]
        local have = Shared.CountSpiritsInInventory(Data.value.inventory, q)
        local color = have >= n and "" or "⚠ "
        costParts[#costParts + 1] = string.format("%s%s×%d(%d/%d)",
            color, disp and disp.name or q, n, have, n)
    end
    local haveGold = Data.value.gold or 0
    costParts[#costParts + 1] = string.format("%s金币×%d(%d/%d)",
        haveGold >= goldCost and "" or "⚠ ", goldCost, haveGold, goldCost)

    modal:AddContent(S.UI.Panel {
        flexDirection = "column", gap = 6,
        children = {
            S.UI.Label {
                text = string.format("技能进度：%d / %d 条（1 层 = 1 条）", curReforge, maxLock),
                fontSize = 12, fontColor = Shared.HexRGB(curReforge >= maxLock and "#88ff88" or "#ffcc66"),
            },
            S.UI.Label {
                text = "点击技能条锁定，已锁 " .. lockCount .. "/" .. maxLock .. " 条",
                fontSize = 11, fontColor = Panels.THEME.textSecond,
            },
            S.UI.Label {
                text = string.format("单次新增概率：%.1f%%（每次最多新增 1 条）", chance * 100),
                fontSize = 11, fontColor = Shared.HexRGB("#9fd8ff"),
            },
            S.UI.Label {
                text = "未锁定的词条将 100% 消失",
                fontSize = 10, fontColor = Shared.HexRGB("#ff8888"),
            },
            S.UI.Label {
                text = "消耗：" .. table.concat(costParts, "，"),
                fontSize = 10, fontColor = Panels.THEME.textSecond,
                maxLines = 0,
            },
            S.UI.Panel { flexDirection = "column", gap = 4, children = rows },
        },
    })
    modal:SetFooter(S.UI.Panel {
        flexDirection = "row", justifyContent = "flex-end", gap = 8,
        children = {
            QButton("确认重铸", function()
                -- 🔴 唯一禁止情形：**技能已达上限 且 全部技能都已锁定**。
                --    此时没有任何技能可被替换 → 重铸无意义（纯扣材料）。
                --    ⚠️ 「满 6 条但只锁 5 条」是**正常玩法**（锁 5 洗 1），必须放行，
                --       所以判断条件是 `cur >= max 且 锁定层数 >= cur`，不是单看条数。
                -- ⚠️ 锁定数**现算**，不用构建时的 lockCount 快照（快照是旧值）。
                -- ⚠️ 且按**层数**累加，不是按种类数：`locks` 存的是 {sid=true}，
                --    而 `{skillA=6}` 锁定 A 就等于锁住 6 条。按种类算会得 1，
                --    导致 `1 >= 6` 不成立 → 放行 → 扣材料却什么都不变。
                local curLock = 0
                for sid in pairs(locks) do
                    curLock = curLock + (item.skills[sid] or 1)
                end
                local curSkill = Shared.CountSkillLayers(item.skills)
                local maxSkill = Shared.MaxSkillAffixes(item.quality)
                if curSkill >= maxSkill and curLock >= curSkill then
                    Notify.Toast(string.format(
                        "技能已达 %d 条上限且全部锁定，没有可替换的词条", maxSkill))
                    return
                end

                -- 前置检查（三项都要通过）
                local goldCost = Shared.GetReforgeGoldCost(item.quality)
                if (Data.value.gold or 0) < goldCost then
                    Notify.Toast("金币不足（需 " .. goldCost .. "）")
                    return
                end
                local costMap = Shared.GetReforgeCostMap(item.quality, lockCount)
                if not Shared.CanPayFragmentMap(Data.value.inventory, costMap) then
                    Notify.Toast("碎片不足")
                    return
                end
                local spiritMap = Shared.GetReforgeSpiritCostMap(item.quality)
                if not Shared.CanPaySpiritMap(Data.value.inventory, spiritMap) then
                    Notify.Toast("精魄不足")
                    return
                end

                -- 扣材料
                Data.SpendGold(goldCost)
                Data.MarkDirty("gold")
                Shared.PayFragmentMap(Data.value.inventory, costMap)
                Shared.PaySpiritMap(Data.value.inventory, spiritMap)

                -- 执行重铸
                local lockedSet = {}
                for sid in pairs(locks) do lockedSet[sid] = true end
                local added = Shared.DoSkillReforge(item, lockedSet)
                MarkItemDirty(item)

                -- 显示口径与上限一致：随机属性 + 技能合计（基础词条不计）
                local cnt = Shared.CountItemAffixes(item)
                if added then
                    Notify.Toast(string.format("重铸成功：新增 1 条（当前 %d 条）", cnt))
                else
                    Notify.Toast(string.format("重铸未触发新增（当前 %d 条）", cnt))
                end
                modal:Close()
                Panels.OpenEnhance()
                if S.ctx and S.ctx.forceSync then S.ctx.forceSync() end
            end, "primary"),
            QButton("取消", function() modal:Close() end),
        },
    })
    -- 不在这里 Open：由调用方 Panels.OpenReforgeLock 统一负责
end

-- ============ 属性重铸面板 ============

-- 属性重铸面板状态（模块级）
---@type any
local attrReforgeParentModal_ = nil
---@type string|nil
local attrReforgeParentId_ = nil
local attrReforgeOpen_ = false
--- 属性重铸锁定：itemId → { [bonus对象] = true }
---@type table<string, table>
local attrReforgeLocks_ = {}

--- 打开属性重铸面板
---@param item table
function Panels.OpenAttrReforgeLock(item)
    if attrReforgeOpen_ then
        local old = Panels.GetCurrentModal()
        if old then old:Close() end
        attrReforgeOpen_ = false
        attrReforgeParentModal_ = nil
        attrReforgeParentId_ = nil
    end
    attrReforgeParentModal_ = Panels.GetCurrentModal()
    attrReforgeParentId_ = Panels.GetCurrentId()
    attrReforgeOpen_ = true

    local modal = S.UI.Modal {
        title = "属性重铸 - 锁定词条",
        size = "lg",
        onClose = function(self)
            if Panels.GetCurrentModal() == self then
                Panels.SetCurrentModal(attrReforgeParentModal_, attrReforgeParentId_)
                Shared.UIState.modalOpen = (attrReforgeParentModal_ ~= nil)
            end
            attrReforgeOpen_ = false
            attrReforgeParentModal_ = nil
            attrReforgeParentId_ = nil
        end,
    }
    Panels.SetCurrentModal(modal, "attrreforgelock")
    Shared.UIState.modalOpen = true

    local locks = attrReforgeLocks_[item.id]
    if not locks then
        locks = {}
        attrReforgeLocks_[item.id] = locks
    end

    local specCount = #(Shared.SLOT_SPEC[item.slot] or {})
    local maxRand = Shared.QUALITY_BONUS_MAX[item.quality] or 6
    local randCount = 0
    for j = specCount + 1, #(item.bonuses or {}) do
        if item.bonuses[j] then randCount = randCount + 1 end
    end

    local lockCount = 0
    for _ in pairs(locks) do lockCount = lockCount + 1 end
    local chance = Shared.CalcAttrReforgeChance(item.quality, lockCount)
    local goldCost = Shared.GetAttrReforgeGoldCost(item.quality)
    local haveGold = Data.value.gold or 0

    -- 词条列表（含基础词条 + 随机词条）
    local rows = {}
    for i, b in ipairs(item.bonuses or {}) do
        local def = Shared.MOD_DEFS[b.modId]
        local v = b.value * (1 + (item.enhanceLevel or 0) * 0.02)
        local txt = (def and def.type == "percent")
            and string.format("%s +%.2f%%", def.name or b.modId, v * 100)
            or string.format("%s +%d", def.name or b.modId, math.floor(v))

        if i <= specCount then
            -- 基础词条：不可锁定、不可洗
            table.insert(rows, S.UI.Panel {
                flexDirection = "row", alignItems = "center", gap = 6,
                children = {
                    S.UI.Label { text = "【基础】", fontSize = 10, fontColor = Shared.HexRGB("#ffcc66") },
                    S.UI.Label { text = txt, fontSize = 11, fontColor = Panels.THEME.textPrimary },
                },
            })
        else
            local locked = locks[b] == true
            table.insert(rows, Panels.Btn {
                text = (locked and "🔒 " or "🔓 ") .. txt,
                fontSize = 11, height = 28, paddingHorizontal = 10,
                variant = locked and "success" or "secondary",
                onClick = function()
                    if locks[b] then
                        locks[b] = nil
                    else
                        local cur = 0
                        for _ in pairs(locks) do cur = cur + 1 end
                        if cur >= maxRand then
                            Notify.Toast("最多锁定 " .. maxRand .. " 条")
                            return
                        end
                        locks[b] = true
                    end
                    modal:Close()
                    Panels.OpenAttrReforgeLock(item)
                end,
            })
        end
    end

    modal:AddContent(S.UI.Panel {
        flexDirection = "column", gap = 6,
        children = {
            S.UI.Label {
                text = string.format("随机属性：%d / %d 条", randCount, maxRand),
                fontSize = 12, fontColor = Shared.HexRGB(randCount >= maxRand and "#88ff88" or "#ffcc66"),
            },
            S.UI.Label {
                text = "点击词条锁定，已锁 " .. lockCount .. "/" .. maxRand .. " 条",
                fontSize = 11, fontColor = Panels.THEME.textSecond,
            },
            S.UI.Label {
                text = string.format("单次新增概率：%.1f%%（每次最多新增 1 条）", chance * 100),
                fontSize = 11, fontColor = Shared.HexRGB("#9fd8ff"),
            },
            S.UI.Label {
                text = "未锁定的随机属性将 100% 消失",
                fontSize = 10, fontColor = Shared.HexRGB("#ff8888"),
            },
            S.UI.Label {
                text = string.format("消耗：金币 ×%d（现有 %d）", goldCost, haveGold),
                fontSize = 11, fontColor = Shared.HexRGB(haveGold >= goldCost and Panels.THEME_HEX.textSecond or "#ff6666"),
            },
            S.UI.Panel { flexDirection = "column", gap = 4, children = rows },
        },
    })

    modal:SetFooter(S.UI.Panel {
        flexDirection = "row", justifyContent = "flex-end", gap = 8,
        children = {
            QButton("确认重铸", function()
                -- 🔴 唯一禁止情形：**属性已达上限 且 全部随机属性都已锁定**。
                --    此时没有任何词条可被替换 → 重铸无意义（纯扣金币）。
                --    ⚠️ 「满 6 条但只锁 5 条」是**正常玩法**（锁 5 洗 1），必须放行，
                --       所以判断条件是 `cur >= max 且 锁定数 >= cur`，不是单看条数。
                -- ⚠️ 锁定数**现算**，不用构建时的 lockCount 快照（快照是旧值）。
                -- 属性是数组元素、每条独立对象，无「叠层」概念，
                -- 所以锁定数直接数对象即可（不需要像技能那样按层数累加）。
                local curRand = 0
                for j = specCount + 1, #(item.bonuses or {}) do
                    if item.bonuses[j] then curRand = curRand + 1 end
                end
                local curLock = 0
                for _ in pairs(locks) do curLock = curLock + 1 end
                if curRand >= maxRand and curLock >= curRand then
                    Notify.Toast(string.format(
                        "属性已达 %d 条上限且全部锁定，没有可替换的词条", maxRand))
                    return
                end

                local goldCost = Shared.GetAttrReforgeGoldCost(item.quality)
                if (Data.value.gold or 0) < goldCost then
                    Notify.Toast("金币不足（需 " .. goldCost .. "）")
                    return
                end
                -- 未鉴定不能重铸
                if item.identified == false then
                    Notify.Toast("未鉴定装备无法重铸")
                    return
                end

                -- 锁 0 条二次确认
                local cur = curLock

                local function doReforge()
                    Data.SpendGold(goldCost)
                    Data.MarkDirty("gold")
                    local added = Shared.DoAttrReforge(item, locks)
                    MarkItemDirty(item)
                    local randCount2 = 0
                    for j = specCount + 1, #(item.bonuses or {}) do
                        if item.bonuses[j] then randCount2 = randCount2 + 1 end
                    end
                    if added then
                        Notify.Toast(string.format("属性重铸成功：新增 1 条（当前 %d 条）", randCount2))
                    else
                        Notify.Toast(string.format("属性重铸未触发新增（当前 %d 条）", randCount2))
                    end
                    modal:Close()
                    Panels.OpenEnhance()
                    if S.ctx and S.ctx.forceSync then S.ctx.forceSync() end
                end

                if cur == 0 then
                    Panels.Confirm("确认属性重铸",
                        "当前没有锁定任何词条。\n\n"
                        .. "⚠️ 未锁定的随机属性将 100% 消失，\n"
                        .. "重铸后最多只能保留 1 条新增属性。\n\n"
                        .. "确定继续？",
                        function() doReforge() end)
                else
                    doReforge()
                end
            end, "primary"),
            QButton("取消", function() modal:Close() end),
        },
    })
    modal:Open()
end

---@param item table
function Panels.DoEnhance(item)
    if not Shared.ENHANCE_RATES then
        Notify.Toast("配置未加载，请重新登录")
        return
    end
    if (item.enhanceLevel or 0) >= (item.maxEnhance or 20) then
        Notify.Toast("已达最大强化")
        return
    end
    -- 金币（按品质）+ 碎片
    local goldCost = Shared.GetEnhanceGoldCost(item.quality)
    if (Data.value.gold or 0) < goldCost then
        Notify.Toast("金币不足（需 " .. goldCost .. "）")
        return
    end
    local costMap = Shared.GetEnhanceCostMap(item.quality, item.enhanceLevel or 0)
    if not Shared.CanPayFragmentMap(Data.value.inventory, costMap) then
        Notify.Toast("碎片不足")
        return
    end
    Data.SpendGold(goldCost)
    Data.MarkDirty("gold")
    Shared.PayFragmentMap(Data.value.inventory, costMap)
    local rate = Shared.ENHANCE_RATES[item.enhanceLevel or 0] or 0.5
    local success = math.random() < rate
    if success then
        -- 夹到上限：即使上游判定被绕过（如 maxEnhance 字段异常），也不会突破
        local cap = item.maxEnhance or Shared.QUALITY_MAX_ENHANCE[item.quality] or 20
        item.enhanceLevel = math.min((item.enhanceLevel or 0) + 1, cap)
    end
    MarkItemDirty(item)
    if success then
        Notify.Toast(string.format("强化成功（成功率 %.1f%%）", rate * 100))
    else
        Notify.Toast(string.format("强化失败（成功率 %.1f%%）", rate * 100))
    end
    Panels.OpenEnhance()
    if S.ctx and S.ctx.forceSync then S.ctx.forceSync() end
end

--- 锻造：消耗底材（普通 1 件 / 其他 2 件）
---@param prevItem table|nil 普通品质时传 nil
---@param curItem table
function Panels.DoForge(prevItem, curItem)
    if not curItem then
        Notify.Toast("请选择底材")
        return
    end

    local quality = curItem.quality
    local isNormal = (quality == "normal")

    -- ============ 普通品质：只 1 件底材 ============
    if isNormal then
        if prevItem ~= nil then
            -- 严格说，普通品质不应该有 prevItem。传了就拒。
            Notify.Toast("普通锻造只需要 1 件底材")
            return
        end
    else
        -- ============ 其他品质：需要 2 件相邻 ============
        if not prevItem then
            Notify.Toast("请选择两件底材")
            return
        end

        -- 检查品质相邻
        local prevRank = Shared.QUALITY_RANK[prevItem.quality] or -1
        local curRank  = Shared.QUALITY_RANK[curItem.quality] or -1
        if curRank - prevRank ~= 1 then
            Notify.Toast("底材品质必须相邻")
            return
        end

        -- 检查 prev 满强化 + 未锻造
        if (prevItem.enhanceLevel or 0) < (prevItem.maxEnhance or 20) or prevItem.forged then
            Notify.Toast("上一品质底材需满强化且未锻造")
            return
        end
    end

    -- 所有品质都检查 curItem
    if (curItem.enhanceLevel or 0) < (curItem.maxEnhance or 20) or curItem.forged then
        Notify.Toast("当前品质底材需满强化且未锻造")
        return
    end

    -- 检查金币 + 碎片 + 精魄
    local goldCost = Shared.GetForgeGoldCost(quality)
    if (Data.value.gold or 0) < goldCost then
        Notify.Toast("金币不足（需 " .. goldCost .. "）")
        return
    end
    local costMap = Shared.GetForgeCostMap(quality)
    local spiritMap = Shared.GetForgeSpiritCostMap(quality)

    if not Shared.CanPayFragmentMap(Data.value.inventory, costMap) then
        Notify.Toast("碎片不足")
        return
    end
    if not Shared.CanPaySpiritMap(Data.value.inventory, spiritMap) then
        Notify.Toast("精魄不足")
        return
    end

    -- 扣材料
    Data.SpendGold(goldCost)
    Data.MarkDirty("gold")
    Shared.PayFragmentMap(Data.value.inventory, costMap)
    Shared.PaySpiritMap(Data.value.inventory, spiritMap)

    -- 移除两件底材
    local inv = Data.value.inventory
    local function RemoveItem(id)
        for i, it in ipairs(inv) do
            if it.id == id then table.remove(inv, i); return end
        end
        for slot, eq in pairs(Data.value.equipment) do
            if eq and eq.id == id then
                Data.value.equipment[slot] = nil
                Data.MarkDirty("equipment")
                return
            end
        end
    end
    if prevItem then RemoveItem(prevItem.id) end
    RemoveItem(curItem.id)

    -- 生成新装备（内部有 isNormal 分支：普通必出满 6 属性 + 6 技能）
    local newItem = Shared.GenerateForgedItem(curItem)
    -- 返还：1%~100% 随机返还材料
    local refundRatio = math.random(1, 100) / 100
    local refundLines = {}
    for q, n in pairs(costMap) do
        local back = math.floor(n * refundRatio)
        if back > 0 then
            Shared.AddFragmentsToInventory(inv, q, back)
            table.insert(refundLines, string.format("%s×%d", q, back))
        end
    end
    for q, n in pairs(spiritMap) do
        local back = math.floor(n * refundRatio)
        if back > 0 then
            Shared.AddSpiritsToInventory(inv, q, back)
            table.insert(refundLines, string.format("%s精魄×%d", q, back))
        end
    end

    table.insert(inv, newItem)
    MarkItemDirty(newItem)
    Data.MarkDirty("inventory")

    local refundText = (#refundLines > 0)
        and string.format("返还 %d%%：%s", math.floor(refundRatio * 100), table.concat(refundLines, " "))
        or "无返还"
    Notify.Toast(string.format("锻造完成（%s）", refundText))

    Panels._forgeSelIds = nil
    Panels.OpenEnhance()
    if S.ctx and S.ctx.forceSync then S.ctx.forceSync() end
end

return Panels
