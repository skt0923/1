-- ============================================================
-- 卡牌自走棋：客户端场景（假数据驱动版）
-- 当前进度：备战界面布局 + 拖拽系统
-- ============================================================
local Shared = require("Shared")
local PrepLayout = require("modes.autochess.PrepLayout")

local Scene = {}

---@type any
local UI_ = nil
---@type any
local ctx_ = nil
---@type any
local WidgetsRef_ = nil
---@type any
local ThemeRef_ = nil

---@type any
local root_ = nil

-- 拖拽落点判定用的区域引用（由 PrepLayout 构建时填充）
-- 见 PrepLayout.shopAreaRef / PrepLayout.boardSlotRefs
---@type boolean
local lastPointerDown_ = false

-- ============================================================
-- 一、Mock 假数据
-- ============================================================
---@class AutochessMockShopCard
---@field name string
---@field cost integer
---@field atk integer
---@field hp integer
---@field tag string
---@field star integer
---@field desc string

---@class AutochessMockOpponent
---@field hp integer
---@field level integer
---@field isDead boolean
---@field isCurrent boolean|nil 本场对手（左侧列表红框高亮）
---@field name string|nil 显示名

---@class AutochessMockBoardSlot
---@field occupied boolean
---@field name string|nil
---@field star integer|nil
---@field atk integer|nil
---@field hp integer|nil

---@class AutochessMockCombatUnit
---@field atk integer
---@field hp integer

---@class AutochessMockCombatData
---@field opponentName string
---@field enemyTeam AutochessMockCombatUnit[]
---@field myTeam AutochessMockCombatUnit[]

---@class AutochessMockResultData
---@field rank integer
---@field score integer
---@field scoreDelta integer
---@field rankDelta integer
---@field readyBonus integer

---@class AutochessMockDragPos
---@field x number
---@field y number

---@class AutochessMockDragging
---@field card AutochessMockShopCard
---@field source string "shop" | "bench"
---@field slotIndex integer
---@field widget any            被拖拽的卡牌 widget（原地平移）
---@field grabDX number         按下点相对卡牌左上角的偏移 x
---@field grabDY number         按下点相对卡牌左上角的偏移 y

---@class AutochessMockPendingPress
---@field card AutochessMockShopCard
---@field source string "shop" | "bench"
---@field slotIndex integer
---@field widget any            按下时命中的卡牌 widget
---@field startX number
---@field startY number
---@field elapsed number

---@class AutochessMockData
---@field state string
---@field gold integer
---@field goldIncome integer
---@field level integer
---@field exp integer
---@field expMax integer
---@field myHp integer
---@field refreshCost integer
---@field buyExpCost integer
---@field shopRefreshCost integer
---@field shopCards AutochessMockShopCard[]
---@field phaseTimeLeft integer
---@field opponents AutochessMockOpponent[]
---@field boardSlots AutochessMockBoardSlot[]
---@field combatData AutochessMockCombatData
---@field resultData AutochessMockResultData
---@field detailCard AutochessMockShopCard|nil
---@field bench AutochessMockShopCard[]
---@field dragging AutochessMockDragging|nil
---@field dragPos AutochessMockDragPos
---@field pendingPress AutochessMockPendingPress|nil

---@type AutochessMockData
local MOCK = {
    state = "prep",
    -- 备战阶段数据
    gold = 4,
    goldIncome = 5,
    level = 1,
    exp = 0,
    expMax = 6,
    myHp = 40,
    refreshCost = 6,
    buyExpCost = 4,
    shopRefreshCost = 1,
    shopCards = {
        { name = "小兵", cost = 1, atk = 5, hp = 10, tag = "战士",
          star = 1, level = 1, desc = "攻击5，血量10" },
        { name = "小兵", cost = 1, atk = 5, hp = 10, tag = "战士",
          star = 1, level = 1, desc = "攻击5，血量10" },
        { name = "小兵", cost = 1, atk = 5, hp = 10, tag = "战士",
          star = 1, level = 1, desc = "攻击5，血量10" },
    },
    -- 第二批数据
    phaseTimeLeft = 29,
    -- 多回合对局状态
    round = 1,               -- 当前回合数
    -- 单机对局：我 + 7 个人机，全部 40 血存活
    opponents = {
        { hp = 40, level = 1, isDead = false, name = "人机1" },
        { hp = 40, level = 1, isDead = false, name = "人机2" },
        { hp = 40, level = 1, isDead = false, name = "人机3" },
        { hp = 40, level = 1, isDead = false, name = "人机4" },
        { hp = 40, level = 1, isDead = false, name = "人机5" },
        { hp = 40, level = 1, isDead = false, name = "人机6" },
        { hp = 40, level = 1, isDead = false, name = "人机7" },
    },
    currentOppIdx = nil,     -- 本场对手在 opponents 中的下标
    boardSlots = {
        { occupied = true,  name = "小兵", star = 1, level = 1, atk = 5, hp = 10 },
        { occupied = true,  name = "小兵", star = 1, level = 1, atk = 5, hp = 10 },
        { occupied = true,  name = "小兵", star = 1, level = 1, atk = 5, hp = 10 },
        { occupied = true,  name = "小兵", star = 1, level = 1, atk = 5, hp = 10 },
        { occupied = true,  name = "小兵", star = 1, level = 1, atk = 5, hp = 10 },
        { occupied = true,  name = "小兵", star = 1, level = 1, atk = 5, hp = 10 },
    },
    bench = {
        { name = "小兵", cost = 1, atk = 5, hp = 10, tag = "战士", star = 1,
          level = 1, desc = "攻击5，血量10" },
        { name = "小兵", cost = 1, atk = 5, hp = 10, tag = "战士", star = 1,
          level = 1, desc = "攻击5，血量10" },
        { name = "小兵", cost = 1, atk = 5, hp = 10, tag = "战士", star = 1,
          level = 1, desc = "攻击5，血量10" },
    },
    -- 战斗阶段数据（实际内容由 Combat 引擎生成，这里是兜底）
    combatData = {
        opponentName = "可爱的矮人3478",
        enemyTeam = {},
        myTeam = {},
    },
    -- 结算界面数据
    resultData = {
        rank = 7,
        score = 12702,
        scoreDelta = 0,
        rankDelta = -2,
        readyBonus = 2,
    },
    detailCard = nil,
    dragging = nil,        -- nil 或 { card = <card>, source = "shop"|"bench", slotIndex = <n> }
    dragPos = { x = 0, y = 0 },
    pendingPress = nil,   -- 按下候选：{card, source, slotIndex, startX, startY, elapsed}
}

-- ============================================================
-- 二、工具函数
-- ============================================================
local function HexRGB(hex, alpha)
    return Shared.HexRGB(hex, alpha)
end

--- 字符画占位块：无背景，有边框，中心一行文字
---@param w number|string
---@param h number
---@param text string
---@param borderColor table|nil
---@param pointerEvents string|nil
---@return any
local function Box(w, h, text, borderColor, pointerEvents)
    return UI_.Panel {
        width = w, height = h,
        backgroundColor = { 0, 0, 0, 0 },
        borderWidth = 2,
        borderColor = borderColor or HexRGB("#888888"),
        flexDirection = "column",
        justifyContent = "center",
        alignItems = "center",
        pointerEvents = pointerEvents,
        children = {
            UI_.Label {
                text = text,
                fontSize = 14,
                fontColor = HexRGB("#dddddd"),
            },
        },
    }
end

--- 圆形元素（费用圈 / 血量圈 / 头像占位）
---@param size number
---@param text string
---@param textColor table
---@param borderColor table
---@param bgColor table|nil
---@param fontSize number|nil
---@param pos table|nil 绝对定位 { position=, left=, top=, right=, bottom= }
---@return any
local function Circle(size, text, textColor, borderColor, bgColor, fontSize, pos)
    pos = pos or {}
    return UI_.Panel {
        width = size, height = size,
        borderRadius = size / 2,
        backgroundColor = bgColor or { 0, 0, 0, 0 },
        borderWidth = 2,
        borderColor = borderColor,
        position = pos.position,
        left = pos.left,
        top = pos.top,
        right = pos.right,
        bottom = pos.bottom,
        flexDirection = "column",
        justifyContent = "center",
        alignItems = "center",
        children = {
            UI_.Label {
                text = text,
                fontSize = fontSize or math.floor(size * 0.42),
                fontColor = textColor,
                textAlign = "center",
                width = "100%",
                maxLines = 1,
            },
        },
    }
end

--- 画虚线矩形（用于棋盘空位格）
---@param nvg any
---@param x number
---@param y number
---@param w number
---@param h number
---@param color table
---@param thickness number
---@param dashLen number
---@param gapLen number
local function DrawDashedRect(nvg, x, y, w, h, color, thickness, dashLen, gapLen)
    nvgStrokeColor(nvg, nvgRGBA(color[1], color[2], color[3], color[4] or 255))
    nvgStrokeWidth(nvg, thickness)

    local function dashedLine(x1, y1, x2, y2)
        local dx, dy = x2 - x1, y2 - y1
        local len = math.sqrt(dx * dx + dy * dy)
        if len == 0 then return end
        local ux, uy = dx / len, dy / len
        local pos = 0
        while pos < len do
            local e = math.min(pos + dashLen, len)
            nvgBeginPath(nvg)
            nvgMoveTo(nvg, x1 + ux * pos, y1 + uy * pos)
            nvgLineTo(nvg, x1 + ux * e, y1 + uy * e)
            nvgStroke(nvg)
            pos = pos + dashLen + gapLen
        end
    end

    dashedLine(x, y, x + w, y)
    dashedLine(x + w, y, x + w, y + h)
    dashedLine(x + w, y + h, x, y + h)
    dashedLine(x, y + h, x, y)
end

-- ============================================================
-- 设计稿坐标换算
--
-- 布局规格基于 1080×2400 竖屏物理像素，但 UI 使用 base 坐标
-- （参考设备上约 509×1131）。这里按短边等比换算，保证
-- 比例与设计稿一致，同时适配其他分辨率。
-- ============================================================
local SPEC_SHORT = 1080          -- 设计稿短边（物理像素）

--- 设计稿像素 → UI base 像素
---@param v number
---@return number
local function S(v)
    local shortSide = math.min(UI_.GetWidth(), UI_.GetHeight())
    return v * shortSide / SPEC_SHORT
end

--- 虚线空位格（棋盘空格子）
---@param w number
---@param h number
---@param color table|nil
---@return any
local function DashedSlot(w, h, color)
    local slot = UI_.Panel {
        width = w, height = h,
        backgroundColor = { 0, 0, 0, 0 },
        pointerEvents = "none",
    }
    local col = color or HexRGB("#3a3a4a")
    slot.Render = function(self, nvg)
        local l = self:GetAbsoluteLayout()
        if not l then return end
        DrawDashedRect(nvg, l.x, l.y, l.w, l.h, col, 1, 6, 4)
    end
    return slot
end


-- ---------------------------------------------------------
-- 备战阶段：委托给 PrepLayout 模块（按设计稿重写）
--
-- 布局规格、调色板、各分区构建都在 PrepLayout.lua 内，
-- 这里只负责：注入 UI 库引用、绑定回调、返回根控件。
-- ---------------------------------------------------------
local function BuildPrep()
    local UI = UI_

    -- 注入依赖
    PrepLayout.UI = UI
    PrepLayout.OnCardTap = function(card)
        MOCK.detailCard = card
        Scene.RefreshUI()
    end
    PrepLayout.OnMenu = function()
        print("[Autochess] 菜单（占位）")
    end
    PrepLayout.OnBuyExp = function()
        print("[Autochess] 购买经验（占位）")
    end
    PrepLayout.OnRefresh = function()
        print("[Autochess] 刷新商店（占位）")
    end
    PrepLayout.OnLock = function()
        print("[Autochess] 锁定（占位）")
    end
    PrepLayout.OnReady = function()
        print("[Autochess] 点击准备 → 进入战斗")
        Scene.EnterCombat()
    end

    local root = PrepLayout.Build(MOCK)

    return root
end

-- ---------------------------------------------------------
-- 战斗阶段（布局在 PrepLayout.BuildCombat，数据来自 Combat 引擎）
--
-- 流程：
--   1. EnterCombat：由备战棋盘生成我方队伍 + 随机生成敌方队伍
--   2. 显示双方阵容，停留 SHOWCASE_SEC 秒
--   3. 按事件流逐条播放（同一时刻只有一个棋子在动）
--   4. 播完 → 回到备战页
-- ---------------------------------------------------------

local Combat = require("modes.autochess.Combat")

local SHOWCASE_SEC = 1.5    -- 展示阵容的停留时间
local STEP_SEC     = 0.35   -- 两次交锋之间的间隔
local DASH_SEC     = 0.28   -- 冲向目标的时间
local HIT_SEC      = 0.35   -- 命中后停留时间
local BACK_SEC     = 0.22   -- 归位时间
local DEAD_SEC     = 0.45   -- 死亡后停留多久再销毁
local FLOAT_SEC    = 0.85   -- 伤害飘字存活时间

-- 战斗播放状态
local combat_ = {
    phase = "idle",   -- idle | showcase | playing | done
    timer = 0,
    events = nil,     -- 事件流
    cursor = 0,       -- 下一条待播事件
    winner = nil,
    anim = nil,       -- 当前攻击动画 { phase, timer, piece, dx, dy, ev }
}

-- 伤害飘字列表：{ widget, t, life, x, y }
local floats_ = {}
-- 待销毁的棋子：{ widget, t }
local pendingKill_ = {}

--- 弹一个伤害飘字（在指定棋子当前位置弹出）
---@param piece any 目标棋子 widget
---@param amount integer 伤害值
---@param color table 文字颜色
local function SpawnFloat(piece, amount, color)
    local layer = PrepLayout.floatLayerRef
    if not layer or not piece then return end
    local l = piece:GetAbsoluteLayout()
    if not l then return end

    local UI = UI_
    local scale = (UI.GetScale and UI.GetScale()) or 1
    if scale == 0 then scale = 1 end

    local lbl = UI.Label {
        text = "-" .. tostring(amount),
        fontSize = 34,
        fontColor = color,
        textStroke = { width = 4, color = "#101010" },
        position = "absolute",
        left = l.x + l.w / 2 - 30,
        top = l.y + l.h * 0.35,
        maxLines = 1,
    }
    layer:AddChild(lbl)
    floats_[#floats_ + 1] = {
        widget = lbl,
        t = 0,
        life = FLOAT_SEC,
        x = l.x + l.w / 2 - 30,
        y = l.y + l.h * 0.35,
    }
end

--- 每帧更新飘字：向上飘 + 淡出
---@param dt number
local function UpdateFloats(dt)
    for i = #floats_, 1, -1 do
        local f = floats_[i]
        f.t = f.t + dt
        local k = f.t / f.life
        if k >= 1 or not f.widget then
            if f.widget then f.widget:Remove() end
            table.remove(floats_, i)
        else
            -- 上飘 60px，后 40% 时间淡出
            local rise = 60 * k
            local alpha = k < 0.6 and 255 or math.floor(255 * (1 - (k - 0.6) / 0.4))
            f.widget:SetStyle({
                top = f.y - rise,
                opacity = alpha / 255,
            })
        end
    end
end

--- 标记棋子死亡（延迟销毁，先让玩家看清骷髅）
---@param piece any
local function MarkDead(piece)
    if not piece then return end
    pendingKill_[#pendingKill_ + 1] = { widget = piece, t = 0 }
end

--- 每帧更新待销毁棋子
---@param dt number
local function UpdatePendingKill(dt)
    for i = #pendingKill_, 1, -1 do
        local p = pendingKill_[i]
        p.t = p.t + dt
        if p.t >= DEAD_SEC then
            if p.widget and p.widget.Remove then p.widget:Remove() end
            table.remove(pendingKill_, i)
        end
    end
end

--- 清空所有飘字与待销毁（进/出战斗时调用）
local function ClearCombatFx()
    for _, f in ipairs(floats_) do
        if f.widget then f.widget:Remove() end
    end
    floats_ = {}
    pendingKill_ = {}
end

--- 进入战斗阶段：生成双方队伍，收起上半屏商店、显示敌方棋子
--- 注意：不重建 UI 树，只切可见性 + 局部刷新敌方区
function Scene.EnterCombat()
    -- 我方队伍来自备战棋盘
    local myTeam = Combat.BuildMyTeam(MOCK.boardSlots)
    -- 敌方队伍本地生成
    local enemyTeam = Combat.BuildEnemyTeam(6)

    -- 随机挑一个存活对手作为本场对手（左侧列表红框高亮）
    local aliveIdx = {}
    for i, op in ipairs(MOCK.opponents) do
        op.isCurrent = false
        if not op.isDead then aliveIdx[#aliveIdx + 1] = i end
    end
    local pick = nil
    if #aliveIdx > 0 then
        pick = aliveIdx[math.random(1, #aliveIdx)]
        MOCK.opponents[pick].isCurrent = true
    end
    MOCK.currentOppIdx = pick

    local oppName = (pick and MOCK.opponents[pick].name) or "人机"

    MOCK.combatData = {
        opponentName = oppName,
        myTeam = myTeam,
        enemyTeam = enemyTeam,
    }

    -- 预跑战斗，拿到事件流
    local events, winner = Combat.Simulate(myTeam, enemyTeam)
    combat_.events = events
    combat_.winner = winner
    combat_.cursor = 0
    combat_.phase = "showcase"
    combat_.timer = 0

    -- 局部刷新：重建敌方棋子区（我方棋子已在下方棋盘上，无需重建）
    ClearCombatFx()
    PrepLayout.RefreshEnemyArea(MOCK)
    -- 我方棋子引用就是棋盘格（战斗动画在棋盘上播放）
    PrepLayout.combatRefs = {
        my = PrepLayout.boardSlotRefs,
        enemy = PrepLayout.enemyRefs or {},
    }

    -- 切到战斗显示：收起商店、显示敌方
    PrepLayout.SetCombatMode(true)
    MOCK.state = "combat"

    -- 左侧列表高亮当前对手
    Scene.RefreshOpponentHighlight()
end

--- 只刷新左侧对手列表的高亮（不重建整树）
function Scene.RefreshOpponentHighlight()
    -- 对手列表是下半屏的一部分，重建成本低，直接局部重建
    if PrepLayout.RefreshOpponentList then
        PrepLayout.RefreshOpponentList(MOCK)
    end
end

--- 单场结束后的结算：扣血 → 提示 → 回备战页 或 进最终结算页
function Scene.AfterRound()
    local winner = combat_.winner

    -- 计算胜方存活棋子的星级总和 = 败方扣血量
    local function AliveStarSum(team)
        local sum = 0
        for _, u in ipairs(team) do
            if u.hp > 0 then sum = sum + (u.star or 1) end
        end
        return sum
    end

    local dmg = 0
    if winner == "my" then
        dmg = AliveStarSum(MOCK.combatData.enemyTeam)
    elseif winner == "enemy" then
        dmg = AliveStarSum(MOCK.combatData.myTeam)
    end
    if dmg < 1 then dmg = 1 end   -- 至少扣 1

    -- 扣血：输方扣
    if winner == "my" then
        local opp = MOCK.currentOppIdx and MOCK.opponents[MOCK.currentOppIdx]
        if opp then
            opp.hp = opp.hp - dmg
            if opp.hp <= 0 then opp.hp = 0 opp.isDead = true end
        end
        Shared.Notify.Toast("胜利！对手 -" .. dmg .. " 血")
    elseif winner == "enemy" then
        MOCK.myHp = MOCK.myHp - dmg
        if MOCK.myHp < 0 then MOCK.myHp = 0 end
        Shared.Notify.Toast("失败！我方 -" .. dmg .. " 血")
    else
        Shared.Notify.Toast("平局")
    end

    print(string.format("[Combat] 回合%d 结束：胜者=%s 扣血=%d 我方=%d 对手=%d",
        MOCK.round, tostring(winner), dmg, MOCK.myHp,
        MOCK.currentOppIdx and MOCK.opponents[MOCK.currentOppIdx].hp or -1))

    MOCK.round = MOCK.round + 1

    -- 判负：我方血量归零 → 最终结算
    if MOCK.myHp <= 0 then
        print("[Combat] 我方血量归零 → 最终结算")
        MOCK.state = "result"
        Scene.RefreshUI()
        return
    end

    -- 存活对手为空 → 我方夺冠 → 最终结算
    local anyAlive = false
    for _, op in ipairs(MOCK.opponents) do
        if not op.isDead then anyAlive = true break end
    end
    if not anyAlive then
        print("[Combat] 所有对手出局 → 最终结算")
        MOCK.state = "result"
        Scene.RefreshUI()
        return
    end

    -- 否则回备战态，进入下一回合（只切显示，不重建整树）
    ClearCombatFx()
    PrepLayout.SetCombatMode(false)
    -- 战斗会消耗我方棋子血量，备战棋盘需要恢复为满血新棋子
    Scene.RestoreBoardAfterCombat()
    MOCK.state = "prep"
    Scene.RefreshOpponentHighlight()
end

--- 战斗结束后恢复我方棋盘（棋子满血、可再次拖拽）
function Scene.RestoreBoardAfterCombat()
    for i = 1, 6 do
        local s = MOCK.boardSlots[i]
        if s and s.occupied then
            s.hp = Combat.UNIT_HP
            s.atk = Combat.UNIT_ATK
        end
    end
    PrepLayout.RefreshBoard(MOCK)
end

--- 从最终结算页返回玩法大厅（玩家主动触发）
function Scene.LeaveToLobby()
    if ctx_ and ctx_.onLeave then
        ctx_.onLeave()
    end
end

--- 按事件更新某个棋子的显示
--- 返回扣血量（供调用方弹飘字），并在血量归零时标记销毁
---@param isEnemy boolean
---@param idx integer
---@param hp integer
---@param dmg integer|nil 本次受到的伤害（用于弹飘字）
---@return number actualDmg 实际扣血量
local function ApplyHp(isEnemy, idx, hp, dmg)
    local refs = PrepLayout.combatRefs
    if not refs then return 0 end
    local piece = (isEnemy and refs.enemy or refs.my)[idx]
    if not piece then return 0 end

    -- 计算实际扣血量（用于飘字）
    local prevHp = piece._hp or hp
    local actual = math.max(0, prevHp - hp)
    piece._hp = hp

    local dead = hp <= 0
    if piece._hpLabel then
        piece._hpLabel:SetText(tostring(hp))
        piece._hpLabel:SetFontColor(dead and HexRGB("#8a8a8a") or HexRGB("#ffb0b0"))
    end
    if piece._hpCircle then
        piece._hpCircle:SetStyle({
            backgroundColor = dead and { 40, 40, 42, 250 } or { 76, 26, 30, 250 },
            borderColor = dead and { 90, 90, 90, 255 } or { 224, 106, 106, 255 },
        })
    end
    if piece._deadMark then
        piece._deadMark:SetVisible(dead)
    end

    -- 弹伤害飘字（受伤方显示红色）
    if actual > 0 then
        SpawnFloat(piece, actual, { 255, 90, 90, 255 })
    end

    -- 血量归零 → 延迟销毁（先让玩家看到骷髅）
    if dead and not piece._deadQueued then
        piece._deadQueued = true
        MarkDead(piece)
    end

    return actual
end

--- 取某个棋子的 widget
---@param isEnemy boolean
---@param idx integer
---@return any|nil
local function GetPiece(isEnemy, idx)
    local refs = PrepLayout.combatRefs
    if not refs then return nil end
    return (isEnemy and refs.enemy or refs.my)[idx]
end

--- 让出手方所在的半屏容器压到另一方之上
---
--- 战斗布局是「上半屏 = 敌方棋子、下半屏 = 我方棋盘」两个独立容器。
--- 棋子位移会跨过半屏边界，而 zIndex 只在同一父容器内比较，
--- 所以必须抬整个半屏容器，才能让冲过去的棋子不被对方遮住。
---@param atkIsEnemy boolean
local function SetAttackerOnTop(atkIsEnemy)
    local upper = PrepLayout.upperRef   -- 上半屏（敌方）
    local lower = PrepLayout.lowerRef   -- 下半屏（我方）
    if not upper or not lower then return end

    local atkPanel = atkIsEnemy and upper or lower
    local defPanel = atkIsEnemy and lower or upper
    atkPanel:SetStyle({ zIndex = 10 })
    defPanel:SetStyle({ zIndex = 1 })
end

--- 恢复默认层级（上半屏压在下方之上）
local function ResetTeamZ()
    if PrepLayout.upperRef then PrepLayout.upperRef:SetStyle({ zIndex = 0 }) end
    if PrepLayout.lowerRef then PrepLayout.lowerRef:SetStyle({ zIndex = 0 }) end
end

--- 结算一次攻击（伤害 + 反击）
---@param ev table
local function ResolveAttack(ev)
    ApplyHp(ev.targetIsEnemy, ev.targetIdx, ev.targetHpAfter, ev.damage)
    if ev.counter and ev.counter > 0 then
        ApplyHp(not ev.targetIsEnemy, ev.attackerIdx, ev.attackerHpAfter, ev.counter)
    end
    print(string.format("[Combat]   结算 %s 的 %d 号打 %s 的 %d 号，伤害 %d，反击 %d",
        ev.side, ev.attackerIdx,
        ev.targetIsEnemy and "敌" or "我", ev.targetIdx,
        ev.damage, ev.counter))
end

--- 播放下一条战斗事件
local function PlayNextEvent()
    local ev = combat_.events[combat_.cursor]
    if not ev then
        combat_.phase = "done"
        combat_.timer = 0
        return
    end

    if ev.kind == "attack" then
        -- 启动一次攻击动画：攻击方位移到目标身边 → 结算伤害 → 归位
        local atkPiece = GetPiece(not ev.targetIsEnemy, ev.attackerIdx)
        local tgtPiece = GetPiece(ev.targetIsEnemy, ev.targetIdx)

        if atkPiece and tgtPiece then
            local a = atkPiece:GetAbsoluteLayout()
            local t = tgtPiece:GetAbsoluteLayout()
            if a and t then
                -- 位移量：让攻击方中心贴到目标中心附近（留一点间距）
                local dx = (t.x + t.w / 2) - (a.x + a.w / 2)
                local dy = (t.y + t.h / 2) - (a.y + a.h / 2)
                -- 朝目标方向收一点，避免完全重叠
                local shrink = 0.72

                -- 让出手方所在队伍整体压到对方之上，
                -- 否则攻击方冲到对方面前时会被对方的行容器盖住。
                local atkIsEnemy = not ev.targetIsEnemy
                SetAttackerOnTop(atkIsEnemy)

                combat_.anim = {
                    phase = "dash",
                    timer = 0,
                    piece = atkPiece,
                    atkIsEnemy = atkIsEnemy,
                    dx = dx * shrink,
                    dy = dy * shrink,
                    ev = ev,
                }
                print(string.format("[Combat] %s 的 %d 号 → %s 的 %d 号（位移 %.0f,%.0f）",
                    ev.side, ev.attackerIdx,
                    ev.targetIsEnemy and "敌" or "我", ev.targetIdx, dx * shrink, dy * shrink))
                return
            end
        end

        -- 取不到布局：直接结算
        ResolveAttack(ev)

    elseif ev.kind == "start" then
        print("[Combat] 战斗开始，我方先手 = " .. tostring(ev.myFirst))
    elseif ev.kind == "end" then
        print("[Combat] 战斗结束，胜者 = " .. tostring(ev.winner))
    end
end

--- 攻击动画状态机（冲刺 → 命中 → 归位）
---@param dt number
---@return boolean 动画是否仍在进行
local function UpdateAttackAnim(dt)
    local a = combat_.anim
    if not a then return false end

    a.timer = a.timer + dt

    if a.phase == "dash" then
        -- 冲向目标（DASH_SEC 秒）
        local k = math.min(a.timer / DASH_SEC, 1)
        if a.piece then
            a.piece:SetStyle({
                translateX = a.dx * k,
                translateY = a.dy * k,
            })
        end
        if k >= 1 then
            a.phase = "hit"
            a.timer = 0
            -- 命中瞬间结算伤害
            ResolveAttack(a.ev)
        end
        return true

    elseif a.phase == "hit" then
        -- 停留一下（HIT_SEC 秒）
        if a.timer >= HIT_SEC then
            a.phase = "back"
            a.timer = 0
        end
        return true

    elseif a.phase == "back" then
        -- 归位（BACK_SEC 秒）
        local k = math.min(a.timer / BACK_SEC, 1)
        if a.piece then
            a.piece:SetStyle({
                translateX = a.dx * (1 - k),
                translateY = a.dy * (1 - k),
            })
        end
        if k >= 1 then
            if a.piece then
                a.piece:SetStyle({ translateX = 0, translateY = 0 })
            end
            ResetTeamZ()
            combat_.anim = nil
        end
        return true
    end

    combat_.anim = nil
    return false
end

--- 战斗阶段每帧更新
---@param dt number
local function UpdateCombat(dt)
    -- 伤害飘字与死亡销毁始终推进（战斗结束后还要把飘字播完）
    UpdateFloats(dt)
    UpdatePendingKill(dt)

    if MOCK.state ~= "combat" then return end
    if combat_.phase == "idle" then return end

    combat_.timer = combat_.timer + dt

    if combat_.phase == "showcase" then
        -- 展示阵容，到点开打
        if combat_.timer >= SHOWCASE_SEC then
            combat_.phase = "playing"
            combat_.timer = 0
            combat_.cursor = 0
            print("[Combat] 阵容展示结束，开始战斗")
        end

    elseif combat_.phase == "playing" then
        -- 攻击动画播放中 → 等它结束
        if UpdateAttackAnim(dt) then return end

        if combat_.timer >= STEP_SEC then
            combat_.timer = 0
            combat_.cursor = combat_.cursor + 1
            PlayNextEvent()
        end

    elseif combat_.phase == "done" then
        -- 单场结束：短暂停留让玩家看清结果，然后回备战页
        if combat_.timer >= 1.2 then
            combat_.phase = "idle"
            Scene.AfterRound()
        end
    end
end

-- ---------------------------------------------------------
-- 结算/失败界面（简化版）
-- ---------------------------------------------------------
local function BuildResult()
    local UI = UI_

    -- 顶部：名次
    local rankLabel = UI.Label {
        text = "第 " .. tostring(MOCK.resultData.rank) .. " 名",
        fontSize = 48,
        fontColor = HexRGB("#dde5f0"),
        width = "100%",
        textAlign = "center",
        marginTop = 40,
        marginBottom = 20,
    }

    -- 中间：吉祥物占位
    local mascot = UI.Panel {
        width = 120, height = 120,
        backgroundColor = { 230, 230, 235, 255 },
        borderRadius = 60,
        alignSelf = "center",
        justifyContent = "center",
        alignItems = "center",
        marginBottom = 40,
        children = {
            UI.Label { text = "(吉祥物)", fontSize = 14,
                       fontColor = HexRGB("#666666") },
        },
    }

    -- 玩家信息：头像 + 昵称
    local playerRow = UI.Panel {
        width = "100%",
        flexDirection = "row",
        justifyContent = "center",
        alignItems = "center",
        gap = 12,
        marginBottom = 12,
        children = {
            Box(60, 60, "头像", HexRGB("#887744")),
            UI.Label {
                text = "敷衍的龙1668",
                fontSize = 20,
                fontColor = HexRGB("#ffcc66"),
            },
        },
    }

    -- 段位积分
    local scoreRow = UI.Panel {
        width = "100%",
        flexDirection = "row",
        justifyContent = "center",
        alignItems = "center",
        gap = 8,
        marginBottom = 10,
        children = {
            UI.Label { text = "段位积分", fontSize = 14,
                       fontColor = HexRGB("#aaaaaa") },
            UI.Label { text = tostring(MOCK.resultData.score), fontSize = 18,
                       fontColor = HexRGB("#ffffff") },
            UI.Label {
                text = (MOCK.resultData.scoreDelta >= 0 and "+" or "")
                    .. tostring(MOCK.resultData.scoreDelta),
                fontSize = 16,
                fontColor = HexRGB("#88cc88"),
            },
            UI.Label { text = "58", fontSize = 14,
                       fontColor = HexRGB("#88cc88") },
        },
    }

    -- 底部小提示行
    local hintRow = UI.Label {
        text = "（第" .. tostring(MOCK.resultData.rank) .. "名 "
            .. tostring(MOCK.resultData.rankDelta) .. "   点击准备 +"
            .. tostring(MOCK.resultData.readyBonus) .. "）",
        fontSize = 12,
        fontColor = HexRGB("#999999"),
        width = "100%",
        textAlign = "center",
        marginBottom = 40,
    }

    -- 返回按钮（圆形 + 文字）
    local backBtn = UI.Panel {
        width = 60, height = 60,
        backgroundColor = { 160, 60, 60, 255 },
        borderRadius = 30,
        alignSelf = "center",
        justifyContent = "center",
        alignItems = "center",
        pointerEvents = "auto",
        onClick = function()
            print("[Autochess] 最终结算 → 返回玩法大厅")
            Scene.LeaveToLobby()
        end,
        children = {
            UI.Label { text = "←", fontSize = 26,
                       fontColor = HexRGB("#ffffff") },
        },
    }
    local backLabel = UI.Label {
        text = "返回大厅",
        fontSize = 14,
        fontColor = HexRGB("#dddddd"),
        width = "100%",
        textAlign = "center",
        marginTop = 8,
    }

    -- 组装
    return UI.Panel {
        width = "100%", height = "100%",
        flexDirection = "column",
        backgroundColor = { 12, 14, 18, 255 },
        paddingHorizontal = 24,
        children = {
            rankLabel,
            mascot,
            playerRow,
            scoreRow,
            hintRow,
            UI.Panel {
                flexGrow = 1,
            },
            backBtn,
            backLabel,
        },
    }
end

-- ---------------------------------------------------------
-- 卡牌详情弹窗
-- ---------------------------------------------------------
---@param card AutochessMockShopCard
---@return any
local function BuildDetailOverlay(card)
    local UI = UI_

    -- 卡牌本体（阻止点击穿透到遮罩）
    local cardBody = UI.Panel {
        width = "60%",
        backgroundColor = { 40, 38, 45, 255 },
        borderWidth = 2,
        borderColor = HexRGB("#c8a96b"),
        borderRadius = 12,
        flexDirection = "column",
        alignItems = "center",
        paddingVertical = 12,
        paddingHorizontal = 10,
        gap = 8,
        pointerEvents = "auto",
        onClick = function()
            -- 空实现：吃掉点击，不关闭弹窗
        end,
        children = {
            -- 卡牌名字
            UI.Label {
                text = card.name,
                fontSize = 20,
                fontColor = HexRGB("#f0e6d0"),
                textAlign = "center",
                width = "100%",
            },
            -- 大头像（圆形）
            UI.Panel {
                width = 160, height = 160,
                backgroundColor = { 70, 65, 80, 255 },
                borderRadius = 80,
                justifyContent = "center",
                alignItems = "center",
                children = {
                    UI.Label { text = "头像", fontSize = 16,
                               fontColor = HexRGB("#aaaaaa") },
                },
            },
            -- 星级（金色星星）
            UI.Label {
                text = "★",
                fontSize = 22,
                fontColor = HexRGB("#ffcc66"),
            },
            -- 描述文本
            UI.Label {
                text = card.desc,
                fontSize = 14,
                fontColor = HexRGB("#dddddd"),
                textAlign = "center",
                width = "90%",
                marginTop = 4,
                marginBottom = 4,
            },
            -- 底部三元素：费用 + 羁绊 + 攻击/血量
            UI.Panel {
                flexDirection = "row",
                alignItems = "center",
                justifyContent = "space-between",
                width = "80%",
                marginTop = 4,
                children = {
                    -- 左：费用圈
                    UI.Panel {
                        width = 32, height = 32,
                        backgroundColor = { 40, 60, 100, 255 },
                        borderRadius = 16,
                        justifyContent = "center", alignItems = "center",
                        children = {
                            UI.Label { text = tostring(card.cost), fontSize = 14,
                                       fontColor = HexRGB("#ffffff") },
                        },
                    },
                    -- 中：羁绊标签
                    UI.Panel {
                        paddingHorizontal = 16, paddingVertical = 4,
                        backgroundColor = { 60, 50, 90, 255 },
                        borderRadius = 12,
                        children = {
                            UI.Label { text = card.tag, fontSize = 14,
                                       fontColor = HexRGB("#ffffff") },
                        },
                    },
                    -- 右：攻击/血量双圈
                    UI.Panel {
                        flexDirection = "row",
                        gap = 4,
                        children = {
                            UI.Panel {
                                width = 32, height = 32,
                                backgroundColor = { 40, 90, 40, 255 },
                                borderRadius = 16,
                                justifyContent = "center", alignItems = "center",
                                children = {
                                    UI.Label { text = tostring(card.atk), fontSize = 13,
                                               fontColor = HexRGB("#ffffff") },
                                },
                            },
                            UI.Panel {
                                width = 32, height = 32,
                                backgroundColor = { 90, 40, 40, 255 },
                                borderRadius = 16,
                                justifyContent = "center", alignItems = "center",
                                children = {
                                    UI.Label { text = tostring(card.hp), fontSize = 13,
                                               fontColor = HexRGB("#ffffff") },
                                },
                            },
                        },
                    },
                },
            },
        },
    }

    -- "查看金色"按钮（先占位，不响应）
    local viewGoldBtn = UI.Panel {
        flexDirection = "row",
        alignItems = "center",
        gap = 8,
        marginTop = 14,
        pointerEvents = "auto",
        onClick = function()
            print("[Mock] 点击查看金色（占位）")
        end,
        children = {
            UI.Panel {
                width = 22, height = 22,
                backgroundColor = { 0, 0, 0, 0 },
                borderWidth = 2,
                borderColor = HexRGB("#aaaaaa"),
                borderRadius = 11,
            },
            UI.Label { text = "查看金色", fontSize = 14,
                       fontColor = HexRGB("#dddddd") },
        },
    }

    -- 羁绊提示框（固定两条，后续会改成动态）
    local tagHint1 = UI.Panel {
        width = "80%",
        paddingVertical = 8,
        paddingHorizontal = 12,
        backgroundColor = { 20, 20, 25, 230 },
        borderWidth = 1,
        borderColor = HexRGB("#555555"),
        borderRadius = 4,
        marginTop = 12,
        children = {
            UI.Label {
                text = "冥想：等待对应的回合数后触发效果",
                fontSize = 13,
                fontColor = HexRGB("#dddddd"),
                width = "100%",
            },
        },
    }

    local tagHint2 = UI.Panel {
        width = "80%",
        paddingVertical = 8,
        paddingHorizontal = 12,
        backgroundColor = { 20, 20, 25, 230 },
        borderWidth = 1,
        borderColor = HexRGB("#555555"),
        borderRadius = 4,
        marginTop = 8,
        children = {
            UI.Label {
                text = "星团：名称包含星团的随从",
                fontSize = 13,
                fontColor = HexRGB("#dddddd"),
                width = "100%",
            },
        },
    }

    -- 全屏遮罩（点击空白关闭）
    return UI.Panel {
        width = "100%", height = "100%",
        position = "absolute",
        top = 0, left = 0,
        backgroundColor = { 0, 0, 0, 180 },
        flexDirection = "column",
        justifyContent = "center",
        alignItems = "center",
        pointerEvents = "auto",
        onClick = function()
            MOCK.detailCard = nil
            Scene.RefreshUI()
        end,
        children = {
            cardBody,
            viewGoldBtn,
            tagHint1,
            tagHint2,
        },
    }
end

-- ============================================================
-- 四、对外接口
-- ============================================================

function Scene.SetDependencies(deps)
    ThemeRef_ = deps.Theme
    WidgetsRef_ = deps.Widgets
end

function Scene.RefreshUI()
    if not UI_ then return end

    local newRoot = nil
    if MOCK.state == "result" then
        newRoot = BuildResult()
    else
        -- prep / combat 共用同一套布局（PrepLayout.Build），
        -- 只通过 PrepLayout.SetCombatMode 切换上下半屏的显示内容
        newRoot = BuildPrep()
        PrepLayout.SetCombatMode(MOCK.state == "combat")
    end

    if newRoot then
        -- 如果有打开的详情卡，把覆盖层叠在最上层
        if MOCK.detailCard then
            newRoot:AddChild(BuildDetailOverlay(MOCK.detailCard))
        end

        if root_ then
            root_:Remove()
        end
        root_ = newRoot
        UI_.SetRoot(root_)
    end
end

function Scene.Build(uiLib, gameScene, ctx)
    UI_ = uiLib
    ctx_ = ctx
    -- 调试开关：可选值 "prep" / "combat" / "result"
    MOCK.state = "prep"
    Scene.RefreshUI()
    print("[Autochess] 客户端场景已构建")
end

-- ============================================================
-- ============================================================
-- 拖拽系统
--
-- 交互（对齐《月圆之夜》的拖拽出牌手感）：
--   1. 按住卡牌 → 卡牌本体跟随手指移动（不新建浮层）
--   2. 拖到有效落点 → 目标区域高亮提示
--   3. 松手 → 命中则生效，未命中则卡牌回弹原位
--   4. 轻点（未达拖拽阈值就松手）→ 交给 onClick 开详情
--
-- 实现要点：
--   · 用 widget 的 translateX/translateY 做平移 —— 这是渲染层变换，
--     不触发 Yoga 重排，因此拖拽期间不会重建 UI 树
--   · 每帧轮询指针位置，不依赖 onPointerMove（触摸事件在部分平台不连续）
--   · 起拖时调 UI.CancelPointer 取消按压，避免松手误触发 onClick
-- ============================================================

-- 拖拽阈值
local DRAG_MOVE_PX  = 8      -- 手指移动超过此距离（base 像素）即起拖
local DRAG_HOLD_SEC = 0.12   -- 按住超过此秒数即起拖

--- 取输入模块
---@return any|nil
local function GetInputLib()
    return UI_ and UI_.Input or nil
end

--- 读指针位置并换算为 base 像素（与 UI 布局同坐标系）
---
--- 注意：UI.Input.GetPointerPosition() 内部只读 activePointers_[0]（鼠标）。
--- 触摸屏的指针 id 从 1 开始，且松手瞬间活跃表会被清空，
--- 所以这里直接遍历活跃指针，并缓存最后一次有效坐标 —— 否则松手时
--- 会拿到 (0,0)，导致落点判定全部失败。
---@type number
local lastPointerX_ = 0
---@type number
local lastPointerY_ = 0

---@return number x, number y
local function GetPointerBasePos()
    local InputLib = GetInputLib()
    local s = (UI_.GetScale and UI_.GetScale()) or 1
    if s == 0 then s = 1 end

    if not InputLib then
        return lastPointerX_ / s, lastPointerY_ / s
    end

    local x, y = nil, nil

    -- 优先鼠标指针（id 0）
    if InputLib.GetPointer then
        local p0 = InputLib.GetPointer(0)
        if p0 then x, y = p0.x, p0.y end
    end

    -- 触摸：指针 id 从 1 起，取任意活跃指针
    if not x and InputLib.GetActivePointers then
        for _, p in pairs(InputLib.GetActivePointers()) do
            if p and p.x then
                x, y = p.x, p.y
                break
            end
        end
    end

    -- 全部松手时沿用最后一次有效坐标
    if not x then
        x, y = lastPointerX_, lastPointerY_
    else
        lastPointerX_, lastPointerY_ = x, y
    end

    return x / s, y / s
end

--- 取当前活跃指针的 id（鼠标为 0，触摸为 >=1）
---@return number|nil
local function GetActivePointerId()
    local InputLib = GetInputLib()
    if not InputLib or not InputLib.GetActivePointers then return nil end
    local pointers = InputLib.GetActivePointers()
    if pointers[0] then return 0 end
    for id in pairs(pointers) do
        return id
    end
    return nil
end

--- 命中检测：返回指针下的可拖拽卡牌条目
--- 逆序遍历，后加入的（层级更高的）优先
---@param x number
---@param y number
---@return table|nil
local function HitTestCard(x, y)
    local entries = PrepLayout.dragEntries
    for i = #entries, 1, -1 do
        local entry = entries[i]
        local w = entry.widget
        if w then
            local l = w:GetAbsoluteLayout()
            if l and x >= l.x and x <= l.x + l.w
                   and y >= l.y and y <= l.y + l.h then
                return entry, l
            end
        end
    end
    return nil
end

--- 把卡牌平移到「让按下点仍贴在手指下」的位置
---@param d AutochessMockDragging
---@param x number
---@param y number
local function MoveCard(d, x, y)
    local w = d.widget
    if not w then return end
    local l = d.baseLayout
    if not l then return end
    w:SetStyle({
        translateX = (x - d.grabDX) - l.x,
        translateY = (y - d.grabDY) - l.y,
    })
end

--- 复位卡牌平移量与容器层级
---@param widget any
local function ResetCard(widget)
    if widget then
        widget:SetStyle({ translateX = 0, translateY = 0, zIndex = 0 })
    end
    -- 上半屏容器层级复位（BeginDrag 抬到 100）
    if PrepLayout.upperRef then
        PrepLayout.upperRef:SetStyle({ zIndex = 0 })
    end
end

--- 开始拖拽
---@param entry table  PrepLayout.dragEntries 中的条目
---@param l table      卡牌的绝对布局
---@param x number
---@param y number
local function BeginDrag(entry, l, x, y)
    MOCK.pendingPress = nil
    MOCK.dragging = {
        card = entry.card,
        source = entry.source,
        slotIndex = entry.slotIndex,
        widget = entry.widget,
        baseLayout = l,
        grabDX = x - l.x,
        grabDY = y - l.y,
    }
    MOCK.dragPos = { x = x, y = y }

    -- 抬高被拖卡牌所在的上半屏容器
    -- 被拖卡片在 prepPanelRef 内部，而 shopAreaRef 是 root 的兄弟节点，
    -- 层级比 prepPanelRef 高；只抬卡片本身不够，必须抬整个上半屏容器，
    -- 否则拖到商店区域时卡片会被 shopAreaRef 盖住看不见。
    if PrepLayout.upperRef then
        PrepLayout.upperRef:SetStyle({ zIndex = 100 })
    end
    entry.widget:SetStyle({ zIndex = 9999 })

    -- 商店卡起拖 → 显示「购买区域」提示框
    if entry.source == "shop" and PrepLayout.buyAreaRef then
        PrepLayout.buyAreaRef:SetVisible(true)
    end

    -- 取消按压：避免松手时触发卡牌 onClick
    local pid = GetActivePointerId()
    if pid and UI_.CancelPointer then
        UI_.CancelPointer(pid)
    end

    print("[Drag] 起拖 source=" .. tostring(entry.source)
        .. " slot=" .. tostring(entry.slotIndex)
        .. " card=" .. tostring(entry.card and entry.card.name))
end

--- 结束拖拽：命中则生效并重建 UI；未命中则卡牌回弹原位
---@param x number
---@param y number
local function EndDrag(x, y)
    local d = MOCK.dragging

    -- 隐藏「购买区域」提示框
    if PrepLayout.buyAreaRef then
        PrepLayout.buyAreaRef:SetVisible(false)
    end

    print("[Drag] 松手 x=" .. tostring(math.floor(x))
        .. " y=" .. tostring(math.floor(y)))

    local handled, reason = Scene.ResolveDrop(x, y)
    MOCK.dragging = nil

    if handled then
        -- 数据已变，更新 UI 反映新状态
        if d and d.source == "board" then
            -- 棋盘内移动/交换：只重建棋盘，避免整树重建导致商店卡闪烁
            PrepLayout.RefreshBoard(MOCK)
        else
            Scene.RefreshUI()
        end
    else
        -- 未命中：先把卡牌平移量复位，再重建（Toast 提示若有）
        if d and d.widget then ResetCard(d.widget) end
        if reason then
            Shared.Notify.Toast(reason)
            Scene.RefreshUI()
        end
    end

    print("[Drag] 落点判定 handled=" .. tostring(handled)
        .. (reason and (" reason=" .. reason) or ""))
end

--- 拖拽每帧更新
---@param dt number
local function UpdateDrag(dt)
    -- 战斗中禁用拖拽
    if PrepLayout.dragEnabled == false then
        MOCK.pendingPress = nil
        return
    end

    local InputLib = GetInputLib()
    if not InputLib then
        MOCK.pendingPress = nil
        return
    end

    local isDown = InputLib.HasActivePointer()
    local px, py = GetPointerBasePos()

    -- ---------- 阶段一：按下候选 → 判断是否起拖 ----------
    if MOCK.pendingPress then
        if not isDown then
            -- 未达阈值就松手 → 轻点，交给 onClick
            MOCK.pendingPress = nil
        else
            local p = MOCK.pendingPress
            p.elapsed = (p.elapsed or 0) + (dt or 0)

            local dx = px - p.startX
            local dy = py - p.startY
            local dist = math.sqrt(dx * dx + dy * dy)

            if dist >= DRAG_MOVE_PX or p.elapsed >= DRAG_HOLD_SEC then
                BeginDrag(p.entry, p.baseLayout, px, py)
            end
        end
        lastPointerDown_ = isDown
        return
    end

    -- ---------- 阶段二：拖拽中 → 移动卡牌，等松手 ----------
    if MOCK.dragging then
        MOCK.dragPos.x = px
        MOCK.dragPos.y = py
        MoveCard(MOCK.dragging, px, py)

        if lastPointerDown_ and not isDown then
            EndDrag(px, py)
            lastPointerDown_ = false
            return
        end
        lastPointerDown_ = isDown
        return
    end

    -- ---------- 空闲：检测按下 → 建立候选 ----------
    if isDown and not lastPointerDown_ then
        local entry, l = HitTestCard(px, py)
        if entry then
            MOCK.pendingPress = {
                card = entry.card,
                source = entry.source,
                slotIndex = entry.slotIndex,
                entry = entry,
                baseLayout = l,
                startX = px,
                startY = py,
                elapsed = 0,
            }
        end
    end

    lastPointerDown_ = isDown
end

function Scene.Update(dt, clientNet)
    -- 拖拽系统（独立于其他状态机，优先级最高）
    UpdateDrag(dt)
    -- 战斗播放
    UpdateCombat(dt)
end

--- 落点判定（纯数据变更，不重建 UI）
---
--- 职责边界：这里只改数据并返回结果；重建 UI 交给调用方，
--- 这样调用方能在重建前先复位被拖卡牌的平移量。
---@param x number
---@param y number
---@return boolean handled 是否命中有效落点
---@return string|nil reason 未命中原因（用于提示）
function Scene.ResolveDrop(x, y)
    local d = MOCK.dragging
    if not d then return false end

    -- 越界保护：slotIndex 缺失直接弹回
    if not d.slotIndex then
        return false
    end

    -- 用绝对布局做矩形判定
    local function InRect(widget)
        if not widget then return false end
        local l = widget:GetAbsoluteLayout()
        if not l then return false end
        return x >= l.x and x <= l.x + l.w
           and y >= l.y and y <= l.y + l.h
    end

    -- 商店区命中 → 卖卡（仅备战区起拖有效）
    if d.source == "bench" and InRect(PrepLayout.shopAreaRef) then
        if not MOCK.bench[d.slotIndex] then
            return false
        end
        table.remove(MOCK.bench, d.slotIndex)
        MOCK.gold = MOCK.gold + 1
        return true
    end

    -- 棋盘格命中 → 上阵（仅备战区起拖有效）
    if d.source == "bench" then
        for idx, slot in pairs(PrepLayout.boardSlotRefs) do
            if InRect(slot) then
                if MOCK.boardSlots[idx] and MOCK.boardSlots[idx].occupied then
                    return false, "该位置已有棋子"
                end
                if not MOCK.bench[d.slotIndex] then
                    return false
                end
                local card = table.remove(MOCK.bench, d.slotIndex)
                MOCK.boardSlots[idx] = {
                    occupied = true,
                    name = card.name,
                    star = card.star or 1,
                    atk = card.atk,
                    hp = card.hp,
                }
                return true
            end
        end
    end

    -- 棋盘棋子拖动 → 与目标格交换，或移到空位
    -- 注意：上阵后的棋子不能拖回备战区，只能留在棋盘上
    if d.source == "board" then
        for idx, slot in pairs(PrepLayout.boardSlotRefs) do
            if InRect(slot) then
                if idx == d.slotIndex then
                    -- 落回原格：不算失败，直接复位
                    return false
                end
                local from = MOCK.boardSlots[d.slotIndex]
                local to = MOCK.boardSlots[idx]
                if not from or not from.occupied then
                    return false
                end
                -- 交换（目标为空位时相当于移动）
                MOCK.boardSlots[d.slotIndex] = to
                MOCK.boardSlots[idx] = from
                return true
            end
        end
    end

    -- 购买区域命中 → 买卡（仅商店起拖有效）
    -- 购买区域 = 下半屏棋盘整块区域，松手即自动入备战区
    if d.source == "shop" and InRect(PrepLayout.buyAreaRef) then
        local card = MOCK.shopCards[d.slotIndex]
        if not card then return false end

        if MOCK.gold < card.cost then
            return false, "金币不足"
        end
        if #MOCK.bench >= 20 then
            return false, "备战区已满"
        end

        MOCK.gold = MOCK.gold - card.cost
        table.insert(MOCK.bench, card)
        MOCK.shopCards[d.slotIndex] = nil
        -- 重新压缩 shopCards（去掉 nil 空洞）
        local newShop = {}
        for _, c in ipairs(MOCK.shopCards) do table.insert(newShop, c) end
        MOCK.shopCards = newShop
        return true
    end

    -- 无效落点
    return false
end

function Scene.OnStateUpdate(s)
end

function Scene.Destroy()
    if root_ then
        root_:Remove()
        root_ = nil
    end
    print("[Autochess] 客户端场景已销毁")
end

return Scene
