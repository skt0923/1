-- ============================================================
-- Shared_Data.lua：客户端玩家数据层（Data / Notify 模块）
--
-- 从 Shared_Logic.lua 拆出（两个 do...end 块原样迁移）。
-- 由 Shared_Logic.lua 在**全部纯函数定义完成后**于文件末尾 require，
-- 把 Shared.Data / Shared.Notify 挂到 Shared 全局表上。
--
-- ⚠️ 本文件不要 require("Shared")：与 Shared_Logic 同理，
--    Shared 是全局表（Shared.lua 里无 local 声明），直接访问即可。
--    Data 的方法会调用 Shared.SafeDecode / Shared.Notify.Toast，
--    这些都由加载顺序保证在运行时已就绪。
-- ============================================================

-- ===== 模块：Data =====
do
    -- ============================================================
    -- client/Data.lua：客户端玩家数据层
    -- 所有 UI 与玩法模块都通过这里读写玩家状态，避免全局变量满天飞
    -- ============================================================

    local Data = {}

    ---@class ClientData
    ---@field gold integer
    ---@field level integer
    ---@field killProgress integer 本级已累计击杀数（纯内存，不写档）
    ---@field hp number
    ---@field maxHp number
    ---@field inventory table[]
    ---@field equipment table<string, table>
    ---@field bagPageCount integer
    ---@field autoDecompose table<string, boolean>     自动分解：已鉴定装备（按品质）
    ---@field autoDecomposeUnid table<string, boolean> 自动分解：未鉴定装备（按品质）
    ---@field autoRepair boolean 自动维修：每 30 分钟修一次全身
    ---@field autoRepairTimer number 自动维修计时（秒，客户端内存态，不持久化）
    ---@field isDead boolean
    ---@field mails table[]
    ---@field onlineTokenSeconds integer
    ---@field isStanding boolean
    ---@field adCountToday integer
    ---@field adCooldownLeft number
    ---@field autoBattleOn boolean
    ---@field normalAttackOn boolean
    ---@field settings table  画面/特效设置（见 Shared.NewDefaultSettings）
    ---@field pets table 宠物系统：{ equipped = { [slot] = pet }, pool = pet[] }
    ---@field petGacha table 抽卡保底计数器：{ counters = { [quality] = integer } }
    ---@field bdTree table 天赋树：{ nodes = { [nodeId] = true } }（客户端权威）
    ---@field levelStone table|nil 等级石（nil = 未装备）；level 字段即玩家等级
    ---@field levelStoneGiftReceived boolean 等级石礼包幂等键

    ---@type ClientData
    local data = {
        gold               = Shared.C.INIT_GOLD,
        level              = 1,
        killProgress       = 0,
        hp                 = 200,
        maxHp              = 200,
        inventory          = {},
        equipment          = {},
        bagPageCount       = 1,
        autoDecompose      = { normal=false, magic=false, rare=false, legendary=false, mythic=false },
        autoDecomposeUnid  = { normal=false, magic=false, rare=false, legendary=false, mythic=false },
        autoRepair         = false,
        autoRepairTimer    = 0,
        -- 注意：autoIdThenDecompose 存在 Data.value.settings 里（见 Shared.NewDefaultSettings），
        -- 这里不重复定义，避免双份数据不一致。
        settings           = Shared.NewDefaultSettings(),
        isDead             = false,
        mails              = {},
        -- 时长：客户端内存用秒（每秒扣减），存档用分钟
        -- 为 0：开局时长由服务端下发的真实值决定（新玩家 = 0，
        -- 靠新手礼包/每日赠送的在线卡自动续）
        onlineTokenSeconds = 0,
        isStanding         = false,
        adCountToday       = 0,
        adCooldownLeft     = 0,
        adLastTime         = 0,
        lastResetDate      = Shared.TodayString(),
        autoBattleOn       = false,
        normalAttackOn     = false,
        -- 邮件汇总数字（服务端下发）
        mailGoldTotal      = 0,
        mailItemTotal      = 0,
        mailTotal          = 0,
        -- 宠物系统（客户端权威；服务端首次下发前用空结构兜底）
        pets               = Shared.NewPetData(),
        petGacha           = Shared.NewPetGachaData(),
        -- 天赋树（客户端权威；服务端首次下发前用空结构兜底）
        bdTree             = Shared.NewBDTree(),
        -- 等级石
        levelStone         = nil,
        levelStoneGiftReceived = false,
    }

    ---@type string|nil
    local playerId_ = nil
    function Data.SetPlayerId(id) playerId_ = id end
    ---@return string|nil
    function Data.GetPlayerId() return playerId_ end

    Data.value = data

    -- ============ 脏标记（字段级）============
    -- 支持字段：inventory / equipment / gold / level / time
    local dirtyFlags_ = {}

    function Data.MarkDirty(field)
        dirtyFlags_[field or "_all"] = true
    end

    ---@param field string
    ---@return boolean
    function Data.HasDirty(field)
        if dirtyFlags_["_all"] then return true end
        return dirtyFlags_[field] == true
    end

    ---@return boolean
    function Data.HasAnyDirty()
        for _ in pairs(dirtyFlags_) do return true end
        return false
    end

    ---@param fields table|nil
    function Data.ClearDirty(fields)
        if fields == nil then
            dirtyFlags_ = {}
            return
        end
        for k in pairs(fields) do dirtyFlags_[k] = nil end
        dirtyFlags_["_all"] = nil
    end

    -- ============ 便捷读写 ============
    function Data.AddGold(v)
        data.gold = data.gold + v
        Data.MarkDirty("gold")
    end

    function Data.SpendGold(v)
        if data.gold < v then return false end
        data.gold = data.gold - v
        Data.MarkDirty("gold")
        return true
    end

    --- 按 id 在背包中查找
    ---@param id string
    ---@return table|nil, integer|nil
    function Data.FindInventoryItem(id)
        for i, it in ipairs(data.inventory) do
            if it.id == id then return it, i end
        end
        return nil, nil
    end

    --- 按 id 在装备栏中查找
    ---@param id string
    ---@return table|nil, string|nil
    function Data.FindEquipmentItem(id)
        for slot, eq in pairs(data.equipment) do
            if eq and eq.id == id then return eq, slot end
        end
        return nil, nil
    end

    --- 接收服务端下发数据。
    --- 客户端权威字段（背包/装备/金币/等级/时长）：本地 dirty 时忽略服务端覆盖。
    --- 服务端权威字段（邮件/邮件汇总）：始终接受。
    ---@param payload table
    function Data.ApplyServerPayload(payload)
        -- Force=1：服务端在「邮件领取 / 市场购买 / 每日赠送」等场景下发，
        -- 表示这份快照是刚算好的权威结果，本地 dirty 也要接受。
        local force = payload.Force == 1 or payload.Force == true
        -- 应用背包前记录旧 id 集合（用于后面识别"本次新增"的装备）
        local oldIds = nil

        if payload.Inventory and (force or not Data.HasDirty("inventory")) then
            local inv = Shared.SafeDecode(payload.Inventory)
            if type(inv) == "table" then
                -- 记录旧 id 集合，识别"本次新增"的装备（用于自动分解扫描）
                oldIds = {}
                for _, it in ipairs(data.inventory) do
                    if type(it) == "table" and it.id then oldIds[it.id] = true end
                end
                data.inventory = inv
            end
        end
        if payload.Equipment and (force or not Data.HasDirty("equipment")) then
            local eq = Shared.SafeDecode(payload.Equipment)
            if type(eq) == "table" then data.equipment = eq end
        end

        -- 宠物系统（客户端权威：本地 dirty 时忽略服务端覆盖）
        -- ⚠️ 必须校验**子结构**：服务端若发出 `{}`（如旧版默认档没有 pets 字段，
        --    经 `p.pets or {}` 编码成空表），SafeDecode 会得到真值空表并覆盖掉
        --    默认结构 —— 之后 UI 读 pets.equipped 直接崩。
        --    （Shared.IsPetDataValid 定义在下方，Lua 全局函数在调用时已就绪。）
        if payload.Pets and (force or not Data.HasDirty("pets")) then
            local pets = Shared.SafeDecode(payload.Pets)
            if Shared.IsPetDataValid(pets) then data.pets = pets end
        end
        if payload.PetGacha and (force or not Data.HasDirty("petGacha")) then
            local pg = Shared.SafeDecode(payload.PetGacha)
            if type(pg) == "table" and type(pg.counters) == "table" then
                data.petGacha = pg
            end
        end

        -- 天赋树（客户端权威：本地 dirty 时忽略服务端覆盖）
        -- ⚠️ 同样必须校验子结构（IsBDTreeValid），理由同 pets。
        if payload.BDTree and (force or not Data.HasDirty("bdTree")) then
            local bd = Shared.SafeDecode(payload.BDTree)
            if Shared.IsBDTreeValid(bd) then data.bdTree = bd end
        end

        -- 🔴 存量清洗（2026-10-04）：移除超出「随机属性 + 技能」上限的词条。
        --    服务端 ApplySaveToPlayer 已做同一件事；这里是**第二道防线**，
        --    覆盖「服务端尚未重启、仍在下发旧存档」的窗口期。
        do
            local r1 = Shared.SanitizeAffixContainer(data.equipment)
            local r2 = Shared.SanitizeAffixContainer(data.inventory)
            if r1 + r2 > 0 then
                Data.MarkDirty("equipment")
                Data.MarkDirty("inventory")
                print(string.format("[Data] 词条清洗：移除 %d 条超限词条", r1 + r2))
            end
            -- 存量清洗：强化等级超出该件上限的历史装备，夹回上限
            local c = 0
            for _, it in pairs(data.equipment) do
                if Shared.ClampItemEnhance(it) then c = c + 1 end
            end
            for _, it in ipairs(data.inventory) do
                if Shared.ClampItemEnhance(it) then c = c + 1 end
            end
            if c > 0 then
                Data.MarkDirty("equipment")
                Data.MarkDirty("inventory")
                print(string.format("[Data] 强化清洗：夹回 %d 件超限装备", c))
            end
        end
        if payload.Gold ~= nil and (force or not Data.HasDirty("gold")) then
            data.gold = math.floor(payload.Gold)
        end
        -- ⚠️ 等级石系统：等级以 levelStone.level 为单一事实来源，
        --    data.level 已废弃。这里不再回写 data.level，
        --    否则会把「等级石被卸下」的权威状态覆盖回去。
        --    客户端权威场景（dirty 时）本就不接受；非 dirty 时服务端下发的
        --    LevelStone 字段才是权威来源（见 Net.OnAssignPlayer / ApplyServerPayload）。
        -- （payload.Level 仍被接收，但不再落地到 data.level）
        if payload.BagPageCount ~= nil and payload.BagPageCount > 0 then
            data.bagPageCount = payload.BagPageCount
        end

        -- 邮件：服务端权威，始终接受
        if payload.Mails then
            local mails = Shared.SafeDecode(payload.Mails)
            if type(mails) == "table" then data.mails = mails end
        end
        if payload.MailTotal ~= nil then
            data.mailTotal = math.floor(payload.MailTotal)
        end
        if payload.MailGoldTotal ~= nil then
            data.mailGoldTotal = math.floor(payload.MailGoldTotal)
        end
        if payload.MailItemTotal ~= nil then
            data.mailItemTotal = math.floor(payload.MailItemTotal)
        end

        -- 时长：dirty 时忽略（分钟 → 秒）
        if payload.OnlineTokenMinutes ~= nil and not Data.HasDirty("time") then
            data.onlineTokenSeconds = math.floor(payload.OnlineTokenMinutes) * 60
        end

        if payload.AdCountToday ~= nil then
            data.adCountToday = math.floor(payload.AdCountToday)
        end

        -- 设置已完全客户端化：服务端不再回传，这里不再合并。
        -- （settings 现在是纯内存会话数据，每次启动由 NewDefaultSettings() 重建）

        -- 最后：所有字段都应用完后，扫描新增装备触发自动分解。
        -- ⚠️ 必须放在最后：DecideAutoHandle 需要读 data.gold 的最新值（金币不足时不触发）。
        if oldIds then
            Data.ProcessAutoHandleFromSync(oldIds)
        end
    end

    --- 玩家当前等级（等级石等级；无等级石时为 Lv1）。
    --- 所有读等级的地方应统一走此函数，不再直接读 d.level。
    ---@return integer
    function Data.GetLevel()
        local stone = Data.value.levelStone
        if type(stone) == "table" and stone.level then
            return stone.level
        end
        return 1
    end

    --- 读取设置表，并补齐旧存档缺失的字段。
    --- 旧存档没有 settings 字段（或只存了一部分）时，用默认值兜底，
    --- 避免调用方读 data.settings.xxx 得到 nil。
    ---@return table
    function Data.GetSettings()
        local d = Data.value
        if type(d.settings) ~= "table" then
            d.settings = Shared.NewDefaultSettings()
        else
            local def = Shared.NewDefaultSettings()
            for k, v in pairs(def) do
                if d.settings[k] == nil then d.settings[k] = v end
            end
        end
        return d.settings
    end

    --- 背包容量。
    --- ⚠️ 改读 Shared.C.MAX_INVENTORY，不再硬编码数字：
    ---    扩容时只需改常量一处，避免"改了 A 忘了 B"导致
    ---    本地容量与服务端校验不一致（背包满判定会漂移）。
    function Data.BagCapacity()
        return Shared.C.MAX_INVENTORY
    end

    --- 判定一件装备应该被自动怎么处理。
    --- 纯判定，不改任何状态；调用方根据返回值决定副作用。
    ---@param item table
    ---@return string|nil  "decompose" | "identify_then_decompose" | nil
    function Data.DecideAutoHandle(item)
        if not Shared.IsEquipment(item) then return nil end
        if Shared.IsLocked(item) then return nil end
        local q = item.quality
        if not q then return nil end

        local isId = (item.identified ~= false)

        if isId then
            -- 已鉴定：只看 autoDecompose
            if data.autoDecompose and data.autoDecompose[q] == true then
                return "decompose"
            end
            return nil
        end

        -- 未鉴定：优先"鉴定 + 分解"（因为用户勾选它表示愿意花钱换碎片）
        local ss = Data.GetSettings()
        local idThen = ss.autoIdThenDecompose
        if type(idThen) == "table" and idThen[q] == true then
            local cost = Shared.GetIdentifyCost(q)
            if (data.gold or 0) >= cost then
                return "identify_then_decompose"
            end
            -- 金币不足：不处理（不 fallback 到"未鉴定直接分解"，符合用户要求）
            return nil
        end

        -- 再退回"未鉴定自动分解"（折金币）
        if data.autoDecomposeUnid and data.autoDecomposeUnid[q] == true then
            return "decompose"
        end

        return nil
    end

    --- 服务端推背包后，扫描"本次新增的装备"，按自动分解设置处理。
    ---
    --- 🔴 邮件领取 / 市场购买的物品会绕过 Client.ClientAddToInventory 直接进包
    ---    （走的是服务端 PushInventory → ApplyServerPayload 覆盖背包的路径），
    ---    不在这里补一道扫描的话，开了自动分解也不会触发。
    ---@param oldIds table<string, boolean>  覆盖前背包里的 item id 集合
    function Data.ProcessAutoHandleFromSync(oldIds)
        local inv = data.inventory
        if type(inv) ~= "table" then return end
        if type(oldIds) ~= "table" then return end

        local handled = false
        for i = #inv, 1, -1 do
            local it = inv[i]
            if type(it) == "table" and it.id and not oldIds[it.id] then
                local mode = Data.DecideAutoHandle(it)
                if mode == "decompose" then
                    if it.identified == false then
                        local g = Shared.GetDecomposeGold(it.quality)
                        Data.AddGold(g)
                        Shared.Notify.Toast(string.format("自动分解（+%d💰）：%s", g, it.name or ""))
                    else
                        Shared.AddFragmentsToInventory(inv, it.quality, 1)
                        Shared.Notify.Toast("自动分解（碎片）：" .. (it.name or ""))
                    end
                    table.remove(inv, i)
                    handled = true
                elseif mode == "identify_then_decompose" then
                    local cost = Shared.GetIdentifyCost(it.quality)
                    if Data.SpendGold(cost) then
                        Shared.AddFragmentsToInventory(inv, it.quality, 1)
                        Shared.Notify.Toast(string.format(
                            "自动鉴定+分解（-%d💰 → 碎片）：%s", cost, it.name or ""))
                        table.remove(inv, i)
                        handled = true
                    end
                end
            end
        end

        if handled then
            Data.MarkDirty("inventory")
            Data.MarkDirty("gold")
        end
    end

    --- 物品是否可堆叠（碎片 / 精魄 / 令牌）
    ---@param item SharedItemLike|nil
    ---@return boolean
    function Data.IsStackable(item)
        -- 等级石不可堆叠
        if Shared.IsLevelStone(item) then return false end
        if Shared.IsFragment(item) or Shared.IsToken(item) then return true end
        if Shared.IsSpirit(item) then return true end
        if Shared.IsSummonScroll(item) then return true end
        if Shared.IsPetEgg(item) or Shared.IsPetMaterial(item) then return true end
        return false
    end

    Shared.Data = Data
end

-- ===== 模块：Notify =====
do
    -- ============================================================
    -- client/Notify.lua：全局提示（Toast）
    -- 独立成模块，避免 Data / Combat / UI 之间循环引用
    -- ============================================================
    local Notify = {}

    ---@type fun(text: string, color: string|nil)|nil
    local impl_ = nil

    --- 由 Client.lua 在 UI 初始化完成后注入真实实现
    ---@param fn fun(text: string, color: string|nil)
    function Notify.SetImpl(fn) impl_ = fn end

    ---@param text string
    ---@param color string|nil 形如 "#ff7878"；nil 用默认黄色
    function Notify.Toast(text, color)
        print("[Toast] " .. tostring(text))
        if impl_ then impl_(text, color) end
    end

    Shared.Notify = Notify
end
