-- ============================================================
-- Client.lua：客户端框架
--
-- 内容：
--   ClientNet     网络层
--   Theme         UI 主题
--   Widgets       通用控件
--   Modal         Modal 栈
--   Toast         顶部提示
--   ClientMain    入口
--
-- 界面流程：
--   MAIN_MENU（主菜单，三玩法文字选项）
--     ↓ enter_mode
--   MODE_PORTAL（玩法门户，[开始对战] + 附加按钮 + [返回主页]）
--     ↓ 点【开始对战】
--   ROOM_LIST（房间列表，顶部 tab 切模式）
--     ↓ create/join/auto_match
--   IN_ROOM（房间内，玩家列表 + 准备 + 离开房间）
--     ↓ 全员 ready 后服务端自动开局
--   对局界面（modes/<id>/ClientScene）
-- ============================================================
local Shared   = require("Shared")
local Protocol = Shared.Protocol
local Theme    = require("shared.Theme")
local AllModes = require("modes.AllModes")

local Client = {}

if log and LOG_INFO then log:Write(LOG_INFO, "[BOOT] Client module loaded") end

-- ============================================================
-- 一、ClientNet：客户端网络层
-- ============================================================

local ClientNet = {}

ClientNet.conn = nil
ClientNet.pendingActions = {}
ClientNet.nextSeq = 0
ClientNet.initialDataReady = false

local modeSubs_ = {}

function ClientNet.Subscribe(modeId, subEvent, handler)
    modeSubs_[modeId] = modeSubs_[modeId] or {}
    modeSubs_[modeId][subEvent] = handler
    print("[ClientNet] " .. modeId .. " 订阅事件：" .. subEvent)
end

function ClientNet.UnsubscribeAll(modeId)
    modeSubs_[modeId] = nil
    print("[ClientNet] " .. modeId .. " 已清空订阅")
end

local function DispatchToMode(modeId, eventName, data)
    -- 先派发给具体玩法的订阅
    local m = modeSubs_[modeId]
    if m then
        local handler = m[eventName]
        if handler then
            local ok, err = pcall(handler, data)
            if not ok then
                print("[ClientNet] 玩法 " .. modeId .. " 事件 "
                    .. eventName .. " 处理失败：" .. tostring(err))
            end
        end
    end

    -- 再派发给通配订阅（"*"）——服务端广播带的是具体 modeId，
    -- 框架层（如 room_state）用通配订阅接收所有玩法的消息。
    local w = modeSubs_["*"]
    if w then
        local handler = w[eventName]
        if handler then
            local ok, err = pcall(handler, data)
            if not ok then
                print("[ClientNet] 通配事件 " .. eventName
                    .. " 处理失败：" .. tostring(err))
            end
        end
    end
end

local cnetCtx = {
    getMyId      = function() return nil end,
    setMyId      = function(_) end,
    getScene     = function() return nil end,
    applyState   = function(_) end,
    onAssigned   = function(_) end,
    onKicked     = function(_) end,
    onServerFull = function(_) end,
    onSaveFailed = function() end,
    onToast      = function(_, _) end,
    onOnlineCount = function(_) end,
    onDisconnected = function() end,
}

function ClientNet.Init(c)
    for k, v in pairs(c) do cnetCtx[k] = v end
end

function ClientNet.Connect()
    ClientNet.conn = network:GetServerConnection()
    if not ClientNet.conn then
        print("[ClientNet] ⚠️ 未取得服务器连接")
        return false
    end
    local sc = cnetCtx.getScene()
    if sc then ClientNet.conn.scene = sc end
    ClientNet.conn:SendRemoteEvent(Protocol.C2S.CLIENT_READY, true)
    print("[ClientNet] 已发送 ClientReady")
    return true
end

function ClientNet.Reconnect()
    ClientNet.conn = network:GetServerConnection()
    if not ClientNet.conn then return false end
    local sc = cnetCtx.getScene()
    if sc then ClientNet.conn.scene = sc end
    ClientNet.conn:SendRemoteEvent(Protocol.C2S.CLIENT_READY, true)
    print("[ClientNet] 已重新连接")
    return true
end

function ClientNet.SendAction(action, payload, onResult)
    if not ClientNet.conn then
        if onResult then onResult(false, { reason = "未连接服务器" }) end
        return
    end
    ClientNet.nextSeq = ClientNet.nextSeq + 1
    local seq = ClientNet.nextSeq
    payload = payload or {}
    payload.Seq = seq
    payload.Action = action

    if onResult then ClientNet.pendingActions[seq] = onResult end

    -- 🔍 诊断探针：确认实际发出的 payload（排查服务端字段缺失）
    local keys = {}
    for k, v in pairs(payload) do
        keys[#keys + 1] = tostring(k) .. "=" .. tostring(v)
    end
    print("[SendAction] action=" .. tostring(action)
        .. " | " .. table.concat(keys, ", ")
        .. " | conn=" .. tostring(ClientNet.conn ~= nil))

    ClientNet.conn:SendRemoteEvent(Protocol.C2S.ACTION_REQUEST, true,
        Shared.ToVariantMap(payload))
end

function ClientNet.EnterMode(modeId, onResult)
    if not ClientNet.conn then
        if onResult then onResult(false, nil) end
        return
    end
    ClientNet.nextSeq = ClientNet.nextSeq + 1
    local seq = ClientNet.nextSeq
    if onResult then ClientNet.pendingActions[seq] = onResult end
    ClientNet.conn:SendRemoteEvent(Protocol.C2S.ENTER_MODE, true,
        Shared.ToVariantMap({ ModeId = modeId, Seq = seq }))
end

function ClientNet.LeaveMode(onResult)
    if not ClientNet.conn then
        if onResult then onResult(false, nil) end
        return
    end
    ClientNet.nextSeq = ClientNet.nextSeq + 1
    local seq = ClientNet.nextSeq
    if onResult then ClientNet.pendingActions[seq] = onResult end
    ClientNet.conn:SendRemoteEvent(Protocol.C2S.LEAVE_MODE, true,
        Shared.ToVariantMap({ Seq = seq }))
end

-- ============ 房间操作快捷方法 ============

--- 列出某模式下的房间
---@param modeId string
---@param gameModeId string
---@param onResult fun(ok: boolean, result: table|nil)
function ClientNet.ListRooms(modeId, gameModeId, onResult)
    ClientNet.SendAction("list_rooms", {
        ModeId = modeId,
        GameModeId = gameModeId,
    }, onResult)
end

--- 创建房间
---@param modeId string
---@param gameModeId string
---@param onResult fun(ok: boolean, result: table|nil)
function ClientNet.CreateRoom(modeId, gameModeId, onResult)
    ClientNet.SendAction("create_room", {
        ModeId = modeId,
        GameModeId = gameModeId,
    }, onResult)
end

--- 加入房间
---@param roomId string
---@param onResult fun(ok: boolean, result: table|nil)
function ClientNet.JoinRoom(roomId, onResult)
    ClientNet.SendAction("join_room", {
        RoomId = roomId,
    }, onResult)
end

--- 自动匹配
---@param modeId string
---@param gameModeId string
---@param onResult fun(ok: boolean, result: table|nil)
function ClientNet.AutoMatch(modeId, gameModeId, onResult)
    ClientNet.SendAction("auto_match", {
        ModeId = modeId,
        GameModeId = gameModeId,
    }, onResult)
end

--- 离开房间
---@param onResult fun(ok: boolean, result: table|nil)
function ClientNet.LeaveRoom(onResult)
    ClientNet.SendAction("leave_room", {}, onResult)
end

--- 准备
---@param onResult fun(ok: boolean, result: table|nil)
function ClientNet.Ready(onResult)
    ClientNet.SendAction("ready", {}, onResult)
end

--- 取消准备
---@param onResult fun(ok: boolean, result: table|nil)
function ClientNet.Unready(onResult)
    ClientNet.SendAction("unready", {}, onResult)
end

-- ============ 下行事件 ============

function ClientNet.OnAssignPlayer(_, e)
    local pid = e["PlayerId"]:GetString()
    cnetCtx.setMyId(pid)
    local nickname = e["Nickname"]:GetString()
    local modeId = e["ModeId"]:GetString()
    local modeData = Shared.SafeDecode(e["ModeData"]:GetString()) or {}

    ClientNet.initialDataReady = true
    print("[ClientNet] 收到 AssignPlayer，PlayerId=" .. tostring(pid))
    cnetCtx.onAssigned({
        playerId = pid,
        nickname = nickname,
        modeId = modeId,
        modeData = modeData,
    })
end

function ClientNet.OnActionResult(_, e)
    local seq = e["Seq"]:GetInt()
    local ok = e["Ok"]:GetInt() == 1
    local reason = e["Reason"] and e["Reason"]:GetString() or nil
    local result = Shared.SafeDecode(e["Result"]:GetString())
    if result and reason and reason ~= "" then result.reason = reason end

    print("[Cli] 收到回执 seq=" .. tostring(seq)
        .. " ok=" .. tostring(ok)
        .. " reason=" .. tostring(reason))

    local cb = ClientNet.pendingActions[seq]
    ClientNet.pendingActions[seq] = nil
    if cb then cb(ok, result) end
end

function ClientNet.OnStateUpdate(_, e)
    local modeId = e["ModeId"]:GetString()
    local modeData = Shared.SafeDecode(e["ModeData"]:GetString()) or {}
    local roomId = e["RoomId"] and e["RoomId"]:GetString() or ""

    cnetCtx.applyState({
        modeId = modeId,
        modeData = modeData,
        roomId = roomId,
    })
    if modeId and modeId ~= "" then
        DispatchToMode(modeId, "state_update", {
            modeData = modeData,
            roomId = roomId,
        })
    end
end

function ClientNet.OnToast(_, e)
    local text = e["Text"]:GetString()
    local color = e["Color"] and e["Color"]:GetString() or nil
    cnetCtx.onToast(text, color)
end

function ClientNet.OnOnlineCount(_, e)
    local n = e["Count"]:GetInt()
    cnetCtx.onOnlineCount(n)
end

function ClientNet.OnKicked(_, e)
    local reason = e["Reason"] and e["Reason"]:GetString() or "顶号登录"
    ClientNet.conn = nil
    cnetCtx.onKicked(reason)
end

function ClientNet.OnServerFull(_, e)
    local max = e["Max"]:GetInt()
    ClientNet.conn = nil
    cnetCtx.onServerFull(max)
end

function ClientNet.OnSaveFailed(_, e)
    cnetCtx.onSaveFailed()
end

function ClientNet.OnServerDisconnected()
    ClientNet.conn = nil
    cnetCtx.onDisconnected()
end

function ClientNet.OnModeBroadcast(_, e)
    local modeId = e["ModeId"]:GetString()
    local subEvent = e["SubEvent"]:GetString()
    local data = Shared.SafeDecode(e["Data"]:GetString()) or {}
    DispatchToMode(modeId, subEvent, data)
end

function ClientNet.Update(dt)
end

-- ============================================================
-- 二、Widgets：通用控件
-- ============================================================

local Widgets = {}

local UI_ = nil

function Widgets.Init(uiLib)
    UI_ = uiLib
end

local function RequireUI()
    if not UI_ then UI_ = require("urhox-libs/UI") end
    return UI_
end

function Widgets.Btn(props)
    local UI = RequireUI()
    local m = {}
    for k, v in pairs(props) do m[k] = v end
    local variant = m.variant or "secondary"
    m.backgroundColor = m.backgroundColor or Theme.ButtonBg(variant)
    m.borderWidth = m.borderWidth or 1
    m.borderColor = m.borderColor or Theme.COLORS.border
    return UI.Button(m)
end

-- ============================================================
-- 三、Modal：栈管理
-- ============================================================

local Modal = {}

local modalCurrent_ = nil
local modalCurrentId_ = nil

function Modal.CloseCurrent()
    local m = modalCurrent_
    modalCurrent_ = nil
    modalCurrentId_ = nil
    while m do
        local parent = m.parentModal_
        m.parentModal_ = nil
        m:Close()
        m = parent
    end
    Shared.UIState.modalOpen = false
end

function Modal.Open(id, title, size, onClose, props)
    if modalCurrent_ and modalCurrentId_ == id
        and modalCurrent_.parentModal_ == nil then
        local modal = modalCurrent_
        modal:SetTitle(title)
        modal:SetSize(size)
        modal:ClearContent()
        modal:SetFooter(nil)
        Shared.UIState.modalOpen = true
        return modal
    end

    Modal.CloseCurrent()
    local UI = RequireUI()

    local modalProps = {}
    if type(props) == "table" then
        for k, v in pairs(props) do modalProps[k] = v end
    end
    modalProps.backgroundColor = Theme.COLORS.bgPanel
    modalProps.borderRadius    = 12
    modalProps.borderWidth     = 1
    modalProps.borderColor     = Theme.COLORS.border
    modalProps.title = title
    modalProps.size = size
    modalProps.onClose = function(self)
        if modalCurrent_ == self then
            modalCurrent_ = nil
            modalCurrentId_ = nil
        end
        Shared.UIState.modalOpen = false
        if onClose then onClose() end
    end

    local modal = UI.Modal(modalProps)
    modalCurrent_ = modal
    modalCurrentId_ = id
    Shared.UIState.modalOpen = true
    return modal
end

-- ============================================================
-- 四、Toast：顶部提示
-- ============================================================

local Toast = {}

local NOTICE_DURATION = 1.0
local noticeQueue_ = {}
local noticeCurrent_ = nil
local noticeTimer_ = 0
local noticeAlpha_ = 1.0
local noticeComp_ = nil

local function NoticeColor(colorHex)
    if colorHex then
        local c = Shared.HexRGB(colorHex)
        if c then
            return math.floor(c[1]), math.floor(c[2]), math.floor(c[3])
        end
    end
    return 255, 255, 255
end

local function NoticePump()
    if noticeCurrent_ or #noticeQueue_ == 0 then return end
    noticeCurrent_ = table.remove(noticeQueue_, 1)
    noticeTimer_ = NOTICE_DURATION
    noticeAlpha_ = 1.0
end

function Toast.Tick(dt)
    NoticePump()
    if not noticeCurrent_ then return end
    noticeTimer_ = noticeTimer_ - (dt or 0)
    if noticeTimer_ <= 0 then
        noticeCurrent_ = nil
        noticeAlpha_ = 1.0
        NoticePump()
        return
    end
    local FADE = 0.25
    noticeAlpha_ = (noticeTimer_ < FADE) and (noticeTimer_ / FADE) or 1.0
end

local function RenderNotice(self, nvg)
    if not noticeCurrent_ then return end
    local a = math.max(0, math.min(1, noticeAlpha_))
    if a <= 0 then return end

    local UI = RequireUI()
    local w = UI.GetWidth and UI.GetWidth() or 800
    local cx = w * 0.5
    local cy = 40
    local fontSize = 24

    nvgSave(nvg)
    nvgFontFace(nvg, "sans")
    nvgFontSize(nvg, fontSize)
    nvgTextAlign(nvg, NVG_ALIGN_CENTER + NVG_ALIGN_MIDDLE)

    local r, g, b = NoticeColor(noticeCurrent_.color)
    local OUTLINE = 1.0
    local oa = math.floor(180 * a)
    nvgFillColor(nvg, nvgRGBA(0, 0, 0, oa))
    for _, off in ipairs({ { -OUTLINE, 0 }, { OUTLINE, 0 }, { 0, -OUTLINE }, { 0, OUTLINE } }) do
        nvgText(nvg, cx + off[1], cy + off[2], noticeCurrent_.msg, nil)
    end
    nvgFillColor(nvg, nvgRGBA(r, g, b, math.floor(255 * a)))
    nvgText(nvg, cx, cy, noticeCurrent_.msg, nil)
    nvgRestore(nvg)
end

function Toast.Show(msg, colorHex)
    if not msg or msg == "" then return end
    local UI = RequireUI()
    if not noticeComp_ then
        noticeComp_ = { Render = RenderNotice }
        if UI.RegisterGlobalComponent then
            UI.RegisterGlobalComponent("TextNotice", noticeComp_)
        end
    end
    table.insert(noticeQueue_, { msg = msg, color = colorHex })
end

-- ============================================================
-- 六、ClientMain：入口
-- ============================================================

local ModeRegistry = Shared.ModeRegistry
local TapLogin     = Shared.TapLogin

-- 屏幕方向切换（异步，带成功/失败日志）
local lastOrientation_ = nil
local function SwitchOrientation(value)
    if not value or value == "" then return end
    if lastOrientation_ == value then return end
    lastOrientation_ = value

    if not (common and common.setDeviceOrientation) then
        print("[Orientation] ⚠️ API 不可用")
        lastOrientation_ = nil
        return
    end
    common.setDeviceOrientation({
        value = value,
        onSuccess = function()
            print("[Orientation] -> " .. value .. " ok")
        end,
        onError = function(e)
            print("[Orientation] -> " .. value
                .. " fail: " .. tostring(e and e.errMsg or e))
            lastOrientation_ = nil
        end,
    })
end

local clientScene_ = nil
local clientCamera_ = nil
local currentModeScene_ = nil
local currentModeId_ = nil
local soloMode_ = false        -- 当前是否处于本地单人模式（不走服务端房间）

local state = {
    modeId = nil,        -- 当前所在玩法
    roomId = "",         -- 当前所在房间（"" = 不在房间）
    modeData = nil,
    nickname = nil,
    playerId = nil,
}

-- 记录上一次的界面状态，用于检测何时需要切换界面
local lastModeId_ = nil
local lastRoomId_ = nil

local function SetupUI()
    local UI = require("urhox-libs/UI")
    if not UI.GetNVGContext() then
        UI.Init({
            theme = "default-dark",
            fonts = {
                { family = "sans", weights = {
                    normal = "Fonts/MiSans-Regular.ttf",
                    bold   = "Fonts/MiSans-Regular.ttf",
                } },
            },
            scale = UI.Scale.DEFAULT,
        })
    end

    Widgets.Init(UI)
    Shared.Notify.SetImpl(function(text, color) Toast.Show(text, color) end)
end

local function SetupScene()
    clientScene_ = Scene()
    clientScene_:CreateComponent("Octree", LOCAL)

    local camNode = clientScene_:CreateChild("Camera", LOCAL)
    clientCamera_ = camNode:CreateComponent("Camera", LOCAL)
    clientCamera_.farClip = 8000
    clientCamera_.fov = 60
    -- 相机位置：仅避免停在 (0,0,0) 产生边缘情况（射线检测等）。
    -- 棋牌 UI 由 NanoVG 叠加渲染，不受相机位置/朝向影响。
    camNode.position = Vector3(0, 0, -10)
    renderer:SetViewport(0, Viewport(clientScene_, clientCamera_))

    -- 环境光模式：COLOR，不加载 HDR 立方体贴图。
    -- ⚠️ 引擎 defaultZone 默认走 PREBAKED，需要 Cube/Day/*.dds；
    --    项目没有该资源，会每帧报 "Could not find resource"。
    --    ambientSource = 2 (COLOR) 告诉引擎用纯色补光，不找贴图。
    renderer.defaultZone.ambientSource = 2
end

local function SubscribeAll()
    Protocol.RegisterClientEvents()

    SubscribeToEvent(Protocol.S2C.ASSIGN_PLAYER, ClientNet.OnAssignPlayer)
    SubscribeToEvent(Protocol.S2C.ACTION_RESULT, ClientNet.OnActionResult)
    SubscribeToEvent(Protocol.S2C.STATE_UPDATE, ClientNet.OnStateUpdate)
    SubscribeToEvent(Protocol.S2C.TOAST, ClientNet.OnToast)
    SubscribeToEvent(Protocol.S2C.ONLINE_COUNT, ClientNet.OnOnlineCount)
    SubscribeToEvent(Protocol.S2C.KICKED, ClientNet.OnKicked)
    SubscribeToEvent(Protocol.S2C.SERVER_FULL, ClientNet.OnServerFull)
    SubscribeToEvent(Protocol.S2C.SAVE_FAILED, ClientNet.OnSaveFailed)
    SubscribeToEvent(Protocol.S2C.MODE_BROADCAST, ClientNet.OnModeBroadcast)
    SubscribeToEvent("ServerDisconnected", ClientNet.OnServerDisconnected)
    SubscribeToEvent("Update", "OnUpdate")
end

local function InjectClientNet()
    ClientNet.Init({
        getMyId = function() return state.playerId end,
        setMyId = function(v) state.playerId = v end,
        getScene = function() return clientScene_ end,
        applyState = function(s)
            state.modeId = s.modeId
            state.roomId = s.roomId
            state.modeData = s.modeData
            Client.OnStateApplied(s)
        end,
        onAssigned = function(info)
            state.nickname = info.nickname
            state.playerId = info.playerId
            state.modeId = info.modeId
            state.modeData = info.modeData
        end,
        onKicked = function(reason)
            Modal.CloseCurrent()
            local UI = RequireUI()
            local m = Modal.Open("kicked", "⚠️ 账号已在其他设备登录", "sm")
            m:AddContent(UI.Label {
                text = "原因：" .. tostring(reason),
                fontSize = 14,
            })
            m:Open()
        end,
        onServerFull = function(max)
            Modal.CloseCurrent()
            local UI = RequireUI()
            local m = Modal.Open("full", "🚫 服务器已满", "sm")
            m:AddContent(UI.Label {
                text = string.format("服务器已满（上限 %d）", max or 0),
                fontSize = 14,
            })
            m:Open()
        end,
        onSaveFailed = function()
            Toast.Show("进度同步失败，请重试")
        end,
        onToast = function(text, color) Toast.Show(text, color) end,
        onOnlineCount = function(_n) end,
        onDisconnected = function()
            Modal.CloseCurrent()
            local UI = RequireUI()
            local m = Modal.Open("disconnect", "⚠️ 服务器断开", "sm")
            m:AddContent(UI.Label {
                text = "连接已断开，请重试",
                fontSize = 14,
            })
            m:AddContent(Widgets.Btn {
                text = "重连",
                variant = "primary",
                fontSize = 14,
                width = 140,
                height = 40,
                marginTop = 12,
                onClick = function()
                    m:Close()
                    if ClientNet.Reconnect() then
                        Toast.Show("正在重新连接…")
                    end
                end,
            })
            m:Open()
        end,
    })
end

--- 进入对局场景（由 room_state.status == "playing" 触发）
--- 进入玩法场景的公共部分（联网 / 单人共用）
---@param modeId string
---@param initialRoomState table|nil
---@param isSolo boolean
local function EnterSceneCommon(modeId, initialRoomState, isSolo)
    local cfg = AllModes.GetConfig(modeId)
    local targetOrientation = (cfg and cfg.screenOrientation) or "landscape"
    SwitchOrientation(targetOrientation)

    local UI = RequireUI()

    local ok, SceneMod = pcall(require, "modes." .. modeId .. ".ClientScene")
    if not ok or not SceneMod then
        Toast.Show("玩法场景加载失败：" .. modeId)
        return false
    end

    -- 进入对局前清空 UI（lobby_runtime 的 root 由引擎回收，
    -- 这里只确保对局画面上没有残留的大厅控件）
    UI.SetRoot(UI.Panel { width = "100%", height = "100%" }, true)

    currentModeScene_ = SceneMod
    currentModeId_ = modeId
    soloMode_ = isSolo and true or false

    if SceneMod.SetDependencies then
        SceneMod.SetDependencies({
            Theme = Theme,
            Widgets = Widgets,
        })
    end

    if SceneMod.Build then
        SceneMod.Build(UI, clientScene_, {
            sendAction = function(action, payload, cb)
                ClientNet.SendAction(action, payload, cb)
            end,
            registerHandler = function(eventName, handler)
                ClientNet.Subscribe(modeId, eventName, handler)
            end,
            state = state,
            initialRoomState = initialRoomState,
            onLeave = function()
                if soloMode_ then
                    Client.ExitSoloMode()
                    return
                end
                ClientNet.LeaveRoom(function(ok2)
                    if not ok2 then
                        Toast.Show("退出失败")
                    end
                end)
            end,
        })
    end
    print("[Client] 已进入玩法场景：" .. modeId)
    return true
end

function Client.EnterModeScene(modeId, initialRoomState)
    EnterSceneCommon(modeId, initialRoomState, false)
end

--- 进入本地单人模式（不走服务端房间流程）
---@param modeId string
function Client.EnterSoloMode(modeId)
    local cfg = AllModes.GetConfig(modeId)
    if not cfg then
        Toast.Show("玩法不存在：" .. tostring(modeId))
        return
    end
    if not cfg.soloEnabled then
        Toast.Show("该玩法暂不支持单人模式")
        return
    end

    local fakeRoomState = {
        status = "playing",
        modeId = modeId,
        roomId = "solo",
        players = {},
    }
    EnterSceneCommon(modeId, fakeRoomState, true)
end

--- 退出本地单人模式（回大厅需由引擎断连，这里只清理场景）
function Client.ExitSoloMode()
    local modeId = currentModeId_
    Client.ExitModeScene()
    if modeId then
        state.modeId = modeId
    end
    Client.ShowLobby()
end

function Client.ExitModeScene()
    SwitchOrientation("landscape")
    soloMode_ = false

    if currentModeId_ then
        ClientNet.UnsubscribeAll(currentModeId_)
    end
    if currentModeScene_ and currentModeScene_.Destroy then
        currentModeScene_.Destroy()
    end
    currentModeScene_ = nil
    currentModeId_ = nil
end

--- 退出对局场景。
--- 大厅已搬到 lobby_runtime（运行在连服之前），游戏脚本里没有大厅，
--- 所以这里只清理对局场景；真正回大厅需要引擎断开本局连接。
function Client.ShowLobby()
    Client.ExitModeScene()
    local UI = RequireUI()
    UI.SetRoot(UI.Panel { width = "100%", height = "100%" }, true)
end

--- 状态变化时调用（对局内只转发给玩法场景）
function Client.OnStateApplied(s)
    lastModeId_ = s.modeId
    lastRoomId_ = s.roomId

    if currentModeScene_ and currentModeScene_.OnStateUpdate then
        currentModeScene_.OnStateUpdate(s)
    end
end

function OnUpdate(_, e)
    local dt = e["TimeStep"]:GetFloat()
    if dt > 0.1 then dt = 0.1 end

    Toast.Tick(dt)

    if currentModeScene_ and currentModeScene_.Update then
        currentModeScene_.Update(dt, ClientNet)
    end

    ClientNet.Update(dt)
end

function Client.Start()
    print("[Client] Starting...")

    SetupUI()
    SetupScene()

    AllModes.RegisterAllForClient()

    -- 订阅服务端的 room_state 广播（保留：服务端可能推送对局状态）
    ClientNet.Subscribe("*", "room_state", function(data)
        -- 大厅已搬到 lobby_runtime，这里只处理对局内的状态变化
        if data.status == "playing" then
            local modeId = data.modeId
            if modeId and modeId ~= "" and not currentModeScene_ then
                Client.EnterModeScene(modeId, data)
            end
        end
    end)

    TapLogin.Login(function(ok, pid, nickname)
        if not ok then
            print("[Client] ⚠️ TapTap 登录失败")
            Toast.Show("登录失败，请重试")
            return
        end
        state.playerId = pid
        state.nickname = nickname
        print("[Client] 登录成功：" .. tostring(pid))

        InjectClientNet()
        SubscribeAll()
        if ClientNet.Connect() then
            print("[Client] 连接成功")
        else
            Toast.Show("连接服务器失败")
        end

        -- 玩家已通过 lobby_runtime 的「准备」进入本服务器，
        -- 这里直接进入对局场景（备战页），不再经过大厅。
        local modeId = state.modeId
        if not modeId or modeId == "" then
            modeId = "autochess"   -- 当前只有一个玩法，兜底
        end
        Client.EnterModeScene(modeId, {
            status = "playing",
            modeId = modeId,
            roomId = state.roomId or "",
            players = {},
        })
    end)

    engine.maxFps = 60
    print("[Client] 启动完成")
end

function Client.Stop()
    print("[Client] Stopping...")
end

return Client
