-- ============================================================
-- UI_System.lua：玩家系统与状态面板
--
-- 内容：自动战斗 / 在线卡 / 自动分解 / 罚站 /
--       设置面板 / 材质面板 / 死亡结算 / 网络门控
--       （市场 / 邮箱 / 调试玩家列表 → UI_Trade.lua）
--
-- 依赖：Shared + UI_Core（共享基础设施）。
--       与 UI_Items / UI_Trade **不 require**，跨域调用走 Panels.X
--       （四个文件写入同一张表，见 UI_Core 顶部说明）。
-- ============================================================
local Shared = require("Shared")
local Data   = Shared.Data
local Notify = Shared.Notify

local Core = require("UI_Core")

-- 与 UI_Core 共用同一张 Panels 表
local Panels = Core

-- 无状态通用控件（加载时捕获即可）
local QLabel           = Core.QLabel
local QButton          = Core.QButton
local OpenModal        = Core.OpenModal

-- ⚠️ 注入值走稳定容器：Panels.Init / SetStatProvider 在运行时填充，
--    不能在这里取局部量（那会是 nil）。用短别名保持代码可读。
local S = Core.shared

-- ============================================================
-- 在线卡面板（OpenOnline）
--
-- ⚠️ 原「自动战斗」面板（Panels.OpenAutoBattle）已删除：
--    · 开关自动战斗已由 HUD 的 ⚔️ 按钮直接切换（Panels.ToggleAutoBattle）
--    · 面板内的「使用在线卡 / 看广告」与在线时长面板完全重复
--    · 其入口（左上角「剩余战斗时长」标签）在删战斗卡时一并移除 → 已成孤儿面板
-- ============================================================

-- ============================================================
-- 自动分解设置
--
-- 实际生效点在客户端拾取/入包路径（Client.ClientAddToInventory）：
-- 掉落拾取、邮件领取、市场购买入包时都会先过一次自动分解。
-- 「已鉴 / 未鉴」两套开关随 autoDecompose / autoDecomposeUnid 上报存档，
-- 服务端只做持久化。
-- ============================================================
function Panels.OpenAutoDecompose()
    local modal = OpenModal("autodecomp", "自动分解设置", "lg")
    local d = Data.value
    -- 云端旧档可能缺这两个字段，兜底成空表避免下面索引 nil 崩溃
    if type(d.autoDecompose) ~= "table" then d.autoDecompose = {} end
    if type(d.autoDecomposeUnid) ~= "table" then d.autoDecomposeUnid = {} end

    --- 切换开关 + 立即清理背包存量。
    ---@param mode string  "identified" | "unid" | "id_then_decompose"
    ---@param q string      品质
    local function ToggleAndClean(mode, q)
        local dv = Data.value

        -- 三态：已鉴 / 未鉴 在 Data.value 里；"鉴+分"存在 settings 里
        local store, dirtyFlag
        if mode == "identified" then
            if type(dv.autoDecompose) ~= "table" then dv.autoDecompose = {} end
            store = dv.autoDecompose
            dirtyFlag = "autoDecompose"
        elseif mode == "unid" then
            if type(dv.autoDecomposeUnid) ~= "table" then dv.autoDecomposeUnid = {} end
            store = dv.autoDecomposeUnid
            dirtyFlag = "autoDecompose"
        else
            local ss = Data.GetSettings()
            if type(ss.autoIdThenDecompose) ~= "table" then
                ss.autoIdThenDecompose = {}
            end
            store = ss.autoIdThenDecompose
            dirtyFlag = "settings"
        end

        local newVal = not (store[q] == true)
        store[q] = newVal or nil
        Data.MarkDirty(dirtyFlag)

        if newVal then
            -- 收集背包里符合"品质 + 鉴定状态"且未上锁的装备 id
            local ids = {}
            local wantIdentified
            if mode == "identified" then wantIdentified = true
            else wantIdentified = false end  -- unid / 鉴+分 都只处理未鉴定

            for _, it in ipairs(dv.inventory) do
                if Shared.IsEquipment(it)
                    and it.quality == q
                    and not Shared.IsLocked(it)
                    and (it.identified == true) == wantIdentified then
                    table.insert(ids, it.id)
                end
            end

            if #ids > 0 then
                if mode == "id_then_decompose" then
                    Panels.IdentifyAndDecomposeItems(ids)
                else
                    -- 分解结果由 DecomposeItems 自己 Toast
                    Panels.DecomposeItems(ids)
                end
            end
        end

        Panels.OpenAutoDecompose()
    end

    -- 5 品质 × 3 开关，2 列网格
    local cells = {}
    local settings_ = Data.GetSettings()
    for _, q in ipairs(Shared.QUALITY_LIST) do
        local onId   = (d.autoDecompose[q]     == true)
        local onUnid = (d.autoDecomposeUnid[q] == true)
        local onIdD  = (settings_.autoIdThenDecompose
                        and settings_.autoIdThenDecompose[q] == true)

        table.insert(cells, S.UI.Panel {
            flexDirection = "column", gap = 6,
            paddingHorizontal = 10, paddingVertical = 8,
            backgroundColor = Panels.THEME.bgCard, borderRadius = 6,
            children = {
                S.UI.Label {
                    text = Shared.QUALITY_NAMES[q] or q,
                    fontSize = 12,
                    fontColor = Shared.HexRGB(Shared.QUALITY_COLORS[q] or Panels.THEME_HEX.textPrimary),
                },
                S.UI.Panel {
                    flexDirection = "row", alignItems = "center", gap = 3,
                    children = {
                        -- 已鉴自动分解
                        Panels.Btn {
                            text = onId and "☑" or "☐",
                            fontSize = 14, height = 30, width = 36,
                            paddingHorizontal = 0,
                            variant = onId and "primary" or "secondary",
                            onClick = function() ToggleAndClean("identified", q) end,
                        },
                        S.UI.Label {
                            text = "已鉴", fontSize = 9,
                            fontColor = Panels.THEME.textSecond,
                        },
                        S.UI.Panel { width = 4 },
                        -- 未鉴自动分解（折金币）
                        Panels.Btn {
                            text = onUnid and "☑" or "☐",
                            fontSize = 14, height = 30, width = 36,
                            paddingHorizontal = 0,
                            variant = onUnid and "primary" or "secondary",
                            onClick = function() ToggleAndClean("unid", q) end,
                        },
                        S.UI.Label {
                            text = "未鉴", fontSize = 9,
                            fontColor = Panels.THEME.textSecond,
                        },
                        S.UI.Panel { width = 4 },
                        -- 鉴定 + 分解（花金币鉴定，返碎片）
                        Panels.Btn {
                            text = onIdD and "☑" or "☐",
                            fontSize = 14, height = 30, width = 36,
                            paddingHorizontal = 0,
                            variant = onIdD and "primary" or "secondary",
                            onClick = function() ToggleAndClean("id_then_decompose", q) end,
                        },
                        S.UI.Label {
                            text = "鉴+分", fontSize = 9,
                            fontColor = Panels.THEME.textSecond,
                        },
                    },
                },
            },
        })
    end

    modal:AddContent(S.UI.Panel {
        flexDirection = "column", gap = 8,
        children = {
            S.UI.Label {
                text = "勾选后，掉落的对应装备会自动分解：",
                fontSize = 11, fontColor = Panels.THEME.textSecond, maxLines = 0,
            },
            S.UI.Label {
                text = "  · 已鉴 → 返还同品质碎片 × 1",
                fontSize = 11, fontColor = Shared.HexRGB("#9fd8ff"),
            },
            S.UI.Label {
                text = "  · 未鉴 → 折算金币（普通 1~2，传说 1~10）",
                fontSize = 11, fontColor = Shared.HexRGB("#ffd24d"),
            },
            S.UI.Label {
                text = "  · 鉴+分 → 先花金币鉴定再分解为碎片（金币不足则不触发）",
                fontSize = 11, fontColor = Shared.HexRGB("#aaffcc"),
            },
            S.UI.Label {
                text = "勾选时会同时清理背包里已有的对应装备。",
                fontSize = 10, fontColor = Panels.THEME.textDim, maxLines = 0,
            },
            S.UI.Divider { orientation = "horizontal" },
            S.UI.SimpleGrid { columns = 2, gap = 8, children = cells },
        },
    })
    modal:SetFooter(S.UI.Panel {
        flexDirection = "row", justifyContent = "flex-end",
        children = { QButton("关闭", function() modal:Close() end) },
    })
    modal:Open()
end

function Panels.ToggleAutoBattle()
    local d = Data.value
    if d.isStanding then
        Notify.Toast("罚站中，无法开启自动战斗")
        return
    end
    if d.autoBattleOn then
        d.autoBattleOn = false
        return
    end
    local tokens = Shared.CountTokensInInventory(d.inventory, "online")
    if tokens <= 0 and d.onlineTokenSeconds <= 0 then
        Notify.Toast("没有在线卡，先看广告或去市场购买")
        return
    end
    -- ⚠️ 只在剩余时长为 0 时才消耗令牌：
    --    否则每次开关自动战斗都会白扣一个令牌（时长本来还够用）。
    if d.onlineTokenSeconds <= 0 and tokens > 0 then
        if Shared.RemoveTokensFromInventory(d.inventory, "online", 1) then
            d.onlineTokenSeconds = d.onlineTokenSeconds + Shared.C.ONLINE_TOKEN_SECONDS
            Data.MarkDirty("inventory")
            Data.MarkDirty("time")
        end
    end
    d.autoBattleOn = true
end

function Panels.OpenOnline()
    local modal = OpenModal("online", "在线时长", "md")
    local d = Data.value

    local infoLabel = S.UI.Label {
        text = "",
        fontSize = 12,
        fontColor = Panels.THEME.textPrimary,
    }
    local function Refresh()
        local tokens = Shared.CountTokensInInventory(d.inventory, "online")
        infoLabel:SetText(string.format(
            "在线卡：%d 张（每张增加 %d 分钟在线时长）\n在线卡剩余：%s\n\n在线卡用尽后，需观看广告或使用在线卡才能继续游戏",
            tokens, math.floor(Shared.C.ONLINE_TOKEN_SECONDS / 60),
            Shared.FormatTime(d.onlineTokenSeconds)))
    end
    Refresh()

    modal:AddContent(S.UI.Panel {
        flexDirection = "column", gap = 10,
        children = {
            infoLabel,
            S.UI.Divider { orientation = "horizontal" },
            S.UI.Panel {
                flexDirection = "row", gap = 8,
                children = {
                    QButton("使用在线卡", function()
                        if Shared.RemoveTokensFromInventory(Data.value.inventory, "online", 1) then
                            Data.value.onlineTokenSeconds = Data.value.onlineTokenSeconds + Shared.C.ONLINE_TOKEN_SECONDS
                            Data.MarkDirty("inventory")
                            Data.MarkDirty("time")
                            if S.ctx and S.ctx.forceSync then S.ctx.forceSync() end
                        else
                            Notify.Toast("没有在线卡了，先看广告或去市场买")
                        end
                        Refresh()
                    end, "primary"),
                    QButton("📺 看广告获得1张在线卡", function()
                        if S.ctx then S.ctx.requestAd("online") end
                    end, "secondary"),
                },
            },
        },
    })
    modal:Open()
end

-- ============================================================
-- 罚站提示（非阻塞）
--
-- 🔴 为什么不用阻塞式 Modal：
--    罚站期间玩家最需要的是「点开左上角的在线时长标签 → 用卡/看广告」，
--    或者去点「进度同步失败」门的重试按钮。阻塞 Modal 会把 HUD 和同步门
--    全部盖住，玩家被卡死在罚站面板里按不了任何东西。
--
--    现在改为：不弹面板，每 60 秒 Toast 提醒一次。
--    恢复入口始终可用 —— 左上角在线时长标签（pointerEvents=auto）点击即开面板。
--
-- ⚠️ Toast 走 Notify → HUD.Toast，是 globalComponent，能盖在其它 Modal 之上，
--    所以即使同步门开着，玩家也能看到罚站提醒。
-- ============================================================
---@type number 距下次提醒的剩余秒数（≤0 表示该提醒了）
local standingNoticeTimer_ = 0
local STANDING_NOTICE_INTERVAL = 60   -- 提醒间隔（秒）

function Panels.UpdateStanding(dt)
    local d = Data.value
    if d.isStanding then
        -- 自动续费：开启且背包里有在线卡 → 自动补 1 小时脱离罚站
        local ss = Data.GetSettings()
        if ss.autoUseOnlineToken
            and Shared.RemoveTokensFromInventory(d.inventory, "online", 1) then
            d.onlineTokenSeconds = d.onlineTokenSeconds + Shared.C.ONLINE_TOKEN_SECONDS
            Data.MarkDirty("inventory")
            Data.MarkDirty("time")
            d.isStanding = false
            standingNoticeTimer_ = 0
            Notify.Toast("自动使用在线卡，+" .. math.floor(Shared.C.ONLINE_TOKEN_SECONDS / 60) .. " 分钟")
            return
        end

        -- 每 60 秒提醒一次（进入罚站时立刻提醒第一次）
        standingNoticeTimer_ = standingNoticeTimer_ - (dt or 0)
        if standingNoticeTimer_ <= 0 then
            standingNoticeTimer_ = STANDING_NOTICE_INTERVAL
            Notify.Toast("⛔ 在线时长耗尽，无法移动/战斗。点击左上角时长栏用卡或看广告", "#ffb0b0")
        end
    else
        -- 脱离罚站 → 重置计时，下次进入罚站立刻提醒
        standingNoticeTimer_ = 0
    end
end
-- ============================================================
-- 通用对话框（alert / confirm / prompt）
--
-- ⚠️ Modal 是单实例互斥的：调这些函数前若已有面板打开（如背包），
--    必须先 CloseCurrent，否则会叠层。
-- ============================================================

--- 设置行通用布局：标签 132px → 控件（自适应）→ 数值 56px 右对齐
---@param label string
---@param control Widget
---@param valueLabel Widget|nil
---@return Panel
local function SettingRow(label, control, valueLabel)
    local children = {
        S.UI.Label {
            text = label, fontSize = 12, width = 132,
            fontColor = Panels.THEME.textSecond, maxLines = 1,
        },
        control,
    }
    if valueLabel then table.insert(children, valueLabel) end
    return S.UI.Panel {
        flexDirection = "row", alignItems = "center", gap = 8,
        children = children,
    }
end

---@return Panel
local function SettingToggle(label, key)
    local s = Data.GetSettings()
    local checked = s[key] == true
    local btn = Panels.Btn {
        text = checked and "☑ 开" or "☐ 关",
        fontSize = 12, height = 40, width = 100,
        variant = checked and "primary" or "secondary",
        onClick = function()
            local ss = Data.GetSettings()
            ss[key] = not checked
            Data.MarkDirty("settings")
            if S.ctx and S.ctx.applySettings then S.ctx.applySettings() end
            Panels.OpenSettingsPanel()
        end,
    }
    return SettingRow(label, btn, nil)
end

--- 技能提示三开关行
---@return Panel
local function SettingSkillHintToggles()
    local s = Data.GetSettings()
    local function Btn(label, key)
        local checked = s[key] ~= false
        return Panels.Btn {
            text = (checked and "☑ " or "☐ ") .. label,
            fontSize = 11, height = 36, paddingHorizontal = 8,
            variant = checked and "primary" or "secondary",
            onClick = function()
                local ss = Data.GetSettings()
                ss[key] = not checked
                Data.MarkDirty("settings")
                Panels.OpenSettingsPanel()
            end,
        }
    end
    return S.UI.Panel {
        flexDirection = "row", gap = 8, flexWrap = "wrap",
        children = {
            Btn("技能弹字", "showSkillPopup"),
            Btn("技能特效", "showSkillEffect"),
            Btn("伤害数字", "dmgNumbers"),
        },
    }
end

--- 一个设置滑动条
---@param label string
---@param key string
---@param min number
---@param max number
---@param step number
---@param isInt boolean
---@param hint string|nil
---@return Panel
local function SettingSlider(label, key, min, max, step, isInt, hint)
    local s = Data.GetSettings()
    local cur = tonumber(s[key]) or min
    local function fmt(v)
        if isInt then return tostring(math.floor(v + 0.5)) end
        return string.format("%.2f", v)
    end
    local valLabel = S.UI.Label {
        text = fmt(cur),
        fontSize = 12, width = 56, textAlign = "right",
        fontColor = Shared.HexRGB("#9fd8ff"),
    }
    local slider = S.UI.Slider {
        min = min, max = max, step = step, value = cur,
        flexGrow = 1, flexBasis = 0, height = 24,
        onChange = function(_, v)
            valLabel:SetText(fmt(v))
        end,
        onChangeEnd = function(_, v)
            local ss = Data.GetSettings()
            ss[key] = isInt and math.floor(v + 0.5) or v
            Data.MarkDirty("settings")
            if S.ctx and S.ctx.applySettings then S.ctx.applySettings() end
        end,
    }
    local row = S.UI.Panel {
        flexDirection = "row", alignItems = "center", gap = 8,
        children = {
            S.UI.Label {
                text = label, fontSize = 12, width = 132,
                fontColor = Panels.THEME.textSecond, maxLines = 1,
            },
            slider,
            valLabel,
        },
    }
    if hint then
        return S.UI.Panel {
            flexDirection = "column", gap = 2,
            children = {
                row,
                S.UI.Label {
                    text = "  " .. hint, fontSize = 10,
                    fontColor = Panels.THEME.textDim,
                },
            },
        }
    end
    return row
end

-- ============================================================
-- 钱庄
-- ============================================================
--- ⚠️ 本函数只渲染本地缓存，不发 bankStateRequest。
---    否则会形成死循环：OnBankState 回包 → RefreshIfOpen("bank", OpenBank)
---    → OpenBank 再发请求 → 再回包……请求由用户点击入口发起（见 Client 的 onAction）。
function Panels.OpenBank()
    local modal = OpenModal("bank", "💰 钱庄", "xl")

    local deposits = Data.value.bankDeposits or {}
    local taxPool = Data.value.bankDailyTaxPool or 0
    local myWeight = Data.value.bankMyWeight or 0
    local totalWeight = Data.value.bankTotalWeight or 0
    local todayEarnings = Data.value.bankTodayEarnings or 0
    local forecastTomorrow = Data.value.bankForecastTomorrow or 0
    local totalInterest = Data.value.bankTotalInterest or 0

    -- 顶部：总资产 + 今日收益 + 明日预期
    local totalPrincipal = 0
    for _, dep in ipairs(deposits) do
        totalPrincipal = totalPrincipal + (dep.amount or 0)
    end

    local summaryPanel = S.UI.Panel {
        flexDirection = "column", gap = 3,
        paddingHorizontal = 8, paddingVertical = 6,
        backgroundColor = Panels.THEME.bgCard,
        borderRadius = 6,
        children = {
            S.UI.Panel {
                flexDirection = "row", justifyContent = "space-between",
                children = {
                    QLabel("总资产（本金 + 累计利息）", Panels.THEME_HEX.textSecond, 11),
                    QLabel((totalPrincipal + totalInterest) .. " 💰", "#ffd24d", 11),
                },
            },
            S.UI.Panel {
                flexDirection = "row", justifyContent = "space-between",
                children = {
                    QLabel("今日收益（昨日税池分配）", Panels.THEME_HEX.textSecond, 10),
                    QLabel("+" .. todayEarnings .. " 💰", "#88ff88", 10),
                },
            },
            S.UI.Panel {
                flexDirection = "row", justifyContent = "space-between",
                children = {
                    QLabel("明日预期收益", Panels.THEME_HEX.textSecond, 10),
                    QLabel("≈ " .. forecastTomorrow .. " 💰", "#9fd8ff", 10),
                },
            },
            S.UI.Panel {
                flexDirection = "row", justifyContent = "space-between",
                children = {
                    QLabel("昨日税池 / 我的权重 / 全服权重", Panels.THEME_HEX.textDim, 9),
                    QLabel(string.format("%d / %d / %d", taxPool, myWeight, totalWeight),
                        Panels.THEME_HEX.textSecond, 9),
                },
            },
        },
    }

    -- 存款列表
    local depRows = {}
    for i, dep in ipairs(deposits) do
        local now = os.time()
        local expired = now >= (dep.expiresAt or 0)
        local leftSec = math.max(0, (dep.expiresAt or 0) - now)
        local leftDays = math.ceil(leftSec / 86400)
        local accInt = math.floor(dep.accumulatedInterest or 0)
        local expDate = os.date("%Y-%m-%d", dep.expiresAt or now)

        table.insert(depRows, S.UI.Panel {
            flexDirection = "row", alignItems = "center", gap = 6,
            paddingHorizontal = 6, paddingVertical = 4,
            backgroundColor = Panels.THEME.bgCard, borderRadius = 5,
            children = {
                S.UI.Label {
                    text = string.format("%d💰 · %d天 · 累计利息 %d",
                        dep.amount or 0, dep.term or 0, accInt),
                    fontSize = 10, flexGrow = 1, flexShrink = 1,
                    fontColor = Shared.HexRGB(expired and "#88ff88" or Panels.THEME_HEX.textPrimary),
                },
                S.UI.Label {
                    text = expired and "已到期" or (expDate .. " · " .. leftDays .. "天"),
                    fontSize = 9, fontColor = Shared.HexRGB(expired and "#88ff88" or Panels.THEME_HEX.textSecond),
                },
                QButton(expired and "取出" or "锁定中", function()
                    if not expired then
                        Notify.Toast("存款未到期")
                        return
                    end
                    if S.ctx and S.ctx.bankWithdraw then S.ctx.bankWithdraw(i - 1) end
                end, expired and "primary" or "secondary"),
            },
        })
    end
    if #depRows == 0 then
        table.insert(depRows, QLabel("暂无存款", Panels.THEME_HEX.textDim, 10))
    end

    -- 存款表单
    local amountField = S.UI.TextField {
        value = "1000",
        placeholder = "金额",
        fontSize = 12, width = 110,
    }
    local termField = S.UI.TextField {
        value = "7",
        placeholder = "期限",
        fontSize = 12, width = 50,
    }

    -- 规则说明（小字一页显示）
    local rulePanel = S.UI.Panel {
        flexDirection = "column", gap = 1,
        paddingHorizontal = 6, paddingVertical = 4,
        backgroundColor = { 255, 230, 200, 12 },
        borderRadius = 5,
        children = {
            S.UI.Label { text = "【钱庄规则】", fontSize = 10, fontColor = Shared.HexRGB("#ffcc66") },
            S.UI.Label {
                text = "· 金币来源：全服拍卖行 5% 手续费 → 昨日税池",
                fontSize = 9, fontColor = Panels.THEME.textSecond,
            },
            S.UI.Label {
                text = "· 利息分配：按权重 = 存款金额 × 期限天数^1.5，分配昨日税池",
                fontSize = 9, fontColor = Panels.THEME.textSecond,
            },
            S.UI.Label {
                text = "· 结算时间：每天凌晨自动结算（按税池归属日）",
                fontSize = 9, fontColor = Panels.THEME.textSecond,
            },
            S.UI.Label {
                text = "· 利息累加：每日利息累加到存款，到期时与本金一起退回邮件",
                fontSize = 9, fontColor = Panels.THEME.textSecond,
            },
            S.UI.Label {
                text = "· 参与次数：存 7 天 = 参与 7 次结算（从存入当天起算）",
                fontSize = 9, fontColor = Panels.THEME.textSecond,
            },
            S.UI.Label {
                text = "· 存款规则：单笔最少 1000 金，期限 7 天或 30 天，锁定到期才能取",
                fontSize = 9, fontColor = Panels.THEME.textSecond,
            },
            S.UI.Label {
                text = "· 本金退回：存款到期后自动退邮件，可在邮箱领取",
                fontSize = 9, fontColor = Panels.THEME.textSecond,
            },
        },
    }

    modal:AddContent(S.UI.Panel {
        flexDirection = "column", gap = 6,
        children = {
            summaryPanel,
            QLabel("我的存款", "#ffcc66", 11),
            S.UI.Panel { flexDirection = "column", gap = 3, children = depRows },
            S.UI.Divider { orientation = "horizontal" },
            S.UI.Panel {
                flexDirection = "row", gap = 6, alignItems = "center",
                children = {
                    amountField,
                    QLabel("金币", Panels.THEME_HEX.textSecond, 11),
                    termField,
                    QLabel("天", Panels.THEME_HEX.textSecond, 11),
                    QButton("锁定存款", function()
                        local amt = math.floor(tonumber(amountField:GetValue()) or 0)
                        local term = math.floor(tonumber(termField:GetValue()) or 0)
                        if amt < 1000 then Notify.Toast("金额需 ≥1000"); return end
                        if amt > 2100000000 then Notify.Toast("金额过大"); return end
                        if term ~= 7 and term ~= 30 then Notify.Toast("期限需 7 或 30"); return end
                        if (Data.value.gold or 0) < amt then
                            Notify.Toast(string.format("金币不足（现有 %d）", Data.value.gold or 0))
                            return
                        end

                        Panels.Confirm("确认存款",
                            string.format("将锁定 %d 金币，期限 %d 天。\n\n"
                                .. "· 存款期间无法取出\n"
                                .. "· 每日利息自动累加\n"
                                .. "· 到期后本金 + 利息退回邮箱\n\n"
                                .. "确认存入？", amt, term),
                            function()
                                if S.ctx and S.ctx.bankDeposit then S.ctx.bankDeposit(amt, term) end
                                -- 立即刷新
                                if S.ctx and S.ctx.bankStateRequest then S.ctx.bankStateRequest() end
                            end)
                    end, "success"),
                },
            },
            rulePanel,
        },
    })
    modal:Open()
end

function Panels.OpenSettingsPanel()
    local modal = OpenModal("settings", "⚙️ 画面与特效", "lg")

    -- 当前 Tab
    if not Panels._settingsTab then Panels._settingsTab = "camera" end
    local activeTab = Panels._settingsTab

    -- Tab 栏
    -- ⚠️ 必须先收集到普通 table 再构造 Panel：
    --    Widget 在构造时（ProcessChildren）就把 props.children 搬进 self.children，
    --    之后再往 props.children 里 insert 不会生效（按钮永远不显示）。
    local tabChildren = {}
    local function Tab(id, label)
        table.insert(tabChildren, Panels.Btn {
            text = label,
            fontSize = 13, height = 40, paddingHorizontal = 16,
            variant = (activeTab == id) and "primary" or "secondary",
            onClick = function()
                Panels._settingsTab = id
                Panels.OpenSettingsPanel()
            end,
        })
    end
    Tab("camera", "相机")
    Tab("ui", "界面显示")
    Tab("fx", "战斗特效")
    Tab("postprocess", "后处理")
    Tab("auto", "自动续费")
    Tab("debug", "调试")

    local tabBar = S.UI.Panel {
        flexDirection = "row", gap = 8, marginBottom = 8,
        children = tabChildren,
    }

    -- 内容
    local body = S.UI.Panel { flexDirection = "column", gap = 6 }

    if activeTab == "camera" then
        -- 视野已固定 200（见 Shared.C.VIEW_DISTANCE_DEFAULT），删除"视野距离"滑块
        body:AddChild(SettingSlider("相机距离", "camDist", 3, 20, 1, true))
        -- ⚠️ 范围必须与 Shared.C.CAM_PITCH_MIN / MAX 一致，
        --    否则滑块拖到底也只能到旧上限（Client.lua 会 Clamp 掉超出值）。
        body:AddChild(SettingSlider("相机俯仰角", "camPitch", 1, 89, 1, true))
        body:AddChild(SettingSlider("怪物信息距离", "nameTagDistance", 20, 200, 20, true))
    elseif activeTab == "ui" then
        body:AddChild(SettingToggle("名称", "showName"))
        body:AddChild(SettingToggle("血条", "showHealthBar"))
        body:AddChild(SettingToggle("小地图", "showMinimap"))
        body:AddChild(SettingToggle("分辨率", "showResolution"))
        body:AddChild(SettingToggle("帧率", "showFPS"))
    elseif activeTab == "fx" then
        body:AddChild(SettingSkillHintToggles())
    elseif activeTab == "postprocess" then
        -- pass 开关（tag 映射见 PostProcess.lua 的 SETTING_KEYS）
        body:AddChild(SettingToggle("FXAA 抗锯齿", "pp_FXAA2"))
        body:AddChild(SettingToggle("Bloom 泛光", "pp_BloomHDRPlus"))
        -- 画面参数（默认值从 Data.GetSettings() 读，见 SettingSlider 实现）
        -- ⚠️ 环境光模式已锁定 COLOR(2)，PREBAKED/SKYBOX 弃用 —— 故无模式选择控件
        body:AddChild(SettingSlider("Bloom 阈值", "bloomThreshold", 0.50, 1.50, 0.01, false))
        body:AddChild(SettingSlider("Bloom 强度", "bloomIntensity", 0.00, 2.00, 0.05, false))
        body:AddChild(SettingSlider("环境光强度", "ambientIntensity", 0.00, 2.00, 0.05, false))
        body:AddChild(SettingSlider("地形 Toon 阈值", "toonThresholdTerrain", 0.00, 1.00, 0.01, false))
        body:AddChild(SettingSlider("角色 Toon 阈值", "toonThresholdCharacter", 0.00, 1.00, 0.01, false))
        body:AddChild(SettingSlider("暗面深浅", "toonShadowStrength", 0.00, 2.00, 0.05, false))
    elseif activeTab == "auto" then
        body:AddChild(SettingToggle("自动使用在线卡", "autoUseOnlineToken"))
    elseif activeTab == "debug" then
        -- 【调试】服务器玩家列表
        -- 用途：两台设备各点一次，对比「玩家数 / 指纹」即可确认是否连到同一台服务器。
        -- 指纹相同 = 同服（那还看不到彼此就是渲染问题）；
        -- 指纹不同 = 各在各的服务器（是匹配/房间的问题）。
        local info = S.ctx and S.ctx.getServerInfo and S.ctx.getServerInfo() or nil
        body:AddChild(QLabel(
            info and string.format("玩家数：%d", info.count) or "尚未查询",
            "#88ddff", 13))
        if info then
            body:AddChild(QLabel("服务器指纹：" .. (info.fingerprint ~= "" and info.fingerprint or "(空)"),
                "#aaaaaa", 10))
            body:AddChild(QLabel(info.list ~= "" and info.list or "(无玩家)",
                "#cccccc", 11))
        end
        body:AddChild(S.UI.Panel {
            flexDirection = "row", gap = 8, marginTop = 6,
            children = {
                QButton("查询服务器", function()
                    if S.ctx and S.ctx.queryServerInfo then
                        S.ctx.queryServerInfo()
                    end
                end, "primary"),
            },
        })
    end

    modal:AddContent(S.UI.Panel {
        flexDirection = "column",
        flexGrow = 1, flexBasis = 0,
        children = { tabBar, body },
    })
    modal:SetFooter(S.UI.Panel {
        flexDirection = "row", justifyContent = "flex-end", gap = 12,
        children = {
            QButton("恢复默认", function()
                Data.value.settings = Shared.NewDefaultSettings()
                Data.MarkDirty("settings")
                if S.ctx and S.ctx.applySettings then S.ctx.applySettings() end
                Notify.Toast("已恢复默认设置")
                Panels.OpenSettingsPanel()
            end),
            QButton("关闭", function()
                modal:Close()
                if S.ctx and S.ctx.applySettings then S.ctx.applySettings() end
            end, "primary"),
        },
    })
    modal:Open()
end

-- ============================================================
-- 死亡结算界面（A3）
-- ============================================================

---@type Modal|nil
local deathModal_ = nil
---@type Label|nil
local deathCountdownLabel_ = nil

--- 显示死亡结算面板。
--- 由 Client 在玩家死亡瞬间调用（参数取自死亡那一刻的敌人数据与本地状态）。
---@param killerSnapshot table
---@param damagedSlots string[]|nil
function Panels.OpenDeathPanel(killerSnapshot, damagedSlots)
    local snap = killerSnapshot or {}

    Panels.CloseCurrent()

    local modal = S.UI.Modal {
        title = "💀 力竭倒下",
        size = "lg",
        closeOnOverlay = false,
        showCloseButton = false,
        onClose = function(self)
            if deathModal_ == self then
                deathModal_ = nil
                deathCountdownLabel_ = nil
            end
            Shared.UIState.modalOpen = false
        end,
    }
    deathModal_ = modal
    Panels.SetCurrentModal(modal, "death")
    Shared.UIState.modalOpen = true

    local killerType = "怪物"
    if snap.isBoss then killerType = "BOSS" end

    -- 8 项属性（4 列 2 行）
    local attrRows = {
        { "生命", math.floor(snap.hp or 0) .. " / " .. math.floor(snap.maxHp or 0) },
        { "攻击", math.floor(snap.atk or 0) },
        { "护甲", math.floor(snap.armor or 0) },
        { "闪避", string.format("%.1f%%", (snap.dodge or 0) * 100) },
        { "命中", string.format("%.1f%%", (snap.hitRate or 0) * 100) },
        { "攻速", string.format("%.2f/s", 1 / math.max(0.01, snap.attackCooldown or 1)) },
        { "攻击范围", string.format("%.1f m", snap.attackRange or 3) },
        { "类型", killerType },
    }
    local attrCells = {}
    for _, row in ipairs(attrRows) do
        table.insert(attrCells, S.UI.Panel {
            flexDirection = "column",
            width = 90, height = 40,
            backgroundColor = { 255, 230, 200, 20 },
            borderRadius = 6,
            justifyContent = "center", alignItems = "center",
            children = {
                S.UI.Label { text = row[1], fontSize = 10, fontColor = Panels.THEME.textSecond },
                S.UI.Label { text = tostring(row[2]), fontSize = 10, fontColor = Shared.HexRGB("#7ad4ff") },
            },
        })
    end

    -- 等级压制信息
    local playerLv = Data.GetLevel()
    local enemyLv = snap.level or 1
    local suppress = math.max(0, enemyLv - playerLv)
    local playerDmgFactor = 1 - math.min(Shared.C.SUPPRESS_PLAYER_DMG_MIN,
        suppress * Shared.C.SUPPRESS_PLAYER_DMG_PER_LEVEL)
    local enemyDmgFactor = 1 + math.min(Shared.C.SUPPRESS_MONSTER_DMG_MAX,
        suppress * Shared.C.SUPPRESS_MONSTER_DMG_PER_LEVEL)
    local suppressLabel = S.UI.Label {
        text = suppress > 0
            and string.format("怪物 Lv.%d · 你 Lv.%d · 压制 %d 级", enemyLv, playerLv, suppress)
            or string.format("怪物 Lv.%d · 你 Lv.%d", enemyLv, playerLv),
        fontSize = 12,
        fontColor = Shared.HexRGB(suppress > 0 and "#ff6666" or Panels.THEME_HEX.textSecond),
    }
    local suppressDetail = S.UI.Label {
        text = suppress > 0
            and string.format("你的伤害 ×%.0f%%  怪物的伤害 ×%.0f%%\n建议等级：Lv.%d",
                playerDmgFactor * 100, enemyDmgFactor * 100, enemyLv)
            or string.format("建议等级：Lv.%d", enemyLv),
        fontSize = 11,
        fontColor = Panels.THEME.textSecond,
        maxLines = 0,
    }

    local content = {
        -- 击倒者
        S.UI.Panel {
            flexDirection = "column", alignItems = "center", gap = 2,
            children = {
                S.UI.Label { text = "击倒者", fontSize = 11, fontColor = Panels.THEME.textSecond },
                S.UI.Label {
                    text = (snap.name or "未知") .. " Lv." .. tostring(snap.level or 0),
                    fontSize = 16, fontColor = Shared.HexRGB("#ffcc44"),
                },
            },
        },
        S.UI.Divider { orientation = "horizontal", marginVertical = 6 },
        -- 4 列 × 2 行统计
        S.UI.SimpleGrid { columns = 4, gap = 6, children = attrCells },
        S.UI.Divider { orientation = "horizontal", marginVertical = 6 },
        suppressLabel,
        suppressDetail,
        S.UI.Divider { orientation = "horizontal", marginVertical = 6 },
        S.UI.Label {
            -- 耐久损失按装备品质递增（普通 −1 … 传说 −5），不再是一个固定值
            text = "🔧 本次阵亡，全身装备按品质损失耐久",
            fontSize = 12, fontColor = Panels.THEME.textSecond,
        },
    }
    if damagedSlots and #damagedSlots > 0 then
        table.insert(content, S.UI.Label {
            text = "⚠️ " .. table.concat(damagedSlots, "、") .. " 已损坏，词条与技能失效",
            fontSize = 12, fontColor = Shared.HexRGB("#ff6666"),
        })
    end

    deathCountdownLabel_ = S.UI.Label {
        text = "5 秒后自动复活",
        fontSize = 12, fontColor = Panels.THEME.textSecond,
    }
    table.insert(content, deathCountdownLabel_)

    modal:AddContent(S.UI.Panel { flexDirection = "column", gap = 6, children = content })
    modal:SetFooter(S.UI.Panel {
        flexDirection = "row", justifyContent = "center",
        children = {
            Panels.Btn {
                text = "⚡ 立即复活",
                width = 160, height = 52,
                variant = "primary",
                onClick = function()
                    -- 直接复位死亡计时，让 Client 的 UpdateDeath 立刻执行复活
                    if S.ctx and S.ctx.requestRespawn then S.ctx.requestRespawn() end
                end,
            },
        },
    })
    modal:Open()
end

--- 由 Client 每帧调用，刷新死亡面板的倒计时文字。
---@param secondsLeft number
function Panels.UpdateDeathCountdown(secondsLeft)
    if deathCountdownLabel_ then
        deathCountdownLabel_:SetText(string.format("%.0f 秒后自动复活", math.max(0, secondsLeft)))
    end
end

---@return boolean
function Panels.IsDeathPanelOpen() return deathModal_ ~= nil end

-- ============================================================
-- 网络门控界面（A8）
--
-- 每个门都是一个不可关闭的 Modal，只留一个操作按钮。
-- ============================================================

---@param title string
---@param text string
---@param btnLabel string
---@param onAction fun()
local function BuildGate(title, text, btnLabel, onAction)
    Panels.CloseCurrent()
    local modal = OpenModal("gate", title, "sm")
    modal:AddContent(S.UI.Panel {
        flexDirection = "column", gap = 10,
        children = {
            S.UI.Label {
                text = text, fontSize = 14,
                fontColor = Panels.THEME.textPrimary, maxLines = 0,
            },
        },
    })
    modal:SetFooter(S.UI.Panel {
        flexDirection = "row", justifyContent = "center",
        children = { QButton(btnLabel, function()
            -- ⚠️ 先关门再执行回调：门是不可关闭的 Modal，
            --    不关会盖住重连/重试过程中的 Toast 与后续界面
            modal:Close()
            if onAction then onAction() end
        end, "primary") },
    })
    modal:Open()
    return modal
end

--- 重连门
function Panels.ShowReconnectGate()
    BuildGate("⚠️ 服务器连接失败", "点击下方按钮重新连接服务器", "🔄 重新连接",
        function() if S.ctx and S.ctx.reconnect then S.ctx.reconnect() end end)
end

--- 服务器满员门
--- ⚠️ 与重连门分开：满员时重连只会再被拒一次，所以按钮是「返回大厅」而非「重新连接」。
---    返回大厅 = 走引擎的断线流程，回到大厅后玩家可以另开一局 / 稍后再试。
---@param maxPlayers integer 服务器人数上限（0 = 服务端未下发，文案降级为不带数字）
function Panels.ShowServerFullGate(maxPlayers)
    local limit = (maxPlayers and maxPlayers > 0)
        and string.format("当前服务器人数已达上限（%d 人），暂时无法加入。", maxPlayers)
        or "当前服务器人数已达上限，暂时无法加入。"
    BuildGate("🚫 服务器人数已满",
        limit .. "\n请稍后再试，或稍等片刻后重新进入游戏。",
        "返回大厅",
        function()
            -- 大厅由引擎托管：断开当前连接即回大厅
            if network and network.Disconnect then network:Disconnect(0) end
        end)
end

--- 存档同步失败门
function Panels.ShowSaveFailedGate()
    BuildGate("⚠️ 进度同步失败", "进度同步失败，请检查网络后重试", "🔄 重新同步进度",
        function() if S.ctx and S.ctx.retrySave then S.ctx.retrySave() end end)
end

--- 顶号门
function Panels.ShowDuplicateGate()
    BuildGate("⚠️ 账号已在其他设备登录",
        "此账号正在别的设备上游戏。点击下方按钮可顶掉对方设备。", "🔄 顶号登录",
        function() if S.ctx and S.ctx.forceLogin then S.ctx.forceLogin() end end)
end

return Panels
