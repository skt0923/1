-- ============================================================
-- 卡牌自走棋：服务端操作处理器
-- ============================================================
local Shared   = require("Shared")

local Actions = {}

function Actions.OnEnter(player)
    print("[Autochess] " .. player.id .. " 进入卡牌自走棋房间列表")
    return true
end

function Actions.OnLeave(player)
    print("[Autochess] " .. player.id .. " 退出卡牌自走棋")
    return true
end

function Actions.OnDisconnect(player)
    print("[Autochess] " .. player.id .. " 断线")
end

function Actions.OnUpdate(dt)
end

function Actions.CanJoin(player)
    return true, nil
end

function Actions.OnPlayerJoin(player, joiner)
end

function Actions.OnRoomStart(player, room)
    print(string.format("[Autochess] 房间 %s 开局，玩家 %s 进入对局（%d 人）",
        room.id, player.id, #room.players))
end

function Actions.Register()
    local ServerRef = require("Server")
    ServerRef.GetRouter().Register("autochess", {
        actions = {},
        onEnter      = Actions.OnEnter,
        onLeave      = Actions.OnLeave,
        onDisconnect = Actions.OnDisconnect,
        onUpdate     = Actions.OnUpdate,
        canJoin      = Actions.CanJoin,
        onPlayerJoin = Actions.OnPlayerJoin,
        onRoomStart  = Actions.OnRoomStart,
    })
end

return Actions
