-- ============================================================
-- UI_Trade.lua：交易与通信面板（UI_System 的兄弟域）
--
-- 内容：市场（行情/筛选/上架/详情） / 邮箱（分页/领取） / 调试玩家列表
--
-- 依赖：Shared + UI_Core（共享基础设施）。
--       与 UI_Items / UI_System **不 require**，跨域调用走 Panels.X
--       （四个文件写入同一张表，见 UI_Core 顶部说明）。
--       由 Client.lua 统一 require 拉起。
-- ============================================================
local Shared = require("Shared")
local Data   = Shared.Data
local Notify = Shared.Notify

local Core = require("UI_Core")

-- 与 UI_Core 共用同一张 Panels 表
local Panels = Core

-- 无状态通用控件（加载时捕获即可）
local QLabel           = Core.QLabel
local QButton          = Core.QButton
local OpenModal        = Core.OpenModal
local OpenStackedModal = Core.OpenStackedModal

-- ⚠️ 注入值走稳定容器：Panels.Init / SetStatProvider 在运行时填充，
--    不能在这里取局部量（那会是 nil）。用短别名保持代码可读。
local S = Core.shared

-- ============================================================
-- 市场
-- ============================================================
---@type table[]
local listings_ = {}
local marketTab_ = "buy"

-- 市场筛选状态（跨面板重建保留）
---@type string
local marketCat_ = "all"           -- 一级：all / equip / fragment / token
---@type string|nil
local marketSubCat_ = nil          -- 二级：部位 key / 碎片品质 / token 类型
---@type string|nil
local marketQuality_ = nil         -- 三级：品质（仅装备）

-- 服务端分页状态（由 SetListings 回包填充）
local marketPage_       = 0
local marketTotal_      = 0
local marketTotalPages_ = 1
-- 我在售的挂单总数（服务端筛选前统计，用于「上架格子 N/20」）
local marketMyTotal_    = 0

--- 筛选条件变化后统一收口：同步给 Net（翻页要用）→ 页码归零 → 拉第一页 → 重建面板。
--- ⚠️ 筛选必须存进 Net.marketFilter_，只在 UI 层保存会导致翻页丢筛选。
local function ReloadMarketWithFilter()
    if S.ctx and S.ctx.setMarketFilter then
        S.ctx.setMarketFilter({
            Category = marketCat_ or "all",
            SubCat   = marketSubCat_ or "",
            Quality  = marketQuality_ or "",
            Tab      = (marketTab_ == "mysell") and "mysell" or "buy",
        })
    end
    if S.ctx and S.ctx.requestMarketPage then S.ctx.requestMarketPage(0) end
    Panels.OpenMarket()
end

--- 玩家当前在拍卖行的挂单数（用于格子上限判断与「N/12」显示）
---@return integer
local function MyListingCount()
    local myId = Data.GetPlayerId and Data.GetPlayerId() or nil
    if not myId then return 0 end
    local n = 0
    for _, l in ipairs(listings_) do
        if l.sellerId == myId then n = n + 1 end
    end
    return n
end

--- 服务端推送的当前页挂单（服务端分页，客户端不再本地筛选）。
---@param list table[]       当前页的挂单
---@param total integer|nil  筛选后的总条数
---@param page integer|nil   当前页（0-based，服务端可能夹回）
---@param totalPages integer|nil 总页数
---@param myTotal integer|nil 我在售的挂单总数（与筛选无关）
function Panels.SetListings(list, total, page, totalPages, myTotal)
    listings_         = list or {}
    marketTotal_      = total or #listings_
    marketPage_       = page or 0
    marketTotalPages_ = totalPages or 1
    marketMyTotal_    = myTotal or 0

    -- 只有市场面板正开着才重建；否则会把玩家正在看的背包/角色面板顶掉
    Panels.RefreshIfOpen("market", Panels.OpenMarket)
end

function Panels.OpenMarket()
    -- ⚠️ 第 4 个参数是 onClose（市场没有，传 nil 占位），
    --    第 5 个参数才是 props。
    -- ⚠️ size 保持 "xl"：背包是 lg（宽约 640），市场要更宽，
    --    所以不减宽度；只把"标题栏 / 内容 padding / 间距"这三个
    --    纵向参数对齐背包，让上下不再松垮。
    local modal = OpenModal("market", "市场", "xl", nil, {
        headerContentGap = 0,
        contentPadding = 6,
        headerHeight = 40,
    })

    -- 3 等分标签：购买物品 / 在售物品 / 上架物品
    local tabs = {}
    local function Tab(id, label)
        table.insert(tabs, Panels.Btn {
            text = label,
            fontSize = 13, height = 40,
            flexGrow = 1, flexBasis = 0,
            variant = (marketTab_ == id) and "primary" or "secondary",
            onClick = function()
                marketTab_ = id
                ReloadMarketWithFilter()
            end,
        })
    end
    Tab("buy", "购买物品")
    Tab("mysell", "在售物品")
    Tab("sell", "上架物品")

    -- ⚠️ alignItems = "flex-start" + paddingHorizontal = 0：
    --    SimpleGrid 的父容器如果默认居中或有内边距，会让网格整体偏移。
    --    显式清零，保证网格从容器最左侧开始排。
    -- ⚠️ width = "100%" 是修 bug 的关键，不是美观调整：
    --    ScrollView 内部的内容容器默认 shrink-to-fit。卡片多时内容够宽、
    --    容器被撑开；只剩 1 个卡片时容器跟着收缩，SimpleGrid 拿到的 w
    --    趋近 0，列宽算出来被 clamp 成 0 → 卡片宽度归零、堆叠到一起。
    --    强制 100% 让 body 始终等于 ScrollView 的宽度，杜绝塌缩。
    -- ⚠️ alignItems 必须保持 "stretch"（Yoga 默认）：设成 "flex-start" 会让
    --    子项（SimpleGrid）按内容宽收缩而非铺满 —— 这正是塌缩的另一半原因。
    local body = S.UI.Panel {
        flexDirection = "column", gap = 6, marginTop = 10,
        width = "100%",
        alignItems = "stretch",
        paddingHorizontal = 0,
    }

    if marketTab_ == "buy" or marketTab_ == "mysell" then
        -- 一级分类侧边栏
        local sidebar = {}
        for _, cat in ipairs(Shared.MARKET_CATEGORIES) do
            table.insert(sidebar, Panels.Btn {
                text = cat.name,
                fontSize = 12, height = 40, paddingHorizontal = 12,
                -- ⚠️ width = "100%" 是必需的，不能用 alignItems = "stretch" 代替：
                --    Button:Init 在「有 text 且没显式传 width」时会自动算一个
                --    固有宽度写进 props.width，而 Yoga 的 stretch 只对宽度为
                --    auto 的子项生效 —— 有显式 width 的按钮不会被拉伸。
                --    显式传 "100%" 会跳过那段固有宽度逻辑，让按钮铺满父容器。
                width = "100%",
                variant = (marketCat_ == cat.id) and "primary" or "secondary",
                onClick = function()
                    marketCat_ = cat.id
                    marketSubCat_ = nil
                    marketQuality_ = nil
                    ReloadMarketWithFilter()
                end,
            })
        end

        -- 二级分类：装备部位 / 碎片品质 / 令牌类型
        local subList = {}
        if marketCat_ == "equip" then
            for _, slotKey in ipairs(Shared.SLOT_LIST) do
                table.insert(subList, Panels.Btn {
                    text = Shared.SLOTS[slotKey].name,
                    fontSize = 11, height = 36, paddingHorizontal = 10,
                    variant = (marketSubCat_ == slotKey) and "primary" or "secondary",
                    onClick = function()
                        marketSubCat_ = slotKey
                        marketQuality_ = nil
                        ReloadMarketWithFilter()
                    end,
                })
            end
        elseif marketCat_ == "fragment" then
            for _, q in ipairs(Shared.QUALITY_LIST) do
                table.insert(subList, Panels.Btn {
                    text = Shared.FRAGMENT_DISPLAY[q].icon .. Shared.FRAGMENT_DISPLAY[q].name,
                    fontSize = 11, height = 36, paddingHorizontal = 10,
                    variant = (marketSubCat_ == q) and "primary" or "secondary",
                    onClick = function()
                        marketSubCat_ = q
                        ReloadMarketWithFilter()
                    end,
                })
            end
        elseif marketCat_ == "token" then
            -- 「在线卡」一级分类下只有在线卡一种
            for _, tk in ipairs({ "online" }) do
                table.insert(subList, Panels.Btn {
                    text = Shared.TOKEN_TYPES[tk].icon .. Shared.TOKEN_TYPES[tk].name,
                    fontSize = 11, height = 36, paddingHorizontal = 10,
                    variant = (marketSubCat_ == tk) and "primary" or "secondary",
                    onClick = function()
                        marketSubCat_ = tk
                        ReloadMarketWithFilter()
                    end,
                })
            end
        elseif marketCat_ == "consume" then
            -- 「消耗」一级分类下只有召唤卷，按品质细分
            -- （不再放「召唤卷（全部）」聚合按钮：一级分类本身已是聚合）
            for _, q in ipairs(Shared.QUALITY_LIST) do
                local sub = "scroll_" .. q
                local disp = Shared.SUMMON_SCROLL[q]
                if disp then
                    table.insert(subList, Panels.Btn {
                        text = disp.icon .. disp.name,
                        fontSize = 11, height = 36, paddingHorizontal = 10,
                        variant = (marketSubCat_ == sub) and "primary" or "secondary",
                        onClick = function()
                            marketSubCat_ = sub
                            ReloadMarketWithFilter()
                        end,
                    })
                end
            end
        elseif marketCat_ == "spirit" then
            for _, q in ipairs(Shared.QUALITY_LIST) do
                table.insert(subList, Panels.Btn {
                    text = Shared.SPIRIT_DISPLAY[q].icon .. Shared.SPIRIT_DISPLAY[q].name,
                    fontSize = 11, height = 36, paddingHorizontal = 10,
                    variant = (marketSubCat_ == q) and "primary" or "secondary",
                    onClick = function()
                        marketSubCat_ = q
                        ReloadMarketWithFilter()
                    end,
                })
            end
        elseif marketCat_ == "pet" then
            -- 宠物类二级：宠物蛋 / 宠物精粹 / 宠物本体
            for _, sub in ipairs({
                { id = "egg",      name = "宠物蛋" },
                { id = "material", name = "宠物精粹" },
                { id = "pet",      name = "宠物" },
            }) do
                table.insert(subList, Panels.Btn {
                    text = sub.name,
                    fontSize = 11, height = 36, paddingHorizontal = 10,
                    variant = (marketSubCat_ == sub.id) and "primary" or "secondary",
                    onClick = function()
                        marketSubCat_ = sub.id
                        ReloadMarketWithFilter()
                    end,
                })
            end
        end

        -- 三级分类：品质（仅装备，且已选部位）
        local qualityList = {}
        if marketCat_ == "equip" and marketSubCat_ then
            for _, q in ipairs(Shared.QUALITY_LIST) do
                table.insert(qualityList, Panels.Btn {
                    text = Shared.QUALITY_NAMES[q],
                    fontSize = 11, height = 32, paddingHorizontal = 10,
                    variant = (marketQuality_ == q) and "primary" or "secondary",
                    onClick = function()
                        -- 再点一次取消品质筛选
                        marketQuality_ = (marketQuality_ == q) and nil or q
                        ReloadMarketWithFilter()
                    end,
                })
            end
        end

        -- 主列表：服务端已按当前筛选分页下发，这里直接渲染本页全部
        -- ⚠️ 不再本地筛选/截断：筛选已上报服务端，本地再筛会导致
        --    「本页条数 < 服务端返回的总数」这类页码错乱。
        local myId = Data.GetPlayerId and Data.GetPlayerId() or nil
        local cards = {}
        for _, l in ipairs(listings_) do
            local mine = (l.sellerId == myId)
            do
                local item = l.item or {}
                local displayName = item.name or "?"
                if Data.IsStackable(item) then
                    displayName = displayName .. " x" .. (item.count or 1)
                end

                local actionBtn
                if marketTab_ == "mysell" then
                    actionBtn = QButton("下架", function()
                        if S.ctx then
                            S.ctx.sendMarket({ Action = "cancel", ListingId = l.id })
                            Notify.Toast("已请求下架")
                        end
                    end, "danger")
                else
                    actionBtn = QButton(mine and "自己" or ("买 " .. l.price),
                        function()
                            if mine then return end
                            if S.ctx then
                                S.ctx.sendMarket({ Action = "buy", ListingId = l.id })
                                Notify.Toast("已请求购买")
                            end
                        end,
                        mine and "secondary" or "success")
                    actionBtn:SetDisabled(mine)
                end

                local durVal = math.floor(item.durability or 0)
                local durColor = "#aabbcc"
                if durVal <= 0 then durColor = "#ff4444"
                elseif durVal <= 20 then durColor = "#ffcc44" end

                -- 商品卡：纵向 —— 损坏标记 / 图标 / 名称 / 耐久 / 价格
                -- ⚠️ 损坏标记只对装备有意义（碎片/精魄/在线卡/召唤卷没有耐久字段）
                local broken = Shared.IsEquipment(item) and durVal <= 0
                local cardChildren = {
                    -- 图标 16：介于最小 13 与原始 26 之间。
                    -- 内高 = 16+10+9+11 + gap 4 = 50，卡片 84 留白 34px，够用。
                    S.UI.Label { text = item.icon or "?", fontSize = 16 },
                    S.UI.Label {
                        text = displayName, fontSize = 10, maxLines = 1,
                        fontColor = Shared.HexRGB(Shared.QUALITY_COLORS[item.quality] or "#ffffff"),
                    },
                }
                if Shared.IsEquipment(item) then
                    table.insert(cardChildren, S.UI.Label {
                        text = "耐久 " .. durVal, fontSize = 9,
                        fontColor = Shared.HexRGB(durColor),
                    })
                end
                table.insert(cardChildren, S.UI.Label {
                    text = "💰 " .. l.price, fontSize = 11,
                    fontColor = Shared.HexRGB("#ffd24d"),
                })
                if broken then
                    table.insert(cardChildren, S.UI.Label {
                        text = "⚠已损坏", fontSize = 8,
                        fontColor = Shared.HexRGB("#ff6666"),
                        position = "absolute", top = 2, left = 4,
                    })
                end

                local card = S.UI.Panel {
                    -- width 会被 SimpleGrid 覆写，写 72 只是表达意图。
                    -- height 84：卡片宽 72 后，内容需要更多纵向呼吸空间。
                    width = 72, height = 84,
                    flexDirection = "column", justifyContent = "center", alignItems = "center",
                    gap = 2,
                    backgroundColor = Panels.THEME.bgCard, borderRadius = 6,
                    borderWidth = 1,
                    -- ⚠️ 条件表达式且含 QUALITY_COLORS → **整条不动**。
                    --    两个分支都是语义色（损坏红 / 品质色），#444444 是品质缺失兜底，
                    --    都不是装饰色。
                    borderColor = Shared.HexRGB(broken and "#ff3333"
                        or (Shared.QUALITY_COLORS[item.quality] or "#444444")),
                    children = cardChildren,
                }
                local listing = l
                card.props.onClick = function() Panels.ShowMarketDetail(listing) end
                card.props.pointerEvents = "auto"

                -- 卡片 + 下方操作按钮打包成一个网格单元
                -- ⚠️ 两者必须包在同一个单元里；若作为两个并列子节点塞进 SimpleGrid，
                --    会被拆到同一行的不同列，卡片和按钮横向交错。
                table.insert(cards, S.UI.Panel {
                    width = 72,
                    flexDirection = "column", alignItems = "center", gap = 2,
                    children = {
                        card,
                        S.UI.Panel {
                            height = 24,
                            flexDirection = "row", justifyContent = "center",
                            children = { actionBtn },
                        },
                    },
                })
            end
        end

        -- 在售物品页：显示上架格子占用，让玩家提前知道还能上几件
        -- （原来没有任何占用提示，格子满了也只能靠上架失败才发现）
        if marketTab_ == "mysell" then
            local maxSlots = Shared.C.MARKET_SLOT_MAX or 20
            -- ⚠️ 用服务端下发的 marketMyTotal_（筛选前统计的全量），
            --    不能用 MyListingCount()：分页后那只统计「当前页」里自己的挂单。
            local used = marketMyTotal_
            body:AddChild(S.UI.Label {
                text = string.format("上架格子：%d / %d", used, maxSlots),
                fontSize = 11,
                fontColor = Shared.HexRGB(used >= maxSlots and "#ff7878" or "#9fd8ff"),
            })
        end

        if #cards == 0 then
            body:AddChild(S.UI.Label {
                text = "暂无商品", fontSize = 12, fontColor = Panels.THEME.textDim,
            })
        else
            -- 8 列 × 72 + 7 × 10 = 646，可用 648，空 2px（视觉上填满）。
            -- ⚠️ 卡片实际宽度由 SimpleGrid 按 (w - gap×7 - 1)/8 算出，
            --    卡片上写的 width 会被覆写 —— 改尺寸只需改 columns 和 gap。
            body:AddChild(S.UI.SimpleGrid { columns = 8, gap = 10, width = "100%", children = cards })
        end

        -- 翻页栏（服务端分页）：上一页 / 第 N/M 页（共 X 件）/ 下一页
        local function GotoPage(page)
            if S.ctx and S.ctx.requestMarketPage then
                S.ctx.requestMarketPage(page)
            end
        end
        local prevBtn = QButton("上一页", function() GotoPage(marketPage_ - 1) end, "secondary")
        if marketPage_ <= 0 then prevBtn:SetDisabled(true) end
        local nextBtn = QButton("下一页", function() GotoPage(marketPage_ + 1) end, "secondary")
        if marketPage_ >= marketTotalPages_ - 1 then nextBtn:SetDisabled(true) end
        body:AddChild(S.UI.Panel {
            flexDirection = "row", gap = 10, justifyContent = "center", alignItems = "center",
            marginTop = 4,
            children = {
                prevBtn,
                S.UI.Label {
                    text = string.format("第 %d / %d 页（共 %d 件）",
                        marketPage_ + 1, marketTotalPages_, marketTotal_),
                    fontSize = 11, fontColor = Shared.HexRGB("#9fd8ff"),
                },
                nextBtn,
            },
        })

        -- ⚠️ 固定高度 400，让市场内容总高与背包持平：
        --     市场 = 40(tabs) + 4(gap) + 400 = 444
        --     背包 = 400(6×60 格子 + 5×8 gap) + 4(gap) + 40(footer 按钮) = 444
        --    不固定的话 Modal 高度会随列表条数变化，切标签时面板忽高忽低。
        modal:AddContent(S.UI.Panel {
            flexDirection = "column", gap = 4,
            children = {
                S.UI.Panel { flexDirection = "row", gap = 8, children = tabs },
                S.UI.Panel {
                    -- gap 归零：消除 sidebar 与右侧列之间的空白。
                    -- sidebar 按钮本身有内边距（paddingHorizontal = 12），
                    -- 视觉上已经和右侧卡片有足够分隔，不需要再留 gap。
                    flexDirection = "row", gap = 0, marginTop = 0,
                    height = 400,
                    children = {
                        -- 左侧筛选栏：从 190 缩到 140，让出空间给右侧多放一列。
                        -- "全部 / 装备 / 碎片 / 精魄 / 在线卡 / 消耗" 最多 3 字，
                        -- 140 减去 padding 24 后内容宽 116，够放。
                        -- ⚠️ alignItems = "stretch" 对 Button 无效：Button:Init 里
                        --    会给 props.width 写死固有宽度（measureIntrinsicWidth），
                        --    有显式 width 的子项不会被 stretch 拉伸。
                        --    要真正铺满必须给按钮传 width（见 sidebar 构造处）。
                        S.UI.Panel {
                            flexDirection = "column", gap = 4, width = 140,
                            height = 400,
                            alignItems = "stretch",
                            children = sidebar,
                        },
                        S.UI.Panel {
                            flexDirection = "column", gap = 4, flexGrow = 1, flexShrink = 1,
                            height = 400,
                            paddingHorizontal = 0,
                            alignItems = "stretch",
                            children = {
                                -- ⚠️ subList / qualityList 显式声明 justify-content:
                                --    flex-start 保证从最左侧开始排，不被居中。
                                S.UI.Panel {
                                    flexDirection = "row", gap = 4, flexWrap = "wrap",
                                    justifyContent = "flex-start",
                                    paddingHorizontal = 0,
                                    children = subList,
                                },
                                S.UI.Panel {
                                    flexDirection = "row", gap = 4, flexWrap = "wrap",
                                    justifyContent = "flex-start",
                                    paddingHorizontal = 0,
                                    children = qualityList,
                                },
                                -- maxHeight 放宽到 400：ScrollView 有 flexGrow=1，
                                -- 实际高度取「右侧列剩余空间」，maxHeight 只是上限。
                                S.UI.ScrollView {
                                    flexGrow = 1, flexBasis = 0, maxHeight = 400,
                                    paddingHorizontal = 0,
                                    children = { body },
                                },
                            },
                        },
                    },
                },
            },
        })
    else
        -- 上架页：提示框 + 背包可上架格子
        local inv = Data.value.inventory
        local cells = {}
        local shown = 0
        for _, item in ipairs(inv) do
            if shown < 24 then
                shown = shown + 1
                local displayName = item.name or "?"
                if Data.IsStackable(item) then
                    displayName = displayName .. " x" .. (item.count or 1)
                end
                local itemId = item.id
                local qcolor = Shared.QUALITY_COLORS[item.quality] or "#ffffff"

                local cell = S.UI.Panel {
                    width = 84, height = 84,
                    flexDirection = "column", justifyContent = "center", alignItems = "center",
                    gap = 2,
                    backgroundColor = Panels.THEME.bgCard, borderRadius = 6,
                    borderWidth = 2,
                    borderColor = Shared.HexRGB(qcolor),
                    pointerEvents = "auto",
                    children = {
                        S.UI.Label { text = item.icon or "?", fontSize = 22 },
                        S.UI.Label {
                            text = displayName, fontSize = 9, maxLines = 1,
                            fontColor = Shared.HexRGB(qcolor),
                        },
                    },
                }
                cell.props.onClick = function() Panels.ShowSellFormById(itemId) end
                table.insert(cells, cell)
            end
        end

        local hintBox = S.UI.Panel {
            height = 44,
            flexDirection = "row", justifyContent = "center", alignItems = "center",
            borderWidth = 1,
            borderColor = Panels.THEME.border,
            borderRadius = 6,
            children = {
                S.UI.Label {
                    text = "点击下方装备选择要上架的物品",
                    fontSize = 12, fontColor = Panels.THEME.textSecond,
                },
            },
        }

        local contentChildren = {
            S.UI.Panel { flexDirection = "row", gap = 8, children = tabs },
            hintBox,
        }
        if shown == 0 then
            table.insert(contentChildren, S.UI.Label {
                text = "背包为空", fontSize = 12, fontColor = Panels.THEME.textDim,
            })
        else
            table.insert(contentChildren, S.UI.ScrollView {
                flexGrow = 1, flexBasis = 0, maxHeight = 380,
                children = { S.UI.SimpleGrid { columns = 6, gap = 8, children = cells } },
            })
        end

        -- 固定 444，与 buy/mysell 分支及背包面板内容总高一致（见上方注释）。
        modal:AddContent(S.UI.Panel {
            flexDirection = "column", gap = 4,
            height = 444,
            children = contentChildren,
        })
    end

    modal:Open()
end

--- 上架表单（按物品 id 定位，B3）。
--- ⚠️ 用 ItemId 而非背包下标：下标在面板重开后可能指向别的物品。
---@param itemId string
function Panels.ShowSellFormById(itemId)
    local item = Data.FindInventoryItem(itemId)
    if not item then
        Notify.Toast("物品已不存在")
        return
    end
    -- 上锁物品禁止上架（背包里点「全部解锁」可解除）
    if Shared.IsLocked(item) then
        Notify.Toast("该物品已上锁，请先解锁")
        return
    end

    -- 🔴 上架格子上限（固定 12 格）：在这里就拦住，别等服务端拒绝。
    --    原实现没有任何上限校验，服务端照收、而界面只渲染前 12 条，
    --    于是「上架后物品消失且无任何提示」。
    local maxSlots = Shared.C.MARKET_SLOT_MAX or 12
    local myCount = MyListingCount()
    if myCount >= maxSlots then
        Notify.Toast(string.format("上架格子已满（%d/%d），请先下架一些物品",
            myCount, maxSlots))
        return
    end

    local stackable = Data.IsStackable(item)
    local maxQty = stackable and (item.count or 1) or 1

    local priceField = S.UI.TextField {
        text = "100",
        placeholder = "整单售价",
        fontSize = 13,
        width = 120,
    }
    local qtyField = S.UI.TextField {
        text = tostring(maxQty),
        placeholder = "数量",
        fontSize = 13,
        width = 120,
    }

    -- ⚠️ 改用栈式 Modal：从市场 / 背包进入上架表单时保留父面板，
    --    上架成功后只关 sellform，市场面板继续显示（并自动刷新）。
    local modal = OpenStackedModal("上架 " .. (item.name or ""), "md")
    local rows = {
        QLabel("物品：" .. (item.name or "?")),
        QLabel("可堆叠数量：" .. maxQty, "#aaaaaa", 11),
        S.UI.Panel {
            flexDirection = "row", alignItems = "center", gap = 8,
            children = { QLabel("整单售价"), priceField },
        },
    }
    -- 只有可堆叠物才需要数量输入
    if stackable then
        table.insert(rows, S.UI.Panel {
            flexDirection = "row", alignItems = "center", gap = 8,
            children = { QLabel("数量"), qtyField },
        })
    end
    modal:AddContent(S.UI.Panel { flexDirection = "column", gap = 10, children = rows })

    modal:SetFooter(S.UI.Panel {
        flexDirection = "row", justifyContent = "flex-end", gap = 8,
        children = {
            QButton("取消", function() modal:Close() end),
            QButton("确认上架", function()
                local price = math.floor(tonumber(priceField:GetValue()) or 0)
                if price < 1 then
                    Notify.Toast("售价必须大于 0")
                    return
                end
                if price > Shared.C.MARKET_PRICE_MAX then
                    Notify.Toast("售价不能超过 21 亿")
                    return
                end
                local qty = 1
                if stackable then
                    qty = math.floor(tonumber(qtyField:GetValue()) or 0)
                    if qty < 1 or qty > maxQty then
                        Notify.Toast("数量需在 1 ~ " .. maxQty .. " 之间")
                        return
                    end
                end

                local inv = Data.value.inventory
                local idx = nil
                for i, it in ipairs(inv) do if it.id == itemId then idx = i; break end end
                if not idx then
                    Notify.Toast("物品已不存在")
                    modal:Close()
                    return
                end

                local function deepCopy(src)
                    if type(src) ~= "table" then return src end
                    local out = {}
                    for k, v in pairs(src) do out[k] = deepCopy(v) end
                    return out
                end
                local origItem = inv[idx]
                local snapshot = deepCopy(origItem)
                -- 可堆叠物：快照只保留本次上架的数量。
                -- ⚠️ 不能带整堆数量：服务端会拿这份快照建单，带 60 就是挂出 60
                --    （上架 10 张却挂 60 张的复制 bug）。
                if stackable then snapshot.count = qty end

                local rollback
                if stackable and qty < (origItem.count or 1) then
                    origItem.count = origItem.count - qty
                    rollback = {
                        Type = "addCount",
                        ItemId = itemId,
                        Count = qty,
                        -- 保存原始类型，回滚时按类型重建
                        -- ⚠️ 必须覆盖全部可堆叠类型（碎片/精魄/令牌）：
                        --    漏掉的类型会落到 "unknown"，回滚时被重建为普通碎片。
                        ItemKind = Shared.IsFragment(origItem) and "fragment"
                                   or (Shared.IsSpirit(origItem) and "spirit"
                                   or (Shared.IsToken(origItem) and "token"
                                   or (Shared.IsSummonScroll(origItem) and "summonScroll" or "unknown"))),
                        FragmentType = origItem.fragmentType,
                        SpiritType   = origItem.spiritType,
                        TokenType    = origItem.tokenType,
                        ScrollType   = origItem.scrollType,
                    }
                else
                    table.remove(inv, idx)
                    rollback = { Type = "append", Item = snapshot }
                end
                Data.MarkDirty("inventory")

                if S.ctx and S.ctx.appendPendingListing then
                    S.ctx.appendPendingListing({
                        ClientId = "c" .. tostring(os.time()) .. tostring(math.random(100000, 999999)),
                        ItemId = itemId,
                        Price = price,
                        Quantity = qty,
                        -- 带上完整快照：客户端已把物品从本地背包移除，
                        -- 服务端重发时可能查不到，靠快照仍能正确建单。
                        Item = snapshot,
                        Rollback = rollback,
                    })
                end
                -- 走一次带 ACK 的 flush：上架意图在 pendingListings_ 里，
                -- SyncToServer 会一并上报，不需要再构造空请求。
                -- 等 ACK 才知道结果，所以 Toast 文案分成功/超时两种。
                -- 价格语义：price 是「整单总价」，不是单价
                if S.ctx and S.ctx.flushOnly then
                    S.ctx.flushOnly(function(ok)
                        if ok then
                            Notify.Toast(string.format("已提交上架：整单 %d💰 ×%d 件", price, qty))
                        else
                            Notify.Toast("上架请求超时，请到市场确认结果")
                        end
                    end)
                else
                    if S.ctx and S.ctx.forceSync then S.ctx.forceSync() end
                    Notify.Toast(string.format("已提交上架：整单 %d💰 ×%d 件", price, qty))
                end
                modal:Close()
                -- ⚠️ 上架是叠加在背包之上的栈式 Modal，关掉表单只回退到背包，
                --    而背包格子还画着刚被移除的物品。这里显式刷新一次，
                --    否则玩家要关掉背包再打开，才会看到该物品消失。
                Panels.RefreshInventoryViews()
            end, "primary"),
        },
    })
    modal:Open()
end

-- ============================================================
-- 邮箱（分页）
-- ============================================================
local mailPage_ = 0
local MAIL_PAGE_SIZE_ = 50

--- 服务端回推的分页邮件（MailPageResult 事件写入）
---@type table|nil
local mailPageData_ = nil
--- 服务端下发的邮件总数（本地缓存只有一页，不能用 #mails 算总页数）
local mailTotal_ = 0

--- 接收服务端分页邮件（由 Client.lua 的 OnMailPageResult 调用）
---@param page integer
---@param total integer
---@param mails table[]
---@param goldTotal integer|nil
---@param itemTotal integer|nil
function Panels.SetMailPage(page, total, mails, goldTotal, itemTotal)
    mailPageData_ = { page = page, total = total, mails = mails or {} }
    mailTotal_ = total or 0
    if goldTotal then Data.value.mailGoldTotal = goldTotal end
    if itemTotal then Data.value.mailItemTotal = itemTotal end
    Panels.RefreshIfOpen("mail", Panels.OpenMail)
end

--- 收到 InvSync / AssignPlayer 时更新邮件总数
---@param total integer
function Panels.SetMailTotal(total)
    mailTotal_ = total or 0
end

--- 服务端邮件列表变化时调用：清空分页缓存，强制下次 OpenMail 重新拉取。
--- ⚠️ mailPageData_ 是「服务端分页结果」的缓存，只在 MAIL_PAGE_RESULT 时更新。
---    如果不清，领完邮件后重开邮箱会优先命中旧缓存，列表看起来没刷新。
function Panels.InvalidateMailPage()
    mailPageData_ = nil
end

function Panels.OpenMail()
    local modal = OpenModal("mail", "邮箱", "lg")

    -- 优先用服务端分页数据；没有则用本地缓存 + 服务端总数
    local mails, total
    if mailPageData_ and mailPageData_.page == mailPage_ then
        mails = mailPageData_.mails or {}
        total = mailPageData_.total or mailTotal_
    else
        mails = Data.value.mails or {}
        total = mailTotal_
        if total == 0 then total = #mails end
    end

    local totalPages = math.max(1, math.ceil(total / MAIL_PAGE_SIZE_))
    if mailPage_ >= totalPages then mailPage_ = totalPages - 1 end

    -- 当前页没有服务端数据时主动拉取（本地只缓存第一页）
    if not (mailPageData_ and mailPageData_.page == mailPage_) then
        -- total == 0 时不必等分页结果：直接往下渲染空列表。
        -- 领完邮件后服务端会推 MailUpdate 并清掉邮件，若还等分页会先闪一下「加载中…」。
        if total > 0 and S.ctx and S.ctx.requestMailPage then
            S.ctx.requestMailPage(mailPage_)
            -- 先显示「加载中」，等服务端 MailPageResult 回来会 RefreshIfOpen 重开本面板。
            -- 之前直接往下渲染会用到上一页的陈旧 mails，出现闪一下旧数据再跳变。
            modal:AddContent(S.UI.Label {
                text = "加载中…", fontSize = 12,
                fontColor = Panels.THEME.textSecond,
            })
            modal:Open()
            return
        end
    end

    local startIdx = mailPage_ * MAIL_PAGE_SIZE_ + 1
    local endIdx = math.min(startIdx + MAIL_PAGE_SIZE_ - 1, total)

    -- 紧凑单列：每行 32px，一页 50 封（附件只在右侧汇总件数，点「全部领取」一次收完）
    local rows = {}
    if total == 0 then
        table.insert(rows, QLabel("暂无邮件", "#888888"))
    else
        for i = startIdx, endIdx do
            local m = mails[i - startIdx + 1]
            if m then
                local rightParts = {}
                if (m.gold or 0) > 0 then
                    table.insert(rightParts, "💰 " .. m.gold)
                end
                if #(m.items or {}) > 0 then
                    table.insert(rightParts, "📦 " .. #m.items .. " 件")
                end

                table.insert(rows, S.UI.Panel {
                    flexDirection = "row", alignItems = "center", gap = 6,
                    paddingHorizontal = 8, paddingVertical = 2,
                    height = 24,
                    backgroundColor = Panels.THEME.bgCard, borderRadius = 4,
                    children = {
                        S.UI.Label {
                            text = "📬 " .. (m.title or "邮件"),
                            fontSize = 10, maxLines = 1,
                            flexGrow = 1, flexShrink = 1,
                            fontColor = Panels.THEME.textPrimary,
                        },
                        S.UI.Label {
                            text = table.concat(rightParts, "   "),
                            fontSize = 10, fontColor = Shared.HexRGB("#ffd24d"),
                        },
                    },
                })
            end
        end
    end

    -- ⚠️ 领取按钮必须定义在 pageRow 之前，才能在 pageRow 里引用。
    -- 保留引用是为了支持「领取中…」禁用态，防止玩家背包满/网络慢时连点。
    -- 尺寸与翻页按钮一致（compact：height 30 / fontSize 11），不用全局 QButton（40 高）
    local claimBtn
    claimBtn = Panels.Btn {
        text = "全部领取", fontSize = 11, height = 30, paddingHorizontal = 12,
        variant = "success",
        onClick = function()
            if total == 0 then
                Notify.Toast("没有可领取的邮件")
                return
            end
            claimBtn:SetDisabled(true)
            claimBtn:SetText("领取中…")

            local function restore()
                -- 领取结果由 MAIL_CLAIM_RESULT 事件驱动（OnMailClaimResult 弹 Toast），
                -- 这里只负责恢复按钮。⚠️ 期间 InvSync 可能触发 RefreshIfOpen 重开邮箱，
                -- 本实例已被销毁 —— 对已销毁节点调 SetDisabled/SetText 可能报错，故加 pcall。
                if claimBtn then
                    pcall(function()
                        claimBtn:SetDisabled(false)
                        claimBtn:SetText("全部领取")
                    end)
                end
            end

            if S.ctx and S.ctx.flushThenSend then
                S.ctx.flushThenSend(Shared.EVENTS.MAIL_CLAIM, { MailId = "__ALL__" }, restore)
            else
                -- 降级：没有 flush 通道时直发（服务端可能拿旧背包判定已满）
                if S.ctx and S.ctx.claimMail then S.ctx.claimMail("__ALL__") end
                restore()
            end
        end,
    }

    -- 分页栏 + 领取按钮合成一行（不再放 Modal footer：footer 会预留底部空间，
    -- 在小屏上把内容区挤没，而且「全部领取」和翻页本来就是同一组操作）
    -- 按钮用 compact 尺寸（30 高），和邮件行的紧凑风格一致
    local pageRow = S.UI.Panel {
        flexDirection = "row", gap = 6, justifyContent = "center",
        alignItems = "center", marginTop = 4,
        children = {
            Panels.Btn {
                text = "上一页", fontSize = 11, height = 30, paddingHorizontal = 12,
                variant = mailPage_ > 0 and "primary" or "secondary",
                onClick = function()
                    if mailPage_ > 0 then
                        mailPage_ = mailPage_ - 1
                        Panels.OpenMail()
                    end
                end,
            },
            QLabel((mailPage_ + 1) .. " / " .. totalPages, "#aaaaaa", 10),
            Panels.Btn {
                text = "下一页", fontSize = 11, height = 30, paddingHorizontal = 12,
                variant = mailPage_ < totalPages - 1 and "primary" or "secondary",
                onClick = function()
                    if mailPage_ < totalPages - 1 then
                        mailPage_ = mailPage_ + 1
                        Panels.OpenMail()
                    end
                end,
            },
            -- 视觉分隔：把「领取」和「翻页」分开，避免误点
            S.UI.Panel { width = 12 },
            claimBtn,
        },
    }

    -- 邮件汇总：待领取金币 / 待领取物品（件数）
    local itemTotal = Data.value.mailItemTotal or 0
    local summaryRow = S.UI.Panel {
        flexDirection = "column", gap = 2,
        paddingHorizontal = 8, paddingVertical = 4,
        backgroundColor = { 255, 230, 200, 15 },
        borderRadius = 6,
        children = {
            S.UI.Panel {
                flexDirection = "row", justifyContent = "space-between",
                children = {
                    S.UI.Label { text = "待领取金币", fontSize = 10,
                        fontColor = Panels.THEME.textSecond },
                    S.UI.Label {
                        text = "💰 " .. tostring(Data.value.mailGoldTotal or 0),
                        fontSize = 10, fontColor = Shared.HexRGB("#ffcc44"),
                    },
                },
            },
            S.UI.Panel {
                flexDirection = "row", justifyContent = "space-between",
                children = {
                    S.UI.Label { text = "待领取物品", fontSize = 10,
                        fontColor = Panels.THEME.textSecond },
                    S.UI.Label {
                        text = tostring(itemTotal) .. " 件",
                        fontSize = 10, fontColor = Shared.HexRGB("#aaddff"),
                    },
                },
            },
        },
    }

    -- 主内容：汇总 + 滚动列表 + 分页(+领取)
    -- ⚠️ 这里刻意不用 flexGrow/flexBasis：Modal 的高度是「按内容测一遍」算出来的，
    --    测量时高度不受约束，弹性高度会塌成 0。改用「外层 Panel 固定高度」的硬约束链条。
    modal:AddContent(S.UI.Panel {
        flexDirection = "column", gap = 4,
        children = {
            summaryRow,
            -- 固定高度的滚动容器：ScrollView 在里面填满并滚动
            S.UI.Panel {
                height = 320,
                flexDirection = "column",
                children = {
                    S.UI.ScrollView {
                        flexGrow = 1, flexBasis = 0,
                        children = { S.UI.Panel { flexDirection = "column", gap = 2, children = rows } },
                    },
                },
            },
            pageRow,
        },
    })

    -- ⚠️ 不再调用 modal:SetFooter：footer 会为底部按钮预留一条固定高度的区域，
    --    在手机上会把 50 行的滚动区挤得很矮。「全部领取」已并入上面的 pageRow。

    modal:Open()
end

-- ============================================================
-- 市场商品详情（B4）
-- ============================================================
---@param listing table
function Panels.ShowMarketDetail(listing)
    local item = listing.item or {}
    local myId = Data.GetPlayerId and Data.GetPlayerId() or nil
    local mine = (listing.sellerId == myId)

    -- ⚠️ 栈式 Modal：从市场面板打开商品详情时保留市场面板
    local modal = OpenStackedModal(item.name or "商品", "xl")

    local infoRows = {
        QLabel("售价：💰" .. tostring(listing.price), "#ffd24d", 16),
        QLabel("卖家：" .. (mine and "自己" or tostring(listing.sellerId or "?")), "#aaaaaa", 12),
    }

    -- 装备走完整详情（词条 + 技能 + 耐久）；碎片/精魄/卡券走简单详情
    local detailLayout
    if Shared.IsEquipment(item) then
        detailLayout = Panels.BuildDetailLayout(item, nil)
    else
        detailLayout = Panels.BuildItemSummaryLayout(item)
    end

    modal:AddContent(S.UI.Panel {
        flexDirection = "column", gap = 8,
        children = {
            detailLayout,
            S.UI.Divider { orientation = "horizontal" },
            S.UI.Panel { flexDirection = "column", gap = 4, children = infoRows },
        },
    })

    -- 下单/下架都是「先 flush 再发」的写操作（见 Client.sendMarket）。
    -- 这里不再立刻 Toast「已请求 xx」：真实结果由服务端回包驱动
    -- （购买成功 → 邮件 + InvSync；失败 → 服务端 Toast），避免出现
    -- 「提示已请求，其实因为背包/金币不足失败了」的误导。
    local btns = {}
    if mine then
        table.insert(btns, QButton("下架", function()
            if S.ctx then
                S.ctx.sendMarket({ Action = "cancel", ListingId = listing.id })
            end
            modal:Close()
        end, "danger"))
    else
        table.insert(btns, QButton("购买", function()
            if S.ctx then
                S.ctx.sendMarket({ Action = "buy", ListingId = listing.id })
            end
            modal:Close()
        end, "primary"))
    end
    table.insert(btns, QButton("取消", function() modal:Close() end))
    modal:SetFooter(S.UI.Panel {
        flexDirection = "row", justifyContent = "flex-end", gap = 8,
        children = btns,
    })
    modal:Open()
end

return Panels

