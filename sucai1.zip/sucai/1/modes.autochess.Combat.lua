-- ============================================================
-- 卡牌自走棋：战斗引擎（纯逻辑，不涉及 UI）
--
-- 规则：
--   · 棋盘 2 行 x 3 列。靠近对方的那行是「前排」，另一行是「后排」
--     - 我方在下方：第 1 行（靠上）是前排
--     - 敌方在上方：第 2 行（靠下）是前排
--   · 先后手随机决定
--   · 同一时刻只有一个棋子行动，行动结束才轮到下一个
--   · 攻击目标：先看对方前排有无存活，有则随机选一个；前排全灭才打后排
--   · 被攻击方同时反击（互相掉血）
--   · 一方全灭 → 战斗结束
--
-- 输出「事件流」，由 UI 层按节奏逐条播放。
-- ============================================================
local Combat = {}

-- ============================================================
-- 一、队伍构建
-- ============================================================

-- ============================================================
-- 统一的棋子模板：所有棋子都是同一种「小兵」
-- ============================================================
Combat.UNIT_NAME = "小兵"
Combat.UNIT_ATK  = 5
Combat.UNIT_HP   = 10

--- 由备战棋盘生成我方战斗队伍
---@param boardSlots table[] 备战页的 boardSlots
---@return table[]
function Combat.BuildMyTeam(boardSlots)
    local team = {}
    for i = 1, 6 do
        local s = boardSlots[i]
        if s and s.occupied then
            team[#team + 1] = {
                idx = i,
                name = Combat.UNIT_NAME,
                atk = Combat.UNIT_ATK,
                hp = Combat.UNIT_HP,
                maxHp = Combat.UNIT_HP,
                star = s.star or 1,
                level = s.level or 1,
            }
        end
    end
    return team
end

--- 生成敌方战斗队伍（本地生成，与统一棋子模板一致）
---@param count integer|nil 默认 6
---@return table[]
function Combat.BuildEnemyTeam(count)
    count = count or 6
    local team = {}
    for i = 1, count do
        team[#team + 1] = {
            idx = i,
            name = Combat.UNIT_NAME,
            atk = Combat.UNIT_ATK,
            hp = Combat.UNIT_HP,
            maxHp = Combat.UNIT_HP,
            star = 1,
            level = 1,
        }
    end
    return team
end

-- ============================================================
-- 二、战斗模拟
-- ============================================================

--- 前排行号（1 或 2）
--- 我方在下方 → 第 1 行靠上、更接近敌方 → 前排
--- 敌方在上方 → 第 2 行靠下、更接近我方 → 前排
---@param isEnemy boolean
---@return integer
local function FrontRow(isEnemy)
    return isEnemy and 2 or 1
end

--- 取某个单位所在的行（1 或 2）
---@param idx integer 1..6
---@return integer
local function RowOf(idx)
    return idx <= 3 and 1 or 2
end

--- 从对方存活单位中选一个攻击目标
--- 优先前排，前排全灭才打后排；同排内随机
---@param foes table[]
---@param isEnemySide boolean 这批 foes 是否为敌方
---@return table|nil
local function PickTarget(foes, isEnemySide)
    local front = FrontRow(isEnemySide)
    local frontAlive, backAlive = {}, {}
    for _, u in ipairs(foes) do
        if u.hp > 0 then
            if RowOf(u.idx) == front then
                frontAlive[#frontAlive + 1] = u
            else
                backAlive[#backAlive + 1] = u
            end
        end
    end
    local pool = #frontAlive > 0 and frontAlive or backAlive
    if #pool == 0 then return nil end
    return pool[math.random(1, #pool)]
end

--- 判断某队是否全灭
---@param team table[]
---@return boolean
local function IsWiped(team)
    for _, u in ipairs(team) do
        if u.hp > 0 then return false end
    end
    return true
end

--- 某方的出手顺序：先前排从左到右，再后排从左到右（双方对称）
---   我方在下方：前排 = idx 1,2,3（靠上那行），后排 = idx 4,5,6
---   敌方在上方：前排 = idx 4,5,6（靠下那行），后排 = idx 1,2,3
--- 两侧都按「屏幕左边优先」，视觉上左右对称
---@param isEnemy boolean
---@return integer[]
local function OrderOf(isEnemy)
    if isEnemy then
        return { 4, 5, 6, 1, 2, 3 }
    end
    return { 1, 2, 3, 4, 5, 6 }
end

--- 从 order 的 startPos 位置起环形查找下一个存活单位（死者跳过）
---@param order integer[] 出手顺序表
---@param team table[]
---@param startPos integer 1-based 起始位置
---@return table|nil unit 找到的单位
---@return integer nextPos 该单位之后的下一个起始位置
local function NextAlive(order, team, startPos)
    local byIdx = {}
    for _, u in ipairs(team) do byIdx[u.idx] = u end

    local n = #order
    for k = 0, n - 1 do
        local pos = ((startPos - 1 + k) % n) + 1
        local u = byIdx[order[pos]]
        if u and u.hp > 0 then
            return u, (pos % n) + 1
        end
    end
    return nil, startPos
end

--- 跑完整场战斗，返回事件流
---@param myTeam table[]
---@param enemyTeam table[]
---@return table[] events
---@return string winner "my" | "enemy" | "draw"
function Combat.Simulate(myTeam, enemyTeam)
    local events = {}

    --- 深拷贝，避免污染传入数据
    ---@param team table[]
    ---@return table[]
    local function clone(team)
        local t = {}
        for i, u in ipairs(team) do
            t[i] = {
                idx = u.idx, name = u.name,
                atk = u.atk, hp = u.hp, maxHp = u.maxHp,
                star = u.star, level = u.level,
            }
        end
        return t
    end

    local mine = clone(myTeam)
    local foes = clone(enemyTeam)

    -- 随机先后手
    local myFirst = math.random(1, 2) == 1
    events[#events + 1] = {
        kind = "start",
        myFirst = myFirst,
    }

    local turn = myFirst and "my" or "enemy"
    local guard = 0
    local MAX_STEPS = 400   -- 防止死循环

    -- 双方各自的出手游标（1-based，指向 order 表中的位置）
    local myOrder  = OrderOf(false)
    local enOrder  = OrderOf(true)
    local myPos    = 1
    local enPos    = 1

    while not IsWiped(mine) and not IsWiped(foes) and guard < MAX_STEPS do
        guard = guard + 1

        local attackerSide = turn
        ---@type table[]
        local atkTeam = (turn == "my") and mine or foes
        ---@type table[]
        local defTeam = (turn == "my") and foes or mine
        local defIsEnemy = (turn == "my")     -- 被攻击方是否为敌方

        -- 按各自出手顺序取下一个存活单位（死者跳过），并推进游标
        local attacker = nil
        if turn == "my" then
            attacker, myPos = NextAlive(myOrder, mine, myPos)
        else
            attacker, enPos = NextAlive(enOrder, foes, enPos)
        end

        if attacker then
            local target = PickTarget(defTeam, defIsEnemy)
            if target then
                -- 攻击方打目标
                local dmg = attacker.atk
                target.hp = target.hp - dmg
                if target.hp < 0 then target.hp = 0 end

                -- 目标反击（若还活着）
                local counter = 0
                if target.hp > 0 then
                    counter = target.atk
                    attacker.hp = attacker.hp - counter
                    if attacker.hp < 0 then attacker.hp = 0 end
                end

                events[#events + 1] = {
                    kind = "attack",
                    side = attackerSide,
                    attackerIdx = attacker.idx,
                    targetIdx = target.idx,
                    targetIsEnemy = defIsEnemy,
                    damage = dmg,
                    counter = counter,
                    attackerHpAfter = attacker.hp,
                    targetHpAfter = target.hp,
                }
            end
        end

        -- 严格交替出手方：A1, B1, A2, B2 ...
        turn = (turn == "my") and "enemy" or "my"
    end

    local winner = "draw"
    if IsWiped(foes) and not IsWiped(mine) then
        winner = "my"
    elseif IsWiped(mine) and not IsWiped(foes) then
        winner = "enemy"
    end

    events[#events + 1] = { kind = "end", winner = winner }
    return events, winner
end

return Combat
