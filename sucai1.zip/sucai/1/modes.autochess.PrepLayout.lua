-- ============================================================
-- 备战界面布局（按设计稿重写）
--
-- 上半屏（设计稿 y 0..955）：石质面板
--   顶栏    y 0..155    金币 / 星级 / 经验 / 菜单
--   商店区  y 318..760  3 张卡（各 270×442，间距 51，左边距 84）
--   操作栏  y 780..955  升级 / 刷新 / 锁定
-- 下半屏（y 955..2400）：地牢氛围底 + 半透明棋盘/备战区浮层
--
-- 设计稿基准 1080×2400，经 S() 按短边等比换算为 UI base 像素。
-- ============================================================
local Shared = require("Shared")

local PrepLayout = {}

local SPEC_SHORT = 1080

-- 调色板（取自设计稿采样）
local C = {
    panelBg     = { 32, 33, 28, 255 },     -- #20211c 石质面板
    panelBorder = { 122, 106, 74, 255 },   -- 金边
    plateBg     = { 42, 43, 38, 255 },     -- 顶栏弧形托板
    cardBg      = { 36, 39, 42, 255 },     -- #24272a 卡面
    cardBorder  = { 113, 114, 126, 255 },  -- #71727e 卡框
    bannerBg    = { 110, 113, 120, 255 },  -- #6e7178 名牌底
    bannerText  = { 26, 26, 30, 255 },
    portraitBg  = { 125, 114, 99, 255 },   -- #7d7263 头像底
    descBg      = { 46, 46, 46, 235 },
    costBg      = { 28, 65, 94, 255 },     -- #1c415e 费用蓝
    costBorder  = { 65, 111, 145, 255 },
    hpBg        = { 122, 42, 42, 255 },
    hpBorder    = { 208, 112, 112, 255 },
    gold        = { 255, 204, 51, 255 },
    green       = { 136, 204, 136, 255 },
    opBarDark   = { 24, 25, 21, 255 },
    opBtnRed    = { 98, 22, 18, 255 },     -- #621612
    opBtnGreen  = { 63, 101, 80, 255 },    -- #3f6550
    wood        = { 141, 124, 96, 255 },   -- #8d7c60 木牌
    dungeonTop  = { 34, 43, 52, 255 },
    dungeonBot  = { 110, 123, 136, 255 },
}

-- 羁绊胶囊配色（按 tag 取色，未知回退蓝灰）
local TRAIT_COLORS = {
    ["战士"] = { 62, 73, 97, 255 },
    ["自然"] = { 48, 74, 42, 255 },
    ["星爵"] = { 70, 60, 86, 255 },
    ["机械"] = { 74, 68, 52, 255 },
    ["幽灵"] = { 58, 52, 78, 255 },
}

local function Hex(s, a)
    return Shared.HexRGB(s, a)
end

-- ---------------------------------------------------------
-- 通用小件
-- ---------------------------------------------------------

--- 圆形数字圈（费用 / 血量）
---@param S fun(v: number): number
---@param size number
---@param text string
---@param bg table
---@param border table
---@param fontSize number
---@return any
local function NumCircle(S, size, text, bg, border, fontSize)
    local UI = PrepLayout.UI
    return UI.Panel {
        width = S(size), height = S(size),
        borderRadius = S(size / 2),
        backgroundColor = bg,
        borderWidth = S(3),
        borderColor = border,
        justifyContent = "center", alignItems = "center",
        children = {
            UI.Label {
                text = text,
                fontSize = S(fontSize),
                fontColor = Hex("#ffffff"),
                textStroke = { width = S(3), color = "#141414" },
                textAlign = "center", maxLines = 1,
            },
        },
    }
end

--- 图标底衬方块（无图资源时的占位图形）
---@param S fun(v: number): number
---@param size number
---@param glyph string
---@param color table
---@param fontSize number
---@return any
local function Glyph(S, size, glyph, color, fontSize)
    local UI = PrepLayout.UI
    return UI.Label {
        text = glyph,
        fontSize = S(fontSize),
        fontColor = color,
        textAlign = "center", maxLines = 1,
        width = S(size), height = S(size),
        verticalAlign = "middle",
    }
end

-- ---------------------------------------------------------
-- 一、顶栏（设计稿 y 0..155）
--   金币圈 x 44..90 / 金币数 / 收入
--   弧形托板 x 300..780（y 90..210）
--   星级居中 / 经验 "0/6"
--   菜单三条 x 1020..1075
-- ---------------------------------------------------------
---@param S fun(v: number): number
---@param mock table
---@return any
local function BuildTopBar(S, mock)
    local UI = PrepLayout.UI

    -- 菜单按钮：三条横杠
    local menuBars = UI.Panel {
        position = "absolute", left = S(1020), top = S(140),
        width = S(56), height = S(40),
        flexDirection = "column",
        justifyContent = "space-between",
        alignItems = "flex-end",
        pointerEvents = "auto",
        onClick = function() PrepLayout.OnMenu() end,
        children = {
            UI.Panel { width = S(46), height = S(6), borderRadius = S(3),
                       backgroundColor = Hex("#d8d8d8") },
            UI.Panel { width = S(56), height = S(6), borderRadius = S(3),
                       backgroundColor = Hex("#d8d8d8") },
            UI.Panel { width = S(40), height = S(6), borderRadius = S(3),
                       backgroundColor = Hex("#d8d8d8") },
        },
    }

    return UI.Panel {
        width = "100%", height = S(155),
        backgroundColor = { 0, 0, 0, 0 },
        pointerEvents = "box-none",
        children = {
            -- 弧形托板（顶栏中央的深色梯形托板，实测 y 88..218）
            UI.Panel {
                position = "absolute", left = S(300), top = S(88),
                width = S(480), height = S(130),
                backgroundColor = C.plateBg,
                borderRadiusTopLeft = S(46),
                borderRadiusTopRight = S(46),
                pointerEvents = "none",
            },
            -- 金币圈（实测 x 47..90 / y 126..171）
            UI.Panel {
                position = "absolute", left = S(47), top = S(124),
                width = S(46), height = S(46),
                borderRadius = S(23),
                backgroundColor = Hex("#b98f3b"),
                borderWidth = S(3), borderColor = Hex("#7a5c1e"),
                justifyContent = "center", alignItems = "center",
                pointerEvents = "none",
                children = {
                    UI.Label { text = "金", fontSize = S(23),
                               fontColor = Hex("#fff2c8"), maxLines = 1 },
                },
            },
            -- 金币数
            UI.Label {
                text = tostring(mock.gold), fontSize = S(48),
                fontColor = C.gold,
                textStroke = { width = S(4), color = "#3a2a00" },
                position = "absolute", left = S(102), top = S(118),
                maxLines = 1,
            },
            -- 收入
            UI.Label {
                text = "+" .. tostring(mock.goldIncome), fontSize = S(32),
                fontColor = C.green,
                textStroke = { width = S(3), color = "#1a2a1a" },
                position = "absolute", left = S(160), top = S(130),
                maxLines = 1,
            },
            -- 星级（实测 x 524..554 / y 140..171）
            UI.Label {
                text = "★", fontSize = S(44),
                fontColor = C.gold,
                textStroke = { width = S(3), color = "#3a2a00" },
                position = "absolute", left = S(518), top = S(134),
                maxLines = 1,
            },
            -- 经验（实测 y 194..209）
            UI.Label {
                text = tostring(mock.exp) .. "/" .. tostring(mock.expMax),
                fontSize = S(28),
                fontColor = Hex("#e8e8e8"),
                textStroke = { width = S(3), color = "#141414" },
                position = "absolute", left = S(492), top = S(188),
                maxLines = 1,
            },
            menuBars,
        },
    }
end

-- ---------------------------------------------------------
-- 二、商店卡（设计稿实测：卡 270×426，间距 51，首卡 left 84 / top 330）
--   卡内相对坐标（实测）：
--     名牌      rel y  0..39     灰底黑字
--     头像圆    rel y 40..311    直径 193，居中（rel x 40..233）
--     星标      rel y ≈318
--     描述框    rel y 270..389   深灰底（与头像底部叠压，视觉在头像上层）
--     底部行    rel y 381..425   费用圈 / 羁绊胶囊 / 血量圈
-- ---------------------------------------------------------
local CARD_W = 270
local CARD_H = 426
local CARD_GAP = 51
local CARD_LEFT = 84
local CARD_TOP = 330

---@param S fun(v: number): number
---@param card table
---@return any
local function BuildShopCard(S, card)
    local UI = PrepLayout.UI

    local traitColor = TRAIT_COLORS[card.tag] or { 62, 73, 97, 255 }

    local body = UI.Panel {
        width = S(CARD_W), height = S(CARD_H),
        backgroundColor = C.cardBg,
        borderWidth = S(4),
        borderColor = C.cardBorder,
        borderRadiusTopLeft = S(30),
        borderRadiusTopRight = S(30),
        borderRadiusBottomLeft = S(16),
        borderRadiusBottomRight = S(16),
        pointerEvents = "auto",
        overflow = "hidden",
        children = {
            -- 名牌（rel y 0..43）
            UI.Panel {
                width = "100%", height = S(44),
                backgroundColor = C.bannerBg,
                justifyContent = "center", alignItems = "center",
                children = {
                    UI.Label {
                        text = card.name, fontSize = S(28),
                        fontColor = C.bannerText,
                        textAlign = "center", maxLines = 1,
                        width = "100%", flexShrink = 1,
                    },
                },
            },
            -- 头像圆（rel y 40..311，直径 193，rel x 40）
            UI.Panel {
                position = "absolute", left = S(40), top = S(40),
                width = S(193), height = S(193),
                borderRadius = S(97),
                backgroundColor = C.portraitBg,
                borderWidth = S(3),
                borderColor = Hex("#4a4438"),
                justifyContent = "center", alignItems = "center",
                pointerEvents = "none",
                children = {
                    UI.Label { text = "头像", fontSize = S(28),
                               fontColor = Hex("#3f3a30"), maxLines = 1 },
                },
            },
            -- 描述框（rel y 262..392，宽 234；顶部留出星标位置）
            UI.Panel {
                position = "absolute", left = S(18), top = S(258),
                width = S(234), height = S(134),
                backgroundColor = C.descBg,
                borderRadius = S(8),
                paddingHorizontal = S(10),
                paddingTop = S(10), paddingBottom = S(6),
                justifyContent = "flex-start",
                pointerEvents = "none",
                children = {
                    UI.Label {
                        text = card.desc, fontSize = S(22),
                        fontColor = Hex("#e6e6e6"),
                        textAlign = "center",
                        width = "100%",
                        whiteSpace = "normal", wordBreak = "break-word",
                        maxLines = 3, lineHeight = 1.15,
                        flexShrink = 1,
                    },
                },
            },
            -- 星标（rel y ≈318，居中）
            UI.Label {
                text = "★", fontSize = S(34),
                fontColor = C.gold,
                textStroke = { width = S(3), color = "#3a2a00" },
                position = "absolute", left = S(118), top = S(226),
                maxLines = 1,
            },
            -- 底部行（rel y 381..425）：费用圈 / 羁绊胶囊 / 血量圈
            UI.Panel {
                position = "absolute", left = S(6), top = S(381),
                children = { NumCircle(S, 62, tostring(card.cost),
                                       C.costBg, C.costBorder, 30) },
            },
            UI.Panel {
                position = "absolute", left = S(78), top = S(392),
                width = S(114), height = S(40),
                backgroundColor = traitColor,
                borderRadius = S(20),
                justifyContent = "center", alignItems = "center",
                pointerEvents = "none",
                children = {
                    UI.Label { text = card.tag, fontSize = S(20),
                               height = S(28),
                               fontColor = Hex("#ffffff"),
                               textAlign = "center", maxLines = 1 },
                },
            },
            UI.Panel {
                position = "absolute", left = S(202), top = S(381),
                children = { NumCircle(S, 62, tostring(card.hp),
                                       C.hpBg, C.hpBorder, 30) },
            },
        },
    }

    -- 注册为可拖拽：条目收集到 dragEntries，由 ClientScene 轮询命中
    body.onClick = function() PrepLayout.OnCardTap(card) end
    PrepLayout.dragEntries[#PrepLayout.dragEntries + 1] = {
        widget = body, card = card, source = "shop",
        slotIndex = card.slotIndex,
    }

    return body
end

--- 商店区容器（3 张卡横向排列）
---@param S fun(v: number): number
---@param cards table[]
---@return any
local function BuildShopRow(S, cards)
    local UI = PrepLayout.UI
    local children = {}
    for i, card in ipairs(cards) do
        -- 记录在 MOCK.shopCards 中的原始下标（拖拽落点判定用）
        card.slotIndex = i
        local slot = UI.Panel {
            position = "absolute",
            left = S(CARD_LEFT + (i - 1) * (CARD_W + CARD_GAP)),
            top = S(CARD_TOP),
            backgroundColor = { 0, 0, 0, 0 },
            pointerEvents = "box-none",
            children = { BuildShopCard(S, card) },
        }
        children[#children + 1] = slot
    end
    return UI.Panel {
        width = "100%", height = S(470),
        position = "absolute", left = 0, top = 0,
        pointerEvents = "box-none",
        children = children,
    }
end

-- ---------------------------------------------------------
-- 三、操作栏（设计稿 y 780..955）
--   左：升级按钮（深底金边 x 196..370）
--   中：刷新按钮（红底 x 690..905）
--   右：锁定按钮（绿底 x 940..1052）
-- ---------------------------------------------------------
---@param S fun(v: number): number
---@param mock table
---@return any
local function BuildOpBar(S, mock)
    local UI = PrepLayout.UI

    --- 深色方按钮（升级）
    local function DarkBtn(left, w, icon, value, onClick)
        return UI.Panel {
            position = "absolute", left = S(left), top = S(822),
            width = S(w), height = S(72),
            backgroundColor = C.opBarDark,
            borderWidth = S(4), borderColor = Hex("#5a5a52"),
            borderRadius = S(8),
            flexDirection = "row",
            justifyContent = "center", alignItems = "center",
            gap = S(12),
            pointerEvents = "auto",
            onClick = onClick,
            children = {
                Glyph(S, 44, icon, Hex("#d8d8d8"), 34),
                UI.Label { text = value, fontSize = S(36),
                           fontColor = Hex("#e8e8e8"),
                           textStroke = { width = S(3), color = "#141414" },
                           maxLines = 1 },
            },
        }
    end

    --- 红底按钮（刷新商店）
    local refreshBtn = UI.Panel {
        position = "absolute", left = S(691), top = S(822),
        width = S(214), height = S(72),
        backgroundColor = C.opBtnRed,
        borderWidth = S(4), borderColor = Hex("#3a0d0a"),
        borderRadius = S(8),
        flexDirection = "row",
        justifyContent = "center", alignItems = "center",
        gap = S(12),
        pointerEvents = "auto",
        onClick = function() PrepLayout.OnRefresh() end,
        children = {
            Glyph(S, 44, "↻", Hex("#f0d8a0"), 38),
            UI.Panel {
                width = S(36), height = S(36),
                borderRadius = S(18),
                backgroundColor = Hex("#c8a03c"),
                justifyContent = "center", alignItems = "center",
                children = {
                    UI.Label { text = "金", fontSize = S(19),
                               fontColor = Hex("#5a3a00"), maxLines = 1 },
                },
            },
            UI.Label { text = tostring(mock.shopRefreshCost),
                       fontSize = S(36), fontColor = Hex("#ffffff"),
                       textStroke = { width = S(3), color = "#2a0806" },
                       maxLines = 1 },
        },
    }

    --- 绿底锁定按钮
    local lockBtn = UI.Panel {
        position = "absolute", left = S(943), top = S(822),
        width = S(111), height = S(72),
        backgroundColor = C.opBtnGreen,
        borderWidth = S(4), borderColor = Hex("#22402f"),
        borderRadius = S(8),
        justifyContent = "center", alignItems = "center",
        pointerEvents = "auto",
        onClick = function() PrepLayout.OnLock() end,
        children = {
            Glyph(S, 44, "🔒", Hex("#f0f0e0"), 34),
        },
    }

    -- 容器铺满上半屏（top=0），内部按钮直接用设计稿绝对坐标
    return UI.Panel {
        width = "100%", height = S(955),
        position = "absolute", left = 0, top = 0,
        backgroundColor = { 0, 0, 0, 0 },
        pointerEvents = "box-none",
        children = {
            DarkBtn(197, 162, "★", tostring(mock.buyExpCost),
                    function() PrepLayout.OnBuyExp() end),
            refreshBtn,
            lockBtn,
        },
    }
end

-- ---------------------------------------------------------
-- 四、倒计时木牌 / 准备按钮（设计稿 x 945..1047 / y 1016..1188）
--   可点击：点击后进入战斗阶段
-- ---------------------------------------------------------
---@param S fun(v: number): number
---@param mock table
---@return any
local function BuildTimerPlaque(S, mock)
    local UI = PrepLayout.UI
    -- 实测木牌内芯 x 953..1040 / y 1030..1178；外框略大一圈
    return UI.Panel {
        position = "absolute", left = S(945), top = S(1016),
        width = S(102), height = S(172),
        backgroundColor = Hex("#2a2a2a"),
        borderWidth = S(6), borderColor = Hex("#3a3a3a"),
        borderRadius = S(10),
        justifyContent = "center", alignItems = "center",
        pointerEvents = "auto",
        onClick = function() PrepLayout.OnReady() end,
        children = {
            -- 内芯（装饰，不拦截点击，让点击落到外层木牌上）
            UI.Panel {
                width = S(88), height = S(150),
                backgroundColor = C.wood,
                borderRadius = S(4),
                flexDirection = "column",
                justifyContent = "center", alignItems = "center",
                pointerEvents = "none",
                children = {
                    UI.Label {
                        text = tostring(mock.phaseTimeLeft),
                        fontSize = S(56),
                        fontColor = Hex("#f0e6d0"),
                        textStroke = { width = S(4), color = "#2a1f0a" },
                        textAlign = "center", maxLines = 1,
                    },
                    UI.Label {
                        text = "准备", fontSize = S(24),
                        fontColor = Hex("#f0e6d0"),
                        textStroke = { width = S(3), color = "#2a1f0a" },
                        textAlign = "center", maxLines = 1,
                    },
                },
            },
        },
    }
end

-- ---------------------------------------------------------
-- 五、下半屏：地牢氛围底 + 半透明浮层
--   地牢底   y 955..2400  竖直渐变（上暗下亮，模拟石壁与地面）
--   对手列表 x 0..96       左缘竖排
--   棋盘     x 96..990     2 行 3 列
--   备战区   y 1980..2280  横排
-- ---------------------------------------------------------

--- 虚线空位格
---@param S fun(v: number): number
---@param w number
---@param h number
---@return any
local function DashedSlot(S, w, h)
    local UI = PrepLayout.UI
    local slot = UI.Panel {
        width = S(w), height = S(h),
        backgroundColor = { 0, 0, 0, 0 },
        borderWidth = S(3),
        borderColor = { 150, 170, 190, 110 },
        borderStyle = "dashed",
        borderRadius = S(12),
        pointerEvents = "none",
    }
    return slot
end

--- 棋盘格（有棋子）
---@param S fun(v: number): number
---@param slot table  棋盘格数据
---@param idx integer 格子下标（1..6）
---@return any
local function BoardCard(S, slot, idx)
    local UI = PrepLayout.UI
    local body = UI.Panel {
        width = S(264), height = S(316),
        backgroundColor = { 40, 40, 55, 190 },
        borderWidth = S(4),
        borderColor = { 136, 153, 170, 220 },
        borderRadiusTopLeft = S(120),
        borderRadiusTopRight = S(120),
        borderRadiusBottomLeft = S(14),
        borderRadiusBottomRight = S(14),
        flexDirection = "column",
        alignItems = "center",
        justifyContent = "center",
        pointerEvents = "auto",
        children = {
            UI.Panel {
                width = S(120), height = S(120),
                borderRadius = S(60),
                backgroundColor = { 70, 70, 90, 220 },
                justifyContent = "center", alignItems = "center",
                children = {
                    UI.Label { text = "头", fontSize = S(28),
                               fontColor = Hex("#cccccc"), maxLines = 1 },
                },
            },
            UI.Label { text = slot.name, fontSize = S(24),
                       fontColor = Hex("#ffffff"),
                       textStroke = { width = S(3), color = "#141414" },
                       textAlign = "center", maxLines = 1,
                       marginTop = S(8) },
        },
    }

    -- 注册为可拖拽：棋子可拖到其他棋子处交换，或拖到空位
    PrepLayout.dragEntries[#PrepLayout.dragEntries + 1] = {
        widget = body, card = slot, source = "board", slotIndex = idx,
    }
    return body
end

--- 备战区卡片（半透明）
---@param S fun(v: number): number
---@param card table
---@return any
local function BenchCard(S, card)
    local UI = PrepLayout.UI
    local body = UI.Panel {
        width = S(196), height = S(290),
        backgroundColor = { 40, 38, 30, 215 },
        borderWidth = S(4),
        borderColor = { 136, 119, 68, 230 },
        borderRadiusTopLeft = S(56),
        borderRadiusTopRight = S(56),
        borderRadiusBottomLeft = S(12),
        borderRadiusBottomRight = S(12),
        flexDirection = "column",
        alignItems = "center",
        justifyContent = "space-between",
        paddingVertical = S(12), paddingHorizontal = S(8),
        pointerEvents = "auto",
        children = {
            UI.Label { text = card.name, fontSize = S(22),
                       fontColor = Hex("#f0e6d0"),
                       textAlign = "center", width = "100%",
                       maxLines = 1, flexShrink = 1 },
            UI.Panel {
                width = S(96), height = S(96),
                borderRadius = S(48),
                backgroundColor = { 60, 55, 45, 230 },
                justifyContent = "center", alignItems = "center",
                children = {
                    UI.Label { text = "头", fontSize = S(24),
                               fontColor = Hex("#cccccc"), maxLines = 1 },
                },
            },
            UI.Label { text = card.desc, fontSize = S(17),
                       fontColor = Hex("#cccccc"),
                       width = "100%", textAlign = "center",
                       maxLines = 3, lineHeight = 1.2,
                       flexGrow = 1, flexShrink = 1 },
            UI.Panel {
                flexDirection = "row", gap = S(6),
                justifyContent = "center", alignItems = "center",
                children = {
                    UI.Label { text = "(" .. tostring(card.atk) .. ")",
                               fontSize = S(22),
                               fontColor = Hex("#88cc88"), maxLines = 1 },
                    UI.Label { text = "(" .. tostring(card.hp) .. ")",
                               fontSize = S(22),
                               fontColor = Hex("#ffaa88"), maxLines = 1 },
                },
            },
        },
    }
    body.onClick = function() PrepLayout.OnCardTap(card) end
    PrepLayout.dragEntries[#PrepLayout.dragEntries + 1] = {
        widget = body, card = card, source = "bench",
        slotIndex = card.slotIndex,
    }
    return body
end

--- 创建单个棋盘格（有棋子 → BoardCard，空位 → 虚线框）
--- 抽成独立函数，供初次构建与 RefreshBoard 局部刷新共用
---@param S fun(v: number): number
---@param mock table
---@param idx integer
---@return any
local function MakeBoardCell(S, mock, idx)
    local slot = mock.boardSlots[idx]
    if slot and slot.occupied then
        return BoardCard(S, slot, idx)
    end
    return DashedSlot(S, 264, 316)
end

--- 地牢渐变底（备战/战斗共用）
---@param S fun(v: number): number
---@return any
local function BuildDungeonBg(S)
    local UI = PrepLayout.UI
    return UI.Panel {
        position = "absolute", left = 0, top = 0,
        width = "100%", height = "100%",
        backgroundGradient = {
            type = "linear", direction = "to-bottom",
            from = C.dungeonTop, to = C.dungeonBot,
        },
        pointerEvents = "none",
    }
end

--- 左侧对手列表（备战/战斗共用）
---@param S fun(v: number): number
---@param mock table
---@return any
local function BuildOpponentList(S, mock)
    local UI = PrepLayout.UI
    local oppChildren = {}

    --- 生成一行（自己 / 人机）
    ---@param idx integer 行号（1 = 自己）
    ---@param hp integer
    ---@param isMe boolean
    ---@param isCurrent boolean
    ---@param isDead boolean
    local function MakeRow(idx, hp, isMe, isCurrent, isDead)
        -- 边框优先级：当前对手（红框）> 自己（金框）> 已死亡（灰）> 普通
        local borderCol, borderW
        if isCurrent then
            borderCol, borderW = Hex("#e04040"), S(5)
        elseif isMe then
            borderCol, borderW = Hex("#d8b45a"), S(4)
        elseif isDead then
            borderCol, borderW = { 68, 68, 68, 200 }, S(2)
        else
            borderCol, borderW = { 102, 102, 102, 200 }, S(2)
        end

        local bg
        if isCurrent then
            bg = { 60, 40, 40, 230 }
        elseif isMe then
            bg = { 55, 48, 30, 230 }
        else
            bg = { 30, 35, 45, 200 }
        end

        return UI.Panel {
            width = "100%", flexGrow = 1, flexBasis = 0,
            backgroundColor = bg,
            borderWidth = borderW, borderColor = borderCol,
            borderRadius = S(6),
            flexDirection = "column",
            alignItems = "center", justifyContent = "center",
            children = {
                UI.Label { text = isMe and "我" or tostring(idx),
                           fontSize = S(18),
                           fontColor = isMe and Hex("#ffe08a") or C.gold,
                           maxLines = 1 },
                UI.Label { text = isDead and "☠" or tostring(hp),
                           fontSize = S(20), fontColor = Hex("#ffffff"),
                           maxLines = 1 },
            },
        }
    end

    -- 第 1 行：自己（行号显示「我」）
    oppChildren[#oppChildren + 1] = MakeRow(1, mock.myHp or 0, true, false,
        (mock.myHp or 0) <= 0)

    -- 后续行：人机对手
    for i, op in ipairs(mock.opponents) do
        oppChildren[#oppChildren + 1] = MakeRow(i + 1, op.hp or 0, false,
            op.isCurrent and true or false, op.isDead and true or false)
    end

    return UI.Panel {
        position = "absolute", left = 0, top = S(20),
        width = S(96), height = S(920),
        flexDirection = "column",
        justifyContent = "space-between",
        paddingVertical = S(4), gap = S(4),
        pointerEvents = "box-none",
        children = oppChildren,
    }
end

--- 下半屏整体
---@param S fun(v: number): number
---@param mock table
---@return any
local function BuildLowerHalf(S, mock)
    local UI = PrepLayout.UI
    local children = {}

    -- 地牢渐变底
    children[#children + 1] = BuildDungeonBg(S)

    -- 左侧对手列表
    local oppList = BuildOpponentList(S, mock)
    PrepLayout.oppListRef = oppList
    children[#children + 1] = oppList

    -- 棋盘 2 行 3 列
    local boardRows = {}
    for row = 1, 2 do
        local rowChildren = {}
        for col = 1, 3 do
            local idx = (row - 1) * 3 + col
            local cell = MakeBoardCell(S, mock, idx)
            PrepLayout.boardSlotRefs[idx] = cell
            rowChildren[#rowChildren + 1] = cell
        end
        boardRows[#boardRows + 1] = UI.Panel {
            flexDirection = "row", gap = S(20),
            pointerEvents = "box-none",
            children = rowChildren,
        }
    end
    local boardContainer = UI.Panel {
        position = "absolute", left = S(116), top = S(120),
        width = S(872), height = S(660),
        flexDirection = "column",
        justifyContent = "center", alignItems = "center",
        gap = S(20),
        pointerEvents = "box-none",
        children = boardRows,
    }
    children[#children + 1] = boardContainer
    -- 记录棋盘行容器，供 RefreshBoard 局部刷新
    PrepLayout.boardRowRefs = { boardRows[1], boardRows[2] }

    -- 备战区
    local benchChildren = {}
    for i, card in ipairs(mock.bench) do
        card.slotIndex = i
        local overlap = (i == 1) and 0 or S(-36)
        local w = BenchCard(S, card)
        w:SetStyle({ marginLeft = overlap, zIndex = i })
        benchChildren[#benchChildren + 1] = w
    end
    children[#children + 1] = UI.Panel {
        position = "absolute", left = S(20), top = S(1020),
        width = "100%", height = S(320),
        flexDirection = "row",
        alignItems = "flex-end",
        overflow = "visible",
        pointerEvents = "box-none",
        children = benchChildren,
    }

    -- 购买区域：下半屏棋盘整块区域（设计稿 x 118..960 / y 1022..2286）
    -- 平时隐藏，从商店拖卡时显示绿框 + 「购买区域」提示；在此松手即买卡入备战区
    -- 相对下半屏容器（top = 955）的偏移
    local buyArea = UI.Panel {
        position = "absolute",
        left = S(118), top = S(1022 - 955),
        width = S(960 - 118), height = S(2286 - 1022),
        backgroundColor = { 120, 160, 60, 40 },
        borderWidth = S(3),
        borderColor = { 180, 210, 100, 230 },
        borderRadius = S(6),
        justifyContent = "center", alignItems = "center",
        pointerEvents = "none",
        visible = false,
        children = {
            UI.Label {
                text = "购买区域", fontSize = S(46),
                fontColor = { 235, 240, 225, 235 },
                textStroke = { width = S(4), color = "#2a3320" },
                textAlign = "center", maxLines = 1,
            },
        },
    }
    children[#children + 1] = buyArea
    PrepLayout.buyAreaRef = buyArea

    return UI.Panel {
        position = "absolute", left = 0, top = S(955),
        width = "100%", height = S(1445),
        overflow = "visible",
        pointerEvents = "box-none",
        children = children,
    }
end

-- ============================================================
-- 七、战斗阶段布局
--
-- 结构（按设计稿实测）：
--   顶栏      y 0..190     金币 / 阵容 / 菜单
--   对手名    y 230..290   居中横幅
--   敌方区    y 330..930   2 行 x 3 列
--   我方区    y 1050..1380 2 行 x 3 列
--   底部      y 2280..2400 头像 + 血量
-- 商店区在战斗阶段隐藏。
-- ============================================================

--- 战斗棋子卡（拱形外框 + 头像 + 等级 + 星级 + 左下攻击圈 + 右下血量圈）
--- 返回的 widget 上挂了 _atkLabel / _hpLabel / _deadMark / _root，供战斗播放时更新
---@param S fun(v: number): number
---@param unit table { idx, atk, hp, maxHp, star, level, name? }
---@param isEnemy boolean
---@return any
local function BuildCombatPiece(S, unit, isEnemy)
    local UI = PrepLayout.UI
    -- 我方偏紫、敌方偏蓝（对齐参考图）
    local frameCol = isEnemy and Hex("#7b86b8") or Hex("#b98ac8")
    local isDead = (unit.hp or 0) <= 0

    -- 血量圈（死亡时变灰）
    local hpLabel = UI.Label {
        text = tostring(unit.hp or 0),
        fontSize = S(30),
        fontColor = isDead and Hex("#8a8a8a") or Hex("#ffb0b0"),
        textStroke = { width = S(3), color = "#1a0a0a" },
        maxLines = 1,
    }
    local hpCircle = UI.Panel {
        width = S(62), height = S(62),
        borderRadius = S(31),
        backgroundColor = isDead and { 40, 40, 42, 250 } or { 76, 26, 30, 250 },
        borderWidth = S(4),
        borderColor = isDead and Hex("#5a5a5a") or Hex("#e06a6a"),
        justifyContent = "center", alignItems = "center",
        children = { hpLabel },
    }

    -- 攻击圈
    local atkLabel = UI.Label {
        text = tostring(unit.atk or 0),
        fontSize = S(30),
        fontColor = Hex("#b8f08a"),
        textStroke = { width = S(3), color = "#0a1a0a" },
        maxLines = 1,
    }
    local atkCircle = UI.Panel {
        width = S(62), height = S(62),
        borderRadius = S(31),
        backgroundColor = { 26, 70, 40, 250 },
        borderWidth = S(4),
        borderColor = Hex("#7ed957"),
        justifyContent = "center", alignItems = "center",
        children = { atkLabel },
    }

    -- 星级标记（黄色星，居中偏下）
    local starLabel = UI.Label {
        text = "★" .. tostring(unit.star or 1),
        fontSize = S(28),
        fontColor = Hex("#ffd24d"),
        textStroke = { width = S(4), color = "#3a2a00" },
        position = "absolute", left = S(70), top = S(196),
        maxLines = 1,
    }

    -- 死亡骷髅标记（默认隐藏）
    local deadMark = UI.Label {
        text = "☠",
        fontSize = S(48),
        fontColor = Hex("#e0e0e0"),
        textStroke = { width = S(4), color = "#101010" },
        position = "absolute", left = S(92), top = S(178),
        maxLines = 1,
        visible = isDead,
    }

    -- 等级数字（左上角，带火焰底衬）
    local levelBadge = UI.Panel {
        position = "absolute", left = S(18), top = S(-6),
        width = S(52), height = S(52),
        justifyContent = "center", alignItems = "center",
        pointerEvents = "none",
        children = {
            UI.Label {
                text = "🔥", fontSize = S(46),
                textAlign = "center", maxLines = 1,
                width = S(52), height = S(52),
                verticalAlign = "middle",
            },
            UI.Label {
                text = tostring(unit.level or 1),
                fontSize = S(28),
                fontColor = Hex("#ffffff"),
                textStroke = { width = S(4), color = "#5a1a00" },
                position = "absolute", left = S(16), top = S(10),
                maxLines = 1,
            },
        },
    }

    local root = UI.Panel {
        width = S(240), height = S(258),
        backgroundColor = { 0, 0, 0, 0 },
        flexDirection = "column",
        alignItems = "center",
        children = {
            -- 拱形主体
            UI.Panel {
                width = S(232), height = S(238),
                backgroundColor = isDead and { 32, 30, 40, 235 } or { 46, 42, 62, 235 },
                borderWidth = S(5),
                borderColor = isDead and Hex("#4a4a52") or frameCol,
                borderRadiusTopLeft = S(116),
                borderRadiusTopRight = S(116),
                borderRadiusBottomLeft = S(12),
                borderRadiusBottomRight = S(12),
                justifyContent = "center", alignItems = "center",
                children = {
                    UI.Label { text = unit.name or "头", fontSize = S(26),
                               fontColor = Hex("#d8d4e8"), maxLines = 1 },
                    starLabel,
                    deadMark,
                },
            },
            -- 等级徽标（悬在卡牌左上角）
            levelBadge,
            -- 攻击 / 血量双圈（叠在卡牌下沿）
            UI.Panel {
                flexDirection = "row",
                justifyContent = "space-between",
                alignItems = "center",
                width = S(240),
                marginTop = S(-22),
                pointerEvents = "none",
                children = { atkCircle, hpCircle },
            },
        },
    }

    -- 暴露给播放器更新用
    root._atkLabel = atkLabel
    root._hpLabel = hpLabel
    root._hpCircle = hpCircle
    root._deadMark = deadMark
    return root
end

--- 战斗队伍：2 行 x 3 列
--- 把每个棋子 widget 按 idx 记入 refs，供战斗播放时更新
---@param S fun(v: number): number
---@param team table[]
---@param isEnemy boolean
---@param refs table 输出：idx -> widget
---@return any
local function BuildCombatTeam(S, team, isEnemy, refs)
    local UI = PrepLayout.UI
    local rows = {}
    for row = 1, 2 do
        local rowChildren = {}
        for col = 1, 3 do
            local idx = (row - 1) * 3 + col
            local unit = nil
            for _, u in ipairs(team) do
                if u.idx == idx then unit = u break end
            end
            local cellChildren = {}
            if unit then
                local piece = BuildCombatPiece(S, unit, isEnemy)
                refs[idx] = piece
                cellChildren[1] = piece
            end
            rowChildren[#rowChildren + 1] = UI.Panel {
                width = S(240), height = S(258),
                alignItems = "center", justifyContent = "center",
                pointerEvents = "none",
                children = cellChildren,
            }
        end
        rows[#rows + 1] = UI.Panel {
            flexDirection = "row",
            justifyContent = "center",
            gap = S(38),
            pointerEvents = "box-none",
            children = rowChildren,
        }
    end
    return UI.Panel {
        flexDirection = "column",
        alignItems = "center",
        gap = S(30),
        pointerEvents = "box-none",
        children = rows,
    }
end

--- 上半屏的敌方棋子区（战斗态显示，2 行 x 3 列，与我方对称）
--- 点准备后：上半屏商店收起，改显示这一区
---@param S fun(v: number): number
---@param mock table
---@return any
local function BuildEnemyArea(S, mock)
    local UI = PrepLayout.UI
    local combat = mock.combatData or {}

    PrepLayout.enemyRefs = {}
    local teamPanel = BuildCombatTeam(S, combat.enemyTeam or {}, true,
        PrepLayout.enemyRefs)
    PrepLayout.enemyTeamPanelRef = teamPanel

    -- 对手名横幅
    local nameBanner = UI.Panel {
        width = "100%", height = S(62),
        justifyContent = "center", alignItems = "center",
        pointerEvents = "none",
        children = {
            UI.Panel {
                paddingHorizontal = S(30), paddingVertical = S(8),
                backgroundColor = { 30, 32, 28, 230 },
                borderRadius = S(6),
                children = {
                    UI.Label { text = combat.opponentName or "对手",
                               fontSize = S(26),
                               fontColor = Hex("#e8e4d8"), maxLines = 1 },
                },
            },
        },
    }

    return UI.Panel {
        position = "absolute", left = 0, top = 0,
        width = "100%", height = S(955),
        backgroundColor = C.panelBg,
        borderWidth = S(6),
        borderColor = C.panelBorder,
        pointerEvents = "box-none",
        visible = false,      -- 默认隐藏，点准备后显示
        flexDirection = "column",
        alignItems = "center",
        justifyContent = "center",
        gap = S(30),
        children = { nameBanner, teamPanel },
    }
end

-- ============================================================
-- 六、对外接口
-- ============================================================

PrepLayout.UI = nil
PrepLayout.S = nil
PrepLayout.boardSlotRefs = {}
PrepLayout.boardRowRefs = nil     -- { 行1容器, 行2容器 }，供 RefreshBoard 局部刷新
PrepLayout.dragEntries = {}      -- 可拖拽条目 { widget, card, source, slotIndex }
PrepLayout.shopAreaRef = nil     -- 顶部商店行（备战区卡拖到此处 = 卖卡）
PrepLayout.buyAreaRef = nil      -- 下半屏购买区域（商店卡拖到此处 = 买卡）
PrepLayout.benchAreaRef = nil
PrepLayout.lowerRef = nil
PrepLayout.combatRefs = nil       -- { my = {idx->widget}, enemy = {idx->widget} }
PrepLayout.combatTeamRefs = nil   -- { my = 队伍容器, enemy = 队伍容器 }
PrepLayout.combatFieldRef = nil   -- 战场容器
PrepLayout.prepPanelRef = nil     -- 备战态上半屏（顶栏+商店+操作栏）
PrepLayout.enemyAreaRef = nil     -- 战斗态上半屏（敌方棋子）
PrepLayout.enemyRefs = nil        -- 敌方棋子 widget { idx -> widget }
PrepLayout.oppListRef = nil       -- 左侧对手列表容器
PrepLayout.upperRef = nil         -- 上半屏容器（备战/战斗共用）
PrepLayout.floatLayerRef = nil    -- 伤害飘字层（最上层）
PrepLayout.dragEnabled = true     -- 战斗中禁用拖拽

-- 回调钩子（由 ClientScene 注入）
PrepLayout.OnCardTap = function(_) end
PrepLayout.OnMenu = function() end
PrepLayout.OnBuyExp = function() end
PrepLayout.OnRefresh = function() end
PrepLayout.OnLock = function() end
PrepLayout.OnReady = function() end   -- 点击「准备」→ 进入战斗

--- 生成「设计稿像素 → UI base 像素」换算函数（按短边等比）
---@return fun(v: number): number
local function MakeScaler()
    local shortSide = math.min(PrepLayout.UI.GetWidth(), PrepLayout.UI.GetHeight())
    return function(v)
        return v * shortSide / SPEC_SHORT
    end
end

--- 构建整个备战界面
---@param mock table
---@return any
function PrepLayout.Build(mock)
    local UI = PrepLayout.UI
    local S = MakeScaler()

    PrepLayout.boardSlotRefs = {}
    PrepLayout.dragEntries = {}
    PrepLayout.S = S

    -- 备战态上半屏：顶栏 + 商店 + 操作栏
    local prepChildren = {
        BuildTopBar(S, mock),
        BuildShopRow(S, mock.shopCards),
        BuildOpBar(S, mock),
    }
    PrepLayout.prepPanelRef = UI.Panel {
        position = "absolute", left = 0, top = 0,
        width = "100%", height = S(955),
        backgroundColor = C.panelBg,
        borderWidth = S(6),
        borderColor = C.panelBorder,
        pointerEvents = "box-none",
        children = prepChildren,
    }

    -- 战斗态上半屏：敌方棋子（默认隐藏）
    PrepLayout.enemyAreaRef = BuildEnemyArea(S, mock)

    -- 上半屏容器（备战/战斗共用，只做定位；底色/边框由两个子面板各自负责，
    -- 否则战斗态收起商店后仍会残留石质底色与边框）
    local panel = UI.Panel {
        position = "absolute", left = 0, top = 0,
        width = "100%", height = S(955),
        backgroundColor = { 0, 0, 0, 0 },
        pointerEvents = "box-none",
        children = {
            PrepLayout.prepPanelRef,
            PrepLayout.enemyAreaRef,
        },
    }

    -- 商店区引用（用于拖拽落点判定，覆盖卡片实际范围 y 330..756）
    PrepLayout.shopAreaRef = UI.Panel {
        position = "absolute", left = 0, top = S(CARD_TOP),
        width = "100%", height = S(CARD_H),
        pointerEvents = "none",
        backgroundColor = { 0, 0, 0, 0 },
    }

    local lower = BuildLowerHalf(S, mock)
    PrepLayout.lowerRef = lower
    PrepLayout.upperRef = panel   -- 上半屏容器（备战/战斗共用）

    -- 伤害飘字层：浮在最上层，战斗时在此弹伤害数字
    PrepLayout.floatLayerRef = UI.Panel {
        position = "absolute", left = 0, top = 0,
        width = "100%", height = "100%",
        backgroundColor = { 0, 0, 0, 0 },
        pointerEvents = "none",
        overflow = "visible",
        zIndex = 900,
    }

    local root = UI.Panel {
        width = "100%", height = "100%",
        backgroundColor = Hex("#0e1014"),
        children = {
            lower,
            panel,
            PrepLayout.shopAreaRef,
            BuildTimerPlaque(S, mock),
            PrepLayout.floatLayerRef,
        },
    }

    return root
end

--- 切换备战 / 战斗显示（同一套布局，只切可见性，不重建 UI 树）
---@param inCombat boolean
function PrepLayout.SetCombatMode(inCombat)
    if PrepLayout.prepPanelRef then
        PrepLayout.prepPanelRef:SetVisible(not inCombat)
    end
    if PrepLayout.enemyAreaRef then
        PrepLayout.enemyAreaRef:SetVisible(inCombat)
    end
    -- 战斗中禁用拖拽（棋子不能操作）
    PrepLayout.dragEnabled = not inCombat
end

--- 重建敌方棋子区（换对手时调用，只重建这一小块）
---@param mock table
function PrepLayout.RefreshEnemyArea(mock)
    local S = PrepLayout.S
    local UI = PrepLayout.UI
    if not S or not UI or not PrepLayout.enemyAreaRef then return end

    local combat = mock.combatData or {}
    PrepLayout.enemyRefs = {}
    local teamPanel = BuildCombatTeam(S, combat.enemyTeam or {}, true,
        PrepLayout.enemyRefs)

    -- 更新对手名
    local banner = PrepLayout.enemyAreaRef:GetChildAt(1)
    if banner then
        local pill = banner:GetChildAt(1)
        if pill then
            local lbl = pill:GetChildAt(1)
            if lbl and lbl.SetText then
                lbl:SetText(combat.opponentName or "对手")
            end
        end
    end

    -- 替换队伍面板（第 2 个子节点）
    local old = PrepLayout.enemyAreaRef:GetChildAt(2)
    if old then PrepLayout.enemyAreaRef:RemoveChild(old) end
    PrepLayout.enemyAreaRef:AddChild(teamPanel)
end

--- 重建左侧对手列表（血量/高亮变化时调用，只重建这一小块）
---@param mock table
function PrepLayout.RefreshOpponentList(mock)
    local S = PrepLayout.S
    local UI = PrepLayout.UI
    local old = PrepLayout.oppListRef
    if not S or not UI or not old or not old.parent then return end

    local fresh = BuildOpponentList(S, mock)
    PrepLayout.oppListRef = fresh
    old.parent:RemoveChild(old)
    old.parent:AddChild(fresh)
end

--- 局部刷新棋盘（只重建 6 个格子，不动商店/顶栏/操作栏/备战区）
--- 用于移动棋子后更新棋盘，避免整树重建导致的闪烁
---@param mock table
function PrepLayout.RefreshBoard(mock)
    local S = PrepLayout.S
    local UI = PrepLayout.UI
    if not S or not UI or not PrepLayout.boardRowRefs then return end

    -- 从 dragEntries 中摘掉旧的棋盘条目（source == "board"）
    local kept = {}
    for _, e in ipairs(PrepLayout.dragEntries) do
        if e.source ~= "board" then kept[#kept + 1] = e end
    end
    PrepLayout.dragEntries = kept

    PrepLayout.boardSlotRefs = {}

    for row = 1, 2 do
        local rowPanel = PrepLayout.boardRowRefs[row]
        if rowPanel then
            rowPanel:ClearChildren()
            for col = 1, 3 do
                local idx = (row - 1) * 3 + col
                local cell = MakeBoardCell(S, mock, idx)
                PrepLayout.boardSlotRefs[idx] = cell
                rowPanel:AddChild(cell)
            end
        end
    end
end


return PrepLayout
