-- ============================================================
-- shared/Theme.lua：统一 UI 主题
--
-- 说明：Client.lua 通过 require("shared.Theme") 使用本模块。
-- 大厅 / 房间列表 / 房间内三个界面都内嵌在 Client.lua 里，
-- 各玩法 ClientScene 通过 SetDependencies 注入拿到 Theme。
-- 颜色集中在这里，新增玩法直接 require 本文件即可。
-- ============================================================

local Theme = {}

-- ============ 调色板（RGBA 0-255）============
Theme.COLORS = {
    bgPanel     = { 46, 40, 34, 240 },
    bgCard      = { 62, 54, 46, 200 },
    border      = { 200, 169, 107, 180 },
    btnPrimary  = { 184, 147, 79, 255 },
    btnSuccess  = { 92, 143, 80, 255 },
    btnDanger   = { 160, 64, 64, 255 },
    btnSecond   = { 62, 54, 46, 255 },
}

-- ============ 文本色（十六进制）============
Theme.HEX = {
    info = "#88ccff",
}

-- ============ 按钮背景色 ============
function Theme.ButtonBg(variant)
    if variant == "primary" then return Theme.COLORS.btnPrimary end
    if variant == "success" then return Theme.COLORS.btnSuccess end
    if variant == "danger"  then return Theme.COLORS.btnDanger end
    return Theme.COLORS.btnSecond
end

return Theme
