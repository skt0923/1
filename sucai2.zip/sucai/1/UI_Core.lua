-- ============================================================
-- UI_Core.lua：UI 面板共享基础设施
--
-- 职责：Modal 栈管理 / 通用控件（QLabel、QButton）/ 通用对话框（Confirm）
--       / 物品详情布局（BuildDetailLayout，背包与市场共用）。
--       另有少量保留备用的接口（见各函数 @deprecated 标记）。
--
-- 依赖：Shared。**不 require UI_Items / UI_System / UI_Trade**（避免循环）。
--
-- 🔴 关键设计：四个 UI 文件写入**同一张 Panels 表**。
--    UI_Core 先建表并 return；UI_Items / UI_System / UI_Trade 通过 local Panels = Core
--    拿到同一张表，因此跨域调用（背包→自动分解、背包→上架、自动战斗→市场）
--    在运行时按 Panels.X 解析，既满足「子文件不互相 require」，又能互相调用。
--    （由 Client.lua 统一 require 四个文件拉起。）
--
-- 注入值通过 Panels.shared 传递（稳定引用，运行时填充）：
--    shared.UI / shared.ctx / shared.statProvider
-- ============================================================
local Shared = require("Shared")

-- 本文件建表；UI_Items / UI_System 复用同一张
local Panels = {}

-- 注入值的稳定容器（UI_Items / UI_System 持有引用，Init 时填充）
Panels.shared = { UI = nil, ctx = nil, statProvider = nil, skillStacksProvider = nil }

--- 原神风格主题色（U3）
--- 🔴 全部面板的配色都应从这里取，不要在各处硬编码 rgba。
---    当前值基于原神 UI 的近似色（暖棕黑底 + 淡金边 + 米白字）。
--- ⚠️ 值类型必须是「记录」而非 number[]：库的 RGBAColor 是
---    {[1]:number,[2]:number,[3]:number,[4]:number?}，变长数组不被视为兼容，
---    传给 backgroundColor 等字段会报 param-type-mismatch。
---@type table<string, {[1]: integer, [2]: integer, [3]: integer, [4]: integer}>
Panels.THEME = {
    -- 背景
    bgPanel     = { 46, 40, 34, 240 },      -- 面板底：暖棕黑，半透明
    bgPanelDeep = { 32, 28, 24, 245 },      -- 深底：标题栏 / 输入框
    bgCard      = { 62, 54, 46, 200 },      -- 卡片
    bgCardHi    = { 88, 74, 56, 220 },      -- 高亮卡片

    -- 边框
    border      = { 200, 169, 107, 180 },   -- 浅金棕
    borderDim   = { 120, 100, 70, 100 },    -- 暗金

    -- 文字
    textPrimary = { 240, 230, 208, 255 },   -- 暖米白
    textSecond  = { 176, 160, 128, 255 },   -- 米棕
    textDim     = { 130, 118, 98, 255 },    -- 暗棕

    -- 按钮
    btnPrimary  = { 184, 147, 79, 255 },    -- 金棕（主色）
    btnSuccess  = { 92, 143, 80, 255 },     -- 暗绿
    btnDanger   = { 160, 64, 64, 255 },     -- 暗红
    btnSecond   = { 62, 54, 46, 255 },      -- 深棕灰
}

--- THEME 的十六进制字符串版本。
---
--- 🔴 用途：**混合条件表达式**专用。例如
---      `Shared.HexRGB(broken and "#ff6666" or "#cccccc")`
---    其中红是语义色（不能动）、灰是装饰色（要改），但 HexRGB 只接受字符串，
---    所以不能直接换成 THEME 的数组。此时用本表的字符串版本。
--- ⚠️ 值与 THEME 一一对应，改 THEME 时必须同步这里。
---@type table<string, string>
Panels.THEME_HEX = {
    textPrimary = "#f0e6d0",   -- 对应 textPrimary { 240, 230, 208 }
    textSecond  = "#b0a080",   -- 对应 textSecond  { 176, 160, 128 }
    textDim     = "#827662",   -- 对应 textDim     { 130, 118,  98 }
}


-- 属性计算函数注入点。
-- 角色面板要显示最终属性，但属性计算属于 Battle_Combat，UI 层不能反向依赖它，
-- 因此由 Client 在启动时通过 Panels.SetStatProvider(Combat.ComputeStats) 注入。
--- 由 Client 注入属性计算实现（UI 层不反向依赖 Battle）
---@param fn fun(equipment: table): table
function Panels.SetStatProvider(fn)
    Panels.shared.statProvider = fn
end

--- 由 Client 注入「全身技能层数统计」实现（UI 层不反向依赖 Battle）。
--- 签名与 Skills.GetStacks 一致：fun(equipment) -> table<skillId, 层数>
---@param fn fun(equipment: table): table
function Panels.SetSkillStacksProvider(fn)
    Panels.shared.skillStacksProvider = fn
end

-- ============================================================
-- 六个功能面板
-- 背包 / 角色 / 市场 / 邮箱 / 强化锻造重铸 / 自动战斗
-- 使用 urhox-libs/UI，Modal 承载，关闭按钮由 Modal 自己管理
-- ============================================================
local UI_ = nil

--- 由 Client.lua 注入
---@type table|nil
local ctx_ = nil

---@param ctx table {
---   sendMarket: fun(payload: table),
---   claimMail: fun(mailId: string),
---   requestAd: fun(rewardType: string),
---   useSummonScroll: fun(scrollType: string),
---   requestMailPage: fun(page: integer),
---   requestRespawn: fun(),
---   requestLevelUp: fun(),
---   requestLevelDown: fun(),
---   bankDeposit: fun(amount: integer, term: integer),
---   bankWithdraw: fun(index: integer),
---   bankStateRequest: fun(),
---   applySettings: fun(),
---   forceSync: fun(),
---   appendPendingListing: fun(pl: table),
---   requestFlush: fun(onAck: fun(ok: boolean)|nil),
---   getPlayerPos: fun(): number|nil, number|nil,
---   flushThenSend: fun(eventName: string, payload: table|nil, onDone: fun(ok: boolean)|nil),
---   flushOnly: fun(onDone: fun(ok: boolean)|nil),
---   queryServerInfo: fun(),   【调试】请求服务器玩家列表
---   getServerInfo: fun(): table|nil,  【调试】读取上次查询结果
--- }
function Panels.Init(ctx)
    ctx_ = ctx
    UI_ = require("urhox-libs/UI")
    Panels.shared.ctx = ctx
    Panels.shared.UI = UI_
end

---@type Modal|nil
local current_ = nil
--- 当前打开的是哪个面板（"inventory" / "market" / "mail" ...）
---@type string|nil
local currentId_ = nil

--- 关闭当前面板
---
--- ⚠️ 必须「先置 nil，再 Close」：
---    Modal:Close() 会同步触发 onClose，而 StackedModal 的 onClose 里有
---    「if current_ == self then 恢复到父面板」的判定。
---    若先 Close 再置 nil，此刻 current_ 还是自己 → onClose 把 current_ 改成父面板，
---    紧接着那句 current_ = nil 又把它抹掉 —— 父面板从此失联（开着却关不掉、
---    刷新不生效、死亡后 UI 冻结）。
function Panels.CloseCurrent()
    local m = current_
    current_ = nil
    currentId_ = nil
    -- ⚠️ 沿父链级联关闭：OpenStackedModal 打开的叠加面板不会关掉父级，
    --    所以父级仍然挂在 widget 树上、仍然在渲染。若只关当前这一个，
    --    父面板就会「留在屏幕上但没人跟踪」：
    --      背包 → 物品详情（叠加）→ 分解确认框（BuildDialog 里 CloseCurrent）
    --      → 确认后 OpenInventory 又开一层
    --    结果是旧的「背包」面板一直留在最底层，它的像素会在重绘时冒出来，
    --    看起来像「分解掉的装备图标又复活了」，点它也没反应（不在最上层，收不到点击），
    --    只有关掉背包再重开（再走一次 CloseCurrent）才会消失。
    while m do
        local parent = m.parentModal_
        m.parentModal_ = nil
        m:Close()
        m = parent
    end
    Shared.UIState.modalOpen = false
end

--- 当前是否有面板开着
-- @deprecated 当前无调用，通用查询接口，保留备用
---@return boolean
function Panels.IsOpen() return current_ ~= nil end

--- 当前打开的面板 id（未打开时为 nil）
---@return string|nil
function Panels.GetCurrentId() return currentId_ end

-- ⚠️ current_ / currentId_ 是本文件的 local，UI_Items / UI_System 里
--    直接写 `current_ = ...` 会静默创建**全局变量**，导致本文件的栈指针
--    永远清不掉（Panel 开了却关不掉、死亡后角色被 UI 冻结）。
--    所有跨文件访问必须走下面这两个访问器。
---@return Modal|nil
function Panels.GetCurrentModal() return current_ end

---@param modal Modal|nil
---@param id string|nil
function Panels.SetCurrentModal(modal, id)
    current_ = modal
    currentId_ = id
end

--- 若指定面板正开着，则重新构建它（服务器推新数据时用）
---@param id string
---@param rebuild fun()
function Panels.RefreshIfOpen(id, rebuild)
    if currentId_ ~= id then return end
    -- 🔴 叠加面板（确认框 / 物品详情）在顶时，不要重建底下的父面板。
    --
    -- 栈式弹窗会保留父面板的 id（见 OpenStackedModal），所以「角色 → 升级确认框」
    -- 期间 currentId_ 仍是 "character"，服务端一推 InvSync 就会重建角色面板；
    -- 而重建走 OpenModal → CloseCurrent 的**级联关闭**，会把玩家正在操作的
    -- 确认框一起关掉。这里直接跳过，等弹窗关掉后自然恢复刷新。
    if current_ and current_.parentModal_ ~= nil then return end
    rebuild()
end

-- ============ 通用小工具 ============
---@param text string
---@param color string|nil
---@param size? integer
---@return Label
local function QLabel(text, color, size)
    return UI_.Label {
        text = text,
        fontSize = size or 12,
        fontColor = Shared.HexRGB(color or "#dddddd"),
        maxLines = 1,
    }
end

---@param label string
---@param onClick fun()
---@param variant? string
---@return Button
local function QButton(label, onClick, variant)
    -- 从 variant 映射到主题色，覆盖 UI 库默认的冷色系。
    -- ⚠️ Button 内部逻辑（Button.lua:314-321）：props.backgroundColor **优先于**
    --    variant 主题色。所以显式传 backgroundColor 即可覆盖，variant 仍保留
    --    （供 hover/pressed 的变体色计算参考）。
    local bg = Panels.THEME.btnSecond
    if variant == "primary"     then bg = Panels.THEME.btnPrimary
    elseif variant == "success" then bg = Panels.THEME.btnSuccess
    elseif variant == "danger"  then bg = Panels.THEME.btnDanger
    end

    return UI_.Button {
        text = label,
        fontSize = 13,
        height = 40,
        paddingHorizontal = 16,
        variant = variant or "secondary",
        -- 原神风格暖棕系配色
        backgroundColor = bg,
        -- 圆角：40 高 → 半径 20 = 胶囊形（原神按钮形态）
        borderRadius = 20,
        -- 描边：浅金棕（原神特征）。
        -- ⚠️ Button.lua:559 说明「border 必须通过显式 borderColor 才启用」，
        --    所以只给 borderWidth 而不给 borderColor 是不生效的。
        borderWidth = 1,
        borderColor = Panels.THEME.border,
        onClick = function() onClick() end,
    }
end

--- 主题化按钮工厂：带任意 props 的按钮（width/height/position/... 全支持）。
--- 与 QButton 的区别：
---   QButton    = 「无 props 的简单按钮」（只有 label/onClick/variant）
---   Panels.Btn = 「带任意 props 的按钮」，自动补主题色 + 描边
---
--- 用途：把各 UI 文件里的 `S.UI.Button { ... }` 直接构造换成 Panels.Btn { ... }。
--- ⚠️ 注意 S.UI 是 Core.shared.UI（运行时填充），与 UI_ 指向同一个库，所以
---    Panels.Btn 与 S.UI.Button 构造出的控件类型完全一致，只是多了主题色。
--- 调用方显式传入的 backgroundColor / borderColor 优先（不被覆盖）。
---@param props table
---@return Button
function Panels.Btn(props)
    local m = {}
    for k, v in pairs(props) do m[k] = v end

    local variant = m.variant or "secondary"
    local bg = Panels.THEME.btnSecond
    if variant == "primary"     then bg = Panels.THEME.btnPrimary
    elseif variant == "success" then bg = Panels.THEME.btnSuccess
    elseif variant == "danger"  then bg = Panels.THEME.btnDanger
    end

    m.backgroundColor = m.backgroundColor or bg
    m.borderWidth     = m.borderWidth     or 1
    m.borderColor     = m.borderColor     or Panels.THEME.border
    return UI_.Button(m)
end

--- 打开一个 Modal（自动处理互斥）
---@param id string 面板标识
---@param title string
---@param size string
---@param onClose? fun()
---@return Modal
---@param id string
---@param title string
---@param size string
---@param onClose? fun()
---@param props? table 额外透传给 UI_.Modal 的 props。
---       常用：headerContentGap（标题栏到内容的间距，默认 16）、
---             contentPadding（内容区内部 padding）。
---       ⚠️ 不会覆盖 title / size / onClose 三个核心字段。
local function OpenModal(id, title, size, onClose, props)
    -- 🔴 同一个面板重复打开 → **原地复用，不关不建**。
    --
    -- 背景：市场 / 钱庄 / 邮箱 / 设置都是「打开面板 → 请求服务端 → 回包后
    -- RefreshIfOpen 重建面板」的模式。若每次重建都「关旧 + 建新」就会闪一下：
    --   · Modal:Close() 把 animProgress_ 置 0 → Render 立刻 return（面板瞬隐）
    --   · 新 Modal 从 animProgress_ = 0 淡入（约 0.125 秒）
    -- 背包 / 角色 / 强化不重建面板，所以没这个问题 —— 与现象一致。
    --
    -- 复用当前 Modal 并只替换内容：面板从未关闭、动画进度始终为 1，
    -- 重建因此是「无感」的，也顺带避免重复 PushOverlay 造成叠层。
    -- ⚠️ 必须同时要求 current_ 是**根面板**（parentModal_ == nil）：
    --    OpenStackedModal 会故意沿用父面板的 id（currentId_ = parentId），
    --    否则「背包 → 物品详情」这类叠加面板会被误判成同一个面板而被复用，
    --    把详情的内容清掉、栈关系也乱掉。
    if current_ and currentId_ == id and current_.parentModal_ == nil then
        local modal = current_
        modal:SetTitle(title)
        modal:SetSize(size)
        modal:ClearContent()
        -- footer 由调用方在 AddContent 之后重设。这里先清掉旧的，
        -- 否则重建后可能残留上一份按钮。
        modal:SetFooter(nil)
        Shared.UIState.modalOpen = true
        return modal
    end

    Panels.CloseCurrent()
    -- 先铺额外 props，再写核心字段 —— 保证调用方传的 props
    -- 无法覆盖 title / size / onClose（否则会破坏面板栈的状态维护）。
    local modalProps = {}
    if type(props) == "table" then
        for k, v in pairs(props) do modalProps[k] = v end
    end
    -- 原神风格：暖棕黑底 + 圆角 + 淡金描边。
    -- ⚠️ Modal.lua 确认支持这三个 props（borderColor/borderWidth/borderRadius，
    --    见 Modal.lua:251/270/274）。放在 title/size 赋值之前，
    --    这样调用方通过 props 传入的同名字段仍可覆盖。
    modalProps.backgroundColor = Panels.THEME.bgPanel
    modalProps.borderRadius    = 12
    modalProps.borderWidth     = 1
    modalProps.borderColor     = Panels.THEME.border

    modalProps.title = title
    modalProps.size = size
    modalProps.onClose = function(self)
        if current_ == self then
            current_ = nil
            currentId_ = nil
        end
        Shared.UIState.modalOpen = false
        if onClose then onClose() end
    end

    local modal = UI_.Modal(modalProps)
    current_ = modal
    currentId_ = id
    Shared.UIState.modalOpen = true
    return modal
end

--- 打开一个叠加在当前 Modal 之上的 Modal（不关闭父级）。
--- 用于「物品详情 → 技能详情」「强化面板 → 重铸锁定面板」这类父子关系：
--- 子面板关闭后自动回退到父面板，而不是把玩家丢回游戏。
---@param title string
---@param size string
---@return Modal
local function OpenStackedModal(title, size)
    local parentModal = current_
    local parentId = currentId_

    local modal = UI_.Modal {
        title = title,
        size = size,
        onClose = function(self)
            if current_ == self then
                current_ = parentModal
                currentId_ = parentId
                Shared.UIState.modalOpen = (parentModal ~= nil)
            end
        end,
    }
    -- 父链：供 Panels.CloseCurrent 级联关闭用（子面板自己关时仍走上面的 onClose 回退父级）
    modal.parentModal_ = parentModal
    current_ = modal
    -- ⚠️ currentId_ 保留父 id（不再拼 "stacked_"）：
    --    RefreshIfOpen(id, ...) 靠它判断「当前在哪个面板体系里」。
    --    栈式 Modal 打开时父面板仍然「活着」，服务端推数据要能刷新到父面板。
    currentId_ = parentId
    Shared.UIState.modalOpen = true
    return modal
end
--- 新版详情布局：
---   对比模式：顶部两卡并排（卡内左右分栏）+ 中部 4 列 + 底部按钮
---   单件模式：顶部单卡 + 中部 2 列 + 底部按钮
---@param item table
---@param compareItem table|nil
---@return Panel
function Panels.BuildDetailLayout(item, compareItem)
    local function Card(it, titleOrNil, titleColor)
        local isUnid = it.identified == false
        -- ⚠️ nameColor 后续会传给 Shared.HexRGB(...)，所以这里必须是**字符串**，
        --    用 THEME_HEX 而非 THEME（数组会命中 HexRGB 的 type 检查而返回白色）。
        local nameColor = Shared.QUALITY_COLORS[it.quality] or Panels.THEME_HEX.textPrimary
        local dur = math.floor(it.durability or 0)
        local durColor = dur <= 0 and "#ff4444" or (dur <= 20 and "#ffcc44" or "#aabbcc")
        local reqLv = it.requiredLevel or 1

        -- 基础词条
        local specList = Shared.SLOT_SPEC[it.slot] or {}
        local specCount = #specList
        local specChildren = {}
        if isUnid then
            table.insert(specChildren, UI_.Label {
                text = "未鉴定", fontSize = 10, fontColor = Shared.HexRGB("#667788"),
            })
        else
            local shown = 0
            for i, b in ipairs(it.bonuses or {}) do
                if i > specCount then break end
                local def = Shared.MOD_DEFS[b.modId]
                if def then
                    local v = b.value * (1 + (it.enhanceLevel or 0) * 0.02)
                    local txt = (def.type == "percent")
                        and string.format("%s +%.2f%%", def.name, v * 100)
                        or string.format("%s +%d", def.name, math.floor(v))
                    table.insert(specChildren, UI_.Label {
                        text = txt, fontSize = 10, fontColor = Shared.HexRGB("#9fd8ff"),
                    })
                    shown = shown + 1
                end
            end
            if shown == 0 then
                table.insert(specChildren, UI_.Label {
                    text = "无", fontSize = 10, fontColor = Panels.THEME.textDim,
                })
            end
        end

        -- 左栏（图标 / 名称 / 摘要）
        local leftChildren = {
            UI_.Label {
                text = (Shared.QUALITY_NAMES[it.quality] or "") .. (it.slotName or ""),
                fontSize = 14, fontColor = Shared.HexRGB(nameColor),
            },
            UI_.Panel {
                flexDirection = "row", alignItems = "center", gap = 6,
                children = {
                    UI_.Label { text = it.icon or "?", fontSize = 28 },
                    UI_.Label {
                        text = string.format("等级 %d · 强化 +%d/%d",
                            it.itemLevel or 1, it.enhanceLevel or 0, it.maxEnhance or 0),
                        fontSize = 10, fontColor = Shared.HexRGB(durColor),
                    },
                },
            },
            UI_.Label {
                text = string.format("耐久 %d · 穿戴需 Lv.%d", dur, reqLv),
                fontSize = 10, fontColor = Shared.HexRGB(durColor),
            },
        }

        -- 天赋点数（按品质查表）
        -- ⚠️ 走 pcall：BD_Tree 若加载失败（或未来被裁掉）不能让详情布局挂掉。
        do
            local okBD, BD = pcall(require, "BD_Tree")
            local bdPoints = 0
            if okBD and BD and BD.QUALITY_POINTS then
                bdPoints = BD.QUALITY_POINTS[it.quality] or 0
            end
            if bdPoints > 0 then
                table.insert(leftChildren, UI_.Label {
                    text = string.format("天赋点数 +%d", bdPoints),
                    fontSize = 10, fontColor = Shared.HexRGB("#aaffcc"),
                })
            end
        end

        local cardChildren = {}
        if titleOrNil then
            table.insert(cardChildren, UI_.Label {
                text = titleOrNil, fontSize = 11, fontColor = Shared.HexRGB(titleColor),
            })
        end
        table.insert(cardChildren, UI_.Panel {
            flexDirection = "row", gap = 10,
            children = {
                UI_.Panel {
                    flexDirection = "column", gap = 4,
                    flexGrow = 1, flexBasis = 0,
                    children = leftChildren,
                },
                UI_.Panel {
                    flexDirection = "column", gap = 2,
                    width = 130,
                    children = {
                        UI_.Label { text = "基础词条", fontSize = 10,
                            fontColor = Shared.HexRGB("#ffcc66") },
                        table.unpack(specChildren),
                    },
                },
            },
        })

        return UI_.Panel {
            flexDirection = "column", gap = 6,
            flexGrow = 1, flexBasis = 0,
            backgroundColor = Panels.THEME.bgCard,
            borderRadius = 8,
            paddingHorizontal = 10, paddingVertical = 8,
            children = cardChildren,
        }
    end

    --- 词条列
    local function BonusColumn(it, kind)  -- kind = "equip" | "skill"
        local children = {}
        if kind == "equip" then
            table.insert(children, UI_.Label { text = "装备词条", fontSize = 11,
                fontColor = Shared.HexRGB("#ffcc66") })
            local isUnid = it.identified == false
            if isUnid then
                table.insert(children, UI_.Label { text = "未鉴定", fontSize = 10,
                    fontColor = Shared.HexRGB("#667788") })
            else
                local specCount = #(Shared.SLOT_SPEC[it.slot] or {})
                local shown = 0
                for i, b in ipairs(it.bonuses or {}) do
                    if i > specCount then
                        local def = Shared.MOD_DEFS[b.modId]
                        if def then
                            local v = b.value * (1 + (it.enhanceLevel or 0) * 0.02)
                            local txt = (def.type == "percent")
                                and string.format("%s +%.2f%%", def.name, v * 100)
                                or string.format("%s +%d", def.name, math.floor(v))
                            table.insert(children, UI_.Label { text = txt, fontSize = 10,
                                fontColor = Shared.HexRGB("#9fd8ff") })
                            shown = shown + 1
                        end
                    end
                end
                if shown == 0 then
                    table.insert(children, UI_.Label { text = "无", fontSize = 10,
                        fontColor = Panels.THEME.textDim })
                end
            end
        else
            table.insert(children, UI_.Label { text = "技能词条", fontSize = 11,
                fontColor = Shared.HexRGB("#ffcc66") })
            local skShown = 0
            if it.identified ~= false then
                for sid, n in pairs(it.skills or {}) do
                    local def = Shared.SKILL_DEFS[sid]
                    if def then
                        table.insert(children, Panels.Btn {
                            text = def.icon .. " " .. def.name .. " ×" .. n,
                            fontSize = 10, height = 22, paddingHorizontal = 6,
                            variant = "secondary",
                            borderRadius = 11,   -- 22 高 → 胶囊形（与主题按钮一致）
                            onClick = function() Panels.ShowSkillDetail(sid, n) end,
                        })
                        skShown = skShown + 1
                    end
                end
            end
            if skShown == 0 then
                table.insert(children, UI_.Label { text = "无", fontSize = 10,
                    fontColor = Panels.THEME.textDim })
            end
        end
        return UI_.Panel {
            flexDirection = "column", gap = 3,
            flexGrow = 1, flexBasis = 0,
            backgroundColor = Panels.THEME.bgCard,
            borderRadius = 8,
            paddingHorizontal = 8, paddingVertical = 6,
            children = children,
        }
    end

    -- 组装
    local rootChildren = {}

    if compareItem then
        -- 对比模式
        table.insert(rootChildren, UI_.Panel {
            flexDirection = "row", gap = 10,
            children = {
                Card(item, "新装备", "#ffdd44"),
                Card(compareItem, "已装备", "#ff8844"),
            },
        })
        table.insert(rootChildren, UI_.Panel {
            flexDirection = "row", gap = 8,
            children = {
                BonusColumn(item, "equip"),
                BonusColumn(item, "skill"),
                BonusColumn(compareItem, "equip"),
                BonusColumn(compareItem, "skill"),
            },
        })
    else
        -- 单件模式
        table.insert(rootChildren, Card(item, nil, nil))
        table.insert(rootChildren, UI_.Panel {
            flexDirection = "row", gap = 8,
            children = {
                BonusColumn(item, "equip"),
                BonusColumn(item, "skill"),
            },
        })
    end

    return UI_.Panel {
        flexDirection = "column", gap = 10,
        flexGrow = 1, flexBasis = 0,
        children = rootChildren,
    }
end

-- ============================================================
-- 非装备物品的简单详情布局
--
-- 装备（type == nil）走 BuildDetailLayout（词条 + 技能 + 耐久）。
-- 碎片 / 精魄 / 卡券等非装备走本函数：大图标 + 名称 + 类别/数量/品质。
--
-- ⚠️ 判定顺序与 Shared.MarketCategoryOf 一致：
--    IsEquipment 优先（装备 type == nil），然后 IsFragment → IsSpirit → IsToken → IsSummonScroll。
-- ============================================================
---@param item table
---@return Panel
function Panels.BuildItemSummaryLayout(item)
    -- 类别文案
    local categoryText = "物品"
    if Shared.IsFragment(item) then
        categoryText = "碎片"
    elseif Shared.IsSpirit(item) then
        categoryText = "精魄"
    elseif Shared.IsToken(item) then
        categoryText = "在线卡"
    elseif Shared.IsSummonScroll(item) then
        categoryText = "召唤卷"
    elseif Shared.IsPetEgg(item) then
        categoryText = "宠物蛋"
    elseif Shared.IsPetMaterial(item) then
        categoryText = "宠物精粹"
    elseif Shared.IsPetItem(item) then
        categoryText = "宠物"
    end

    local qcolor = Shared.QUALITY_COLORS[item.quality] or "#ffffff"

    -- 描述：渲染时从 TOKEN_TYPES 读，不写进物品存档
    local desc = nil
    if Shared.IsToken(item) then
        local disp = Shared.TOKEN_TYPES[item.tokenType or "online"]
        desc = disp and disp.desc or nil
    end

    -- ============ 查说明表 ============
    -- 🔴 只读 item 的标识字段（类型/品质），不读也不写任何说明字段。
    --    说明是静态数据，渲染时查表，不进存档、不上报服务端。
    local detailType, detailSub
    if Shared.IsFragment(item) then
        detailType, detailSub = "fragment", item.fragmentType
    elseif Shared.IsSpirit(item) then
        detailType, detailSub = "spirit", item.spiritType
    elseif Shared.IsToken(item) then
        detailType, detailSub = "token", (item.tokenType or "online")
    elseif Shared.IsSummonScroll(item) then
        detailType, detailSub = "summonScroll", item.scrollType
    elseif Shared.IsPetEgg(item) then
        detailType, detailSub = "petEgg", (item.eggQuality or "normal")
    elseif Shared.IsPetMaterial(item) then
        detailType, detailSub = "petMaterial", (item.materialQuality or "normal")
    elseif Shared.IsPetItem(item) then
        -- 宠物本体说明与品质无关，固定用 sub "pet"
        detailType, detailSub = "petItem", "pet"
    end

    local entry = nil
    if detailType and detailSub then
        local byType = Shared.ITEM_DETAILS[detailType]
        if byType then
            entry = byType[detailSub]
            -- 召唤卷 5 品质共用文案：缺失时回退到 normal
            if not entry and detailType == "summonScroll" then
                entry = byType.normal
            end
        end
    end

    -- ============ 通用段构造 ============
    -- 标题列固定宽：容纳"用途"/"获取"两个汉字（字号 12 → 约 24px）+ 余量
    local TITLE_W = 32
    -- 标题列与条目列之间的间隙，同时也是"·"的缩进基准
    local TITLE_GAP = 8

    --- 组装一段：标题与首条目同行，后续条目缩进对齐"·"
    ---@param title string
    ---@param lines string[]
    ---@param contentWidth integer|nil 内容列固定宽度。
    ---       父容器宽度未定时（如放在 row 里按内容排布）必须给固定值，
    ---       否则 whiteSpace="normal" 的 Label 没有 intrinsic 宽度，会被压成 0。
    ---       父容器宽度确定时（如占满整行的 column）传 nil，走 flexGrow 分支。
    ---@return Panel|nil
    local function BuildSection(title, lines, contentWidth)
        if not lines or #lines == 0 then return nil end
        local rows = {}
        for i, line in ipairs(lines) do
            local contentLabel
            if contentWidth then
                -- 固定宽度（父容器宽度未定）
                contentLabel = UI_.Label {
                    text = "· " .. line,
                    fontSize = 11,
                    width = contentWidth,
                    fontColor = Panels.THEME.textSecond,
                    whiteSpace = "normal",
                    wordBreak = "break-word",
                }
            else
                -- 弹性宽度（父容器宽度确定，占满剩余空间）
                contentLabel = UI_.Label {
                    text = "· " .. line,
                    fontSize = 11,
                    flexGrow = 1, flexBasis = 0,
                    fontColor = Panels.THEME.textSecond,
                    whiteSpace = "normal",
                    wordBreak = "break-word",
                }
            end
            table.insert(rows, UI_.Panel {
                flexDirection = "row",
                alignItems = "flex-start",
                gap = TITLE_GAP,
                children = {
                    -- 左列：首行显示标题，其余行留空占位（保证"·"垂直对齐）
                    UI_.Label {
                        text = (i == 1) and title or "",
                        fontSize = 12,
                        width = TITLE_W,
                        fontColor = Shared.HexRGB("#ffcc66"),
                    },
                    contentLabel,
                },
            })
        end
        return UI_.Panel {
            flexDirection = "column", gap = 2,
            children = rows,
        }
    end

    -- ============ 顶部：图标 + 左信息堆叠 + 右"获取"段 ============
    -- 左侧堆叠：名称 / desc / 类别·数量·品质
    local leftChildren = {
        UI_.Label {
            text = item.name or "?",
            fontSize = 16,
            fontColor = Shared.HexRGB(qcolor),
        },
    }
    if desc then
        table.insert(leftChildren, UI_.Label {
            text = desc, fontSize = 11,
            fontColor = Panels.THEME.textSecond,
        })
    end
    table.insert(leftChildren, UI_.Label {
        text = string.format("%s · ×%d · %s",
            categoryText, item.count or 1,
            Shared.QUALITY_NAMES[item.quality] or "?"),
        fontSize = 11,
        fontColor = Panels.THEME.textSecond,
    })

    -- 顶部三列：图标 | 左信息堆叠（flexGrow 吃剩余空间）| 获取段
    -- ⚠️ 图标不设 width，让 emoji 按自然宽度渲染（避免水平拉伸成长方体）
    local topChildren = {
        UI_.Label {
            text = item.icon or "?",
            fontSize = 56,
        },
        UI_.Panel {
            flexDirection = "column", gap = 4,
            -- 不加 flexGrow：按内容宽度排布，让"获取"段跟在中间位置，
            -- 右侧剩余空间自动留白（不把"获取"推到最右）。
            flexShrink = 0,
            children = leftChildren,
        },
    }

    -- ⚠️ "获取"段在 row 里按内容排布，父容器宽度未定，
    --    必须传固定内容宽（240），否则内容 Label 被压成 0 宽、文字不可见。
    local obtainPanel = entry and BuildSection("获取", entry.obtain, 240) or nil
    if obtainPanel then
        table.insert(topChildren, obtainPanel)
    end

    local headerChildren = {
        UI_.Panel {
            flexDirection = "row",
            alignItems = "flex-start",
            gap = 12,
            children = topChildren,
        },
    }

    -- ============ 用途段（独占下方整行宽度）============
    if entry then
        local usesPanel = BuildSection("用途", entry.uses)
        if usesPanel then
            table.insert(headerChildren, usesPanel)
        end
    end

    -- ⚠️ 移除分隔线：上下左右四边已有边框，中间不再加线。
    -- ⚠️ 移除 alignItems = "center"：改回默认 stretch，
    --    否则顶部的 row Panel 会收缩到内容宽度、右列 flexGrow 失效。
    return UI_.Panel {
        flexDirection = "column", gap = 8,
        paddingHorizontal = 16, paddingVertical = 16,
        backgroundColor = Panels.THEME.bgCard,
        borderRadius = 8,
        children = headerChildren,
    }
end

-- ============================================================
-- 装备穿戴（B2）
--
-- ⚠️ 装备变更在客户端本地完成 + MarkDirty 上报（与背包/金币同路径）。
--    Server.lua 的 OnInvSync 只接受位置，其余字段由客户端存档上行。
--    这里做的是「本地权威 + 服务端持久化」，不做服务端校验。
-- ============================================================

--- 通用对话框骨架。三者的差异只在「有没有输入框」「有几个按钮」。
---@param title string
---@param text string
---@param size string
---@param withInput boolean
---@param defaultVal string|nil
---@param buttons table[]  形如 { { label=, variant=, onClick= }, ... }
---@return Modal, TextField|nil
local function BuildDialog(title, text, size, withInput, defaultVal, buttons)
    -- 🔴 栈式弹窗：**不关掉底下的面板**。
    --
    -- 原实现用 OpenModal("dialog", …)，而 OpenModal 会先 CloseCurrent() ——
    -- 于是「角色 → 点升级 → 确认框」会把角色面板关掉，玩家确认完就被丢回游戏，
    -- 得重新开角色面板。角色面板上的三个按钮（技能概率 / 升级 / 降级）全中这个坑。
    --
    -- 改用 OpenStackedModal：确认框叠加在角色/背包之上，确认或取消后自动回退，
    -- 底层面板始终保持打开、且其状态（升级进度、金币）也还在。
    local modal = OpenStackedModal(title, size)
    modal:SetTitle(title)
    modal:SetSize(size)
    local children = {
        UI_.Label {
            text = text,
            fontSize = 14,
            fontColor = Panels.THEME.textPrimary,
            maxLines = 0,          -- 允许多行
            marginTop = 10,
        },
    }

    local input = nil
    if withInput then
        input = UI_.TextField {
            text = defaultVal or "",
            width = 220,
            height = 36,
            marginTop = 10,
        }
        table.insert(children, input)
    end

    modal:AddContent(UI_.Panel {
        flexDirection = "column", gap = 8,
        children = children,
    })

    local btns = {}
    for _, b in ipairs(buttons) do
        table.insert(btns, QButton(b.label, function()
            modal:Close()
            if b.onClick then b.onClick(input) end
        end, b.variant))
    end
    modal:SetFooter(UI_.Panel {
        flexDirection = "row", justifyContent = "flex-end", gap = 12,
        children = btns,
    })
    modal:Open()
    return modal, input
end

--- 双按钮确认框。
---
--- ⚠️ 用 xl 而不是 sm：确认框经常要塞下「升级门槛逐件明细 + 伤害衰减表」
---    这类长文本，sm（320px 宽 / 400 高）会把内容挤到看不全。
---    这里放宽到 800px，配合 maxLines=0 让长文本完整换行显示。
---@param title string
---@param text string
---@param onOk fun()
---@param onCancel? fun()
function Panels.Confirm(title, text, onOk, onCancel)
    BuildDialog(title, text, "xl", false, nil, {
        { label = "确定", variant = "primary", onClick = onOk },
        { label = "取消", variant = "secondary", onClick = onCancel },
    })
end

--- 单按钮通知框（纯告知，无「取消」语义）。
--- 用于「新手礼包已自动穿戴」这类只需要玩家知悉、不需要做选择的提示。
---@param title string
---@param text string
function Panels.Alert(title, text)
    BuildDialog(title, text, "xl", false, nil, {
        { label = "知道了", variant = "primary" },
    })
end

-- ============================================================
-- 画面与特效设置面板
--
-- ⚠️ urhox-libs/UI 的 SetStyle 改不了 variant（构造时定配色），
--    所以任何「开关高亮」都靠改完值后重开面板刷新。
-- ============================================================

-- ============ 暴露给 UI_Items / UI_System ============
-- 无状态工具，加载时捕获即可（Core 返回前已全部定义）
Panels.QLabel           = QLabel
Panels.QButton          = QButton
Panels.OpenModal        = OpenModal
Panels.OpenStackedModal = OpenStackedModal

return Panels
