-- ============================================================
-- Battle_Terrain.lua：地形视觉（Battle_Visual.lua 的兄弟文件）
--
-- 职责：高度场 / 地形网格 / 高度图 / 4 色硬边界 / 树木石头装饰 / 接触阴影。
--
-- 与 Battle_Visual.lua 共享同一张 Battle 表：
--   · Battle_World 先建表并 return
--   · Battle_Visual 在**文件末尾** require 本文件（必须晚于 Battle.V 的写入；
--     且 Client_Network 会在加载期取 require("Battle_Visual").Visual.Terrain，
--     所以 Terrain 必须在 Battle_Visual 返回之前注入）
--   · 本文件把 Battle.Visual.Terrain 填好，Battle_Visual 末尾统一导出 Battle.Visual
--
-- 依赖：Shared + Battle_World。通过 Battle.V 复用 Battle_Visual 的顶点工具
--       （V.tri / V.box / V.sphere / V.revolve …），
--       通过 Battle.getTerrainMaterial 复用其地形材质工厂
--       （两者均由 Battle_Visual 在本文件加载前写入 Battle 表）。
--       不依赖 UI，也不依赖 Battle_Combat。
--
-- 对外接口：Battle.Visual.Terrain
--   HeightAt(x,z) / GetHeight(x,z) / Build(scene) / UpdateDecor(dt, px, pz)
-- ============================================================
local Shared = require("Shared")
local Battle = require("Battle_World")

-- Battle_Visual 写入的共享容器（本文件在 Battle_Visual 末尾被 require，此时已就绪）
local V = Battle.V
local getTerrainMaterial = Battle.getTerrainMaterial

-- ============================================================
-- ===== 模块：Visual.Terrain =====
-- ============================================================
do
    local Terrain = {}
    local scene_ = nil

    -- ---------- 地面装饰状态（分块）----------
    --- 装饰材质缓存（灰白石灰岩）
    local decorMaterial_ = nil

    --- 装饰块尺寸（米）。每块 100×100。
    --- ⚠️ 从 200 改到 100 的原因：块尺寸决定"加载范围"的粒度。
    ---    3×3 块 + 块尺寸 100 → 覆盖 300×300 米（最远 212~226 米，取决于玩家在块内的位置），
    ---    符合"200 米外不加载装饰"的目标。
    ---    块尺寸 200 时覆盖 600×600 米（最远 424 米），超出太多。
    local DECOR_CHUNK_SIZE = 100

    --- 玩家周围加载的块半径：1 = 3×3 块（覆盖 300×300 米，最远约 226 米）。
    local DECOR_LOAD_RADIUS = 1

    --- 已加载块表：key = "cx_cz"，value = { node, shadowNode, cx, cz }
    ---@type table<string, {node: Node, shadowNode: Node, cx: integer, cz: integer}>
    local loadedChunks_ = {}

    --- 上次玩家所在块坐标（nil = 尚未初始化，会触发首次加载）
    local lastChunkX_, lastChunkZ_ = nil, nil

    --- 待构建的装饰块队列（分帧构建，避免启动时一次性建 9 块造成长时间卡顿）
    ---@type {cx: integer, cz: integer}[]
    local pendingChunks_ = {}

    --- 世界坐标 → 块坐标（负数也用 floor 正确取整）
    ---@param worldCoord number
    ---@return integer
    local function WorldToChunk(worldCoord)
        return math.floor(worldCoord / DECOR_CHUNK_SIZE)
    end

    -- 世界尺寸
    local TERRAIN_SIZE = 10000
    local TERRAIN_SEG  = 300                -- 每顶点 33.3m（原 50m）
    local TERRAIN_HALF = TERRAIN_SIZE / 2
    local CHUNK_SEG    = 30                 -- 每块 1000m
    local RING_RADIUS  = 240                -- 内圈半径
    local RING_RISE    = 40                 -- 外圈最大抬升

    -- ---------- 湖泊（阶段 2.2 批 1）----------
    -- 🔴 全局开关：地形改造影响所有用 HeightAt / GetHeight 的逻辑
    --    （怪物刷新、装饰、相机避让、掉落物贴地），出问题可一键关掉。
    --
    -- ⚠️ 尺寸为什么是 120 米而不是 40 米：
    --    高度图采样间隔 = TERRAIN_SIZE / MAP_SEG = 10000 / 300 ≈ 33.3 米。
    --    40 米半径的湖只能覆盖约 1 个格子，双线性插值后会**被完全抹平**。
    --    120 米能覆盖 3~4 格，坑的形态才出得来。
    --    （另一条路是把 MAP_SEG 提到 600，但那会让地形顶点数 ×4，
    --      挤占阶段 3 的 VRM 角色预算，性价比不对。）
    -- ⚠️ 湖心距离必须 > 湖半径，否则出生点会被压进湖里。
    --    实测教训：曾取 (0,100) + 半径 120 → 覆盖 z ∈ [-20, 220]，
    --    出生点 (0,0) 落在范围内，玩家 Y 被沉到 -4.69 米、站在水下看不到水面。
    --    现取 (0,150)：覆盖 z ∈ [30, 270]，出生点距湖心 150 > 120，安全。
    local WATER_LAKE_ENABLED = true
    local LAKE_CX     = 0                   -- 湖心 X
    local LAKE_CZ     = 150                 -- 湖心 Z（playerFacing_=0 → +Z 方向）
    local LAKE_RADIUS = 120                 -- 湖总半径（含过渡带）
    local LAKE_FLAT   = 90                  -- 湖底平坦区半径
    local LAKE_DEPTH  = 6.0                 -- 湖底下沉量
    -- 水位 = 湖底 + 5.5（运行时按湖心实际地形高度算，见 Terrain.GetWaterY）

    --- 湖泊对地形高度的偏移量（负值 = 下挖）
    --- 用 smoothstep 从湖底平坦区平滑过渡回原地形，避免出现硬边台阶。
    ---@param x number
    ---@param z number
    ---@return number
    local function lakeOffset(x, z)
        if not WATER_LAKE_ENABLED then return 0 end
        local dx, dz = x - LAKE_CX, z - LAKE_CZ
        local d = math.sqrt(dx * dx + dz * dz)
        if d >= LAKE_RADIUS then return 0 end
        local t
        if d <= LAKE_FLAT then
            t = 1.0                                  -- 平坦区：全量下沉
        else
            t = (LAKE_RADIUS - d) / (LAKE_RADIUS - LAKE_FLAT)
            t = t * t * (3 - 2 * t)                  -- smoothstep 过渡
        end
        return -LAKE_DEPTH * t
    end

    -- ---------- 噪声 ----------
    local function hashUnit(x, y, s)
        local n = math.sin(x * 127.1 + y * 311.7 + s * 74.7) * 43758.5453
        return n - math.floor(n)
    end

    local function valueNoise(x, y, s)
        local ix, iy = math.floor(x), math.floor(y)
        local fx, fy = x - ix, y - iy
        local ux = fx * fx * (3 - 2 * fx)
        local uy = fy * fy * (3 - 2 * fy)
        local a = hashUnit(ix,     iy,     s)
        local b = hashUnit(ix + 1, iy,     s)
        local c = hashUnit(ix,     iy + 1, s)
        local d = hashUnit(ix + 1, iy + 1, s)
        return a + (b - a) * ux + (c - a) * uy + (a - b - c + d) * ux * uy
    end

    local function fractalSum(x, y, oct, s)
        local amp, freq, sum, norm = 0.5, 1, 0, 0
        for i = 1, oct do
            sum  = sum + amp * valueNoise(x * freq, y * freq, s + i * 23)
            norm = norm + amp
            amp  = amp * 0.5
            freq = freq * 2.03
        end
        return sum / norm
    end

    --- 远山抬升：240m 内为 0；240~480m 用 smoothstep 平滑升到 RING_RISE；之后保持
    local function platformRise(R)
        local u = Shared.Clamp((R - RING_RADIUS) / RING_RADIUS, 0, 1)
        return RING_RISE * u * u * (3 - 2 * u)
    end

    --- 起伏振幅：50m 内 ±6 米；50~240m 从 6 米平滑升到 10 米
    ---
    --- ⚠️ 33.33 米顶点间距下实测（纯噪声项，排除 platformRise）：
    ---     相邻顶点高差：均值 0.67~0.99m，最大 1.71~4.07m
    ---     坡度：均值 1.2~1.7°，最大 2.9~7.0°
    ---     "最大"和"平均"差约 4 倍——因为地形形态由 n1（权重 0.55、波长 167m）
    ---     主导，长波本身就缓，振幅加倍也拉不动平均坡度。
    ---     折面感主要来自 n2 的局部尖峰（最大 7°），靠色阶阈值的硬边界强化。
    local function noiseAmp(R)
        if R <= 50 then return 12.0 end
        return 12.0 + math.min(8.0, (R - 50) / 190 * 8.0)
    end

    --- 世界坐标 → 地面高度（连续函数；供高度图采样）
    ---@param x number
    ---@param z number
    ---@return number
    function Terrain.HeightAt(x, z)
        local R = math.sqrt(x * x + z * z)
        local amp = noiseAmp(R)
        local n1 = fractalSum(x * 0.006, z * 0.006, 3, 11) - 0.5
        local n2 = fractalSum(x * 0.018, z * 0.018, 3, 57) - 0.5
        local n3 = valueNoise(x * 0.05, z * 0.05, 99) - 0.5
        -- 湖泊项作为独立加法项，不改动原有噪声/抬升逻辑
        return platformRise(R) + (n1 * 0.55 + n2 * 0.30 + n3 * 0.15) * amp
            + lakeOffset(x, z)
    end

    --- 水位高度（世界 Y）。供水面 mesh 与"涉水判定"使用。
    --- 取湖心处**原始地形**（不含湖泊下沉）再减去 0.5 米，
    --- 这样水位相对岸边的关系是稳定的，不会随湖深变化而漂。
    ---@return number
    function Terrain.GetWaterY()
        local saved = WATER_LAKE_ENABLED
        WATER_LAKE_ENABLED = false          -- 临时关掉，量原始地形
        local h0 = Terrain.HeightAt(LAKE_CX, LAKE_CZ)
        WATER_LAKE_ENABLED = saved
        return h0 - 0.5
    end

    --- 湖心坐标与半径（供水面 mesh 与扫描工具使用）
    ---@return number cx, number cz, number radius
    function Terrain.GetLakeInfo()
        return LAKE_CX, LAKE_CZ, LAKE_RADIUS
    end

    -- ---------- 高度图 ----------
    local heightMapCache_ = {}
    local MAP_SIZE = 10000
    local MAP_SEG  = 300    -- 与 TERRAIN_SEG 一致，确保双线性插值和网格剖分匹配

    function Terrain.BuildHeightMap()
        heightMapCache_ = {}
        for iz = 0, MAP_SEG do
            heightMapCache_[iz] = {}
            for ix = 0, MAP_SEG do
                local x = ix * (MAP_SIZE / MAP_SEG) - MAP_SIZE / 2
                local z = iz * (MAP_SIZE / MAP_SEG) - MAP_SIZE / 2
                heightMapCache_[iz][ix] = Terrain.HeightAt(x, z)
            end
        end
        print("[Visual.Terrain] 高度图预计算完成 " .. (MAP_SEG + 1) .. "x" .. (MAP_SEG + 1))
    end

    --- 双线性插值查询地面高度（所有贴地逻辑都用这个）
    ---@param x number
    ---@param z number
    ---@return number
    function Terrain.GetHeight(x, z)
        if not heightMapCache_[0] then return Terrain.HeightAt(x, z) end
        local fx = (x + MAP_SIZE / 2) / (MAP_SIZE / MAP_SEG)
        local fz = (z + MAP_SIZE / 2) / (MAP_SIZE / MAP_SEG)
        local ix = math.floor(fx)
        local iz = math.floor(fz)
        ix = math.max(0, math.min(MAP_SEG - 1, ix))
        iz = math.max(0, math.min(MAP_SEG - 1, iz))
        local u = fx - ix
        local v = fz - iz
        local hA = heightMapCache_[iz][ix] or 0
        local hB = heightMapCache_[iz + 1][ix] or 0
        local hC = heightMapCache_[iz][ix + 1] or 0
        local hD = heightMapCache_[iz + 1][ix + 1] or 0
        -- 插值必须与 BuildChunk 的三角剖分一致：
        -- T1 = (hA, hB, hC) 覆盖 u+v<=1；T2 = (hC, hB, hD) 覆盖 u+v>=1
        if u + v <= 1 then
            return (1 - u - v) * hA + v * hB + u * hC
        else
            return (1 - v) * hC + (1 - u) * hB + (u + v - 1) * hD
        end
    end

    --- 按高度着色（4 色硬边界，暖调写实色板）
    ---
    --- ⚠️ 阈值 0.7 / 3 / 8 的取法（实测标定，不是按"海拔语义"取的）：
    ---     近场(默认视野 100m 内)实测高度只有 [-1.6, +2.0] 米，
    ---     p50 仅 -0.07 米、p90 仅 +1.24 米。所以第一档必须压到 1 米以下，
    ---     否则近场永远只有一档色，不会出现绿黄交错。
    ---     若按直觉取 3 米，近场超过 3 米的面占比为 0%，色阶完全不触发。
    ---     第一档取 0.7（而非 1）：让草黄从约 15% 扩到约 25%，
    ---     色块沿地形起伏成片分布，而不是零星斑点。
    ---     再往下压到 0.5 会让草黄超过 30%，抢掉"草原为主"的基调。
    ---     第二/三档 3 / 8 米对应中距(±10m)与远山(platformRise 到 40m)。
    ---@param h number
    ---@return number r, number g, number b
    local function heightColor(h)
        -- 提饱和度 + 提亮度：当前色板是"低饱和写实"调子，
        -- 原神是"高饱和二次元"调子。逐档对比：
        --   低地草原  0.42,0.58,0.30 → 0.52,0.82,0.34（更亮更饱和的草绿）
        --   中地草黄  0.62,0.58,0.34 → 0.72,0.76,0.36（草黄但明亮）
        --   高地岩灰  0.52,0.46,0.40 → 0.62,0.56,0.48（浅岩灰）
        --   远山深绿  0.92,0.90,0.84 → 0.40,0.68,0.42（原为"雪顶暖白 0.98,0.97,0.94"）
        if h < 0.7 then
            -- 低地草原：再提饱和 + 提亮。0.58,0.88,0.32 是"明亮黄绿"，
            -- 目标对齐原神草地亮部（不是写实的暗绿）。
            return 0.58, 0.88, 0.32
        elseif h < 3 then
            -- 中地草黄：往"金黄绿"偏。原神丘陵是饱和的暖黄绿，不是灰绿。
            return 0.82, 0.82, 0.34
        elseif h < 8 then
            -- 高地：暗草绿（不是岩灰）。
            -- 岩灰 (0.62,0.56,0.48) 与前后两档都不搭，视觉上像"两个色块拼接"。
            -- 改草绿系后色相连续：明黄绿 → 中地草黄 → 暗草绿 → 远山深绿。
            return 0.52, 0.72, 0.34
        else
            -- 远山高处：深绿（不是雪白）。
            -- 略暗略冷于低地草原（0.58,0.88,0.32），形成"远山比近景深"的层次，
            -- 方向是大气透视（远景饱和度降、明度降）。
            -- ⚠️ 旧值 (0.98,0.97,0.94) 是暖白雪顶，在全绿场景里像"白带"。
            -- 本档只覆盖 h >= 8m 的区域（远山，platformRise 到 40m）；
            -- 若截图里白色残留不在此高度范围，那是天空盒 horizon 或雾色，不是这里。
            return 0.40, 0.68, 0.42
        end
    end

    --- 平滑顶点法线：用相邻网格点的高度差近似。
    ---
    --- 同一网格点被周围多个三角形共享 → 法线连续 → 曲面平滑，
    --- Toon 分界沿地形起伏走，而不是沿三角形边界跳成条带。
    ---
    --- ⚠️ 与低多边形风格的 flat 法线相反。转 Toon 必须用它。
    ---@param px number[]
    ---@param py number[]
    ---@param pz number[]
    ---@param i integer 1-based 网格点索引
    ---@param cols integer 每行网格点数
    ---@param seg integer 分段数
    ---@return Vector3
    local function VertexNormal(px, py, pz, i, cols, seg)
        local ix = (i - 1) % cols
        local iz = math.floor((i - 1) / cols)
        local iL = (ix > 0) and (i - 1) or i
        local iR = (ix < seg) and (i + 1) or i
        local iD = (iz > 0) and (i - cols) or i
        local iU = (iz < seg) and (i + cols) or i
        local dx = px[iR] - px[iL]
        local dz = pz[iU] - pz[iD]
        local n = Vector3(
            -(py[iR] - py[iL]) / math.max(math.abs(dx), 1e-4),
            1.0,
            -(py[iU] - py[iD]) / math.max(math.abs(dz), 1e-4))
        return n:Normalized()
    end

    --- 生成单个地形块（平滑法线 + 面级色块）。
    ---
    --- 与"全共享顶点"版本的区别，以及为什么这样做：
    ---   · 法线用 VertexNormal（平滑）→ 光照连续，Toon 分界沿地形起伏走
    ---   · 顶点色仍按**面**取三顶点高度中位数 → 保留原有 4 色硬边界色块
    ---
    --- ⚠️ 色块与平滑法线会不一致（一个硬边、一个连续），但这是刻意的：
    ---    地形靠 4 色硬边界出"低多边形色块"风格（heightColor 的阈值是实测标定过的），
    ---    若改成逐顶点插值色，地形会变成连续渐变，丢掉原有的色块分界。
    ---    所以这里每三角形仍输出 3 个独立顶点——不是为 flat 法线，而是为硬边界色。
    ---
    --- ⚠️ 顶点顺序必须与 GetHeight 的三角剖分一致：
    ---    T1 = (i0, i2, i1)，T2 = (i1, i2, i3)。
    ---    改顺序会让渲染出的表面和 GetHeight 求出的表面错位
    ---    → 玩家 / 怪物 / 掉落物 / 装饰全部浮空或沉地。
    local function BuildChunk(parent, originX, originZ, seg, material)
        local node = parent:CreateChild("Chunk", LOCAL)
        local step = TERRAIN_SIZE / TERRAIN_SEG
        local half = seg * step * 0.5
        node.position = Vector3(originX + half, 0, originZ + half)

        local geom = node:CreateComponent("CustomGeometry", LOCAL)
        geom:SetNumGeometries(1)
        geom:BeginGeometry(0, TRIANGLE_LIST)

        -- 网格顶点的局部坐标与高度
        local cols = seg + 1
        local px, py, pz = {}, {}, {}
        for iz = 0, seg do
            for ix = 0, seg do
                local idx = iz * cols + ix + 1
                local x = originX + ix * step
                local z = originZ + iz * step
                local h = Terrain.HeightAt(x, z)
                px[idx], py[idx], pz[idx] = ix * step - half, h, iz * step - half
            end
        end

        --- 面级上色：取三角形三顶点高度的中位数去查色板
        ---@param i0 integer
        ---@param i1 integer
        ---@param i2 integer
        ---@return number r, number g, number b
        local function FaceColor(i0, i1, i2)
            local a, b, c = py[i0], py[i1], py[i2]
            -- 中位数：提前 return 消除未初始化变量（避免 LSP 的 nil 误报）
            if (a <= b and b <= c) or (c <= b and b <= a) then
                return heightColor(b)
            elseif (b <= a and a <= c) or (c <= a and a <= b) then
                return heightColor(a)
            end
            return heightColor(c)
        end

        --- 输出一个三角形：顶点色取面级色块，法线取逐顶点平滑法线
        ---@param i0 integer
        ---@param i1 integer
        ---@param i2 integer
        local function EmitTri(i0, i1, i2)
            local r, g, b = FaceColor(i0, i1, i2)
            local col = Color(r, g, b, 1)
            local ids = { i0, i1, i2 }
            for k = 1, 3 do
                local i = ids[k]
                geom:DefineVertex(Vector3(px[i], py[i], pz[i]))
                geom:DefineNormal(VertexNormal(px, py, pz, i, cols, seg))
                geom:DefineColor(col)
            end
        end

        for iz = 0, seg - 1 do
            for ix = 0, seg - 1 do
                local i0 = iz * cols + ix + 1
                local i1 = i0 + 1
                local i2 = i0 + cols
                local i3 = i2 + 1

                -- T1 = (i0, i2, i1)
                EmitTri(i0, i2, i1)
                -- T2 = (i1, i2, i3)
                EmitTri(i1, i2, i3)
            end
        end

        geom:Commit()
        if material then geom:SetMaterial(material) end
        return node
    end

    --- 一次性构建整个地形
    ---@param scene Scene
    ---@return Node
    function Terrain.Build(scene)
        scene_ = scene
        Terrain.BuildHeightMap()

        local material = getTerrainMaterial()
        if not material then
            print("[Visual.Terrain] ⚠️ 顶点色材质缺失，地形将无高度色")
        end

        local root = scene:CreateChild("Terrain", LOCAL)
        local step = TERRAIN_SIZE / TERRAIN_SEG
        local chunks = math.ceil(TERRAIN_SEG / CHUNK_SEG)

        for cz = 0, chunks - 1 do
            for cx = 0, chunks - 1 do
                local segX = math.min(CHUNK_SEG, TERRAIN_SEG - cx * CHUNK_SEG)
                local segZ = math.min(CHUNK_SEG, TERRAIN_SEG - cz * CHUNK_SEG)
                local seg = math.min(segX, segZ)
                local originX = cx * CHUNK_SEG * step - TERRAIN_HALF
                local originZ = cz * CHUNK_SEG * step - TERRAIN_HALF
                BuildChunk(root, originX, originZ, seg, material)
            end
        end

        print("[Visual.Terrain] 地形已生成 " .. chunks .. "x" .. chunks .. " 块")
        -- 装饰不再在此初始化：改为 Client 主循环每帧调 UpdateDecor(dt, px, pz)，
        -- 首次调用（lastChunkX_ = nil）会自动加载玩家周围 3×3 块。
        return root
    end

    -- ============ 地面装饰（石头圈 + 随机小石）============

    --- 获取装饰材质（灰白石灰岩）
    local function getDecorMaterial()
        if not decorMaterial_ then
            decorMaterial_ = getTerrainMaterial()
        end
        return decorMaterial_
    end

    --- 生成一个石头（随机棱角的盒子堆叠）。
    ---
    --- 🔴 确定性：所有随机量改用 hashUnit(cx, cz, seed)，
    ---    相同坐标永远生成相同的石头（位置 + 颜色都固定）。
    ---@param g CustomGeometry
    ---@param cx number
    ---@param cz number
    ---@param h number 石头高度
    ---@param baseColor number[] {r,g,b}
    local function addRock(g, cx, cz, h, baseColor)
        local groundY = Terrain.GetHeight(cx, cz)
        -- 色抖：用世界坐标作种子（同一位置永远得到同一个色抖）
        local c = {
            baseColor[1] + (hashUnit(cx, cz, 11) - 0.5) * 0.06,
            baseColor[2] + (hashUnit(cx, cz, 12) - 0.5) * 0.06,
            baseColor[3] + (hashUnit(cx, cz, 13) - 0.5) * 0.06,
        }
        V.box(g, cx, groundY + h * 0.5, cz, h * 0.9, h, h * 0.9, c)
        -- 上方小凸起
        if h > 0.3 then
            V.box(g,
                cx + (hashUnit(cx, cz, 14) - 0.5) * h * 0.4,
                groundY + h * 0.9,
                cz + (hashUnit(cx, cz, 15) - 0.5) * h * 0.4,
                h * 0.5, h * 0.4, h * 0.5, c)
        end
    end

    -- 石头色板（4 档，目标分布 5:2:2:1）
    local ROCK_COLORS = {
        { 0.68, 0.64, 0.58 },  -- 浅暖灰（主体）
        { 0.55, 0.53, 0.50 },  -- 中灰
        { 0.50, 0.55, 0.55 },  -- 青灰（冷色点缀）
        { 0.42, 0.38, 0.34 },  -- 深褐灰（重量感）
    }

    -- 树色板
    -- ⚠️ 必须标注 number[]：裸字面量会被 EmmyLua 推断成 tuple (r,g,b)，
    --    赋给 number[] 形参时报 param-type-mismatch。
    ---@type number[]
    local TRUNK_DARK  = { 0.28, 0.18, 0.10 }   -- 深褐
    ---@type number[]
    local TRUNK_LIGHT = { 0.42, 0.28, 0.16 }   -- 浅褐
    ---@type number[]
    local LEAF_DARK   = { 0.18, 0.38, 0.16 }   -- 深绿
    ---@type number[]
    local LEAF_MID    = { 0.28, 0.50, 0.22 }   -- 中绿
    ---@type number[]
    local LEAF_YELLOW = { 0.38, 0.58, 0.26 }   -- 黄绿
    -- 棕榈叶：更亮的黄绿（热带感）
    ---@type number[]
    local LEAF_PALM   = { 0.45, 0.65, 0.28 }
    -- 枯树用灰褐（区别于活树干）
    ---@type number[]
    local TRUNK_DEAD  = { 0.35, 0.30, 0.24 }

    --- 针叶树：细柱干 + 三层弧形冠。约 4 米高。
    ---@param g CustomGeometry
    ---@param cx number
    ---@param cz number
    ---@param trunkColor number[]
    ---@param leafColor number[]
    local function addConifer(g, cx, cz, trunkColor, leafColor)
        local gy = Terrain.GetHeight(cx, cz)
        -- 树干（下 0 → 上 1.3 米，半径 0.14 → 0.22）
        V.revolve(g, cx, cz, {
            { 0.22, gy },
            { 0.22, gy + 1.3 },
        }, 6, trunkColor)
        -- 三层弧形冠。
        -- ⚠️ 单换 revolveSmooth 是零效果：2 点 profile 是直线，切线处处相同，
        --    平滑法线退化成面法线。必须同时加中间点把轮廓变成弧线。
        --
        -- 近直线锥：每个中间点仅比直线插值高 3~5%（已逐点核算）。
        -- 3% 是保住 revolveSmooth 有效性的下限 —— 完全共线会让切线恒定，
        -- 平滑法线退化成面法线（与 V.revolve 等价）。
        V.revolveSmooth(g, cx, cz, {
            { 1.00, gy + 1.20 },   -- y=1.53 直线 0.746 → 0.77
            { 0.77, gy + 1.53 },
            { 0.51, gy + 1.86 },   -- y=1.86 直线 0.492 → 0.51
            { 0.24, gy + 2.20 },   -- y=2.20 直线 0.231 → 0.24
            { 0.00, gy + 2.50 },
        }, 6, leafColor)
        V.revolveSmooth(g, cx, cz, {
            { 0.78, gy + 2.10 },
            { 0.55, gy + 2.44 },
            { 0.31, gy + 2.78 },
            { 0.15, gy + 3.00 },
            { 0.00, gy + 3.20 },
        }, 6, leafColor)
        V.revolveSmooth(g, cx, cz, {
            { 0.52, gy + 2.90 },
            { 0.39, gy + 3.18 },
            { 0.24, gy + 3.46 },
            { 0.10, gy + 3.72 },
            { 0.00, gy + 3.90 },
        }, 6, leafColor)
    end

    --- 阔叶树：细柱干 + 低面数球冠。约 4 米高。
    ---@param g CustomGeometry
    ---@param cx number
    ---@param cz number
    ---@param trunkColor number[]
    ---@param leafColor number[]
    local function addBroadleaf(g, cx, cz, trunkColor, leafColor)
        local gy = Terrain.GetHeight(cx, cz)
        -- 树干（下 0 → 上 1.6 米，半径 0.16 → 0.26）
        V.revolve(g, cx, cz, {
            { 0.26, gy },
            { 0.26, gy + 1.6 },
        }, 6, trunkColor)
        -- 平滑版球冠：顶点法线 = normalize(顶点 - 球心)，相邻格之间法线连续。
        -- ⚠️ 有意偏离 Battle_Visual 里"树用硬折面"的旧约定：树冠要圆润化。
        --
        V.sphereSmooth(g, cx, gy + 2.7, cz, 1.15, 6, 3, leafColor)
    end

    --- 棕榈树：直干 + 顶部 6 片下垂大叶。约 5.5 米高。
    ---@param g CustomGeometry
    ---@param cx number
    ---@param cz number
    ---@param trunkColor number[]
    ---@param leafColor number[]
    local function addPalmTree(g, cx, cz, trunkColor, leafColor)
        local gy = Terrain.GetHeight(cx, cz)
        -- 直干：细长，从 0 到 5.5 米，半径逐渐收窄
        V.revolve(g, cx, cz, {
            { 0.20, gy + 0.0 },
            { 0.16, gy + 2.0 },
            { 0.13, gy + 4.0 },
            { 0.10, gy + 5.5 },
        }, 6, trunkColor)

        -- 顶部叶片：6 片，从干顶向外下垂
        local N_LEAF   = 6
        local LEAF_LEN = 2.4    -- 叶片水平伸出长度
        local LEAF_W   = 0.55   -- 叶片中段宽度
        local by = gy + 5.5     -- 叶片根部高度

        for i = 0, N_LEAF - 1 do
            local a = 2 * math.pi * i / N_LEAF + 0.3
            local c, s = math.cos(a), math.sin(a)
            local px, pz = -s * LEAF_W, c * LEAF_W

            local midX = cx + c * LEAF_LEN * 0.55
            local midZ = cz + s * LEAF_LEN * 0.55
            local midY = by + 0.5
            local tipX = cx + c * LEAF_LEN
            local tipZ = cz + s * LEAF_LEN
            local tipY = by - 0.8

            -- 正面：根 → 中（宽） → 尖
            V.quad(g,
                Vector3(cx, by, cz),
                Vector3(midX + px, midY, midZ + pz),
                Vector3(tipX, tipY, tipZ),
                Vector3(midX - px, midY, midZ - pz),
                leafColor)
            -- 反面：反向绕序，双面可见
            V.quad(g,
                Vector3(midX - px, midY - 0.02, midZ - pz),
                Vector3(tipX, tipY - 0.02, tipZ),
                Vector3(midX + px, midY - 0.02, midZ + pz),
                Vector3(cx, by - 0.02, cz),
                leafColor)
        end
    end

    --- 灌木：3 个低面数小球堆叠。约 0.8 米高。
    ---@param g CustomGeometry
    ---@param cx number
    ---@param cz number
    ---@param leafColor number[]
    local function addBush(g, cx, cz, leafColor)
        local gy = Terrain.GetHeight(cx, cz)
        V.sphereSmooth(g, cx,        gy + 0.35, cz,        0.55, 5, 2, leafColor)
        V.sphereSmooth(g, cx + 0.32, gy + 0.28, cz + 0.18, 0.42, 5, 2, leafColor)
        V.sphereSmooth(g, cx - 0.28, gy + 0.32, cz - 0.22, 0.45, 5, 2, leafColor)
    end

    --- 枯树：主杆 + 3 根竖直分枝（无叶）。约 4 米高。
    --- ⚠️ 分枝用"竖直细锥 + 水平偏移"近似斜枝。
    ---    V.revolve 只支持竖直轴心，做不出真正的斜枝；
    ---    但"无叶 + 不规则轮廓"这个枯树的核心特征已经传达。
    ---@param g CustomGeometry
    ---@param cx number
    ---@param cz number
    ---@param trunkColor number[]
    local function addDeadTree(g, cx, cz, trunkColor)
        local gy = Terrain.GetHeight(cx, cz)
        -- 主杆
        V.revolve(g, cx, cz, {
            { 0.22, gy + 0.0 },
            { 0.18, gy + 1.5 },
            { 0.14, gy + 3.0 },
            { 0.10, gy + 4.0 },
        }, 6, trunkColor)

        -- 3 根分枝
        local BRANCHES = {
            { dx =  0.35, dz =  0.20, yBase = gy + 2.0, h = 1.8, r = 0.10 },
            { dx = -0.30, dz =  0.30, yBase = gy + 2.5, h = 1.5, r = 0.08 },
            { dx =  0.15, dz = -0.35, yBase = gy + 3.0, h = 1.3, r = 0.07 },
        }
        for _, b in ipairs(BRANCHES) do
            V.revolve(g, cx + b.dx, cz + b.dz, {
                { b.r,        b.yBase },
                { b.r * 0.7,  b.yBase + b.h * 0.6 },
                { 0.0,        b.yBase + b.h },
            }, 5, trunkColor)
        end
    end

    --- 选树干颜色（大尺度哈希，成片色块）
    local function PickTrunkColor(wx, wz)
        if hashUnit(wx * 0.04, wz * 0.04, 599) < 0.5 then return TRUNK_DARK end
        return TRUNK_LIGHT
    end

    --- 选树冠颜色（针叶只用深/中绿，阔叶三色随机）
    ---@param isConifer boolean
    local function PickLeafColor(wx, wz, isConifer)
        local t = hashUnit(wx * 0.05, wz * 0.05, isConifer and 701 or 811)
        if isConifer then
            if t < 0.60 then return LEAF_DARK end
            return LEAF_MID
        end
        if t < 0.40 then return LEAF_DARK
        elseif t < 0.75 then return LEAF_MID
        else return LEAF_YELLOW end
    end

    --- 按世界坐标挑石头档位：大尺度哈希 → 形成成片色块（而不是逐块随机）
    ---@param wx number
    ---@param wz number
    ---@return number[]
    local function PickRockColor(wx, wz)
        local t = hashUnit(wx * 0.013, wz * 0.013, 313)
        if t < 0.50 then return ROCK_COLORS[1]
        elseif t < 0.70 then return ROCK_COLORS[2]
        elseif t < 0.90 then return ROCK_COLORS[3]
        else return ROCK_COLORS[4] end
    end


    --- 生成一个装饰块（按需加载，玩家靠近时调用一次）。
    ---
    --- 🔴 位置固定：所有位置抖动、数量、颜色全部用 hashUnit / valueNoise 计算，
    ---    相同块坐标永远生成相同装饰。跨会话、跨玩家一致。
    ---@param cx integer 块坐标 X
    ---@param cz integer 块坐标 Z
    local function BuildDecorChunk(cx, cz)
        if not scene_ then return end
        local key = cx .. "_" .. cz
        if loadedChunks_[key] then return end

        local parent = scene_:GetChild("TerrainDecor", false)
        if not parent then
            parent = scene_:CreateChild("TerrainDecor", LOCAL)
        end

        local node = parent:CreateChild("DecorChunk_" .. key, LOCAL)
        local g = node:CreateComponent("CustomGeometry", LOCAL)
        g:SetNumGeometries(1)
        g:BeginGeometry(0, TRIANGLE_LIST)

        local shadowNode = parent:CreateChild("DecorChunkShadow_" .. key, LOCAL)
        local shadowG = shadowNode:CreateComponent("CustomGeometry", LOCAL)
        shadowG:SetNumGeometries(1)
        shadowG:BeginGeometry(0, TRIANGLE_LIST)

        local baseX = cx * DECOR_CHUNK_SIZE
        local baseZ = cz * DECOR_CHUNK_SIZE

        -- ============ 石头（每 30 米一圈）============
        local ringStep = 30
        local ringCount = math.floor(DECOR_CHUNK_SIZE / ringStep)
        for ix = 0, ringCount - 1 do
            for iz = 0, ringCount - 1 do
                -- 圈中心世界坐标（用于色档挑选，跨块一致）
                local ringCx = baseX + ix * ringStep
                local ringCz = baseZ + iz * ringStep
                -- 出生点 10 米内不生成
                if ringCx * ringCx + ringCz * ringCz >= 100 then
                    -- 种子：块坐标 + 块内索引（跨块不会碰撞）
                    local seed = cx * 100000 + cz * 1000 + ix * 31 + iz
                    local stones = 8 + math.floor(hashUnit(seed, 0, 1) * 4)
                    local r = 1.5 + hashUnit(seed, 0, 2) * 0.5
                    local rockColor = PickRockColor(ringCx, ringCz)
                    for k = 0, stones - 1 do
                        local a = 2 * math.pi * k / stones
                        local sx = ringCx + math.cos(a) * r
                        local sz = ringCz + math.sin(a) * r
                        local h = 0.35 + hashUnit(seed, k, 3) * 0.15
                        addRock(g, sx, sz, h, rockColor)
                    end
                end
            end
        end

        -- ============ 小石（每 15 米 2~3 块）============
        local smallStep = 15
        local smallCount = math.floor(DECOR_CHUNK_SIZE / smallStep)
        for ix = 0, smallCount - 1 do
            for iz = 0, smallCount - 1 do
                local seed = cx * 200000 + cz * 2000 + ix * 41 + iz
                local cellCx = baseX + ix * smallStep
                local cellCz = baseZ + iz * smallStep
                local jx = hashUnit(seed, 0, 4)
                local jz = hashUnit(seed, 0, 5)
                local wx = cellCx + jx * smallStep
                local wz = cellCz + jz * smallStep
                -- 出生点 8 米内不生成
                if wx * wx + wz * wz >= 64 then
                    local n = 2 + math.floor(hashUnit(seed, 0, 6) * 2)
                    local rockColor = PickRockColor(cellCx, cellCz)
                    for k = 0, n - 1 do
                        local sx = wx + (hashUnit(seed, k, 7) - 0.5) * smallStep
                        local sz = wz + (hashUnit(seed, k, 8) - 0.5) * smallStep
                        local h = 0.20 + hashUnit(seed, k, 9) * 0.12
                        addRock(g, sx, sz, h, rockColor)
                    end
                end
            end
        end

        -- ============ 树（每 25 米一棵，成簇分布）============
        local treeStep = 25
        local treeCount = math.floor(DECOR_CHUNK_SIZE / treeStep)
        for ix = 0, treeCount - 1 do
            for iz = 0, treeCount - 1 do
                local seed = cx * 300000 + cz * 3000 + ix * 51 + iz
                local cellCx = baseX + ix * treeStep
                local cellCz = baseZ + iz * treeStep
                local jx = hashUnit(seed, 0, 21)
                local jz = hashUnit(seed, 0, 22)
                local wx = cellCx + (jx - 0.5) * treeStep * 0.7
                local wz = cellCz + (jz - 0.5) * treeStep * 0.7
                -- 出生点 30 米外才种树
                if wx * wx + wz * wz >= 900 then
                    -- 成簇：低频噪声（世界坐标驱动，跨块连续）
                    local cluster = valueNoise(wx * 0.008, wz * 0.008, 271)
                    if cluster > 0.35 then
                        local biome = valueNoise(wx * 0.003, wz * 0.003, 733)
                        local variant = valueNoise(wx * 0.02, wz * 0.02, 977)

                        local treeType
                        if biome < 0.35 then
                            treeType = (variant < 0.85) and "conifer" or "dead"
                        elseif biome > 0.65 then
                            if variant < 0.65 then treeType = "broadleaf"
                            elseif variant < 0.90 then treeType = "bush"
                            else treeType = "palm" end
                        else
                            if variant < 0.35 then treeType = "conifer"
                            elseif variant < 0.65 then treeType = "broadleaf"
                            elseif variant < 0.85 then treeType = "bush"
                            else treeType = "dead" end
                        end

                        ---@type number[]?
                        local trunkColor
                        ---@type number[]?
                        local leafColor
                        if treeType == "dead" then
                            trunkColor = TRUNK_DEAD
                            leafColor  = nil
                        elseif treeType == "bush" then
                            trunkColor = nil
                            leafColor  = LEAF_MID
                        elseif treeType == "palm" then
                            trunkColor = PickTrunkColor(wx, wz)
                            leafColor  = LEAF_PALM
                        else
                            trunkColor = PickTrunkColor(wx, wz)
                            leafColor  = PickLeafColor(wx, wz, treeType == "conifer")
                        end

                        local shadowR = 1.4
                        if treeType == "bush" then shadowR = 0.7 end
                        if treeType == "palm" then shadowR = 2.2 end
                        if treeType == "dead" then shadowR = 1.0 end
                        local gy = Terrain.GetHeight(wx, wz)
                        V.appendShadowDisc(shadowG, wx, wz, shadowR, gy + 0.05, 8)

                        if treeType == "conifer" then
                            addConifer(g, wx, wz, trunkColor, leafColor)
                        elseif treeType == "broadleaf" then
                            addBroadleaf(g, wx, wz, trunkColor, leafColor)
                        elseif treeType == "palm" then
                            addPalmTree(g, wx, wz, trunkColor, leafColor)
                        elseif treeType == "bush" then
                            addBush(g, wx, wz, leafColor)
                        elseif treeType == "dead" then
                            addDeadTree(g, wx, wz, trunkColor)
                        end
                    end
                end
            end
        end

        g:Commit()
        local mat = getDecorMaterial()
        if mat then g:SetMaterial(mat) end
        g.castShadows = false

        shadowG:Commit()
        local smat = V.getShadowMaterial()
        if smat then shadowG:SetMaterial(smat) end
        shadowG.castShadows = false

        loadedChunks_[key] = {
            node = node, shadowNode = shadowNode, cx = cx, cz = cz,
        }
    end

    --- 每帧驱动装饰块加载/卸载（由 Client.OnUpdate 调用）。
    ---
    --- 🔴 只在玩家跨越块边界时触发加载/卸载 —— 玩家在块内小范围移动
    ---    不会引起任何装饰变化。改设置面板也不触发（不再读 viewDistance）。
    ---@param dt number
    ---@param px number|nil 玩家世界坐标 X
    ---@param pz number|nil 玩家世界坐标 Z
    function Terrain.UpdateDecor(dt, px, pz)
        if not scene_ then return end
        if not px or not pz then return end

        local chunkX = WorldToChunk(px)
        local chunkZ = WorldToChunk(pz)

        -- 玩家跨块 → 重新收集需要加载的块 + 卸载超范围的块
        if chunkX ~= lastChunkX_ or chunkZ ~= lastChunkZ_ then
            lastChunkX_, lastChunkZ_ = chunkX, chunkZ

            -- 需要的块集合（3×3）
            local need = {}
            pendingChunks_ = {}
            for dx = -DECOR_LOAD_RADIUS, DECOR_LOAD_RADIUS do
                for dz = -DECOR_LOAD_RADIUS, DECOR_LOAD_RADIUS do
                    local cx, cz = chunkX + dx, chunkZ + dz
                    local key = cx .. "_" .. cz
                    need[key] = true
                    if not loadedChunks_[key] then
                        table.insert(pendingChunks_, { cx = cx, cz = cz })
                    end
                end
            end

            -- 卸载超出范围的块
            for key, chunk in pairs(loadedChunks_) do
                if not need[key] then
                    chunk.node:Remove()
                    chunk.shadowNode:Remove()
                    loadedChunks_[key] = nil
                end
            end
        end

        -- 每帧只构建 1 块（队列非空时）
        if #pendingChunks_ > 0 then
            local job = table.remove(pendingChunks_, 1)
            BuildDecorChunk(job.cx, job.cz)
        end
    end

    -- 注入
    Battle.Visual = Battle.Visual or {}
    Battle.Visual.Terrain = Terrain
end
return Terrain
