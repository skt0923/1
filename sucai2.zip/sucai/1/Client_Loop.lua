-- ============================================================
-- Client_Loop.lua：客户端主循环 + 其他玩家渲染（Client.lua 的兄弟文件）
--
-- 从 Client.lua 原样迁出三个全局函数：
--   · OnUpdate                      每帧主循环（引擎按全局名订阅 "Update"）
--   · UpdateRemotePlayerAnimations  其他玩家走路动画
--   · EnsureOtherPlayersBuilt       其他玩家模型补挂
--
-- ⚠️ 必须是**全局**函数：SubscribeToEvent 传字符串时引擎按全局名查找，
--    OnUpdate 由 Client.lua 的 Start() 订阅，OnScreenModeChanged /
--    ReapplyServerSettingsIfChanged 等仍留在 Client.lua。
--
-- 本文件自行 require 所需模块并建立 local 别名（require 有缓存，
-- 与 Client.lua 拿到的是同一张表；常量类如 TIME_DIRTY_INTERVAL
-- 在本文件重新声明一份，值必须与 Client.lua 保持一致）。
-- ============================================================
local Shared  = require("Shared")

-- 世界层 / 视觉层 / 战斗计算层
local World        = require("Battle_World")
local Visual       = require("Battle_Visual").Visual
local CombatBundle = require("Battle_Combat")

-- UI 层
local HUD    = require("UI_HUD")
local Panels = require("UI_Core")

-- 网络层 / 广告层
local Net = require("Client_Network")
local Ad  = require("Client_Ad")

local Data    = Shared.Data
local Notify  = Shared.Notify
local Terrain = Visual.Terrain
local Enemies = World.Enemies
local Items   = World.Items
local Effects = World.Effects
local Skills  = CombatBundle.Skills
local Combat  = CombatBundle.Combat

-- 跨函数共享的可变状态（与 Client.lua 同一张表）
---@type ClientState
local S = require("Client_State")

-- 玩家控制 / 攻击 / 死亡 / 拾取（与 Client.lua 同一模块表）
local Player = require("Client_Player")
local PlayerCtl         = Player
local UpdateAttack      = Player.UpdateAttack
local HandleEnemyKilled = Player.HandleEnemyKilled
local UpdateDeath       = Player.UpdateDeath
local TryBindPlayerNode = Player.TryBindPlayerNode
local CanPickDrop       = Player.CanPickDrop

-- 虚拟摇杆 / 捏合缩放
local Touch = require("Client_Touch")

-- 时长脏标记间隔（秒）—— 与 Client.lua 的同名 local 保持一致
local TIME_DIRTY_INTERVAL = 30.0

-- ============ 主循环 ============
-- ⚠️ 必须是全局函数：SubscribeToEvent 传字符串时引擎按全局名查找，
--    local function 不可见 → 报 "Could not find Lua function: OnUpdate"
---@param eventType string
---@param eventData VariantMap
function OnUpdate(eventType, eventData)
    local dt = eventData:GetFloat("TimeStep")
    if dt > 0.1 then dt = 0.1 end   -- 卡顿保护，避免单帧位移过大

    -- 等待服务器下发的玩家节点出现（REPLICATED 节点同步有延迟）
    if S.myId_ and not S.myNode_ then
        TryBindPlayerNode()
    end

    if not S.myNode_ then return end

    -- 给「其他玩家」的节点挂模型。
    -- ⚠️ 服务端为每个玩家创建 Player_<pid>（REPLICATED），但客户端此前只给
    --    「自己」那个挂模型（见 TryBindPlayerNode），其他玩家的节点是空壳 ——
    --    结果就是同服也看不见对方。这里补上。
    --    Player.Build 内部幂等（已有 PlayerRig 直接返回），每帧调用无副作用。
    EnsureOtherPlayersBuilt()

    local stats = Combat.ComputeStats(Data.value.equipment)
    -- 同步血量上限（强化装备后 maxHp 会变）
    if stats.maxHp ~= Data.value.maxHp then
        local ratio = (Data.value.maxHp > 0) and (Data.value.hp / Data.value.maxHp) or 1
        Data.value.maxHp = stats.maxHp
        -- ⚠️ ratio * maxHp 是浮点，取整保证 HP 全程为整数
        Data.value.hp = math.floor(math.min(stats.maxHp, math.max(1, ratio * stats.maxHp)))
    end

    -- 摇杆
    if S.joystick_ then
        S.joyX_, S.joyY_ = S.joystick_.x or 0, S.joystick_.y or 0
    end

    -- 记录本帧移动前的位置，用于判断「本帧是否发生位移」
    -- （自动战斗寻路 / 普攻贴近 / UpdateDeath 复活都会改本地权威位置，
    --   统一在帧末比较，比在各处埋 isMoving 标志更不容易漏）
    local prevPX_, prevPZ_ = S.localPlayerX_, S.localPlayerZ_

    PlayerCtl.Update(dt, stats)

    -- 双指捏合缩放视角距离
    Touch.UpdatePinchZoom()

    -- 自动战斗：优先捡掉落物（15m 内）。捡不到时，UpdateAttack 会主动寻怪。
    if Data.value.autoBattleOn and not Data.value.isStanding and not Data.value.isDead then
        -- 找 15m 内最近的「捡得起来」的掉落物
        local target = nil
        local minD = Player.AUTO_BATTLE_PICKUP_RANGE
        for _, gi in ipairs(Items.GetAll()) do
            local dist = Shared.Dist2D(S.localPlayerX_, S.localPlayerZ_, gi.x, gi.z)
            if dist < minD and CanPickDrop(gi) then minD = dist; target = gi end
        end
        -- 有掉落物就走向它（Items.Update 会在 2.2m 内自动拾取）
        if target and minD > 1.2 then
            local dx = target.x - S.localPlayerX_
            local dz = target.z - S.localPlayerZ_
            local dl = math.sqrt(dx * dx + dz * dz)
            if dl > 0.001 then
                local spd = stats.moveSpeed or Player.MOVE_SPEED_FALLBACK
                S.localPlayerX_ = S.localPlayerX_ + (dx / dl) * spd * dt
                S.localPlayerZ_ = S.localPlayerZ_ + (dz / dl) * spd * dt
                S.playerFacing_ = math.atan2(dx, dz)
            end
        end
    end

    -- 网络：2 秒周期上报 + flush 超时/重试（实现已迁到 Client_Network.lua）
    Net.Update(dt)

    -- 时长每秒扣减
    -- ⚠️ 无条件扣减：离线暂停由服务端存档层保证（时间走脏标记上报），
    --    客户端这里再拦一层是重复逻辑，且会在断线时误暂停。
    S.timeTickAccum_ = S.timeTickAccum_ + dt
    while S.timeTickAccum_ >= 1.0 do
        S.timeTickAccum_ = S.timeTickAccum_ - 1.0

        local d = Data.value
        local ss = Data.GetSettings()

        -- 在线时长
        if d.onlineTokenSeconds > 0 then
            d.onlineTokenSeconds = d.onlineTokenSeconds - 1
        end
        -- 自动续费：剩余 ≤ 5 秒就补一张（含 0 —— 新玩家初始就是 0，
        -- 靠每日赠送的在线卡直接开跑，不需要先去看广告）
        if d.onlineTokenSeconds <= 5 then
            if ss.autoUseOnlineToken
                and Shared.RemoveTokensFromInventory(d.inventory, "online", 1) then
                d.onlineTokenSeconds = d.onlineTokenSeconds + Shared.C.ONLINE_TOKEN_SECONDS
                Data.MarkDirty("inventory")
                Data.MarkDirty("time")
                Notify.Toast("自动使用在线卡，+" .. math.floor(Shared.C.ONLINE_TOKEN_SECONDS / 60) .. " 分钟")
            end
        end
        -- 续费后仍 ≤ 0 才罚站
        -- ⚠️ Net.initialDataReady：客户端刚连上、服务端还没推令牌时
        --    （此时背包为空，续费必然失败）不能判罚站，否则加载窗口内会闪一下罚站面板
        if d.onlineTokenSeconds <= 0 and Net.initialDataReady then
            d.isStanding = true
            d.autoBattleOn = false
        elseif d.onlineTokenSeconds > 0 then
            d.isStanding = false
        end

        -- 自动战斗不再单独计时：有在线时长就能自动战斗。
        -- 在线时长耗尽时由上面的罚站逻辑把 autoBattleOn 关掉。

        -- 自动维修：每 30 分钟修一次全身（走同一秒级计时器）
        Player.UpdateAutoRepair(1)
    end

    -- 5 分钟标记时长脏
    S.timeDirtyAccum_ = S.timeDirtyAccum_ + dt
    if S.timeDirtyAccum_ >= TIME_DIRTY_INTERVAL then
        S.timeDirtyAccum_ = 0
        Data.MarkDirty("time")
    end

    -- 战斗模块 Update
    if Combat.Update then Combat.Update(dt) end

    -- 怪物 AI
    Enemies.Update(dt, S.myNode_.position.x, S.myNode_.position.z, stats)

    -- 装饰块加载/卸载（玩家跨块边界时触发；玩家位置由本地权威变量提供）
    if Visual.Terrain.UpdateDecor then
        Visual.Terrain.UpdateDecor(dt, S.localPlayerX_, S.localPlayerZ_)
    end

    -- 攻击
    UpdateAttack(dt, stats)

    -- 技能（DoT / buff 过期）
    Skills.Update(dt, Enemies.GetAliveList(), function(enemy)
        HandleEnemyKilled(enemy)
    end)

    -- 掉落物 / 特效（用本地权威坐标，避免读到上一帧的节点位置）
    Items.Update(dt, S.localPlayerX_, S.localPlayerZ_)
    Effects.Update(dt)

    -- 共享 BOSS 动画（晶体花花瓣旋转 + 核心呼吸）
    for _, e in ipairs(Enemies.GetAliveList()) do
        if e.isSharedBoss and e.__nodeRef then
            Visual.Monster.Update(e.__nodeRef, dt)
        end
    end

    -- 死亡复活
    if Data.value.isDead then
        UpdateDeath(dt, stats)
    end

    -- ⚠️ 方案 B：把本地权威位置写回节点。
    --    必须放在所有会移动玩家的逻辑（PlayerCtl / 自动寻路 / UpdateAttack / UpdateDeath）
    --    **之后**，否则本帧后发生的移动要等到下一帧才反映到节点上（1 帧延迟 + 抖动）。
    --    每帧覆盖也能压掉 REPLICATED 偶尔推回来的服务端旧位置。
    S.myNode_.position = Vector3(
        S.localPlayerX_,
        Terrain.GetHeight(S.localPlayerX_, S.localPlayerZ_),
        S.localPlayerZ_)

    -- 驱动玩家模型动画（走路摆臂 / 转向）
    -- isMoving：本帧位置是否发生位移（对比帧首快照）
    local isMoving = (S.localPlayerX_ ~= prevPX_) or (S.localPlayerZ_ ~= prevPZ_)
    Visual.Player.Update(S.myNode_, dt, isMoving, S.playerFacing_)

    -- 其他玩家：插值逼近目标位置 + 驱动走路动画
    -- 位置插值放在这里（每帧），广播只是「目标点」，避免瞬移。
    -- 先把自身位置写给网络层：它据此判断对方是否超出广播范围（超了就隐藏模型）
    local mp = S.myNode_.position
    Net.selfX, Net.selfZ = mp.x, mp.z
    Net.UpdateRemotePlayers(dt)
    UpdateRemotePlayerAnimations(dt)

    -- 相机跟随（轨道式：由 S.camYaw_/S.camPitch_/S.camDist_ 决定位置，始终看向玩家）
    -- 平滑插值 + 地形避让：相机不会被地形挡住，也不会硬跟产生抖动。
    local p = S.myNode_.position
    if S.cameraNode_ then
        -- ① 平滑基准 Y（时间常数 0.8 秒）：吞掉地形 ±4 米起伏引起的上下抖动。
        --    ⚠️ 0.8 秒会让上坡时相机轻微滞后于玩家。这是低多边形风格下的
        --    有意取舍——宁可稍滞后，也不要让视角跟着地形每帧上下摇。
        if S.camSmoothY_ == nil then
            S.camSmoothY_ = p.y
        else
            local yT = math.min(1, dt * 1.25)
            S.camSmoothY_ = S.camSmoothY_ + (p.y - S.camSmoothY_) * yT
        end

        -- ② 理想机位（XZ 相对玩家固定偏移，Y 用平滑基准）
        local horiz = math.cos(S.camPitch_) * S.camDist_
        local vert  = math.sin(S.camPitch_) * S.camDist_
        local idealX = p.x + math.sin(S.camYaw_) * horiz
        local idealY = S.camSmoothY_ + vert + 1.3
        local idealZ = p.z + math.cos(S.camYaw_) * horiz

        -- ③ 地形避让（10 步采样，阈值 0.7 米）
        --    ⚠️ 采样步数从 8 提到 10：地形起伏加大后，快速抬升的坡面
        --    在 8 步采样下可能被跳过，导致相机穿地形。
        --    阈值从 0.4 提到 0.7：让相机在贴近地面时不那么敏感地触发避让，
        --    否则起伏地形会让相机频繁"顶到玩家脸上"。
        local ex, ey, ez = p.x, S.camSmoothY_ + 1.3, p.z
        local rawFinalT = 1.0
        for i = 1, 10 do
            local tt = i / 10
            local cx = ex + (idealX - ex) * tt
            local cy = ey + (idealY - ey) * tt
            local cz = ez + (idealZ - ez) * tt
            if cy < Terrain.GetHeight(cx, cz) + 0.7 then
                rawFinalT = (i - 1) / 10
                break
            end
        end

        -- ④ 避让系数平滑（0.25 秒）
        --    ⚠️ 从 0.15 秒提到 0.25 秒：地形起伏加大后，避让触发更频繁，
        --    平滑太短会让相机"弹"得太快，观感像被地形推来推去。
        local tT = math.min(1, dt * 4.0)
        S.camSmoothT_ = S.camSmoothT_ + (rawFinalT - S.camSmoothT_) * tT
        local finalT = S.camSmoothT_

        -- ⑤ 应用避让
        local tx = ex + (idealX - ex) * finalT
        local ty = ey + (idealY - ey) * finalT
        local tz = ez + (idealZ - ez) * finalT

        -- ⑥ 直接设置（X/Z 不做平滑，避免滞后导致"相机转动"错觉）
        S.cameraNode_.position = Vector3(tx, ty, tz)
        S.cameraNode_:LookAt(Vector3(p.x, S.camSmoothY_ + 1.3, p.z))

    end

    -- ⚠️ 这里曾有「每帧把 lightNode.position 设为玩家上方」的代码，已随 SpotLight 一起删除。
    --    那对方向光是 no-op（position 不参与光照/阴影计算），只在 SpotLight 下有意义。
    --    现已回退方向光，故删除。阴影改由几何层假阴影解决（Battle_Visual 的 ShadowDisc）。

    -- 太阳跟随玩家（不是相机）：保持"无限远天体"的视觉。
    -- 每帧只更新位置 = 玩家位置 + 固定方向 × 距离。
    -- 相机转动时这个值不变 → 太阳在世界空间不动。
    if S.sunNode_ and S.sunDir_ and S.myNode_ then
        local pp = S.myNode_.position
        S.sunNode_.position = Vector3(
            pp.x + S.sunDir_.x * S.sunDist_,
            pp.y + S.sunDir_.y * S.sunDist_,
            pp.z + S.sunDir_.z * S.sunDist_)
    end

    -- 广告冷却
    local d = Data.value
    if d.adCooldownLeft > 0 then
        d.adCooldownLeft = math.max(0, d.adCooldownLeft - dt)
    end

    -- 广告无回调兜底（实现见 Client_Ad.Tick）
    Ad.Tick(dt)

    -- 位置与脏数据已合并到上面的 2 秒同步

    -- UI
    HUD.Update(dt)
    HUD.UpdateStats(dt)     -- A11：分辨率/FPS（内部按 0.25 秒节流）
    Panels.UpdateStanding(dt)
end


-- ============ 其他玩家动画 ============
--- 驱动其他玩家的走路动画。
--- 位置由 Net.UpdateRemotePlayers 插值写入，这里只负责判断移动状态并驱动模型。
---
--- ⚠️ 「是否在移动」不能用逐帧位置差判断：
---    位置是指数插值，接近目标时单帧位移会跌破任何阈值，
---    于是 isMoving 在 true/false 之间反复跳，腿在「摆动/站直」间弹跳 = 抽搐。
---    改用「最近是否收到过位置广播」：服务端在位移 > 0.1 米时才广播，
---    所以收到广播本身就意味着对方在动；超过 0.35 秒没广播即视为停下。
---@param dt number
function UpdateRemotePlayerAnimations(dt)
    if not S.scene_ then return end
    local now = Net.elapsedTime or 0
    local n = S.scene_:GetNumChildren()
    for i = 1, n do
        local child = S.scene_:GetChild(i - 1)
        if child and child.name and child.name:sub(1, 7) == "Player_" then
            local pid = child.name:sub(8)
            if pid ~= S.myId_ then
                -- 最近 0.35 秒内收到过位置广播 → 在移动
                -- （0.35 秒 = 广播间隔 0.2 秒的 1.75 倍，容忍丢一两个包）
                local t = Net.remoteTargets[pid]
                local isMoving = (t and t.lastUpdateTime
                    and (now - t.lastUpdateTime) < 0.35) or false

                -- 朝向只认「网络层缓存的目标角度」。
                -- ⚠️ 不要用 child.rotation:YawAngle() 兜底：那是父节点当前角度，
                --    会和 Player.Update 内部的平滑叠加（朝向翻倍），
                --    而且父节点旋转本身被我们强制归零，读出来恒为 0 —— 兜底没意义还会误导。
                --    还没收到过广播（targetAngle 为 nil）时保持当前朝向不动。
                local targetAngle = Net.GetRemoteTargetAngle(pid)
                if targetAngle then
                    Visual.Player.Update(child, dt, isMoving, targetAngle)
                else
                    -- 尚无朝向数据：只驱动走路动画，不碰朝向
                    Visual.Player.Update(child, dt, isMoving, nil)
                end
            end
        end
    end
end

-- ============ 其他玩家模型 ============
-- 服务端为每个玩家建 Player_<pid>（REPLICATED），但客户端原先只给自己那个挂模型，
-- 其他玩家的节点始终是空壳 —— 同服也看不见对方。
-- 这里扫描场景里所有 Player_* 节点，除自己外都补上模型。
-- Player.Build 幂等，重复调用只做一次 GetChild 检查。
function EnsureOtherPlayersBuilt()
    if not S.scene_ or not S.myId_ then return end
    local n = S.scene_:GetNumChildren()
    for i = 1, n do
        local child = S.scene_:GetChild(i - 1)
        if child and child.name and child.name:sub(1, 7) == "Player_" then
            local pid = child.name:sub(8)
            if pid ~= S.myId_ then
                if not child:GetChild("PlayerRig", false) then
                    Visual.Player.Build(child)
                    print("[Client] 其他玩家模型已挂载：" .. child.name)
                end
            end
        end
    end
end

