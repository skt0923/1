-- ============================================================
-- Client_Network.lua：客户端网络层（同步 / 事件中枢）
--
-- 职责：
--   · 上报存档（SYNC_REQUEST：位置 + 脏数据 + 待上架队列）
--   · flush 机制（带 Seq 的请求 → SYNC_ACK 回执 → 回调 / 重试 / 超时）
--   · 服务端下行事件的全部处理器（AssignPlayer / InvSync / 市场 / 邮箱 /
--     共享 Boss / 上架回执 / 每日赠送 …）
--
-- 与 Client.lua 的边界：
--   ➜ 游戏侧状态（玩家坐标 / 朝向 / 节点 / 玩家 id）通过 Net.Init(ctx)
--     注入的**访问器**读写 —— 网络层不持有游戏对象引用，也不碰渲染。
--   ➜ 网络侧状态（连接 / Seq / flush / 上架队列 / 首次权威数据标记）
--     保存在本模块，Client.lua 以 Net.conn、Net.pendingListings … 访问。
--
-- 依赖：Shared + Battle_World（共享 Boss 的本地渲染/移除）+ Battle_Visual（地形高度）。
-- ============================================================
local Shared  = require("Shared")
local Data    = Shared.Data
local Notify  = Shared.Notify
local World   = require("Battle_World")

local Enemies = World.Enemies
local Terrain = require("Battle_Visual").Visual.Terrain
local Panels  = require("UI_Core")
local HUD     = require("UI_HUD")

local Net = {}

-- ============ 网络侧状态 ============
---@type Connection|nil
Net.conn = nil
---@type integer  自增的 flush 序号（服务端原样回 ACK）
Net.syncSeq = 0
---@type table|nil  { seq, onAck, timer, retried }
Net.pendingFlush = nil
Net.FLUSH_TIMEOUT = 3.0
--- 待上架意图队列（脏标记顺风车 + 失败回滚）
--- 结构：[ { ClientId, ItemId, Price, Quantity, Rollback } ]
---@type table[]
Net.pendingListings = {}
--- 是否已收到服务端首次权威数据（AssignPlayer 或首次 InvSync）。
--- ⚠️ 防「加载窗口短暂罚站」：客户端刚连上时 onlineTokenSeconds 还是本地默认 0、
---    背包也是空的（续费必然失败），若直接判罚站会在加载期间闪出罚站面板。
Net.initialDataReady = false

--- 待弹出的新手礼包件数（事件可能早于 UI 就绪到达，先存下来，UI 就绪后补弹）。
---@type integer|nil
Net.pendingStarterGift = nil
--- UI 是否已初始化完成（SetupUI 里置 true）。
---@type boolean
Net.uiReady = false

--- 市场列表缓存（仅在进入市场 / 切页签 / 手动操作时刷新）
-- ============ 拍卖行分页 ============
Net.marketPage_   = 0
-- 当前筛选条件。⚠️ 必须存在这里而不是 UI 层：
--    翻页时要带上同一套筛选，否则第 2 页会变成「无筛选」的结果。
Net.marketFilter_ = { Category = "all", SubCat = "", Quality = "", Tab = "buy" }

--- 更新筛选条件（UI 在分类/Tab 变化时调用，页码由调用方重置）。
---@param f table { Category?, SubCat?, Quality?, Tab? }
function Net.SetMarketFilter(f)
    local cur = Net.marketFilter_
    if f.Category ~= nil then cur.Category = f.Category end
    if f.SubCat   ~= nil then cur.SubCat   = f.SubCat   end
    if f.Quality  ~= nil then cur.Quality  = f.Quality  end
    if f.Tab      ~= nil then cur.Tab      = f.Tab      end
end

--- 请求某一页挂单（带当前筛选）。
---@param page integer|nil 0-based；省略则沿用上次页码
function Net.RequestMarketPage(page)
    if not Net.conn then return end
    Net.marketPage_ = math.max(0, page or Net.marketPage_ or 0)
    local f = Net.marketFilter_
    Net.conn:SendRemoteEvent(Shared.EVENTS.REQUEST_MARKET_PAGE, true,
        Shared.ToVariantMap({
            Page     = Net.marketPage_,
            PageSize = Shared.C.MARKET_PAGE_SIZE or 100,
            Category = f.Category or "all",
            SubCat   = f.SubCat or "",
            Quality  = f.Quality or "",
            Tab      = f.Tab or "buy",
        }))
end

--- 周期同步计时（2 秒上报一次）
local syncTimer_ = 0

-- ============ 游戏侧注入 ============
--- ⚠️ 默认实现全是空操作：Init 之前若真的有事件进来（不该发生），
---    也只会退化成「不做位置/节点操作」，不会因为 nil 调用崩掉。
---@type table
local ctx = {
    ---@return number, number
    getPlayerPos     = function() return 0, 0 end,
    ---@return number
    getPlayerFacing  = function() return 0 end,
    getMyNode        = function() return nil end,
    getMyId          = function() return nil end,
    setMyId          = function(_) end,
    setPlayerPos     = function(_, _) end,
    getScene         = function() return nil end,
    bindPlayerNode   = function() end,
    applyServerSettings = function() end,
}

--- 注入游戏侧访问器 / 回调（Client.lua 在 Start 里调用一次）
---@param c table
function Net.Init(c)
    for k, v in pairs(c) do ctx[k] = v end
end

-- ============ 每帧驱动 ============
--- 2 秒周期上报 + flush 超时/重试
--- （原 Client.OnUpdate 里的「位置 + 脏数据同步」「flush 超时检查」两段）
---@param dt number
function Net.Update(dt)
    syncTimer_ = syncTimer_ + dt
    if syncTimer_ >= Shared.C.SYNC_INTERVAL and Net.conn then
        syncTimer_ = 0
        Net.SyncToServer()
    end

    if Net.pendingFlush then
        Net.pendingFlush.timer = Net.pendingFlush.timer - dt
        if Net.pendingFlush.timer <= 0 then
            if not Net.pendingFlush.retried then
                Net.pendingFlush.retried = true
                Net.pendingFlush.timer = Net.FLUSH_TIMEOUT
                Net.SyncToServer()
            else
                -- 重试两次仍失败 → 进度同步失败门（可手动重试，比 Toast 更有出路）
                Panels.ShowSaveFailedGate()
                local cb = Net.pendingFlush.onAck
                Net.pendingFlush = nil
                -- 失败也要回调（ok=false）：否则调用方（如邮箱「全部领取」）
                -- 会一直停在「领取中…」的禁用状态，再也点不动。
                if cb then cb(false) end
            end
        end
    end
end

-- ============ 上报存档 ============
--- 上报存档（客户端权威 + 脏标记）。
---
--- ⚠️ 权威边界：
---   · 客户端权威：inventory / equipment / gold / level / settings /
---     autoDecompose / time（脏标记上报）
---   · 服务端权威：mails / bank / boss / market 成交（服务端推送）
---
--- 客户端只上报本地已发生的改变，服务端不主动下发这些字段。
function Net.SyncToServer()
    if not Net.conn or not ctx.getMyNode() then return end
    local px, pz = ctx.getPlayerPos()
    local payload = {
        X = px,
        Y = Terrain.GetHeight(px, pz),
        Z = pz,
        -- ⚠️ 朝向读 playerFacing_（经 ctx.getPlayerFacing 注入）：
        --    玩家节点的 rotation 从未被移动逻辑更新过，一直是初始 0，
        --    直接读节点朝向会导致其他玩家永远看到你面朝同一方向。
        Angle = ctx.getPlayerFacing() or 0,
    }

    local sentFields = {}

    if Data.HasDirty("inventory") then
        payload.Inventory = cjson.encode(Data.value.inventory)
        sentFields.inventory = true
    end
    if Data.HasDirty("equipment") then
        payload.Equipment = cjson.encode(Data.value.equipment)
        sentFields.equipment = true
    end
    if Data.HasDirty("gold") then
        payload.Gold = Data.value.gold
        sentFields.gold = true
    end
    if Data.HasDirty("level") then
        -- 等级石 = 等级：上报等级石本身 + 计算后的等级
        payload.Level = Data.GetLevel()
        payload.LevelStone = cjson.encode(Data.value.levelStone or {})
        sentFields.level = true
    end
    if Data.HasDirty("time") then
        payload.OnlineTokenMinutes = math.floor(Data.value.onlineTokenSeconds / 60)
        sentFields.time = true
    end
    -- 设置（相机 / 界面开关 / 自动续费）：已完全客户端化，不再上报。
    -- 自动分解开关（服务端存档留一份，换设备后设置不丢）
    if Data.HasDirty("autoDecompose") then
        payload.AutoDecompose     = cjson.encode(Data.value.autoDecompose)
        payload.AutoDecomposeUnid = cjson.encode(Data.value.autoDecomposeUnid)
        sentFields.autoDecompose = true
    end
    -- 自动维修开关（服务端存档留一份，换设备后设置不丢）
    if Data.HasDirty("autoRepair") then
        payload.AutoRepair = Data.value.autoRepair and 1 or 0
        sentFields.autoRepair = true
    end
    -- 宠物系统（客户端权威）
    if Data.HasDirty("pets") then
        payload.Pets = cjson.encode(Data.value.pets or {})
        sentFields.pets = true
    end
    if Data.HasDirty("petGacha") then
        payload.PetGacha = cjson.encode(Data.value.petGacha or {})
        sentFields.petGacha = true
    end
    -- 天赋树（客户端权威）
    if Data.HasDirty("bdTree") then
        payload.BDTree = cjson.encode(Data.value.bdTree or {})
        sentFields.bdTree = true
    end
    -- 广告计数（客户端权威）：不报的话服务端永远保留 0，
    -- 每次重连下发 AdCountToday=0 就把本地计数清零 → 每日上限失效。
    if Data.HasDirty("ad") then
        payload.AdCountToday = Data.value.adCountToday
        sentFields.ad = true
    end

    -- flush 时带 Seq
    if Net.pendingFlush then
        payload.Seq = Net.pendingFlush.seq
    end
    -- 待上架队列（不随发送清除，等服务端 SYNC_ACK 回执）
    if #Net.pendingListings > 0 then
        payload.PendingListings = cjson.encode(Net.pendingListings)
    end

    Net.conn:SendRemoteEvent(Shared.EVENTS.SYNC_REQUEST, true, Shared.ToVariantMap(payload))
    Data.ClearDirty(sentFields)
end

--- 触发一次带 Seq 的 flush，等服务端 SYNC_ACK 后回调
---@param onAck fun(ok: boolean)|nil 成功/失败都会回调一次（失败时 ok=false）
function Net.RequestFlush(onAck)
    if not Net.conn then
        if onAck then onAck(false) end
        return
    end
    Net.syncSeq = Net.syncSeq + 1
    Net.pendingFlush = { seq = Net.syncSeq, onAck = onAck, timer = Net.FLUSH_TIMEOUT, retried = false }
    Net.SyncToServer()
end

--- 立即同步（不等 2 秒周期）
function Net.ForceSyncNow()
    if Net.conn then Net.SyncToServer() end
end

--- 只做一次「等 ACK 的 flush」，不额外发别的事件。
--- 适合「脏数据自带意图」的场景（例如上架：意图在 Net.pendingListings 里，
--- Net.SyncToServer 会一并带上去，不需要再构造一个空请求）。
---@param onDone fun(ok: boolean)|nil
function Net.FlushOnly(onDone)
    if not Net.conn then
        if onDone then onDone(false) end
        return
    end
    Net.RequestFlush(onDone)
end

--- 先 flush（把本地脏数据推给服务端），成功后再发一条远程事件。
---
--- ⚠️ 为什么必须按顺序：
---   服务端对「背包满」的判断基于它手里的背包。若玩家刚捡到东西还没上报就领邮件/
---   买东西，服务端会拿旧背包判定为满，把物品留在邮箱里（玩家看到「领取失败」）。
---   先 flush 再发写操作，服务端看到的才是最新状态。
---@param eventName string
---@param payload table|nil
---@param onDone fun(ok: boolean)|nil 失败（含 flush 超时）时 ok=false，且不会发送事件
function Net.FlushThenSend(eventName, payload, onDone)
    if not Net.conn then
        if onDone then onDone(false) end
        return
    end
    local sent = false
    Net.RequestFlush(function(ok)
        if sent then return end     -- 成功/失败只会回调一次，防御性去重
        sent = true
        if not ok then
            Notify.Toast("网络不稳定，请重试")
            if onDone then onDone(false) end
            return
        end
        Net.conn:SendRemoteEvent(eventName, true, Shared.ToVariantMap(payload or {}))
        if onDone then onDone(true) end
    end)
end

-- ============ 网络事件 ============
---@param eventType string
---@param eventData VariantMap
function Net.OnSyncAck(eventType, eventData)
    local seq = eventData:GetInt("Seq")

    -- 处理上架结果：成功的从队列移除；失败的移除 + 回滚本地物品
    local resultsStr = eventData:GetString("ListingResults")
    if resultsStr and resultsStr ~= "" then
        local results = Shared.SafeDecode(resultsStr)
        if type(results) == "table" then
            for _, r in ipairs(results) do
                local clientId = r.ClientId
                for i = #Net.pendingListings, 1, -1 do
                    local pl = Net.pendingListings[i]
                    if pl.ClientId == clientId then
                        if r.Ok ~= 1 then
                            local rb = pl.Rollback
                            if rb then
                                if rb.Type == "append" and rb.Item then
                                    table.insert(Data.value.inventory, rb.Item)
                                elseif rb.Type == "addCount" and rb.ItemId then
                                    local found = false
                                    for _, it in ipairs(Data.value.inventory) do
                                        if it.id == rb.ItemId then
                                            it.count = (it.count or 1) + (rb.Count or 0)
                                            found = true
                                            break
                                        end
                                    end
                                    if not found then
                                        -- 物品已被分解/卖掉，无法回滚到具体堆 → 按原类型重建
                                        local newId = "rb_" .. tostring(os.time())
                                            .. tostring(math.random(1000, 9999))
                                        if rb.ItemKind == "token" then
                                            local disp = Shared.TOKEN_TYPES[rb.TokenType or "online"]
                                            table.insert(Data.value.inventory, {
                                                id = newId,
                                                type = Shared.TokenTypeKey(rb.TokenType or "online"),
                                                tokenType = rb.TokenType or "online",
                                                count = rb.Count or 1,
                                                icon = disp and disp.icon or "🎟️",
                                                name = disp and disp.name or "在线卡",
                                                quality = "normal",
                                            })
                                        elseif rb.ItemKind == "spirit" then
                                            local disp = Shared.SPIRIT_DISPLAY[rb.SpiritType or "normal"]
                                            table.insert(Data.value.inventory, {
                                                id = newId,
                                                type = "spirit",
                                                spiritType = rb.SpiritType or "normal",
                                                count = rb.Count or 1,
                                                icon = disp and disp.icon or "⚪",
                                                name = disp and disp.name or "精魄",
                                                quality = rb.SpiritType or "normal",
                                            })
                                        elseif rb.ItemKind == "summonScroll" then
                                            local disp = Shared.SUMMON_SCROLL[rb.ScrollType or "normal"]
                                                or { icon = "📜", name = "召唤卷" }
                                            table.insert(Data.value.inventory, {
                                                id = newId,
                                                type = "summonScroll",
                                                scrollType = rb.ScrollType or "normal",
                                                count = rb.Count or 1,
                                                icon = disp.icon,
                                                name = disp.name,
                                                quality = rb.ScrollType or "normal",
                                            })
                                        else
                                            local disp = Shared.FRAGMENT_DISPLAY[rb.FragmentType or "normal"]
                                            table.insert(Data.value.inventory, {
                                                id = newId,
                                                type = "fragment",
                                                fragmentType = rb.FragmentType or "normal",
                                                count = rb.Count or 1,
                                                icon = disp and disp.icon or "⬜",
                                                name = disp and disp.name or "碎片",
                                                quality = rb.FragmentType or "normal",
                                            })
                                        end
                                    end
                                end
                                Data.MarkDirty("inventory")
                            end
                            -- 服务端拒绝原因码 → 玩家看得懂的话。
                            -- 原来直接 tostring(reason) 会显示 "slot_full" 这种内部码。
                            local REASON_TEXT = {
                                slot_full    = "上架格子已满（最多 "
                                    .. (Shared.C.MARKET_SLOT_MAX or 12)
                                    .. " 件），请先下架一些物品",
                                bad_price    = "售价无效，必须大于 0",
                                bad_quantity = "上架数量超过持有数量",
                                bad_item     = "物品信息无效",
                                not_found    = "物品已不在背包",
                                market_full  = "市场挂单已满，请稍后再试",
                            }
                            local reason = tostring(r.Reason or "")
                            Notify.Toast("上架失败："
                                .. (REASON_TEXT[reason] or reason ~= "" and reason
                                    or "请稍后重试"))
                        end
                        table.remove(Net.pendingListings, i)
                        break
                    end
                end
            end
        end
    end

    if Net.pendingFlush and Net.pendingFlush.seq == seq then
        local cb = Net.pendingFlush.onAck
        Net.pendingFlush = nil
        if cb then cb(true) end
    end
end

--- 召唤卷结果回包（击杀达标 roll / 主动使用卷，共用此回包）。
---@param eventType string
---@param eventData VariantMap
function Net.OnSummonScrollResult(eventType, eventData)
    local success = eventData:GetInt("Success") == 1
    local reason  = eventData:GetString("Reason")
    if reason and reason ~= "" then
        Notify.Toast(reason, success and "#7affa0" or "#ff7878")
    end
    if success then
        -- 服务端已 PushInventory，这里只需重建已打开的背包面板
        Panels.RefreshIfOpen("inventory", Panels.OpenInventory)
    end
end

---@param eventType string
---@param eventData VariantMap
function Net.OnServerToast(eventType, eventData)
    local text = eventData:GetString("Text")
    if text and text ~= "" then Notify.Toast(text) end
end

---@param eventType string
---@param eventData VariantMap
function Net.OnKicked(eventType, eventData)
    Data.MarkDirty("inventory")
    Data.MarkDirty("equipment")
    Data.MarkDirty("gold")
    Data.MarkDirty("level")
    Data.MarkDirty("time")
    Data.MarkDirty("settings")
    if Net.conn then
        local p = ctx.getMyNode() and ctx.getMyNode().position or Vector3(0, 0, 0)
        local payload = {
            X = p.x, Y = p.y, Z = p.z,
            Inventory = cjson.encode(Data.value.inventory),
            Equipment = cjson.encode(Data.value.equipment),
            Gold = Data.value.gold,
            Level = Data.GetLevel(),
            OnlineTokenMinutes = math.floor(Data.value.onlineTokenSeconds / 60),
        }
        if #Net.pendingListings > 0 then
            payload.PendingListings = cjson.encode(Net.pendingListings)
        end
        Net.conn:SendRemoteEvent(Shared.EVENTS.SYNC_REQUEST, true, Shared.ToVariantMap(payload))
    end
    -- 弹顶号门（不再是纯 Toast）：门里提供「顶号登录」按钮，玩家有出路
    Panels.ShowDuplicateGate()
end

---@param eventType string
---@param eventData VariantMap
function Net.OnAssignPlayer(eventType, eventData)
    ctx.setMyId(eventData:GetString("PlayerId"))
    Data.SetPlayerId(ctx.getMyId())
    print("[Client] 收到 AssignPlayer，PlayerId=" .. tostring(ctx.getMyId()))

    -- 先应用服务端配置（品质权重/技能池/强化率等），再应用玩家数据，
    -- 否则数据里的品质名、词条定义可能还是本地默认值。
    local configStr = eventData:GetString("Config")
    if configStr and configStr ~= "" then
        local cfg = Shared.SafeDecode(configStr)
        if cfg then Shared.ApplyServerConfig(cfg) end
    end

    Data.ApplyServerPayload({
        Inventory          = eventData:GetString("Inventory"),
        Equipment          = eventData:GetString("Equipment"),
        Gold               = eventData:GetInt("Gold"),
        Level              = eventData:GetInt("Level"),
        BagPageCount       = eventData:GetInt("BagPageCount"),
        Mails              = eventData:GetString("Mails"),
        MailTotal          = eventData:GetInt("MailTotal"),
        MailGoldTotal      = eventData:GetInt("MailGoldTotal"),
        MailItemTotal      = eventData:GetInt("MailItemTotal"),
        OnlineTokenMinutes = eventData:GetInt("OnlineTokenMinutes"),
        AdCountToday       = eventData:GetInt("AdCountToday"),
        -- 宠物系统（换设备/重连时用服务端存档兜底）
        Pets               = eventData:GetString("Pets"),
        PetGacha           = eventData:GetString("PetGacha"),
        -- 天赋树（换设备/重连时用服务端存档兜底）
        BDTree             = eventData:GetString("BDTree"),
    })

    -- 自动分解开关（已鉴 / 未鉴两套）：换设备登录时本地没有，用服务端下发的整表覆盖
    local adStr = eventData:GetString("AutoDecompose")
    if adStr and adStr ~= "" then
        local ad = Shared.SafeDecode(adStr)
        if type(ad) == "table" then Data.value.autoDecompose = ad end
    end
    local adUnidStr = eventData:GetString("AutoDecomposeUnid")
    if adUnidStr and adUnidStr ~= "" then
        local ad = Shared.SafeDecode(adUnidStr)
        if type(ad) == "table" then Data.value.autoDecomposeUnid = ad end
    end
    -- 自动维修开关：服务端存档权威，换设备登录时覆盖本地
    Data.value.autoRepair = (eventData:GetInt("AutoRepair") == 1)

    -- 等级石
    local lsStr = eventData:GetString("LevelStone")
    if lsStr and lsStr ~= "" then
        local ls = Shared.SafeDecode(lsStr)
        if type(ls) == "table" and ls.level then
            Data.value.levelStone = ls
        else
            Data.value.levelStone = nil
        end
    end
    Data.value.levelStoneGiftReceived = (eventData:GetInt("LevelStoneGiftReceived") == 1)

    -- 首次权威数据到达：此后才允许判罚站（见 OnUpdate 时长段）
    Net.initialDataReady = true

    Panels.SetMailTotal(Data.value.mailTotal or 0)

    -- 钱庄存款
    local bankStr = eventData:GetString("BankDeposits")
    if bankStr and bankStr ~= "" then
        local bd = Shared.SafeDecode(bankStr)
        if type(bd) == "table" then
            Data.value.bankDeposits = bd
            -- 给旧存档里的存款补 accumulatedInterest
            for _, dep in ipairs(bd) do
                if dep.accumulatedInterest == nil then dep.accumulatedInterest = 0 end
            end
        end
    end
    Data.value.bankTodayEarnings = eventData:GetInt("BankTodayEarnings") or 0

    -- 服务端回传的设置（相机 / 视野 / 开关）已并入 Data，立即生效一次：
    -- Start() 里用的是默认值，这里要用真实设置覆盖（否则本次会话一直是默认相机/雾）
    -- （首次 AssignPlayer 带的是服务端内存里的设置；云存档恢复后 PushInventory
    --   会再推一次真实设置，由 Net.OnInvSync 里的同一函数按需生效）
    ctx.applyServerSettings()

    -- 恢复上次下线时的位置：服务端下发 X/Z 到本地权威变量
    local sx = eventData:GetFloat("X")
    local sz = eventData:GetFloat("Z")
    ctx.setPlayerPos(sx or 0, sz or 0)

    ctx.bindPlayerNode()

    -- ⚠️ 上线后立即上报一次位置：其他玩家眼里的你在服务端创建节点时是 (0,0,0)，
    --    需要这次上报触发 PLAYER_MOVE 广播，才会跳到真实坐标。
    Net.ForceSyncNow()
end

---@param eventType string
---@param eventData VariantMap
function Net.OnInvSync(eventType, eventData)
    Data.ApplyServerPayload({
        Inventory          = eventData:GetString("Inventory"),
        Equipment          = eventData:GetString("Equipment"),
        Gold               = eventData:GetInt("Gold"),
        Level              = eventData:GetInt("Level"),
        BagPageCount       = eventData:GetInt("BagPageCount"),
        Mails              = eventData:GetString("Mails"),
        MailTotal          = eventData:GetInt("MailTotal"),
        MailGoldTotal      = eventData:GetInt("MailGoldTotal"),
        MailItemTotal      = eventData:GetInt("MailItemTotal"),
        OnlineTokenMinutes = eventData:GetInt("OnlineTokenMinutes"),
        -- 宠物系统（服务端随背包一起下发；空结构由 ApplyServerPayload 校验拦截）
        Pets               = eventData:GetString("Pets"),
        PetGacha           = eventData:GetString("PetGacha"),
        -- 天赋树（服务端随背包一起下发；空结构由 ApplyServerPayload 校验拦截）
        BDTree             = eventData:GetString("BDTree"),
        -- Force=1：服务端刚算好的权威快照（邮件领取/市场购买/每日赠送），
        -- 客户端即使本地 dirty 也要接受，否则界面会停在旧数据上
        Force              = eventData:GetInt("Force"),
    })

    -- 等级石（服务端下发，覆盖本地）
    -- ⚠️ 与 Pets 一致加 dirty 门控：防"刚升级等级石、上报未落库时被旧值覆盖"
    do
        local force = (eventData:GetInt("Force") == 1)
        local lsStr = eventData:GetString("LevelStone")
        if lsStr and lsStr ~= "" and (force or not Data.HasDirty("level")) then
            local ls = Shared.SafeDecode(lsStr)
            if type(ls) == "table" and ls.level then
                Data.value.levelStone = ls
            else
                Data.value.levelStone = nil
            end
        end
        -- giftReceived 是服务端单向标志（客户端从不上报）→ 无条件接受
        Data.value.levelStoneGiftReceived = (eventData:GetInt("LevelStoneGiftReceived") == 1)
    end

    -- 首次权威数据到达：此后才允许判罚站（见 OnUpdate 时长段）
    Net.initialDataReady = true

    Panels.SetMailTotal(Data.value.mailTotal or 0)
    -- 云存档恢复后服务端会补推一次真实设置 → 这里按需生效（值没变则不重建装饰）
    ctx.applyServerSettings()

    -- 等级或金币变化时刷新角色面板（升级/降级/升级按钮状态）
    -- ⚠️ 必须走 RefreshIfOpen，**不能直接调 Panels.OpenCharacter()**：
    --    玩家在角色面板点「升级」会弹出栈式确认框（见 UI_Core.BuildDialog），
    --    此时 currentId_ 仍是 "character"（栈式弹窗沿用父 id）。
    --    直接 OpenCharacter 会走 OpenModal → CloseCurrent 的级联关闭，
    --    把玩家刚打开的确认框一起关掉 —— 表现为「点升级按钮，二次确认弹窗
    --    一直不出现」。RefreshIfOpen 内部有「叠加面板在顶时不重建父面板」的保护。
    Panels.RefreshIfOpen("character", Panels.OpenCharacter)
end

--- 玩家昵称映射（pid → TapTap 昵称），由服务端广播。
---@type table<string, string>
Net.playerNames = {}

--- 收到昵称映射（服务端上线/下线时全量重推）
---@param eventType string
---@param eventData VariantMap
function Net.OnPlayerInfo(eventType, eventData)
    local names = Shared.SafeDecode(eventData:GetString("Names"))
    if type(names) ~= "table" then return end
    Net.playerNames = names
end

--- 其他玩家的目标位置缓存。
--- key = pid，value = { tx, ty, tz, tangle, lastMoveTime }
--- 收到广播只更新目标；实际位置由 Net.UpdateRemotePlayers 每帧插值逼近。
--- ⚠️ 直接设位置会「瞬移」—— 广播是离散的（5 次/秒），
---    必须补间才能像网游那样连续移动。
---@type table<string, table>
Net.remoteTargets = {}

--- 超出这个距离就隐藏对方模型（米）。
---
--- 服务端只广播 100 米内的位置（Server.lua 的 BCAST_RADIUS），超出的玩家收不到更新，
--- 模型会**停在最后位置**。不隐藏的话，远处会堆一片静止的「假人」，
--- 看起来就是「原地踏步」。
---
--- 比服务端 100 米多 10 米缓冲：玩家在边界来回走时，
--- 广播断掉的瞬间模型还没被隐藏，不会闪烁。
local HIDE_RADIUS = 110.0
local HIDE_RADIUS_SQ = HIDE_RADIUS * HIDE_RADIUS

--- 我自己的位置（由 Client.OnUpdate 每帧写入，用于上面的距离判断）。
Net.selfX, Net.selfZ = 0, 0

--- 其他玩家的位置广播（方案 B：位置不走 REPLICATED，走自定义事件）
---@param eventType string
---@param eventData VariantMap
function Net.OnPlayerMoveBroadcast(eventType, eventData)
    local pid = eventData:GetString("PlayerId")
    if not pid or pid == ctx.getMyId() then return end
    local x = eventData:GetFloat("X")
    local y = eventData:GetFloat("Y")
    local z = eventData:GetFloat("Z")
    local angle = eventData:GetFloat("Angle")

    -- 只记录目标位置，不直接设节点（避免瞬移）。
    -- 节点可能还没同步过来（REPLICATED 有延迟）；插值时找不到节点会跳过，
    -- 等节点出现后自然开始跟随。
    local t = Net.remoteTargets[pid]
    if not t then
        t = { tx = x, ty = y, tz = z, tangle = angle,
              -- 首次收到：直接落位，不要从 (0,0) 滑过来
              snap = true,
              -- 由 UpdateRemotePlayers 首次匹配到节点时填入（见那里的同名节点处理）
              node = nil }
        Net.remoteTargets[pid] = t
    end
    t.tx, t.ty, t.tz, t.tangle = x, y, z, angle
    -- 记录「最近一次收到该玩家位置」的时刻。
    -- 走路动画据此判断对方是否在移动（见 Client.UpdateRemotePlayerAnimations）：
    -- 比「逐帧位置差」可靠 —— 位置是指数插值，接近目标时单帧位移会跌破阈值，
    -- 导致动画在「摆动/站直」之间反复弹跳（表现为抽搐）。
    t.lastUpdateTime = Net.elapsedTime or 0
end

--- 每帧插值其他玩家位置（由 Client.OnUpdate 调用）。
--- 位置用指数逼近（帧率无关）；朝向用最短角度差。
---@param dt number
function Net.UpdateRemotePlayers(dt)
    Net.elapsedTime = (Net.elapsedTime or 0) + dt
    local sc = ctx.getScene and ctx.getScene()
    if not sc then return end

    -- 帧率无关的平滑系数：约 0.1 秒追平目标（time constant）
    local posT = 1 - math.exp(-dt / 0.1)

    for pid, t in pairs(Net.remoteTargets) do
        -- 🔴 必须按「名字 + 对象」双重匹配，不能用 GetChild(name) 直接取。
        --
        -- 原因：玩家掉线重连时，服务端会 Remove 旧节点再建一个同名新节点。
        -- 若客户端那一帧还没处理完移除，场景里会**短暂并存两个同名节点**；
        -- GetChild("Player_"..pid) 只返回第一个 —— 若它是残留的旧节点，
        -- 位置更新就全打在旧节点上，新节点纹丝不动，
        -- 表现为「对方原地踏步」+ 场上多一个不动的模型。
        --
        -- 判定依据：remoteTargets[pid].node 记录了我们认可的那个节点。
        --   不匹配 → 说明拿到的是残留节点 → 销毁它，等正确节点出现。
        local node = sc:GetChild("Player_" .. pid, true)
        if node and t.node and t.node ~= node then
            if node.name == "Player_" .. pid then
                node:Remove()
                print("[Client] 清理残留同名节点：" .. node.name)
            end
            node = nil
        end
        if node then
            t.node = node

            -- 超出范围 → 隐藏（服务端已停止广播他的位置，模型只会停在原处）。
            -- 用 SetEnabled 而不是 SetVisible：Node 没有 SetVisible（见项目笔记）。
            local dx, dz = node.position.x - Net.selfX, node.position.z - Net.selfZ
            if dx * dx + dz * dz > HIDE_RADIUS_SQ then
                if node:IsEnabled() then node:SetEnabled(false) end
            elseif not node:IsEnabled() then
                -- 回到范围内：重新显示，并直接落位到最新目标，避免从远处滑过来
                node:SetEnabled(true)
                t.snap = true
            end

            local p = node.position
            if t.snap then
                -- 首次：直接落位，避免从原点滑过去
                node.position = Vector3(t.tx, t.ty, t.tz)
                t.snap = false
            else
                node.position = Vector3(
                    p.x + (t.tx - p.x) * posT,
                    p.y + (t.ty - p.y) * posT,
                    p.z + (t.tz - p.z) * posT)
            end
        end
    end
end

--- 取其他玩家的目标朝向（弧度）。无记录时返回 nil。
--- 朝向平滑由 Visual.Player.Update 统一负责（见 Client.UpdateRemotePlayerAnimations）。
--- ⚠️ 不要在这里插值旋转：PlayerRig 是 Player_<pid> 的**子节点**，
---    子旋转是相对父旋转的，两边都插值会让朝向翻倍并来回过冲（表现为抽搐）。
---@param pid string
---@return number|nil
function Net.GetRemoteTargetAngle(pid)
    local t = Net.remoteTargets[pid]
    return t and t.tangle or nil
end

-- OnOnlineStatus（已客户端化）

--- 服务端广播共享 Boss（新增或血量变化）→ 本地渲染/同步血量
---@param eventType string
---@param eventData VariantMap
function Net.OnSharedBossUpdate(eventType, eventData)
    local monsterId = eventData:GetString("MonsterId")
    if not monsterId or monsterId == "" then return end
    local hp       = eventData:GetFloat("Hp")
    local maxHp    = eventData:GetFloat("MaxHp")
    local x        = eventData:GetFloat("X")
    local z        = eventData:GetFloat("Z")

    -- 已存在就同步血量，否则新建节点
    if Enemies.GetAll()[monsterId] then
        Enemies.SyncSharedBoss(monsterId, hp, maxHp)
    else
        Enemies.SpawnSharedBoss(monsterId, x, z, hp, maxHp)
        Notify.Toast("共享首领已降临！")
    end
end

--- 服务端通知共享 Boss 移除（被击杀 / 超时逃跑）
---@param eventType string
---@param eventData VariantMap
function Net.OnSharedBossRemove(eventType, eventData)
    local monsterId = eventData:GetString("MonsterId")
    if not monsterId or monsterId == "" then return end
    Enemies.RemoveSharedBoss(monsterId)
end

--- 拍卖行分页回包。
---@param eventType string
---@param eventData VariantMap
function Net.OnMarketPageResult(eventType, eventData)
    local page       = eventData:GetInt("Page")
    local total      = eventData:GetInt("Total")
    local totalPages = eventData:GetInt("TotalPages")
    local myTotal    = eventData:GetInt("MyTotal")
    local list = Shared.SafeDecode(eventData:GetString("Listings"))
    if type(list) ~= "table" then list = {} end

    -- 服务端可能把越界页码夹回（如最后一页被下空），以回包为准
    Net.marketPage_    = page

    Panels.SetListings(list, total, page, totalPages, myTotal)
end

--- 邮箱翻页结果（服务端分页下发）
---@param eventType string
---@param eventData VariantMap
function Net.OnMailPageResult(eventType, eventData)
    local page  = eventData:GetInt("Page")
    local total = eventData:GetInt("Total")
    local mails = Shared.SafeDecode(eventData:GetString("Mails"))
    if type(mails) ~= "table" then mails = {} end
    Panels.SetMailPage(page, total, mails,
        eventData:GetInt("MailGoldTotal"), eventData:GetInt("MailItemTotal"))
end

---@param eventType string
---@param eventData VariantMap
function Net.OnMailUpdate(eventType, eventData)
    local mails = Shared.SafeDecode(eventData:GetString("Mails"))
    if type(mails) == "table" then
        Data.value.mails = mails

        -- 汇总数字（服务端已随 Mails 一起推，客户端不必遍历求和）
        -- ⚠️ MailTotal 保留 > 0 守卫：字段缺失时 GetInt 返回 0，
        --    无脑赋值会把 mailTotal 误刷成 0。
        local total = eventData:GetInt("MailTotal")
        if total and total > 0 then
            Data.value.mailTotal = total
        elseif #mails == 0 then
            -- 空列表 + MailTotal 为 0 → 邮件确实被领完了。
            -- ⚠️ 必须在这里同步清掉总数：服务端发事件的顺序是
            --    MAIL_UPDATE → INV_SYNC（SetMailTotal 走后者），
            --    下面 RefreshIfOpen 会立刻重开邮箱，此时 mailTotal_ 还是旧值，
            --    OpenMail 会以为「有邮件但没分页缓存」→ 先闪一下「加载中…」。
            Data.value.mailTotal = 0
            if Panels.SetMailTotal then Panels.SetMailTotal(0) end
        end
        local mg = eventData:GetInt("MailGoldTotal")
        if mg then Data.value.mailGoldTotal = mg end
        local mi = eventData:GetInt("MailItemTotal")
        if mi then Data.value.mailItemTotal = mi end

        -- 清分页缓存：下次 OpenMail 重新拉最新分页，而不是命中旧缓存
        if Panels.InvalidateMailPage then Panels.InvalidateMailPage() end

        -- 只在邮箱面板开着时重建，避免顶掉玩家正在看的其他面板
        Panels.RefreshIfOpen("mail", Panels.OpenMail)
    end
end

--- 邮件领取结果汇总（服务端权威：背包满时会有物品留在邮箱）
---@param eventType string
---@param eventData VariantMap
function Net.OnMailClaimResult(eventType, eventData)
    local mails = eventData:GetInt("ClaimedMails") or 0
    local gold  = eventData:GetInt("ClaimedGold") or 0
    local items = eventData:GetInt("ClaimedItems") or 0
    local kept  = eventData:GetInt("KeptItems") or 0
    -- 同步刷新 MailGoldTotal
    local mg = eventData:GetInt("MailGoldTotal")
    if mg then Data.value.mailGoldTotal = mg end
    local mi = eventData:GetInt("MailItemTotal")
    if mi then Data.value.mailItemTotal = mi end

    if mails == 0 and gold == 0 and items == 0 then
        Notify.Toast("没有可领取的邮件")
        return
    end
    local parts = {}
    if mails > 0 then table.insert(parts, "领取 " .. mails .. " 封") end
    if gold > 0 then table.insert(parts, "金币 +" .. gold) end
    if items > 0 then table.insert(parts, "物品 +" .. items) end
    local msg = table.concat(parts, "，")
    if kept > 0 then
        msg = msg .. "（" .. kept .. " 件因背包满留在邮箱）"
    end
    Notify.Toast(msg)
end

--- 新手礼包提示：装备已自动穿戴，弹出对话框告知玩家到角色面板查看。
--- ⚠️ 只在「首次进入的新玩家」触发（服务端幂等控制），不占用顶部提示条。
---@param eventType string
---@param eventData VariantMap
function Net.OnStarterGift(eventType, eventData)
    local count = eventData:GetInt("Count") or 8
    -- 等 UI 就绪后再弹（事件可能早于 SetupUI 到达）
    Net.pendingStarterGift = count
    if Net.uiReady then
        Net.FlushStarterGift()
    end
end

--- 弹出新手礼包对话框（UI 就绪后调用；幂等，弹一次即清空待弹标记）
function Net.FlushStarterGift()
    local count = Net.pendingStarterGift
    if not count then return end
    Net.pendingStarterGift = nil
    Panels.Alert(
        "新手礼包",
        string.format("已赠送 %d 件新手装备，并已自动穿戴到角色面板中。\n\n可点击主界面「角色」按钮查看。", count))
end

-- ============ 【调试】服务器信息 ============
--- 发起一次服务器信息查询（服务端回 DEBUG_SERVER_INFO）
function Net.QueryServerInfo()
    if not Net.conn then
        Notify.Toast("未连接服务器")
        return
    end
    Net.conn:SendRemoteEvent(Shared.EVENTS.DEBUG_QUERY_SERVER_INFO, true)
end

--- 服务器玩家列表回包 → 存进 Net.serverInfo 供设置面板展示
---@param eventType string
---@param eventData VariantMap
function Net.OnDebugServerInfo(eventType, eventData)
    local count = eventData:GetInt("Count") or 0
    local list  = eventData:GetString("List") or ""
    local fp    = eventData:GetString("Fingerprint") or ""

    Net.serverInfo = {
        count       = count,
        list        = list,
        fingerprint = fp,
    }

    print("[Debug] 服务器玩家数=" .. tostring(count))
    print("[Debug] 服务器指纹=" .. fp)
    if list ~= "" then print("[Debug] 玩家列表:\n" .. list) end

    -- 面板开着就刷新显示
    if Panels.RefreshIfOpen then
        Panels.RefreshIfOpen("settings", Panels.OpenSettingsPanel)
    end
end

-- ============ 钱庄 ============
--- 钱庄状态推送
---@param eventType string
---@param eventData VariantMap
function Net.OnBankState(eventType, eventData)
    local deposits = Shared.SafeDecode(eventData:GetString("Deposits"))
    if type(deposits) ~= "table" then deposits = {} end

    Data.value.bankDeposits = deposits
    Data.value.bankDailyTaxPool = eventData:GetInt("DailyTaxPool") or 0
    Data.value.bankMyWeight = eventData:GetInt("MyWeight") or 0
    Data.value.bankTotalWeight = eventData:GetInt("TotalWeight") or 0
    Data.value.bankTodayEarnings = eventData:GetInt("TodayEarnings") or 0
    Data.value.bankForecastTomorrow = eventData:GetInt("ForecastTomorrow") or 0
    Data.value.bankTotalInterest = eventData:GetInt("TotalInterest") or 0

    if Panels.RefreshIfOpen then
        Panels.RefreshIfOpen("bank", Panels.OpenBank)
    end
end

--- 钱庄操作结果
---@param eventType string
---@param eventData VariantMap
function Net.OnBankResult(eventType, eventData)
    local ok = eventData:GetInt("Ok") == 1
    local reason = eventData:GetString("Reason") or ""
    if ok then
        Notify.Toast(reason)
    else
        Notify.Toast("操作失败：" .. reason, "#ff7878")
    end
end

-- OnTokenUseResult（已客户端化）

-- OnAdResult（已客户端化）

--- 玩家下线：清掉他的模型 / 位置缓存 / 头顶标签。
---
--- ⚠️ 不能只依赖引擎的 REPLICATED 移除：玩家重连时服务端会「先删旧节点、再建同名新节点」，
---    两个节点可能短暂并存；客户端若把位置更新打在残留节点上就会「原地踏步」。
---    这里按名字主动清一遍，把残留节点和缓存一并收拾干净。
---@param eventType string
---@param eventData VariantMap
function Net.OnPlayerLeave(eventType, eventData)
    local pid = eventData:GetString("PlayerId")
    if not pid or pid == ctx.getMyId() then return end

    -- 位置缓存：连同它记录的节点一起清掉
    local t = Net.remoteTargets[pid]
    if t then
        if t.node then t.node:Remove() end
        Net.remoteTargets[pid] = nil
    end

    -- 场景里所有同名节点（可能有多个，全删）
    local sc = ctx.getScene and ctx.getScene()
    if sc then
        local i = 0
        while i < sc:GetNumChildren() do
            local child = sc:GetChild(i)
            if child and child.name == "Player_" .. pid then
                child:Remove()
            else
                i = i + 1
            end
        end
    end

    -- 头顶标签：unitTags_ 里的 key 是 "op_" .. pid
    if HUD and HUD.RemoveOtherPlayerTag then
        HUD.RemoveOtherPlayerTag(pid)
    end
    print("[Client] 玩家下线，已清理：" .. pid)
end

--- 服务器满员（服务端已发 SERVER_FULL 并主动断开）。
--- ⚠️ 不能用普通的 ShowReconnectGate：那是「服务器故障 → 重连」的语义，
---    满员时重连只会再被拒一次，玩家会陷入反复重连的死循环。
---    这里用独立的「满员」门，按钮是「返回大厅」而不是「重新连接」。
---@param eventType string
---@param eventData VariantMap
function Net.OnServerFull(eventType, eventData)
    local max = eventData:GetInt("Max")
    print("[Client] 服务器已满，上限=" .. tostring(max))
    -- 主动置空连接：服务端已经断开，留着会让重连门逻辑误判成「可重连」
    Net.conn = nil
    -- 服务端发完本事件就会断开连接，随后引擎必然触发 ServerDisconnected。
    -- 用这个标志抑制那一次，否则重连门会盖掉满员提示（见 OnServerDisconnected）。
    Net.serverFull_ = true
    Panels.ShowServerFullGate(max)
end

-- ============ 断线 / 重连（网络门控）============
--- 客户端侧断线（ServerDisconnected）：清掉连接引用 + 弹重连门。
--- ⚠️ 引擎在此之后会自动重建传输层，重连时重新 GetServerConnection 即可
---    （见 network-game-guide.md §11 的客户端范式）。
function Net.OnServerDisconnected()
    Net.conn = nil
    -- 满员时服务端会主动断开，这一次不弹重连门（会盖掉满员提示，
    -- 且满员下重连只会再被拒一次）。只抑制紧随满员提示的那一次。
    if Net.serverFull_ then
        Net.serverFull_ = false
        print("[Client] 服务器满员导致的断开，跳过重连门")
        return
    end
    Panels.ShowReconnectGate()
end

--- 重连：重新取回服务器连接并重新握手（重连门 / 顶号门的按钮回调）。
function Net.Reconnect()
    Net.conn = network:GetServerConnection()
    if not Net.conn then
        Notify.Toast("重连失败，请稍后重试")
        return
    end
    local sc = ctx.getScene()
    if sc then Net.conn.scene = sc end
    Net.conn:SendRemoteEvent(Shared.EVENTS.CLIENT_READY, true)
    Net.serverFull_ = false
    Notify.Toast("已重新连接")
    -- 重连成功 → 关掉门控面板（门是不可关闭的 Modal，不关会一直挡着）
    if Panels.GetCurrentId and Panels.GetCurrentId() == "gate" then
        Panels.CloseCurrent()
    end
end

--- 服务端读档或落盘失败 → 弹「进度同步失败」门。
--- 玩家点「重新同步进度」走 RetrySave（标脏全部客户端权威字段 + ForceSyncNow）。
---@param eventType string
---@param eventData VariantMap
function Net.OnSaveFailed(eventType, eventData)
    Panels.ShowSaveFailedGate()
end

--- 存档同步失败后手动重试（进度同步失败门的按钮回调）。
---
--- 🔴 语义修正：重试 = 重新走一遍上线流程，**不是**「标脏上报」。
---
--- 原实现的错误前提：以为「客户端手里有数据，推回来即可恢复」。
--- 实际上客户端从不读磁盘 —— 背包/装备/金币全靠服务端下发。
--- 读档失败时服务端不下发权威字段，客户端手里就是空的；
--- 此时标脏上报只会推一份空档，反而把服务端内存和云档一起写坏。
--- （已造成过一次真实清档事故。）
---
--- 正确做法：重发 CLIENT_READY → 服务端 OnClientReady → 重新 LoadSaveAsync。
---   读档成功 → 恢复
---   读档失败 → 服务端重发 SAVE_FAILED → 门重新弹出（形成循环提示，不静默失败）
function Net.RetrySave()
    Net.Reconnect()
end

return Net
