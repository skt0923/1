-- ============================================================
-- Server.lua：服务器核心（连接 / 状态机 / 主循环调度）
--
-- 职责：连接与身份（含顶号）· 基本数据同步（OnInvSync 脏标记上报）
--       · 全局主循环调度（共享 Boss 见 Server_Boss.lua）
--
-- 云存档（快照 / 异步加载 / 落盘 / 清档）已拆到 Server_Cloud.lua：
--   本文件通过 Cloud.Init 注入 players，并用 local 别名（SaveToCloud /
--   LoadSaveAsync / PushCloud / RunOneShotWipe）沿用拆分前的短名。
--
-- 业务子系统（拍卖行 / 邮件 / 每日赠送 / 离线存档队列 / 离线卖家结算）
-- 在 Server_System.lua：本文件通过 Sys.Init 注入核心状态与服务（players /
-- connections / MarkPlayerDirty / SaveToCloud / LoadSaveAsync /
-- ApplySaveToPlayer / PushCloud），并在主循环里驱动 Sys.Update(dt)。
--
-- 共享 Boss（生成 / 广播 / 伤害上报 / 击杀奖励 / 召唤卷）在 Server_Boss.lua：
-- 本文件通过 Boss.Init 注入 players / connections / MarkPlayerDirty /
-- SaveToCloud / Sys，并在主循环里驱动 Boss.Update(dt)。
--
-- 玩家生命周期（就绪处理 / 顶号 / 权威数据下发 / 云档套用 / 背包校验）
-- 在 Server_Player.lua：本文件通过 Player.Init 注入 players / connections /
-- getScene / MarkPlayerDirty / SaveToCloud / LoadSaveAsync / Sys / Boss / Cloud。
-- ============================================================
local Shared = require("Shared")
local Sys    = require("Server_System")   -- 业务子系统：拍卖行 / 邮件 / 每日赠送 / 离线任务
local Cloud  = require("Server_Cloud")    -- 云存档：快照 / 异步读取 / 落盘 / 清档
local Boss   = require("Server_Boss")     -- 共享 Boss（生成 / 广播 / 奖励 / 召唤卷）
local Player = require("Server_Player")   -- 玩家生命周期（就绪 / 下发 / 套用 / 校验）

-- 沿用拆分前的短名（Cloud.* 是跨文件入口；本文件内仍按原样调用）
local RunOneShotWipe = Cloud.RunOneShotWipe
local PushCloud      = Cloud.PushCloud
local LoadSaveAsync  = Cloud.LoadSaveAsync
local SaveToCloud    = Cloud.SaveToCloud

--- 服务器端场景：网络同步的必要媒介（connection.scene 必须指向有效 Scene）。
--- ⚠️ 即使服务器不渲染，也必须创建，否则 REPLICATED 节点无法同步，
---    且 connection.scene = scene_ 会因 nil 直接崩溃。
---@type Scene|nil
scene_ = nil

---@class ServerPlayer
---@field id string
---@field userId integer|nil 认证 user_id（人数上限的顶号判定用）
---@field node Node|nil
---@field gold integer
---@field level integer ⚠️ 冗余字段：权威来源是 p.levelStone.level（等级石系统）
---@field inventory table[]
---@field equipment table<string, table>
---@field bagPageCount integer
---@field autoDecompose table<string, boolean>     自动分解：已鉴定装备
---@field autoDecomposeUnid table<string, boolean> 自动分解：未鉴定装备
---@field autoRepair boolean 自动维修：每 30 分钟修一次全身
---@field pets table 宠物系统：{ equipped = {...}, pool = {...} }（客户端权威）
---@field petGacha table 抽卡保底计数器：{ counters = {...} }（客户端权威）
---@field bdTree table 天赋树：{ nodes = { [nodeId] = true } }（客户端权威）
---@field levelStone table|nil 等级石（客户端权威；nil = 未装备）
---@field levelStoneGiftReceived boolean 等级石礼包幂等键（一次性迁移用）
---@field mails table[]
---@field nextMailId integer
---@field onlineTokenMinutes integer
---@field settings table 已废弃：设置完全客户端化，服务端不读不写不持久化（仅保留字段占位）
---@field autoUseOnlineToken boolean 已废弃：原为自动续费镜像，现已无任何读写方
---@field adCountToday integer
---@field adLastTime integer
---@field lastResetDate string
---@field lastDailyGiftDate string 新手礼包幂等键 + 新老玩家判定（"" = 未领过礼包的新玩家）
---@field starterGiftReceived boolean 新手礼包装备是否已补发（幂等键）
---@field dailyGiftDate string 每日礼包幂等键（"" = 今天还没领，跟 lastDailyGiftDate 独立）
---@field bankDeposits table[] 钱庄存款列表（每笔含 accumulatedInterest）
---@field bankTodayEarnings integer 今日结算分到的利息
---@field bankLastSettledDate string 最近一次结算日期（幂等键，防重复结算）
---@field save table|nil
---@field lastBroadcastX number|nil 位置广播去重基准（nil = 尚未广播过，见 OnInvSync）
---@field lastBroadcastZ number|nil
---@field __dirty boolean|nil
---@field __hasValidClientData boolean|nil 数据可信（读档成功/收到客户端实质上报）；false 时不下发客户端权威字段、不落盘
---@field __saveFailedNotified boolean|nil 落盘失败是否已通知过客户端（去重，防每 30 秒重复弹门）
---@field __sentAuthData boolean|nil 是否已向客户端下发过权威数据（客户端上报可信的前提）
---@field saveLoaded boolean|nil 云存档是否已读回（读回前禁止落盘，见 SaveToCloud）
---@field saveWait number|nil 等待云存档读回的累计秒数（看门狗用，见 OnUpdate）
---@field saveVersion integer|nil 存档结构版本（见 Shared.SAVE_VERSION）

---@class MarketListing
---@field id string
---@field sellerId string
---@field item table
---@field price integer
---@field createdAt integer
---@field expiresAt integer|nil 过期时间戳（7 天后自动下架退回）

---@class ConnectionInfo
---@field connection Connection
---@field userId integer|nil
---@field playerId string|nil
---@field fallbackId string|nil
---@field nickname string|nil  TapTap 昵称（认证时从 identity 取，用于头顶显示）

---@type table<string, ServerPlayer>
local players        = {}
---@type table<string, ConnectionInfo>
local connections    = {}
-- ⚠️ 拍卖行挂单表 / 离线存档队列 / 相关计时器已迁至 Server_System.lua（Sys.*）。
local saveTimer      = 0

-- ⚠️ 离线存档串行队列（offlineSaveQueue_ / OFFLINE_TASK_TIMEOUT /
--    offlineStaleAdvance_）已迁至 Server_System.lua。

-- 框架在服务器端注入的全局变量（.emmylua 未声明，此处补齐供 LSP 识别）
---@type integer
SERVER_MAX_PLAYERS = SERVER_MAX_PLAYERS

--- 位置广播的最大距离（米）。超出这个距离的玩家收不到对方的位置更新。
---
--- 常驻服下人数上限可达 50，而位置广播原本是「无差别转发给所有连接」——
--- 每人每次移动都要发 N-1 个包，50 人时约 2450 包/秒，且跨全图的无用包占绝大多数。
--- 按距离裁剪后包量降到 O(N x 同屏人数)。
---
--- ⚠️ 这是一个**可见性裁剪**：超出半径的玩家收不到对方位置更新，模型会停在最后位置。
---    客户端必须配套隐藏（见 Client_Network.HIDE_RADIUS），否则会看到一堆静止模型。
---    两侧阈值要留缓冲：隐藏半径 > 广播半径，否则玩家在边界来回走会闪烁。
local BCAST_RADIUS = 100.0
local BCAST_RADIUS_SQ = BCAST_RADIUS * BCAST_RADIUS

-- ============ 入口 ============
function Start()
    print("[Server] Starting... Max:" .. SERVER_MAX_PLAYERS)

    scene_ = Scene()
    scene_:CreateComponent("Octree", LOCAL)
    print("[Server] 场景已创建（网络同步媒介）")

    Shared.RegisterServerEvents()

    -- 注入云存档模块所需的共享状态（players 表由本文件持有）
    -- getConnection：SaveToCloud 失败时通知客户端用（通过 Sys 查连接）
    Cloud.Init({
        players = players,
        getConnection = function(pid)
            local info = Sys.FindConnectionByPlayerId(pid)
            return info and info.connection or nil
        end,
    })

    -- 玩家生命周期（就绪 / 下发 / 套用 / 校验，已迁至 Server_Player.lua）
    -- ⚠️ Init 必须在 RegisterEvents 之前：事件回调依赖注入的 players/connections
    Player.Init({
        players         = players,
        connections     = connections,
        getScene        = function() return scene_ end,
        MarkPlayerDirty = MarkPlayerDirty,
        SaveToCloud     = SaveToCloud,
        LoadSaveAsync   = LoadSaveAsync,
        Sys             = Sys,
        Boss            = Boss,
        Cloud           = Cloud,
        -- 新增：全局广播与人数上限，走 ctx 显式注入（不再依赖 Server.lua 的全局符号）
        serverMaxPlayers     = SERVER_MAX_PLAYERS,
        broadcastPlayerLeave = BroadcastPlayerLeave,
        broadcastOnlineCount = BroadcastOnlineCount,
        broadcastPlayerInfo  = BroadcastPlayerInfo,
    })
    Player.RegisterEvents()

    SubscribeToEvent("ClientConnected",              "OnConnected")
    SubscribeToEvent("ClientIdentity",               "OnIdentity")
    SubscribeToEvent("ClientDisconnected",           "OnDisconnected")
    SubscribeToEvent(Shared.EVENTS.SYNC_REQUEST,     "OnInvSync")
    -- 业务子系统：拍卖行 / 邮件 / 每日赠送 / 离线任务
    -- ⚠️ Init 必须在 RegisterEvents 之前：事件回调依赖注入的 players/connections 与核心服务
    Sys.Init({
        players             = players,
        connections         = connections,
        MarkPlayerDirty     = MarkPlayerDirty,
        SaveToCloud         = SaveToCloud,
        LoadSaveAsync       = LoadSaveAsync,
        ApplySaveToPlayer   = Player.ApplySaveToPlayer,
        PushCloud           = PushCloud,
        PlayerOf            = PlayerOf,
    })
    Sys.RegisterEvents()      -- 内部会调 Bank.RegisterEvents()（钱庄）

    -- 共享 Boss（独立子系统，已迁至 Server_Boss.lua）
    -- ⚠️ Init 必须在 RegisterEvents 之前：事件回调依赖注入的 players/connections
    Boss.Init({
        players         = players,
        connections     = connections,
        MarkPlayerDirty = MarkPlayerDirty,
        SaveToCloud     = SaveToCloud,
        Sys             = Sys,
    })
    Boss.RegisterEvents()

    SubscribeToEvent("Update", "OnUpdate")

    Sys.LoadMarket()
    Sys.LoadBankState()       -- 税池 / 存款索引 / 结算快照（见 Server_Bank.lua）

    -- 【调试】客户端查询服务器玩家列表
    SubscribeToEvent(Shared.EVENTS.DEBUG_QUERY_SERVER_INFO, "OnDebugQueryServerInfo")

    -- 【一次性】指定 uid 清档（列表为空时函数内部直接返回）
    RunOneShotWipe()
end

--- 【调试】把本服务器的玩家列表回给请求方。
---
--- 用途：排查「两个玩家看不到彼此」这类问题 —— 直接看两人是否在**同一台服务器**。
--- 每台服务器实例的玩家集合不同，对比两台设备返回的列表即可确认。
---
--- ⚠️ 全局函数（不是 local）：Start() 定义在文件更靠前的位置，
---    局部变量在那里不可见；全局函数在「调用时」解析，从 Start 里能调到。
---@param eventType string
---@param eventData VariantMap
function OnDebugQueryServerInfo(eventType, eventData)
    local c = eventData["Connection"] and eventData["Connection"]:GetPtr("Connection")
    if not c then return end

    local lines = {}
    local n = 0
    for pid, p in pairs(players) do
        n = n + 1
        -- ⚠️ 同上：服务端节点位置恒为 (0,0,0)，真实位置在 p.save
        local pos = p.save or { x = 0, z = 0 }
        local conn = nil
        for _, info in pairs(connections) do
            if info.playerId == pid then conn = info.connection break end
        end
        -- 连接地址能区分「同一台服务器上的不同玩家」
        local addr = (conn and conn.GetAddress and conn:GetAddress()) or "?"
        table.insert(lines, string.format("%s  位置(%.1f, %.1f)  连接=%s",
            pid, pos.x, pos.z, tostring(addr)))
    end
    table.sort(lines)

    c:SendRemoteEvent(Shared.EVENTS.DEBUG_SERVER_INFO, true, Shared.ToVariantMap({
        Count = n,
        List  = table.concat(lines, "\n"),
        -- 服务器指纹：用本机所有连接的地址拼一个稳定串。
        -- 两台设备拿到**相同指纹** ⇒ 连的是同一台服务器。
        Fingerprint = (function()
            local addrs = {}
            for k in pairs(connections) do table.insert(addrs, tostring(k)) end
            table.sort(addrs)
            return table.concat(addrs, "|")
        end)(),
    }))
end

-- ============ 连接 / 身份 ============
--- 除 selfConn 之外，是否还有别的连接持有该玩家。
---
--- 顶号时新旧连接会**短暂并存**：新连接接管玩家后，旧连接只是被通知弹窗，
--- 服务端并没有断开它（客户端是否真的断开不可控）。
--- 所以清理 players[pid] 前必须先确认没有别的连接还指着它。
---@param pid string
---@param selfConn Connection
---@return boolean
local function HasOtherConnectionFor(pid, selfConn)
    for _, cinfo in pairs(connections) do
        if cinfo.playerId == pid and cinfo.connection ~= selfConn then
            return true
        end
    end
    return false
end

-- ⚠️ ClientConnected 时 identity 尚未建立，拿不到 user_id
function OnConnected(_, e)
    local c = e["Connection"]:GetPtr("Connection")
    connections[tostring(c)] = {
        connection = c,
        userId     = nil,   -- 等 ClientIdentity 填充
    }
end

-- 认证完成：user_id 可用。这是唯一稳定的玩家主键来源
function OnIdentity(_, e)
    local c = e["Connection"]:GetPtr("Connection")
    local info = connections[tostring(c)]
    if not info then return end

    local identity = c.identity
    local userId = identity and identity["user_id"] and identity["user_id"]:GetInt64() or nil
    if userId then
        info.userId = userId
        print("[Server] 认证通过 user_id=" .. tostring(userId))
    else
        print("[Server] ⚠️ ClientIdentity 未取到 user_id，将回退到连接级临时 ID")
    end

    -- 取昵称：引擎在认证阶段已查过 BatchUserNickname 并注入 identity。
    -- 取不到时回退成 user_id，至少保证有东西可显示。
    if identity then
        local nk = identity["nick_name"] or identity["nickname"]
        if nk then
            local ok, s = pcall(function()
                if nk.GetString then return nk:GetString() end
                return tostring(nk)
            end)
            if ok and s and s ~= "" then
                info.nickname = s
                print("[Server] 昵称=" .. s)
            end
        end
    end
    if not info.nickname then
        info.nickname = userId and ("玩家" .. tostring(userId)) or "玩家"
        print("[Server] ⚠️ 未取到昵称，回退为 " .. info.nickname)
    end

    -- 【诊断】已删除：确认 nick_name 字段名后不再需要。
    -- ⚠️ 原实现 `for k, v in pairs(identity)` 会抛
    --    「bad argument #1 to 'for iterator' (table expected, got VariantMap)」——
    --    identity 是 VariantMap（tolua++ 绑定对象），不是 Lua table，不能直接 pairs。
    --    它在 OnIdentity 里抛错会中断本函数，**导致后续所有初始化被跳过**。
end

function OnDisconnected(_, e)
    local c = e["Connection"]:GetPtr("Connection")
    local key = tostring(c)
    local info = connections[key]
    if info then
        local pid = info.playerId
        if pid and players[pid] then
            if HasOtherConnectionFor(pid, c) then
                -- 顶号场景：老连接断开时，新连接已经接管了这个玩家。
                -- ⚠️ 此时**不能**清 players[pid] —— 那会删掉新连接正在用的状态，
                --    后果是在线人数少 1，且新连接之后所有操作静默失效
                --    （PlayerOf 查不到玩家，事件处理直接 return）。
                --    玩家的下线存档交给真正持有它的那条连接去写。
                print("[Server] " .. pid .. " 老连接断开，但玩家已由其他连接接管，保留状态")
            else
                SaveToCloud(pid)
                -- 🔴 必须删节点：Player_<pid> 是 REPLICATED 创建的，
                --    服务端不删则客户端永远收不到「移除」同步，模型原地残留；
                --    该玩家重连时服务端会再建一个同名节点，于是模型越堆越多。
                local gone = players[pid]
                if gone and gone.node then
                    gone.node:Remove()
                    gone.node = nil
                end
                players[pid] = nil
                -- 广播下线：客户端清掉残留模型 / 位置缓存 / 头顶标签。
                -- ⚠️ 只靠节点移除不够 —— 客户端可能已经缓存了位置目标，
                --    也可能因为同名节点竞态而挂在错误的对象上。
                BroadcastPlayerLeave(pid)
                print("[Server] " .. pid .. " 下线（存档已保存，节点已移除）")
            end
        end
        connections[key] = nil
        -- 人数变化 → 广播给剩下的人（放在清 connections 之后，避免推给已断开的连接）
        BroadcastOnlineCount()
        -- 同时重推昵称映射（去掉下线玩家的条目）
        BroadcastPlayerInfo()
    end
end

--- 广播某玩家下线。
--- ⚠️ 全局函数（不是 local）：OnDisconnected 定义在文件靠前位置。
---@param pid string
function BroadcastPlayerLeave(pid)
    local payload = Shared.ToVariantMap({ PlayerId = pid })
    for _, info in pairs(connections) do
        if info.connection then
            info.connection:SendRemoteEvent(Shared.EVENTS.PLAYER_LEAVE, true, payload)
        end
    end
end

--- 当前在线人数
---@return integer
local function CountOnline()
    local n = 0
    for _ in pairs(players) do n = n + 1 end
    return n
end

--- 广播当前在线人数（客户端 HUD 左上角显示「在线: N」）。
--- 上线 / 下线时调用；人数变化不频繁，不做节流。
--- ⚠️ 全局函数（不是 local）：OnConnected/OnDisconnected 定义在文件靠前位置。
function BroadcastOnlineCount()
    local payload = Shared.ToVariantMap({ Count = CountOnline() })
    for _, info in pairs(connections) do
        if info.connection then
            info.connection:SendRemoteEvent(Shared.EVENTS.ONLINE_COUNT, true, payload)
        end
    end
end

--- 广播所有玩家的「昵称映射」（pid → TapTap 昵称）。
---
--- 用途：客户端头顶显示真实昵称，而不是 Player_u123456 这种内部 ID。
--- 每次有人上线/下线都全量重推（人数少，数据量可忽略），
--- 这样新进来的玩家立刻能拿到所有人的昵称，不必等别人再动一次。
function BroadcastPlayerInfo()
    local map = {}
    for pid, info in pairs(connections) do
        if info.playerId then
            map[info.playerId] = info.nickname or ""
        end
    end
    local payload = Shared.ToVariantMap({
        Names = cjson.encode(map),
    })
    for _, info in pairs(connections) do
        if info.connection then
            info.connection:SendRemoteEvent(Shared.EVENTS.PLAYER_INFO, true, payload)
        end
    end
end


--- 标记玩家本次会话已有新操作（各写操作修改 p 之后调用）
---@param pid string
function MarkPlayerDirty(pid)
    local p = players[pid]
    if p then p.__dirty = true end
end

-- ============ 时长（已客户端化）============



-- ============ 位置转发（已合并入 OnInvSync）============


-- ============ 脏标记同步接收 ============
function OnInvSync(_, e)
    local p, c = PlayerOf(e)
    if not p then return end

    -- 🔴 客户端主动上报 = 玩家在尝试恢复（可能是「进度同步失败门」的重试按钮）。
    --    无条件重置失败通知标志，让后续的落盘失败能重新弹门。
    --
    --    否则：玩家点重试 → 上报失败（网络持续问题）→ 门关闭但不重开
    --    → 玩家卡在「以为成功」的状态，实际数据仍未恢复。
    p.__saveFailedNotified = nil

    local seq = e["Seq"] and e["Seq"]:GetInt() or 0

    -- ⚠️ 这里曾经有「带 Seq 的请求每秒最多处理一次」的限流，已删除：
    --    限流时服务端会直接 ACK 但不落库，客户端据此认为「flush 成功」，
    --    随后的写操作（买/领邮件/上架）就会基于旧数据判定（背包已满、金币不足）。
    --    现在带 Seq 的请求一律真实处理，ACK 才代表数据真的进了服务端。

    -- 位置（每次都带）
    local x = e["X"] and e["X"]:GetFloat() or 0
    local y = e["Y"] and e["Y"]:GetFloat() or 0
    local z = e["Z"] and e["Z"]:GetFloat() or 0
    local angle = e["Angle"] and e["Angle"]:GetFloat() or 0

    -- ⚠️ 客户端本地权威：服务端不再写 p.node.position。
    --    原实现每次收到上报都改节点位置，REPLICATED 会把旧位置回推给客户端，
    --    造成「走两步被墙顶住」的回拉现象。
    --    现在位置只入存档；其他玩家靠 PLAYER_MOVE 自定义事件同步。
    p.save = p.save or {}
    p.save.x = x
    p.save.z = z

    -- 位置去重广播：移动超过 0.1 米才广播给其他玩家。
    -- 领邮件 / 买东西 / 看面板触发的 flush 位置没变，不必刷屏；
    -- 真正移动时上报受客户端 2 秒 sync 周期自然限制。
    -- 基准为 nil（首次上报 / 刚上线 / 重连）→ 必然广播一次，其他玩家才看得到你入场。
    local BCAST_EPSILON = 0.1
    local lastX, lastZ = p.lastBroadcastX, p.lastBroadcastZ
    local moved = (lastX == nil) or (lastZ == nil)
        or (math.abs(x - lastX) > BCAST_EPSILON)
        or (math.abs(z - lastZ) > BCAST_EPSILON)

    if moved then
        p.lastBroadcastX = x
        p.lastBroadcastZ = z
        local movePayload = Shared.ToVariantMap({
            PlayerId = p.id,
            X = x, Y = y, Z = z,
            Angle = angle,
        })
        for _, info2 in pairs(connections) do
            local conn2 = info2.connection
            if conn2 and conn2 ~= c then
                -- 距离裁剪：只发给附近的玩家，跳过跨全图的无用包。
                -- 对方还没上线时也发，让他一进来就拿到基准位置。
                --
                -- ⚠️ 用 p.save.x/z，不要用 p.node.position！
                --    服务端从不更新节点位置（客户端本地权威，见上方注释），
                --    node.position 恒为创建时的 (0,0,0)，拿它算距离会退化成
                --    「按到世界原点的距离裁剪」，判断完全错误。
                local other = info2.playerId and players[info2.playerId]
                local osave = other and other.save
                if not osave then
                    conn2:SendRemoteEvent(Shared.EVENTS.PLAYER_MOVE, true, movePayload)
                else
                    local dx, dz = (osave.x or 0) - x, (osave.z or 0) - z
                    if dx * dx + dz * dz <= BCAST_RADIUS_SQ then
                        conn2:SendRemoteEvent(Shared.EVENTS.PLAYER_MOVE, true, movePayload)
                    end
                end
            end
        end
    end

    -- 🔴 云存档读回前，忽略客户端上报的持久化字段。
    --
    -- 服务端对背包/金币是「客户端权威」，而玩家刚上线时**两端手里都是默认空档**：
    --   服务端还没读到云档（players[pid] 是 Server_Player.OnClientReady 建的默认档），
    --   客户端拿到的是 Player.SendAssignPlayer 下发的同一份默认值。
    -- 只要窗口期内客户端上报一次（自动续费、拾取、任何 MarkDirty），
    -- 服务端就会用空档覆盖自己；等云档回来时 __dirty 已为真 →
    -- 合并分支「保留本地游戏性字段」→ 玩家的真实进度被永久清空。
    --
    -- 光在 SaveToCloud 加守卫不够：空档在落盘之前就已经写进内存了，
    -- 必须从**入口**就拒绝，窗口才真正封死。
    --
    -- 位置不在此列：下面照常处理并广播（否则其他玩家看不到你入场）。
    local accept = p.saveLoaded == true
    if not accept and (e["Inventory"] ~= nil or e["Gold"] ~= nil or e["Level"] ~= nil) then
        print("[Server] " .. p.id .. " 云存档未读回，忽略本次客户端上报"
            .. "（inventory=" .. tostring(e["Inventory"] ~= nil)
            .. " gold=" .. tostring(e["Gold"] ~= nil)
            .. " level=" .. tostring(e["Level"] ~= nil) .. "）")
    end

    -- 背包
    if accept and e["Inventory"] then
        local inv = Shared.SafeDecode(e["Inventory"]:GetString())
        if type(inv) == "table" then
            p.inventory = Player.ValidateInventory(inv, p.bagPageCount or 1)
        end
    end
    -- 装备栏
    if accept and e["Equipment"] then
        local eq = Shared.SafeDecode(e["Equipment"]:GetString())
        if type(eq) == "table" then p.equipment = eq end
    end
    -- 金币
    if accept and e["Gold"] then p.gold = e["Gold"]:GetInt() end
    -- 等级（⚠️ 冗余字段：权威来源是下面的 p.levelStone.level，
    --   见同函数里的 "LevelStone" 分支；此处仅为存档/未来校验保留快照）
    if accept and e["Level"] then
        local lv = e["Level"]:GetInt()
        if lv > 0 then p.level = lv end
    end
    -- 时长（分钟）
    if accept and e["OnlineTokenMinutes"] then p.onlineTokenMinutes = e["OnlineTokenMinutes"]:GetInt() end
    -- 设置已客户端化：不再接收（客户端不再上报，服务端不再存）。
    -- 自动分解开关（整表覆盖，客户端权威）：已鉴 / 未鉴两套
    if accept and e["AutoDecompose"] then
        local ad = Shared.SafeDecode(e["AutoDecompose"]:GetString())
        if type(ad) == "table" then p.autoDecompose = ad end
    end
    if accept and e["AutoDecomposeUnid"] then
        local ad = Shared.SafeDecode(e["AutoDecomposeUnid"]:GetString())
        if type(ad) == "table" then p.autoDecomposeUnid = ad end
    end
    -- 自动维修开关（客户端权威，整值覆盖）
    if accept and e["AutoRepair"] then
        p.autoRepair = (e["AutoRepair"]:GetInt() == 1)
    end
    -- 宠物系统（客户端权威，整表覆盖）。
    -- ⚠️ 与背包/金币/自动维修同为客户端权威字段，必须同样受 accept 保护：
    --    云档未读回前的上报若被接受，会把空结构写进内存，覆盖即将读回的云档。
    if accept and e["Pets"] and e["Pets"]:GetString() ~= "" then
        local pets = Shared.SafeDecode(e["Pets"]:GetString())
        if type(pets) == "table" then p.pets = pets end
    end
    if accept and e["PetGacha"] and e["PetGacha"]:GetString() ~= "" then
        local pg = Shared.SafeDecode(e["PetGacha"]:GetString())
        if type(pg) == "table" then p.petGacha = pg end
    end
    -- 等级石（客户端权威，整表覆盖）
    if accept and e["LevelStone"] and e["LevelStone"]:GetString() ~= "" then
        local ls = Shared.SafeDecode(e["LevelStone"]:GetString())
        if type(ls) == "table" and ls.level then
            p.levelStone = ls
        else
            p.levelStone = nil
        end
    end
    -- 天赋树（客户端权威，整表覆盖）。
    -- ⚠️ 与 Pets/PetGacha 同理：必须受 accept 保护，否则云档未读回前的空档上报
    --    会把空树写进内存，覆盖即将读回的云档。
    -- ⚠️ 用 IsBDTreeValid 而非 `type(...)=="table"`：客户端发的 `{}` 也是 table，
    --    收下会让 p.bdTree 变成缺 nodes 的残表。
    if accept and e["BDTree"] and e["BDTree"]:GetString() ~= "" then
        local bd = Shared.SafeDecode(e["BDTree"]:GetString())
        if Shared.IsBDTreeValid(bd) then p.bdTree = bd end
    end
    -- 广告计数（客户端权威）：与背包/金币同为「客户端权威」字段，
    -- 同样必须在 accept（云档已读回）之后才接受，避免窗口期空档覆盖。
    -- 同时把 lastResetDate 刷成今天：本次上报本身就证明玩家今天在线，
    -- 否则下次重连 dailyReset 会再清零一次（虽无害，但会让计数看起来跳变）。
    if accept and e["AdCountToday"] then
        p.adCountToday  = e["AdCountToday"]:GetInt()
        p.lastResetDate = Shared.TodayString()
    end

    -- 上架意图（批量，按 ClientId 幂等）
    local listingResults = {}
    if accept and e["PendingListings"] then
        local arr = Shared.SafeDecode(e["PendingListings"]:GetString())
        if type(arr) == "table" then
            for _, pl in ipairs(arr) do
                if type(pl) == "table" then
                    local ok, reason, listingId = Sys.HandleMarketSellFromSync(p, c, pl)
                    table.insert(listingResults, {
                        ClientId  = pl.ClientId or "",
                        Ok        = ok and 1 or 0,
                        Reason    = reason or "",
                        ListingId = listingId or "",
                    })
                end
            end
        end
    end

    -- ⚠️ 不能无条件 MarkPlayerDirty：位置是每次上报都带的
    --    （客户端上线后的 ForceSyncNow 会立刻发一个纯位置包），
    --    那不代表玩家有「实质操作」。误标记会让 LoadSaveAsync 认为
    --    「玩家已操作」→ 丢弃云端存档 → 老玩家进度被空档覆盖。
    --    只有携带了真正改变持久化状态的字段时才算实质操作。
    --
    -- 🔴 并且必须在 accept（云档已读回）之后才算数：窗口期内的字段
    --    已被上面整体忽略，若仍标脏，就会把 LoadSaveAsync 逼进
    --    「玩家已有新操作」分支，等于绕过了那道门。
    local hasSubstantiveChange = accept and (e["Inventory"] ~= nil
        or e["Equipment"] ~= nil
        or e["Gold"] ~= nil
        or e["Level"] ~= nil
        or e["AutoDecompose"] ~= nil
        or e["AutoDecomposeUnid"] ~= nil
        or e["AutoRepair"] ~= nil
        or e["AdCountToday"] ~= nil
        or e["PendingListings"] ~= nil
        or e["OnlineTokenMinutes"] ~= nil
        or e["Pets"] ~= nil
        or e["PetGacha"] ~= nil
        or e["BDTree"] ~= nil
        or e["LevelStone"] ~= nil)

    if hasSubstantiveChange then
        MarkPlayerDirty(p.id)
        -- 🔴 客户端上报只有在「它确实收到过权威数据」时才算可信。
        --
        -- ⚠️ 血的教训：曾无条件 MarkClientDataValid，结果读档失败时
        --    客户端手里是**启动时的空档**（客户端从不读磁盘，全靠服务端下发），
        --    玩家点「重新同步进度」上报空背包 → 被当成权威数据 → 落盘 → 云档被清空。
        --
        --    客户端数据可信的前提是它拿过服务端的权威快照；
        --    没拿过（读档失败）就上报，只可能是空档或残缺数据，必须拒绝。
        if p.__sentAuthData then
            Cloud.MarkClientDataValid(p)
        else
            print("[Server] " .. p.id
                .. " 收到上报但客户端从未收到权威数据，拒绝标记可信（防空档覆盖）")
        end
    end

    local ackPayload = { Seq = seq }
    if #listingResults > 0 then
        ackPayload.ListingResults = cjson.encode(listingResults)
    end
    c:SendRemoteEvent(Shared.EVENTS.SYNC_ACK, true, Shared.ToVariantMap(ackPayload))
end

-- 以下模块已完全客户端化（服务端不再处理，仅由客户端算完随存档上报）：
--   广告 / 使用令牌 / 强化 / 锻造 / 重铸

-- ============ 每秒处理：在线时长扣费 ============
function OnUpdate(_, e)
    local dt = e["TimeStep"]:GetFloat()

    -- 系统域：每日赠送跨日检查 / 挂单过期 / 离线队列兜底 / 拍卖行落盘
    Sys.Update(dt)

    -- 共享 Boss：在线人数归零时清空（逻辑在 Server_Boss.lua）
    Boss.Update(dt)

    -- 🔴 共享 BOSS 定时扫描已移除（原为 10 秒一次）：
    --    · 脱战回满血 —— 按需求删除，Boss 不再自动回血。
    --    · 服务端血量校正广播 —— 按需求删除，服务端不再用自己算的血量
    --      覆盖客户端。血量与击杀完全以客户端上报为准。
    --    ⚠️ 删除校正后**不能再周期性广播血量**：客户端 Net.OnSharedBossUpdate
    --       会调 Enemies.SyncSharedBoss 把本地血条改成广播值，若服务端仍广播
    --       自己那份（永不扣减的）血量，Boss 会被反复刷回满血、永远打不死。
    --       现在只在**生成时**广播一次（满血），此后血量由客户端各自维护。

    -- 玩家存档落盘（30 秒）
    saveTimer = saveTimer + dt
    if saveTimer >= Shared.C.SAVE_INTERVAL then
        saveTimer = 0
        for pid in pairs(players) do
            SaveToCloud(pid)
        end
        Sys.SaveMarket()
    end

    -- 云存档读取看门狗。
    --
    -- ⚠️ LoadSaveAsync 没有超时：云变量既不回调 ok 也不回调 error 时，
    --    saveLoaded 会永远为 false，SaveToCloud 的守卫就会**永久拒绝落盘**
    --    —— 这一局的进度全都白玩。（Server_System 对离线队列用
    --    OFFLINE_TASK_TIMEOUT 兜同样的底，这里同理。）
    --    超时后放行落盘：此时按「云端读不到」处理，至少保证本局进度能存下来。
    for pid, p in pairs(players) do
        if not p.saveLoaded then
            p.saveWait = (p.saveWait or 0) + dt
            if p.saveWait >= Cloud.SAVE_LOAD_TIMEOUT then
                p.saveLoaded = true
                print("[Server] " .. pid .. " 云存档读取超时 "
                    .. Cloud.SAVE_LOAD_TIMEOUT .. "s，放行落盘（本局进度以本地为准）")
            end
        end
    end
end


-- ============ 装备修理 / 升级 / 自动分解（已客户端化）============

--- 从事件里取出「上报者」：连接 + 已激活的玩家。
--- 本文件的下发处理与 Server_System / Server_Bank 的
--- OnMarket / OnMailClaim / OnRequestMailPage / OnBagOverflowToMail /
--- 钱庄事件共用同一套「连接 → 玩家」解析（各模块按需注入）。
--- ⚠️ 全局函数（不是 local）：Start() 在文件更靠前的位置，局部变量在那里不可见，
---    而 Start 里的 Sys.Init 要把本函数注入给 Server_System。
---@param e VariantMap
---@return ServerPlayer|nil, Connection|nil
function PlayerOf(e)
    local c = e["Connection"]:GetPtr("Connection")
    local info = connections[tostring(c)]
    local p = info and info.playerId and players[info.playerId]
    return p, c
end

-- OnLevelUpRequest（已客户端化）

-- OnAutoDecomposeSet（已客户端化）

-- ============ ProcessOnlineSecond（已客户端化）============

-- ============ SendOnlineStatus（已客户端化）============

return { Start = Start }
