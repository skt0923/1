-- ============================================================
-- lobby_runtime.lua：零大厅入口（完全自建路径）
--
-- 作用：multiplayer.enabled = true 时，引擎默认会弹出自带的
--       「快速匹配 / 浏览房间 / 创建房间」大厅。本文件替换该默认入口：
--       不构建任何大厅界面，启动即自动发起匹配并直连游戏服务器，
--       连服完成后引擎自动切到 Client.lua 场景。
--
-- 配置：.project/settings.json
--   "@runtime": { "multiplayer": { "lobby_runtime": "scripts/lobby_runtime.lua" } }
--
-- 契约（见 urhox-libs/GameLobby/Runtime/lobby_client.d.lua）：
--   入口脚本 return function(ctx)，ctx = { client, root }
--   root 由引擎托管，退出大厅/切脚本时整树回收，不需要自己销毁。
-- ============================================================

-- 连服期间是否显示极简加载提示（居中的一行文字）。
-- 置 false 则 root 完全为空，连服期间为纯黑画面。
local SHOW_HINT = true

-- 自动模式开关（仅控制 **UI 形态**，不控制是否发起匹配）。
--   true  = 简洁 UI：只显示「正在连接服务器…」，无输入框/按钮
--   false = 手动 UI：保留房间号输入框 + 建房/加入按钮
--
-- 🔴 关键：本项目的匹配由**引擎常驻服逻辑自动完成**（日志可见
--    "Querying middle room" → "creating new game" → "NotifyGameStart"），
--    不依赖本脚本调用 client:StartMatch。
--    ⚠️ 因此**不要**在这里调 client:StartMatch：会与引擎的自动匹配重复触发，
--       导致每局都开一台独立服务器（这正是本文件下方注释记录的老问题）。
local AUTO_MATCH = true

-- 🔴 服务器无响应判定阈值（秒）。
--    大厅 API 没有「服务器是否可达」的直接查询，所以用**静默超时**推断：
--    发起匹配后若在这么长时间内没有收到任何服务器回调
--    （onStarted / onMatchFound / onProgress / onError 都算「有响应」），
--    就判定服务器不可达（维护 / 宕机 / 网络不通），弹出维护提示。
--    ⚠️ 取值要明显大于正常连服耗时，否则网络慢时会被误判。
local SERVER_TIMEOUT = 9.0

local function logInfo(msg)
    local s = "[lobby_runtime] " .. tostring(msg)
    if log and LOG_INFO then log:Write(LOG_INFO, s) else print(s) end
end

local function logError(msg)
    local s = "[lobby_runtime] " .. tostring(msg)
    if log and LOG_ERROR then log:Write(LOG_ERROR, s) else print(s) end
end

return function(ctx)
    print("[lobby_runtime] 脚本已加载，开始执行")
    local client, root = ctx.client, ctx.root

    -- ============ 极简加载提示 ============
    -- ⚠️ UI 可能尚未初始化（默认入口 LobbyUI.Show 才会调 UI.Init）。
    --    这里自己保证一次 UI.Init，拿到控件能力。
    local UI = require("urhox-libs.UI")
    if not UI.GetNVGContext() then
        UI.Init({
            scale = function()
                return math.max(graphics.height / 1080, 0.4)
            end,
        })
    end

    -- 前向声明：UI 按钮在构造时就引用它们，而定义在下方。
    -- ⚠️ 不加这几行，按钮的 onClick 会解析成全局 nil，点了没反应。
    local onCreateRoom
    local onJoinRoom
    ---@type integer|nil
    local roomId_ = nil

    -- ============ 大厅界面 ============
    -- 手动「加入房间」入口：用于验证常驻服能否跨玩家发现房间。
    -- 自动匹配（StartMatch）已证明不行 —— 平台只按 match_info 分配，
    -- 每次都会开一局独立服务器。这里改由玩家自己指定房号加入。
    ---@type any
    local statusLabel_ = nil
    local roomInput_   = nil

    if SHOW_HINT then
        local hint = UI.Panel {
            position = "absolute", left = 0, top = 0, width = "100%", height = "100%",
            justifyContent = "center", alignItems = "center",
            backgroundColor = { 10, 14, 26, 255 },
        }

        local card = UI.Panel {
            flexDirection = "column", gap = 18, alignItems = "center",
            padding = 36, borderRadius = 14,
            backgroundColor = { 24, 30, 44, 255 },
            width = AUTO_MATCH and 360 or 420,
        }

        if AUTO_MATCH then
            -- ============ 自动模式 UI（简洁，只有状态）============
            card:AddChild(UI.Label {
                text = "正在连接服务器…",
                fontSize = 24,
                fontColor = { 220, 228, 245, 255 },
            })

            statusLabel_ = UI.Label {
                text = "正在匹配中，请稍候…",
                fontSize = 14,
                fontColor = { 170, 180, 200, 255 },
                textAlign = "center",
                maxLines = 0,
            }
            card:AddChild(statusLabel_)
        else
            -- ============ 手动模式 UI（原样保留）============
            card:AddChild(UI.Label {
                text = "联机大厅",
                fontSize = 28,
                fontColor = { 220, 228, 245, 255 },
            })

            statusLabel_ = UI.Label {
                text = "输入房间号加入，或创建新房间",
                fontSize = 15,
                fontColor = { 170, 180, 200, 255 },
                textAlign = "center",
                maxLines = 0,
            }
            card:AddChild(statusLabel_)

            roomInput_ = UI.TextField {
                placeholder = "房间号（房主建好后告知）",
                fontSize = 18,
                width = "100%",
                height = 48,
            }
            card:AddChild(roomInput_)

            card:AddChild(UI.Panel {
                flexDirection = "row", gap = 12,
                children = {
                    UI.Button {
                        text = "创建房间",
                        variant = "primary",
                        fontSize = 16, height = 46, paddingHorizontal = 22,
                        -- 建房成功后把房号显示出来，方便告知另一个玩家
                        onClick = function() onCreateRoom() end,
                    },
                    UI.Button {
                        text = "加入房间",
                        variant = "secondary",
                        fontSize = 16, height = 46, paddingHorizontal = 22,
                        onClick = function() onJoinRoom() end,
                    },
                },
            })
        end

        hint:AddChild(card)
        root:AddChild(hint)
    end

    ---@param text string
    local function setStatus(text)
        if statusLabel_ and statusLabel_.SetText then
            statusLabel_:SetText(text)
        end
    end

    -- ============ 状态 ============
    -- ⚠️ 必须声明在维护弹窗之前：弹窗的「重试」按钮会读写这些变量，
    --    Lua 的 local 作用域从声明处开始，放在后面会解析成全局 nil。
    local stopped_      = false
    local retries_      = 0
    local retryPending_ = false
    local retryCountdown_ = 0
    local updateSub_    = nil
    -- 本轮匹配已静默等待的秒数（收到任何服务器回调即清零）
    local silentElapsed_ = 0
    -- 是否已判定服务器不可达（避免每帧重复判定）
    local serverDown_   = false

    -- ============ 服务器维护提示（弹窗）============
    -- 服务器不可达时显示，替代原来的「正在进入游戏…」纯文字。
    ---@type any
    local maintModal_ = nil

    --- 显示「服务器维护中」弹窗（幂等：已显示则不重复建）
    local function showMaintenanceDialog()
        if maintModal_ then return end

        local overlay = UI.Panel {
            position = "absolute", left = 0, top = 0, width = "100%", height = "100%",
            justifyContent = "center", alignItems = "center",
            backgroundColor = { 0, 0, 0, 200 },
        }
        -- ⚠️ 以下尺寸 = 原始设计 × 2.5（整体放大）。
        --    改缩放倍数时把这一段的数值一起按比例调整。
        local card = UI.Panel {
            width = "85%", maxWidth = 950,
            flexDirection = "column",
            backgroundColor = { 34, 30, 44, 255 },
            borderRadius = 40,
            padding = 80,
            gap = 40,
            alignItems = "center",
        }
        card:AddChild(UI.Label {
            text = "🛠️",
            fontSize = 110,
            fontColor = { 255, 204, 102, 255 },
        })
        card:AddChild(UI.Label {
            text = "服务器维护中",
            fontSize = 55,
            fontColor = { 240, 236, 226, 255 },
        })
        card:AddChild(UI.Label {
            text = "TapTap 服务器正在维护，暂时无法进入游戏。\n请稍后再试。",
            fontSize = 33,
            fontColor = { 190, 190, 200, 255 },
            textAlign = "center",
            maxLines = 0,
        })
        card:AddChild(UI.Button {
            text = "重试",
            fontSize = 35,
            width = 400,
            height = 100,
            variant = "primary",
            onClick = function()
                -- 玩家手动重试：关弹窗 → 清空所有重试/计时状态 → 重新发起匹配
                if maintModal_ then
                    root:RemoveChild(overlay)
                    maintModal_ = nil
                end
                if not stopped_ then
                    serverDown_     = false
                    silentElapsed_  = 0
                    retries_        = 0
                    retryPending_   = false
                    retryCountdown_ = 0
                    -- 不再自动重连：回到大厅让玩家自己决定建房还是加入
                    setStatus("服务器已恢复，请选择创建或加入房间")
                end
            end,
        })
        overlay:AddChild(card)
        root:AddChild(overlay)
        maintModal_ = overlay
    end

    --- 关闭维护弹窗（匹配恢复有响应时调用）
    local function hideMaintenanceDialog()
        if maintModal_ then
            root:RemoveChild(maintModal_)
            maintModal_ = nil
        end
    end

    -- 收到任何服务器回调 → 说明服务器活着，清零静默计时并收起维护弹窗
    local function markServerAlive()
        silentElapsed_ = 0
        if serverDown_ then
            serverDown_ = false
            hideMaintenanceDialog()
            logInfo("服务器已恢复响应")
        end
    end

    -- ============ 建房 / 加入房间 ============
    --
    -- 🔴 为什么改成手动加入：
    --    自动匹配（StartMatch）已实测三次都无法让两人同服 —— 平台按 match_info
    --    分配服务器，每个玩家都会拿到一局独立的服务器实例。
    --    日志证据：两人各自的 QUICK_QUERY_MIDDLE_ROOM 都是 success=false，
    --    而查「自己」建的局却返回 success=true —— 该接口是重连语义，
    --    不提供跨玩家的公开房间发现。
    --
    --    所以这里改成显式流程：房主建房并把房号告知对方，对方输房号加入。
    --    用来验证「加入房间」这条路能否让两人落到同一台服务器。

    --- 发起匹配并连服（加入房间成功后调用）。
    --- ⚠️ 必须在「已在房间内」时调用 —— 否则平台又会开一局独立服务器。
    local function doStartMatch()
        client:StartMatch {
            onStarted = function()
                markServerAlive()
                logInfo("匹配已开始")
            end,
            onMatchFound = function(serverInfo)
                markServerAlive()
                logInfo("匹配成功，开始连服")
                setStatus("正在连接服务器…")
            end,
            onProgress = function(progress, status)
                if stopped_ then return end
                markServerAlive()
                if status and status ~= "" then
                    setStatus(status)
                elseif progress then
                    setStatus(string.format("正在连接服务器… %d%%",
                        math.floor((progress or 0) * 100)))
                end
            end,
            onError = function(code, message)
                markServerAlive()
                logError("匹配失败 code=" .. tostring(code) .. " msg=" .. tostring(message))
                setStatus("连接失败（" .. tostring(code) .. "），请重试")
            end,
        }
    end

    --- 建房成功后的提示（把房号显眼地打出来，方便告知另一个玩家）
    ---@param roomId integer
    local function onRoomCreated(roomId)
        markServerAlive()
        logInfo("已创建房间，房号=" .. tostring(roomId))
        setStatus("房间已创建，房号：" .. tostring(roomId)
            .. "\n请把房号告知对方，等他加入后点「开始游戏」")
        roomId_ = roomId
    end

    --- 创建房间（不自动开局，等人加入）
    onCreateRoom = function()
        if stopped_ then return end
        setStatus("正在创建房间…")
        logInfo("创建房间")
        client:CreateRoom {
            onCreated = function(roomId) onRoomCreated(roomId) end,
            onError = function(code, message)
                markServerAlive()
                logError("创建房间失败 code=" .. tostring(code) .. " msg=" .. tostring(message))
                setStatus("创建房间失败（" .. tostring(code) .. "），请重试")
            end,
        }
    end

    --- 加入指定房号的房间
    onJoinRoom = function()
        if stopped_ then return end
        local raw = roomInput_ and roomInput_:GetValue() or ""
        local num = tonumber((raw or ""):match("^%s*(.-)%s*$"))
        if not num then
            setStatus("请输入正确的房间号")
            return
        end
        setStatus("正在加入房间 " .. tostring(num) .. "…")
        logInfo("加入房间 " .. tostring(num))
        client:JoinRoom {
            roomId = num,
            onJoined = function()
                markServerAlive()
                logInfo("已加入房间 " .. tostring(num))
                setStatus("已加入房间，正在进入游戏…")
                -- 加入成功后直接开局（房主已在该房间里）
                doStartMatch()
            end,
            onError = function(code, message)
                markServerAlive()
                logError("加入房间失败 code=" .. tostring(code) .. " msg=" .. tostring(message))
                setStatus("加入失败（" .. tostring(code) .. "）：房间不存在或已满")
            end,
        }
    end

    -- 平台推送的全局异步错误（与具体动作无关，签名与 opts.onError 不同）
    client:OnError(function(errorType, errorCode)
        -- 平台能推送错误 = 网络层活着，不算服务器不可达
        markServerAlive()
        logError("平台异步错误 type=" .. tostring(errorType) .. " code=" .. tostring(errorCode))
    end)

    -- 重试计时 + 服务器无响应看门狗（完整 Runtime 没有模板沙箱的 Timer，用 Update 驱动）
    updateSub_ = SubscribeToEvent("Update", function(eventType, eventData)
        if stopped_ then return end
        local dt = eventData:GetFloat("TimeStep")

        -- 服务器无响应看门狗：静默超过阈值 → 判定维护中，弹窗
        if not serverDown_ then
            silentElapsed_ = silentElapsed_ + dt
            if silentElapsed_ >= SERVER_TIMEOUT then
                serverDown_ = true
                logError(string.format("服务器 %d 秒无响应，判定为维护/不可达", SERVER_TIMEOUT))
                -- 停掉自动重试：维护期间反复发起匹配没有意义，
                -- 交给玩家点弹窗上的「重试」手动触发。
                retryPending_   = false
                retryCountdown_ = 0
                setStatus("")
                showMaintenanceDialog()
            end
        end

        -- 🔴 维护弹窗显示期间不自动重试（只有玩家点「重试」才会重新发起）
        if serverDown_ then return end

        -- 自动重试已停用：房间流程由玩家手动触发，不做后台重试
        if not retryPending_ then return end
        retryPending_ = false
    end)

    -- ============ 启动 ============
    if not client:IsOnline() then
        logError("当前不在线，无法匹配")
        setStatus("当前离线，请检查网络后重试")
    elseif AUTO_MATCH then
        -- 自动模式：匹配由**引擎常驻服逻辑**自动完成（见文件顶部 AUTO_MATCH 注释）。
        -- ⚠️ 这里只设文案，**不要**调 doStartMatch() —— 会与引擎的自动匹配
        --    重复触发，导致每局都开一台独立服务器。
        logInfo("自动模式：等待引擎自动匹配")
        setStatus("正在匹配中，请稍候…")
    else
        logInfo("大厅就绪，等待玩家选择")
    end

    return {
        -- stop 在「连服成功、引擎切换游戏脚本」时被调用。
        -- ⚠️ 这里绝对不能发任何网络请求！
        --    尤其不能调 client:CancelMatch() —— 此时匹配已成功、正在连服，
        --    取消匹配会被服务器判定为「放弃重连」，立刻回一个
        --    KickedByServer(reason=GiveUpReconnect)，把玩家踢下线。
        -- stop 只做本地清理：置标志位、注销本地事件订阅。root 由引擎回收。
        stop = function()
            stopped_ = true
            retryPending_ = false
            if updateSub_ then
                UnsubscribeFromEvent(updateSub_)
                updateSub_ = nil
            end
            logInfo("大厅入口已停止（仅本地清理，未发送任何网络请求）")
        end,
    }
end
