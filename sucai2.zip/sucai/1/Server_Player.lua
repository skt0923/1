-- ============================================================
-- Server_Player.lua：玩家生命周期（Server.lua 的兄弟文件）
--
-- 职责：客户端就绪处理（顶号/新玩家/异步读档）· 权威数据下发 ·
--       云档套用 · 背包上报校验。
--
-- 与 Server.lua 的关系：
--   · 通过 Player.Init(ctx) 注入核心状态与服务
--   · 事件订阅由 Server.Start 调 Player.RegisterEvents() 完成
--   · BroadcastPlayerLeave / BroadcastOnlineCount / BroadcastPlayerInfo
--     与 SERVER_MAX_PLAYERS 仍**定义**在 Server.lua，但已通过 Player.Init
--     显式注入（ctx.broadcast* / ctx.serverMaxPlayers），不再走全局名解析
--
-- 依赖：Shared。**不 require Server.lua**（避免循环）。
-- ============================================================
local Shared = require("Shared")

local Player = {}

-- ============ 注入 ============
--- ⚠️ 默认空表 / 空实现：Init 前若真有事件进来（不该发生），
---    只会退化成「什么都不做」，不会因 nil 调用崩掉。
---@type table
local ctx = {
    players         = {},
    connections     = {},
    getScene        = function() return nil end,
    MarkPlayerDirty = function(_) end,
    SaveToCloud     = function(_) end,
    LoadSaveAsync   = function(_, cb) if cb then cb(nil) end end,
    Sys             = nil,
    Boss            = nil,
    Cloud           = nil,
    -- 全局广播与人数上限（Server.lua 注入）
    serverMaxPlayers     = 0,                   -- 兜底：Init 前不应有事件；真到了走保守拒绝（n >= 0 恒真）
    broadcastPlayerLeave = function(_) end,
    broadcastOnlineCount = function() end,
    broadcastPlayerInfo  = function() end,
}

function Player.Init(c)
    for k, v in pairs(c) do ctx[k] = v end
end

-- ============ 事件订阅 ============
function Player.RegisterEvents()
    SubscribeToEvent(Shared.EVENTS.CLIENT_READY, Player.OnClientReady)
end

-- ============ 以下为从 Server.lua 搬来的 4 个函数 ============
-- 纯搬运：函数体逻辑一字不改，仅做了 4 处改写
--   1) 函数名加 Player. 前缀（validateInventory 同时改名 ValidateInventory），内部互调同步
--   2) scene_ -> ctx.getScene()
--   3) players / connections / Sys. / Boss. / Cloud. / MarkPlayerDirty / SaveToCloud /
--      LoadSaveAsync -> 全部走注入的 ctx
--   4) Broadcast* 三个全局广播函数与 SERVER_MAX_PLAYERS 通过 Player.Init
--      显式注入（ctx.broadcast* / ctx.serverMaxPlayers），不依赖全局名解析

function Player.OnClientReady(_, e)
    local c = e["Connection"]:GetPtr("Connection")
    local info = ctx.connections[tostring(c)]
    if not info then return end

    -- 人数上限拦截。
    -- 平台层理论上会在更早的阶段拒绝超员连接，但这里再兜一道：
    -- 常驻服是「随时加入」，人数可能在两次连接之间被填满，
    -- 不拦的话 players 会无限增长（位置广播随之变成 O(N^2)）。
    --
    -- 顶号（同 playerId 重连）必须放行，否则人满了房主自己掉线就再也回不来。
    -- 判定时机在 playerId 赋值之前，所以用 userId 比。
    local myUid = info.userId
    local alreadyIn = false
    if myUid then
        for _, other in pairs(ctx.players) do
            if other.userId == myUid then alreadyIn = true break end
        end
    end
    if not alreadyIn then
        local n = 0
        for _ in pairs(ctx.players) do n = n + 1 end
        if n >= ctx.serverMaxPlayers then
            print(string.format("[Server] 服务器已满（%d/%d），拒绝 %s",
                n, ctx.serverMaxPlayers, tostring(info.userId or "?")))
            -- 先通知再断开：断开后这条连接就发不出去了
            c:SendRemoteEvent(Shared.EVENTS.SERVER_FULL, true, Shared.ToVariantMap({
                Max = ctx.serverMaxPlayers,
            }))
            ctx.connections[tostring(c)] = nil
            c:Disconnect(0)
            return
        end
    end

    -- ✅ 客户端已就绪，此时才能设置场景（触发全量同步）
    c.scene = ctx.getScene()

    -- 玩家主键：优先用认证 user_id（重连后稳定，存档能读回来）
    -- 回退方案只用于预览等无认证环境，会导致重连丢档，仅作兜底
    local pid
    if info.userId then
        pid = "u" .. tostring(info.userId)
    else
        pid = info.fallbackId or ("p" .. tostring(math.random(100000, 999999)))
        info.fallbackId = pid
        print("[Server] ⚠️ " .. pid .. " 使用回退 ID（无认证），重连会丢档")
    end
    info.playerId = pid

    -- 🔴 重建节点前，先删掉可能存在的同名旧节点。
    --    REPLICATED 是按「节点 ID」同步的，同名但 ID 不同的节点会**并存**；
    --    客户端 UpdateRemotePlayers 用 GetChild("Player_"..pid) 按名字查找，
    --    只拿到第一个 → 位置更新全打在旧节点上，新节点纹丝不动，
    --    表现为「对方原地踏步」+ 场上多出一个不动的模型。
    --    这里用精确名字查找（recursive=false），拿到的就是顶层同名节点。
    local sc = ctx.getScene()
    local stale = sc:GetChild("Player_" .. pid, false)
    if stale then
        stale:Remove()
        print("[Server] " .. pid .. " 发现残留同名节点，已移除（避免客户端同名竞态）")
    end

    local node = sc:CreateChild("Player_" .. pid, REPLICATED)
    node.position = Vector3(0, 0, 0)

    -- 已在线（重连 / 顶号）：复用内存状态，避免重复建表
    local existing = ctx.players[pid]
    if existing then
        -- 【新增】数据不可信（上次读档失败）→ 强制重新读档。
        --
        -- 场景：玩家上线 → LoadSaveAsync 失败 → __hasValidClientData = false
        --       → 客户端弹「进度同步失败」门 → 玩家点重试
        --       → Net.RetrySave → Net.Reconnect → 重发 CLIENT_READY → 到这里。
        --
        -- 此时**不能**复用 existing（它还是默认空档），必须重新读档。
        if not existing.__hasValidClientData then
            print("[Server] " .. pid .. " 重连但数据不可信，强制重新读档")

            -- ⚠️ 节点交接必须做（与下面顶号路径一致）：
            --    本分支会 return，若跳过这段，新建的 node 就成了孤儿节点，
            --    场景里会残留一个同名 Player_<pid> —— 客户端 GetChild 按名查找
            --    可能拿到错的那个，位置同步错乱（见上方同名竞态注释）。
            if existing.node then
                existing.node:Remove()
            end
            existing.node = node
            ctx.broadcastPlayerLeave(pid)

            -- 先下发一次现状，保证客户端界面有响应
            -- （门控下不会下发客户端权威字段，客户端保持本地显示）
            existing.lastBroadcastX = nil
            existing.lastBroadcastZ = nil
            Player.SendAssignPlayer(c, existing)
            ctx.Boss.PushSharedBossesTo(c)

            -- 异步重新读档；成功后再次下发覆盖
            ctx.LoadSaveAsync(pid, function(save, loaded)
                local live = ctx.players[pid]
                if not live then return end
                -- 重新查连接：加载期间玩家可能又断线/重连
                local info2 = ctx.Sys.FindConnectionByPlayerId(pid)
                local c2 = info2 and info2.connection
                if not c2 then return end

                if loaded and type(save) == "table" then
                    ctx.Cloud.MarkClientDataValid(live)
                    Player.ApplySaveToPlayer(live, save)
                    Player.SendAssignPlayer(c2, live)
                    print("[Server] " .. pid .. " 重连后读档成功，已恢复")
                else
                    print("[Server] " .. pid .. " 重连后读档仍失败")
                    -- 让客户端门重新弹出（否则门关了就再也没提示）
                    c2:SendRemoteEvent(
                        Shared.EVENTS.SAVE_FAILED, true, Shared.ToVariantMap({}))
                end
            end)
            return
        end

        -- 顶号：老会话的进度可能还没落云，先写一次再交棒，避免丢操作
        ctx.SaveToCloud(pid)
        print("[Server] " .. pid .. " 顶号，老玩家存档已写云")
        -- 通知旧连接被顶下线。
        -- ⚠️ 必须排除当前这条新连接：此时 info.playerId 已被设为 pid，
        --    FindConnectionByPlayerId 可能返回新连接本身，导致把自己踢掉。
        for _, cinfo in pairs(ctx.connections) do
            if cinfo.playerId == pid and cinfo.connection and cinfo.connection ~= c then
                cinfo.connection:SendRemoteEvent(Shared.EVENTS.KICKED, true,
                    Shared.ToVariantMap({ Reason = "顶号登录" }))
                print("[Server] " .. pid .. " 已通知旧连接下线")
                break
            end
        end
        -- 老节点不清理的话，场景里会残留一个同名节点
        if existing.node then
            existing.node:Remove()
        end
        existing.node = node
        -- 通知其他客户端：这个 pid 的旧模型先清掉，避免与新节点并存
        ctx.broadcastPlayerLeave(pid)
        -- ⚠️ 这条重连路径不走 ApplySaveToPlayer（直接复用内存状态），
        --    必须在这里手动清掉广播基准：否则重连后如果位置和断线前一样，
        --    就不会广播 → 其他玩家看不到他回来了（一直停在旧坐标/不可见）。
        existing.lastBroadcastX = nil
        existing.lastBroadcastZ = nil
        Player.SendAssignPlayer(c, existing)
        -- 断线期间可能已经刷出了共享 Boss，补推一次（理由见 Server_Boss.PushSharedBossesTo）
        ctx.Boss.PushSharedBossesTo(c)
        print("[Server] " .. pid .. " 重连，复用内存状态")
        return
    end

    -- 新玩家：先建好默认状态，再异步读云存档
    -- （服务端文件 I/O 被引擎屏蔽，存档只能走 serverCloud）
    local base = Shared.NewPlayerSave()
    ---@type ServerPlayer
    local p = {
        id                 = pid,
        userId             = info.userId,
        node               = node,
        gold               = base.gold,
        level              = base.level,
        inventory          = {},
        equipment          = base.equipment,
        bagPageCount       = base.bagPageCount,
        autoDecompose      = base.autoDecompose,
        autoDecomposeUnid  = base.autoDecomposeUnid,
        autoRepair         = base.autoRepair,
        -- 🔴 宠物系统必须在这里初始化（与 equipment 同理）：
        --    漏掉会让 p.pets 为 nil，SendAssignPlayer 用 `p.pets or {}` 发出空表
        --    → 客户端拿到 {}(真值) 覆盖掉默认结构 → UI 读 pets.equipped 崩溃。
        --    同时 SnapshotJson 的 `p.pets or {...}` 会把默认空结构写进云档。
        pets               = base.pets,
        petGacha           = base.petGacha,
        -- 天赋树：与 pets 同理，必须在这里初始化 —— 漏掉会让 p.bdTree 为 nil，
        -- SendAssignPlayer 用 `p.bdTree or {}` 发出空表（真值）覆盖客户端默认结构。
        bdTree             = base.bdTree,
        mails              = {},
        nextMailId         = base.nextMailId,
        onlineTokenMinutes = 0,
        adCountToday       = 0,
        adLastTime         = 0,
        lastResetDate      = Shared.TodayString(),
        lastDailyGiftDate  = "",
        starterGiftReceived = base.starterGiftReceived,
        settings           = base.settings,
        save               = { x = 0, z = 0 },
        -- 钱庄
        bankDeposits       = {},
        bankTodayEarnings  = 0,
        bankLastSettledDate = "",
        dailyGiftDate      = "",
    }
    -- 数据可信标志：读档成功 / 会话内收到客户端实质上报 → true
    -- 读档失败 + 无上报 → false（此时不下发客户端权威字段、不落盘）
    -- 见 SaveToCloud / SendAssignPlayer / OnInvSync
    p.__hasValidClientData = false
    ctx.players[pid] = p

    -- 立即激活：先让玩家进游戏，不等待云存档
    -- （原实现挂起等存档，云变量慢时会卡在「加载中」最多 3 秒）
    Player.SendAssignPlayer(c, p)
    print("[Server] " .. pid .. " 上线（本地档）")

    -- 在线人数广播（自己也会收到，HUD 立刻显示正确人数）
    ctx.broadcastOnlineCount()
    -- 昵称映射广播（让所有人立刻拿到新玩家的昵称）
    ctx.broadcastPlayerInfo()
    -- 常驻服：中途加入的玩家补推当前存活的共享 Boss（理由见 Server_Boss.PushSharedBossesTo）
    ctx.Boss.PushSharedBossesTo(c)

    -- 后台异步拉云存档。回调可能晚于玩家的第一批操作到达，所以要先看 __dirty：
    --   有脏数据 → 云端是旧的，丢弃它，把本地状态回写云端（否则会覆盖掉玩家的新操作）
    --   无脏数据 → 玩家还没动过，可以安全地用云端覆盖本地
    --
    -- ⚠️ 新手礼包必须放在「存档合并之后」：GrantStarterGift 会写邮件并 MarkPlayerDirty，
    --    若在合并前发放，__dirty 会让下面的分支误判为「玩家已有新操作」，
    --    从而丢弃云存档、把刚建好的空档回写云端 —— 老玩家的存档会被直接清掉。
    --    兜底还有 SaveToCloud 里「saveLoaded 之前拒绝落盘」那道守卫。
    ctx.LoadSaveAsync(pid, function(save, loaded)
        local live = ctx.players[pid]
        if not live then
            -- 玩家已下线/被销毁，回调不再适用
            return
        end

        -- 🔴 云档已读回（无论有无数据）→ 放开落盘。
        --    必须在这里置位：SaveToCloud 在读到云档前一律拒绝写云，
        --    否则上面说的「每秒赠送 → __dirty → 回写空档」会永久覆盖玩家进度。
        live.saveLoaded = true

        if loaded then
            -- 读档成功（save 可能是 nil = 新玩家）→ 数据可信
            ctx.Cloud.MarkClientDataValid(live)
            -- 【诊断】打印云档内容，用于确认数据是否丢失（确认后删除）
            if type(save) == "table" then
                local poolN = (save.pets and save.pets.pool) and #save.pets.pool or 0
                local eqN = 0
                for _, v in pairs(save.equipment or {}) do if v then eqN = eqN + 1 end end
                print(string.format(
                    "[Server][诊断] %s 云档内容：背包 %d 项 / 装备 %d 件 / 金币 %d / 宠物池 %d / 邮件 %d",
                    pid, #(save.inventory or {}), eqN, save.gold or 0, poolN,
                    #(save.mails or {})))
            end
        else
            -- 读档失败：live 保持默认档，__hasValidClientData 保持 false
            -- 主动通知客户端弹「进度同步失败」门，让玩家手动重试
            print("[Server] " .. pid .. " 读档失败，通知客户端重试")
            local info = ctx.Sys.FindConnectionByPlayerId(pid)
            if info and info.connection then
                info.connection:SendRemoteEvent(
                    Shared.EVENTS.SAVE_FAILED, true, Shared.ToVariantMap({}))
            end
        end

        if type(save) == "table" then
            if live.__dirty then
                -- 玩家确实在加载窗口内做了实质操作 → 游戏性字段保留 live 的本地值。
                --
                -- ⚠️ 以下字段是「客户端权威」，故意不合并（保持 live 现状）：
                --    gold / level / inventory / equipment / onlineTokenMinutes /
                --    settings / autoDecompose / autoDecomposeUnid / save.x / save.z
                --
                -- ⚠️ 以下字段是「服务端权威」，必须从云端恢复，否则会：
                --    · 重复发每日奖励（lastDailyGiftDate 丢失 → 幂等键失效）
                --    · 邮件全丢（mails / nextMailId 丢失）
                --    · 广告次数被重置（adCountToday 丢失）
                --    · 背包页数退回初始值（bagPageCount 丢失）
                live.mails              = save.mails or live.mails
                live.nextMailId         = save.nextMailId or live.nextMailId
                live.lastDailyGiftDate  = save.lastDailyGiftDate or ""
                live.starterGiftReceived = save.starterGiftReceived or false
                live.dailyGiftDate      = save.dailyGiftDate or ""
                live.lastResetDate      = save.lastResetDate or live.lastResetDate
                live.adCountToday       = save.adCountToday or live.adCountToday
                live.adLastTime         = save.adLastTime or live.adLastTime
                live.bagPageCount       = save.bagPageCount or live.bagPageCount
                live.bankDeposits       = save.bankDeposits or live.bankDeposits
                live.bankTodayEarnings  = save.bankTodayEarnings or 0
                live.bankLastSettledDate = save.bankLastSettledDate or ""
                -- 宠物系统：客户端权威，但**本地未必已上报**（抽卡后立刻断线时
                -- 脏标记还没走完同步周期），所以云档里的宠物不能丢。
                -- ⚠️ 只在云端结构完整时才覆盖；空档（新玩家 / 结构损坏）保留 live。
                if Shared.IsPetDataValid(save.pets) then live.pets = save.pets end
                if type(save.petGacha) == "table"
                    and type(save.petGacha.counters) == "table" then
                    live.petGacha = save.petGacha
                end

                print("[Server] " .. pid .. " 玩家已有新操作，保留本地游戏性字段，合并服务端权威字段")
                -- 刚恢复的邮件要推给客户端，否则玩家要等下一次 InvSync / 开邮箱翻页
                -- 才看得到（AssignPlayer 时下发的邮件列表是空的）。
                -- ⚠️ 只推邮件，不推 PushInventory：背包/金币是客户端权威，
                --    强推会覆盖掉玩家刚做、还没上报的那部分操作。
                ctx.Sys.NotifyMail(live)
                ctx.SaveToCloud(pid)
                live.__dirty = false
            else
                Player.ApplySaveToPlayer(live, save)
                ctx.Sys.PushInventory(live, true)
                -- 云端数据已推给客户端 → 客户端手里有权威数据，其上报可信
                live.__sentAuthData = true
                print("[Server] " .. pid .. " 云存档异步恢复")
            end
        end

        -- 新手礼包 / 每日礼包：**仅在数据可信时发放**。
        -- ⚠️ 读档失败时不能发：那会写邮件并 MarkPlayerDirty，而
        --    __hasValidClientData 仍为 false → 一旦后续落盘被放行，
        --    就会把「凭空多出的礼包」写进云档。
        if loaded then
            -- 新手礼包：首次上线补发（幂等靠 starterGiftReceived）
            local granted = ctx.Sys.GrantStarterGift(live)
            if granted then
                ctx.Sys.NotifyMail(live)
                ctx.Sys.PushInventory(live)
                -- 告知客户端：新手装备已自动穿戴，引导玩家到角色面板查看
                local info = ctx.Sys.FindConnectionByPlayerId(pid)
                if info and info.connection then
                    info.connection:SendRemoteEvent(Shared.EVENTS.STARTER_GIFT, true,
                        Shared.ToVariantMap({ Count = #Shared.SLOT_LIST }))
                end
            end

            -- 每日礼包：每天上线时发一次（存档读取完成之后执行）
            -- ⚠️ 只在 LoadSaveAsync 回调里调用一次，不做每秒检查
            -- 发放到邮箱，由玩家到邮件面板自行领取（不再弹顶部提示）
            local dailyGranted = ctx.Sys.GrantDailyGift(live)
            if dailyGranted then
                ctx.Sys.PushInventory(live)
                ctx.Sys.NotifyMail(live)
            end
        end

        -- 【等级石迁移】独立于 ApplySaveToPlayer。
        -- 无论 loaded / save / __dirty 都会执行一次（幂等靠 levelStoneGiftReceived）。
        if not live.levelStoneGiftReceived then
            local oldLevel = 1
            if type(save) == "table" and type(save.level) == "number" then
                oldLevel = math.floor(save.level)
                if oldLevel < 1 then oldLevel = 1 end
                if oldLevel > Shared.C.MAX_LEVEL then oldLevel = Shared.C.MAX_LEVEL end
            end
            live.levelStone = {
                id    = "ls_" .. Shared.UUID(),
                type  = "levelStone",
                level = oldLevel,
                icon  = "💎",
                name  = "等级石 Lv." .. oldLevel,
            }
            live.levelStoneGiftReceived = true
            ctx.MarkPlayerDirty(pid)
            print(string.format("[Server] %s 等级石迁移：发放 Lv.%d 等级石（自动穿戴）",
                pid, oldLevel))

            -- 主动下发（迁移发生在首次 SendAssignPlayer 之后）
            local info3 = ctx.Sys.FindConnectionByPlayerId(pid)
            if info3 and info3.connection then
                Player.SendAssignPlayer(info3.connection, live)
            end
        end
    end)
end

--- 把存档数据套用到玩家状态上
---@param p ServerPlayer
---@param save table|nil
function Player.ApplySaveToPlayer(p, save)
    if type(save) ~= "table" then save = {} end
    local base = Shared.NewPlayerSave()
    local today = Shared.TodayString()
    local dailyReset = (save.lastResetDate ~= nil and save.lastResetDate ~= today)

    p.gold               = save.gold or base.gold
    p.level              = save.level or base.level
    p.inventory          = save.inventory or {}
    p.equipment          = save.equipment or base.equipment
    -- 🔴 存量清洗（2026-10-04）：移除历史装备中超出「随机属性 + 技能」上限的词条。
    --    ⚠️ 必须**服务端也做**：客户端 ApplyServerPayload 会用服务端下发的
    --       equipment/inventory 直接覆盖本地，只在客户端清会被覆盖回来。
    do
        local r1 = Shared.SanitizeAffixContainer(p.equipment)
        local r2 = Shared.SanitizeAffixContainer(p.inventory)
        local total = r1 + r2
        -- 存量清洗：强化等级超出该件上限的历史装备，夹回上限
        local c = 0
        for _, it in pairs(p.equipment) do
            if Shared.ClampItemEnhance(it) then c = c + 1 end
        end
        for _, it in ipairs(p.inventory) do
            if Shared.ClampItemEnhance(it) then c = c + 1 end
        end
        if total + c > 0 then
            -- 标脏 → 下次 SaveToCloud 会把清洗后的存档写回，否则每次上线都要重清
            ctx.MarkPlayerDirty(p.id)
            print(string.format("[Server] %s 存档清洗：词条 %d 条 / 强化超限 %d 件（已标脏待落盘）",
                p.id, total, c))
        end
    end

    -- 【一次性】把旧存档里的战斗卡转为在线卡（功能已删除，仅老存档有存量）。
    --   ⚠️ 只需在此处转换：所有玩家（在线/离线）上线时都走 ApplySaveToPlayer，
    --      战斗卡不会再新增，转一次即永久有效。
    --   战斗卡与在线卡原本同源（都是时长消耗品），1:1 转换语义正确。
    do
        local converted = 0
        local disp = Shared.TOKEN_TYPES["online"]
        for _, it in ipairs(p.inventory) do
            if it and it.type == "battleToken" then
                it.type      = "onlineToken"
                it.tokenType = "online"
                it.name      = (disp and disp.name) or "在线卡"
                it.icon      = (disp and disp.icon) or "🎟️"
                it.quality   = it.quality or "normal"
                converted    = converted + (it.count or 1)
            end
        end
        if converted > 0 then
            ctx.MarkPlayerDirty(p.id)
            print(string.format("[Server] %s 战斗卡转为在线卡 %d 张（旧存档遗留）",
                p.id, converted))
        end
    end

    p.bagPageCount       = save.bagPageCount or base.bagPageCount
    p.autoDecompose      = save.autoDecompose or base.autoDecompose
    p.autoDecomposeUnid  = save.autoDecomposeUnid or base.autoDecomposeUnid
    p.autoRepair         = save.autoRepair or base.autoRepair
    -- 宠物系统：老存档无该字段（或结构不完整）时用 base 的空结构兜底。
    -- ⚠️ 不能只判 `save.pets or base.pets`：云档里可能是**不完整的表**
    --    （如 `{}`），它是真值，会绕过兜底并让后续 UI 读 pets.equipped 崩溃。
    p.pets               = Shared.IsPetDataValid(save.pets) and save.pets or base.pets
    p.petGacha           = (type(save.petGacha) == "table"
                            and type(save.petGacha.counters) == "table")
                           and save.petGacha or base.petGacha
    -- 天赋树：结构不完整时用空档兜底（与 pets 同样的容错逻辑）
    p.bdTree             = Shared.IsBDTreeValid(save.bdTree) and save.bdTree or base.bdTree
    -- 老宠物迁移：无 maxLevel 字段的补一个（用品质固定上限作兜底）。
    -- ⚠️ 静默迁移：玩家本来就不知道这个字段，提示反而困惑。
    --    迁移后的宠物下次落盘时写回云档。
    do
        local function MigratePet(pet)
            if type(pet) == "table" and not pet.maxLevel then
                pet.maxLevel = Shared.PET_QUALITY_MAX_LEVEL[pet.quality] or 20
            end
        end
        for _, pet in ipairs(p.pets.pool or {}) do MigratePet(pet) end
        for _, pet in pairs(p.pets.equipped or {}) do
            if pet then MigratePet(pet) end
        end
    end
    p.mails              = save.mails or {}
    p.nextMailId         = save.nextMailId or base.nextMailId

    -- 时长：旧存档无 Minutes 字段则从旧 Seconds 字段迁移
    if save.onlineTokenMinutes ~= nil then
        p.onlineTokenMinutes = save.onlineTokenMinutes
    elseif (save.onlineTokenSeconds or 0) > 0 then
        p.onlineTokenMinutes = math.floor(save.onlineTokenSeconds / 60)
    else
        p.onlineTokenMinutes = 0
    end
    p.adCountToday       = dailyReset and 0 or (save.adCountToday or 0)
    p.adLastTime         = save.adLastTime or 0
    p.lastResetDate      = today
    p.lastDailyGiftDate  = save.lastDailyGiftDate or ""
    p.starterGiftReceived = save.starterGiftReceived
    p.dailyGiftDate      = save.dailyGiftDate or ""

    p.save = p.save or {}
    if save.x then p.save.x = save.x end
    if save.z then p.save.z = save.z end

    -- 等级石
    if type(save.levelStone) == "table" and save.levelStone.level then
        p.levelStone = save.levelStone
    else
        p.levelStone = nil
    end
    p.levelStoneGiftReceived = save.levelStoneGiftReceived or false

    -- 【一次性】等级石迁移：从未领过礼包 → 发放对应等级的等级石（自动穿戴）
    if not p.levelStoneGiftReceived then
        local oldLevel = save.level or 1
        if oldLevel < 1 then oldLevel = 1 end
        if oldLevel > Shared.C.MAX_LEVEL then oldLevel = Shared.C.MAX_LEVEL end

        local stone = {
            id    = "ls_" .. Shared.UUID(),
            type  = "levelStone",
            level = oldLevel,
            icon  = "💎",
            name  = "等级石 Lv." .. oldLevel,
        }
        p.levelStone = stone
        p.levelStoneGiftReceived = true
        ctx.MarkPlayerDirty(p.id)
        print(string.format("[Server] %s 等级石迁移：发放 Lv.%d 等级石（自动穿戴）",
            p.id, oldLevel))
    end

    -- 设置已客户端化：不上报、不读取、不写云。
    -- p.settings 保留字段声明（ServerPlayer 类型里有它），但不参与任何逻辑。
    p.settings = base.settings

    -- 钱庄存款列表 + 结算状态
    p.bankDeposits = save.bankDeposits or {}
    -- 新字段：给旧存档里的存款补 accumulatedInterest
    for _, dep in ipairs(p.bankDeposits) do
        if dep.accumulatedInterest == nil then dep.accumulatedInterest = 0 end
    end
    p.bankTodayEarnings = save.bankTodayEarnings or 0
    p.bankLastSettledDate = save.bankLastSettledDate or ""

    -- 位置广播去重的基准。置 nil 让上线后第一次上报必然广播一次：
    -- 其他玩家眼里的你是「刚入场」，不广播他们就不知道你在哪
    -- （存档里的 x/z 只是上次下线的位置，不会主动推给别人）。
    p.lastBroadcastX = nil
    p.lastBroadcastZ = nil
end

---@param c Connection
---@param p table
function Player.SendAssignPlayer(c, p)
    local configJson = cjson.encode(Shared.BuildConfigPayload())
    local mg, mi = ctx.Sys.CalcMailTotals(p)

    -- ============ 服务端权威字段（不受门控，始终下发）============
    local payload = {
        PlayerId           = p.id,
        -- 邮件（服务端权威）
        Mails              = cjson.encode(ctx.Sys.MailPageSlice(p, 0)),
        MailTotal          = #p.mails,
        MailGoldTotal      = mg,
        MailItemTotal      = mi,
        -- 钱庄（服务端权威）
        BankDeposits       = cjson.encode(p.bankDeposits or {}),
        BankTodayEarnings  = p.bankTodayEarnings or 0,
        -- 服务器配置（与玩家数据无关，始终下发）
        Config             = configJson,
        -- 位置：客户端权威，但每个玩家都必须下发 —— 否则读档失败时玩家会
        -- 回到 (0,0,0)，比留在客户端内存位置更差
        X                  = (p.save and p.save.x) or 0,
        Z                  = (p.save and p.save.z) or 0,
    }

    -- ============ 客户端权威字段（仅在数据可信时下发）============
    -- 🔴 读档失败时**不带**这些字段：客户端 ApplyServerPayload 里
    --    `if payload.X ~= nil then ... end` 的逻辑会自动保留本地数据，
    --    不会被服务端的默认空档覆盖。
    if p.__hasValidClientData then
        payload.Gold               = p.gold
        payload.Level              = p.level
        payload.Inventory          = cjson.encode(p.inventory)
        payload.Equipment          = cjson.encode(p.equipment)
        payload.BagPageCount       = p.bagPageCount
        payload.OnlineTokenMinutes = p.onlineTokenMinutes or 0
        payload.AdCountToday       = p.adCountToday
        -- 自动分解 / 自动维修开关（客户端权威，换设备时由服务端下发）
        payload.AutoDecompose      = cjson.encode(p.autoDecompose or {})
        payload.AutoDecomposeUnid  = cjson.encode(p.autoDecomposeUnid or {})
        payload.AutoRepair         = p.autoRepair and 1 or 0
        -- 宠物系统：结构走 Shared 单一事实来源（空表会被客户端校验拦截，
        -- 但仍以发完整结构为准，避免依赖客户端的容错）
        payload.Pets               = cjson.encode(
            Shared.IsPetDataValid(p.pets) and p.pets or Shared.NewPetData())
        payload.PetGacha           = cjson.encode(
            (type(p.petGacha) == "table" and type(p.petGacha.counters) == "table")
            and p.petGacha or Shared.NewPetGachaData())
        -- 等级石（客户端权威）
        payload.LevelStone             = cjson.encode(p.levelStone or {})
        payload.LevelStoneGiftReceived = p.levelStoneGiftReceived and 1 or 0
        -- 天赋树：结构走 Shared 单一事实来源
        payload.BDTree             = cjson.encode(
            Shared.IsBDTreeValid(p.bdTree) and p.bdTree or Shared.NewBDTree())
        -- 🔴 只有真正下发了客户端权威字段，客户端才算「手里有权威数据」。
        --    读档失败时这一段不执行 → 客户端从未拿到权威数据 →
        --    它后续的上报一律不可信（见 OnInvSync）。
        p.__sentAuthData = true
    end

    c:SendRemoteEvent(Shared.EVENTS.ASSIGN_PLAYER, true, Shared.ToVariantMap(payload))
end

--- 校验并裁剪客户端上报的背包：去重 id、丢弃非法项、限制总格数。
---@param arr any
---@param bagPageCount integer
---@return table[]
function Player.ValidateInventory(arr, bagPageCount)
    if type(arr) ~= "table" then return {} end
    local max = math.min((bagPageCount or 1) * Shared.C.BAG_PAGE_SIZE, Shared.C.MAX_INVENTORY)
    local out = {}
    local seen = {}
    for _, it in ipairs(arr) do
        if #out >= max then break end
        if type(it) == "table" and type(it.id) == "string" and not seen[it.id] then
            seen[it.id] = true
            table.insert(out, it)
        end
    end
    return out
end

return Player
