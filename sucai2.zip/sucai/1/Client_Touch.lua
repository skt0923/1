-- ============================================================
-- Client_Touch.lua：虚拟摇杆与视角触摸（Client.lua 的兄弟文件）
--
-- 职责：创建虚拟摇杆（左下角）、右半屏视角拖动区、双指捏合缩放。
--
-- 与 Client.lua 的关系：
--   · 跨函数共享状态走 Client_State（local S），不 require Client.lua
--   · 相机轨道上下限（CAM_PITCH_MIN_/MAX_、CAM_DIST_MIN_/MAX_）两边共用，
--     由 Client.lua 在 Start() 里通过 Touch.Init 注入，保持单一数据源
--   · 灵敏度常量（VIEW_SENS / PINCH_SENS）只在本文件用，随逻辑迁入
--
-- 跨文件调用走 Touch.*：
--   Touch.Setup()          ← Client.lua 的 Start() 调用
--   Touch.UpdatePinchZoom() ← Client.lua 的 OnUpdate() 每帧调用
--
-- 依赖：Shared + Client_State + urhox-libs/UI/VirtualControls。
--       **不 require Client.lua**。
-- ============================================================
local Shared = require("Shared")
local Data   = Shared.Data
local S      = require("Client_State")

require "urhox-libs.UI.VirtualControls"   -- 注册全局 VirtualControls

local Touch = {}

--- 由 Client.lua 注入共用的相机轨道上下限（Start 里调用一次）
---@param c table { CAM_PITCH_MIN_: number, CAM_PITCH_MAX_: number,
---                 CAM_DIST_MIN_: number, CAM_DIST_MAX_: number }
function Touch.Init(c)
    if c.CAM_PITCH_MIN_ then Touch.CAM_PITCH_MIN_ = c.CAM_PITCH_MIN_ end
    if c.CAM_PITCH_MAX_ then Touch.CAM_PITCH_MAX_ = c.CAM_PITCH_MAX_ end
    if c.CAM_DIST_MIN_  then Touch.CAM_DIST_MIN_  = c.CAM_DIST_MIN_ end
    if c.CAM_DIST_MAX_  then Touch.CAM_DIST_MAX_  = c.CAM_DIST_MAX_ end
end

-- 与 Client.lua 共用的相机轨道上下限（默认值 = 拆分前原值；Start() 里 Touch.Init 覆盖）
Touch.CAM_PITCH_MIN_ = math.rad(Shared.C.CAM_PITCH_MIN)
Touch.CAM_PITCH_MAX_ = math.rad(Shared.C.CAM_PITCH_MAX)
Touch.CAM_DIST_MIN_  = Shared.C.CAM_DIST_MIN
Touch.CAM_DIST_MAX_  = Shared.C.CAM_DIST_MAX

-- ============ 摇杆与视角触摸 ============
-- 右半屏拖动 → 旋转视角；双指捏合 → 缩放距离。
-- 视角灵敏度单位：弧度 / 设计像素（设计分辨率 1920x1080）。
-- 0.0035 ≈ 拖满整个屏幕宽度转约 385°，接近主流手游手感。
local VIEW_SENS = 0.0035
local PINCH_SENS = 0.03


function Touch.Setup()
    VirtualControls.Initialize()

    -- C1：摇杆（触摸 + PC 键盘 WASD 双通道）
    S.joystick_ = VirtualControls.CreateJoystick({
        position = Vector2(150, -150),          -- 左下角：距左 150、距底 150
        alignment = { HA_LEFT, VA_BOTTOM },
        baseRadius = 80,
        knobRadius = 35,
        moveRadius = 55,
        deadZone = 0.16,
        opacity = 0.55,
        activeOpacity = 0.9,
        keyBinding = "WASD",
        alwaysShow = true,
    })

    -- 右半屏视角拖动。已确认 urhox-libs/UI/VirtualControls 提供
    -- CreateTouchLookArea（内部按设计坐标做区域判定，优先级低于按钮/摇杆）。
    S.lookArea_ = VirtualControls.CreateTouchLookArea({
        regionPreset = "right_half",
        -- 设置面板已删除视角灵敏度选项，固定 1.0
        sensitivity = VIEW_SENS,
        on_look = function(deltaYaw, deltaPitch)
            -- Modal 打开时让位给 UI，不转视角
            if Shared.UIState.modalOpen or Shared.UIState.inputFocus then return end
            -- deltaYaw = 手指水平位移 × 灵敏度（右拖为正）。
            -- 相机位置 = 玩家 + (sin(yaw), cos(yaw))·dist，yaw 增大即相机绕玩家右移，
            -- 视角随之右转 —— 与手指方向一致。之前写成减法会让视角反向。
            S.camYaw_ = S.camYaw_ + deltaYaw
            S.camPitch_ = Shared.Clamp(S.camPitch_ + deltaPitch,
                Touch.CAM_PITCH_MIN_, Touch.CAM_PITCH_MAX_)
            -- 实时写回设置（下次开设置面板能看到当前值）
            local s = Data.GetSettings()
            local deg = math.deg(S.camPitch_)
            if math.abs((s.camPitch or 0) - deg) > 0.5 then
                s.camPitch = math.floor(deg + 0.5)
                Data.MarkDirty("settings")
            end
        end,
    })

    print("[Client] 虚拟摇杆已创建")
    print("[Client] 右半屏视角触摸区已创建（灵敏度 " .. VIEW_SENS .. " 弧度/像素）")
end

--- 双指捏合缩放（在 OnUpdate 里每帧调用）
function Touch.UpdatePinchZoom()
    if Shared.UIState.modalOpen or Shared.UIState.inputFocus then
        S.pinchLastDist_ = 0
        return
    end
    -- 已确认引擎提供 input:GetNumTouches() / input:GetTouch(i)
    if input:GetNumTouches() < 2 then
        S.pinchLastDist_ = 0
        return
    end

    -- 收集落在 3D 区域（非 UI 元素上）的触摸点
    local pts = {}
    for i = 0, input:GetNumTouches() - 1 do
        local t = input:GetTouch(i)
        -- touchedElement 非空表示这条触摸被 UI 吃掉了，不参与缩放
        if t and not t.touchedElement then
            pts[#pts + 1] = t.position
        end
    end
    if #pts < 2 then
        S.pinchLastDist_ = 0
        return
    end

    local dx = pts[1].x - pts[2].x
    local dy = pts[1].y - pts[2].y
    local dist = math.sqrt(dx * dx + dy * dy)
    if S.pinchLastDist_ > 0 then
        S.camDist_ = S.camDist_ - (dist - S.pinchLastDist_) * PINCH_SENS
        S.camDist_ = Shared.Clamp(S.camDist_, Touch.CAM_DIST_MIN_, Touch.CAM_DIST_MAX_)
        -- 实时写回设置
        local s = Data.GetSettings()
        local rounded = math.floor(S.camDist_ + 0.5)
        if (s.camDist or 0) ~= rounded then
            s.camDist = rounded
            Data.MarkDirty("settings")
        end
    end
    S.pinchLastDist_ = dist
end

return Touch
