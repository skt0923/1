-- ============================================================
-- Battle_World.lua：世界层（客户端）
--
-- 目录
--   Assets   资源（程序化模型 / 材质 / 真实 .mdl 加载）
--   Terrain  地形高度场与网格
--   Items    地面掉落物
--   Enemies  怪物生成与 AI
--   Effects  技能特效（对象池）
--
-- 依赖：Shared（含 Data / Notify）。**不依赖 UI，也不依赖 Battle_Combat**。
--       与 Battle_Combat.lua 之间无任何交叉引用（技能/伤害计算走回调解耦）。
-- 说明：各模块放在独立的 do...end 作用域里，通过 Battle.<模块名> 互相引用，
--       避免合并后局部变量互相污染，也避免 require 顺序造成的 nil 引用。
--
-- 对外接口：Battle.Assets / Terrain / Items / Enemies / Effects / Now
-- ============================================================
local Shared = require("Shared")

local Data   = Shared.Data

local Battle = {}

--- 当前墙钟秒数（全模块共用）。
--- ⚠️ 必须用 GetTime():GetElapsedTime()，不能用 os.clock()！
---    实测 os.clock 在本引擎是 **CPU 时间** —— 空闲 2 秒墙钟只走 0.075 秒（比值 0.04），
---    拿它做保护期/脱战/冷却计时会几乎永不推进。
---@return number
local function Now()
    return GetTime():GetElapsedTime()
end
Battle.Now = Now

-- ===== 模块：Assets =====
do
    -- ============================================================
    -- client/Assets.lua：程序化模型与材质
    --
    -- 原代码引用的 Models/Demon.mdl、Models/Explorer.mdl、Models/Octahedron.mdl、
    -- Materials/VColUnlit.xml、Materials/Item.xml、Materials/SkillFx.xml 在引擎里都不存在。
    -- 这里改用引擎内置的基础形状 + three.js 兼容的程序化几何体，全部在运行时生成，
    -- 不依赖任何外部资源文件。后续接入真实美术资源时，只需替换本文件。
    -- ============================================================

    local Assets = {}

    -- ============ 材质 ============

    --- 自发光材质（技能特效 / 掉落物）
    ---@param color Color
    ---@param strength? number
    ---@return Material|nil
    function Assets.MakeEmissiveMaterial(color, strength)
        strength = strength or 2.0
        local tech = cache:GetResource("Technique", "Techniques/PBR/PBRNoTexture.xml")
        if not tech then return nil end
        local mat = Material:new()
        mat:SetTechnique(0, tech)
        mat:SetShaderParameter("MatDiffColor", Variant(color))
        mat:SetShaderParameter("MatEmissiveColor",
            Variant(Color(color.r * strength, color.g * strength, color.b * strength)))
        mat:SetShaderParameter("Metallic", Variant(0.0))
        mat:SetShaderParameter("Roughness", Variant(0.3))
        return mat
    end

    -- ============ 模型 ============
    -- 模型缓存：同一种形状只生成一次，多个节点复用同一个 Model 省内存
    local modelCache_ = {}

    ---@param key string
    ---@param build fun():Model|nil
    ---@return Model|nil
    local function Cached(key, build)
        if modelCache_[key] == nil then
            local ok, m = pcall(build)
            if ok and m ~= nil then
                modelCache_[key] = m
            else
                modelCache_[key] = false
                if not ok then
                    print("[Assets] 模型生成失败 " .. key .. "：" .. tostring(m))
                end
            end
        end
        local cached = modelCache_[key]
        if cached == false then return nil end
        return cached --[[@as Model]]
    end

    -- 玩家 / 怪物模型已迁移到 Battle_Visual.lua：
    --   Visual.Player.Build  机械师 7 节点模型
    --   Visual.Monster.Build 种子囊袋 / 晶体花 BOSS
    -- 本模块不再提供 PlayerModel / EnemyModel / BuildPlayerRig / BuildEnemyRig。

    --- 构造技能特效的几何体（五种形状之一）。
    --- 全部为平面薄片（XZ 平面，法线朝 Y），pillar 是十字竖直面。
    --- 顶点色近白（0.92），真实颜色由材质 tint_color 相乘。
    --- ⚠️ 不用 V.quad/V.tri（Battle.V 由 Battle_Visual 加载后填充，此处可能仍为 nil）。
    ---
    --- ⚠️ 池化复用时会**重复调用**本函数（同一 geometry 换形状），
    ---    所以必须先 Clear() —— 否则旧顶点会累积，形状会越来越乱。
    ---@param g CustomGeometry
    ---@param shapeType string "slash"|"ring"|"shield"|"pillar"|"burst"
    function Assets.BuildFXShape(g, shapeType)
        g:Clear()
        g:SetNumGeometries(1)
        g:BeginGeometry(0, TRIANGLE_LIST)

        -- 🔴 描边用顶点色渐变实现，不用引擎 outline。
        --    引擎描边的实现是「沿顶点法线外扩」，而本特效全是平面薄片
        --    （顶点 y=0、法线全为 (0,1,0)）→ 外扩等于整片平移，画不出边缘。
        --    改用几何层的颜色渐变：内圈亮（≈主色）→ 外缘深（深色边）。
        --    这比硬黑线更接近原神的手绘边。
        --
        -- ⚠️ 内圈色 0.6，不是 0.92（真机日志实测）：
        --    fx_toon 的 light() 里 DIFFUSE_LIGHT 逐灯累加，ALBEDO 接近 1 时
        --    乘 LIGHT_COLOR 后三通道一起过曝裁切成纯白，tint 的色相被冲掉
        --    —— 表现就是"特效是白的"。角色 shader 用同样的 light() 却不过曝，
        --    因为它的顶点色只有 0.18~0.38。这里取与地形同量级（0.6）。
        --    内圈过曝的话，改 colInner（0.4~0.6 之间）。
        local colInner = Color(0.60, 0.60, 0.60, 1)
        -- 外缘：深色。数值越小边越黑（0.03 更黑 / 0.20 更柔）。
        local colOuter = Color(0.10, 0.12, 0.18, 1)

        --- 单色三角形（用于无渐变需求的区域）
        ---@param col Color
        local function tri(v1, v2, v3, col)
            local n = (v2 - v1):CrossProduct(v3 - v1)
            local len = n:Length()
            if len > 1e-6 then n = n:Normalized() else n = Vector3(0, 1, 0) end
            local c = col or colInner
            g:DefineVertex(v1); g:DefineNormal(n); g:DefineColor(c)
            g:DefineVertex(v2); g:DefineNormal(n); g:DefineColor(c)
            g:DefineVertex(v3); g:DefineNormal(n); g:DefineColor(c)
        end

        --- 双色四边形：v1/v2 内圈色，v3/v4 外缘色（环带 / 弧片：内→外渐深）
        local function quadDual(v1, v2, v3, v4)
            local n = (v2 - v1):CrossProduct(v3 - v1)
            local len = n:Length()
            if len > 1e-6 then n = n:Normalized() else n = Vector3(0, 1, 0) end
            g:DefineVertex(v1); g:DefineNormal(n); g:DefineColor(colInner)
            g:DefineVertex(v2); g:DefineNormal(n); g:DefineColor(colInner)
            g:DefineVertex(v3); g:DefineNormal(n); g:DefineColor(colOuter)
            g:DefineVertex(v4); g:DefineNormal(n); g:DefineColor(colOuter)
        end

        --- 双色扇形三角：中心内圈色，边缘两点外缘色（径向渐变）
        local function triFan(center, v1, v2)
            local n = (v1 - center):CrossProduct(v2 - center)
            local len = n:Length()
            if len > 1e-6 then n = n:Normalized() else n = Vector3(0, 1, 0) end
            g:DefineVertex(center); g:DefineNormal(n); g:DefineColor(colInner)
            g:DefineVertex(v1);     g:DefineNormal(n); g:DefineColor(colOuter)
            g:DefineVertex(v2);     g:DefineNormal(n); g:DefineColor(colOuter)
        end

        if shapeType == "slash" then
            -- 90° 弧形薄片（斩击轨迹）
            local SEGS  = 10
            local R_IN  = 0.45
            local R_OUT = 0.95
            local A0 = -math.pi * 0.25
            local A1 =  math.pi * 0.25
            for i = 0, SEGS - 1 do
                local a1 = A0 + (A1 - A0) * i / SEGS
                local a2 = A0 + (A1 - A0) * (i + 1) / SEGS
                local v1 = Vector3(R_IN  * math.cos(a1), 0, R_IN  * math.sin(a1))
                local v2 = Vector3(R_IN  * math.cos(a2), 0, R_IN  * math.sin(a2))
                local v3 = Vector3(R_OUT * math.cos(a2), 0, R_OUT * math.sin(a2))
                local v4 = Vector3(R_OUT * math.cos(a1), 0, R_OUT * math.sin(a1))
                quadDual(v1, v2, v3, v4)
            end

        elseif shapeType == "ring" then
            -- 扁平圆环（扩散 / 增益）：内圈亮、外缘深
            local SEGS  = 16
            local R_IN  = 0.55
            local R_OUT = 1.0
            for i = 0, SEGS - 1 do
                local a1 = 2 * math.pi * i / SEGS
                local a2 = 2 * math.pi * (i + 1) / SEGS
                local v1 = Vector3(R_IN  * math.cos(a1), 0, R_IN  * math.sin(a1))
                local v2 = Vector3(R_IN  * math.cos(a2), 0, R_IN  * math.sin(a2))
                local v3 = Vector3(R_OUT * math.cos(a2), 0, R_OUT * math.sin(a2))
                local v4 = Vector3(R_OUT * math.cos(a1), 0, R_OUT * math.sin(a1))
                quadDual(v1, v2, v3, v4)
            end

        elseif shapeType == "shield" then
            -- 正六边形（防御 / 反伤）：中心亮 → 边缘深
            local R = 0.55
            local center = Vector3(0, 0, 0)
            for i = 0, 5 do
                local a1 = 2 * math.pi * i / 6 + math.pi / 2
                local a2 = 2 * math.pi * (i + 1) / 6 + math.pi / 2
                local v1 = Vector3(R * math.cos(a1), 0, R * math.sin(a1))
                local v2 = Vector3(R * math.cos(a2), 0, R * math.sin(a2))
                triFan(center, v1, v2)
            end

        elseif shapeType == "pillar" then
            -- 治疗 / 吸血：水平圆盘。
            -- ⚠️ 原设计是竖直十字面 —— 俯视角下只能看到一条线，几乎没有视觉信息。
            --    改为水平圆盘后是完整圆面，配合动效「上升 + 放大」传达扩散感。
            local SEGS = 12
            local R = 0.6
            local center = Vector3(0, 0, 0)
            for i = 0, SEGS - 1 do
                local a1 = 2 * math.pi * i / SEGS
                local a2 = 2 * math.pi * (i + 1) / SEGS
                local v1 = Vector3(R * math.cos(a1), 0, R * math.sin(a1))
                local v2 = Vector3(R * math.cos(a2), 0, R * math.sin(a2))
                triFan(center, v1, v2)
            end

        elseif shapeType == "burst" then
            -- 四角星芒（命中即时反馈）：长短尖交替，中心亮 → 尖端深
            local center  = Vector3(0, 0, 0)
            local R_LONG  = 0.6
            local R_SHORT = 0.15
            local N = 8
            for i = 0, N - 1 do
                local a1 = 2 * math.pi * i / N
                local a2 = 2 * math.pi * (i + 1) / N
                local r1 = (i % 2 == 0)         and R_LONG or R_SHORT
                local r2 = ((i + 1) % 2 == 0)   and R_LONG or R_SHORT
                local v1 = Vector3(r1 * math.cos(a1), 0, r1 * math.sin(a1))
                local v2 = Vector3(r2 * math.cos(a2), 0, r2 * math.sin(a2))
                triFan(center, v1, v2)
            end
        end
        -- 未知形状 → 空几何体（不绘制，不报错）

        g:Commit()
    end

    -- ============ 共享材质 ============
    -- 玩家 / 怪物 / 地形材质已迁移到 Battle_Visual（走 Visual.Player / Visual.Monster
    -- / Visual.Terrain 各自的材质系统），此处只保留受击闪烁（怪物通用）。

    -- 受击闪烁材质（高亮红，自发光强度大，切上去立刻可见）
    local hitFlashMat_ = nil
    ---@return Material|nil
    function Assets.HitFlashMaterial()
        if not hitFlashMat_ then
            hitFlashMat_ = Assets.MakeEmissiveMaterial(Color(1.0, 0.25, 0.2), 3.5)
        end
        return hitFlashMat_
    end

    --- 品质颜色 → 自发光材质（掉落物用），按品质缓存
    local qualityMats_ = {}
    ---@param quality string
    ---@return Material|nil
    function Assets.QualityMaterial(quality)
        if not qualityMats_[quality] then
            local color = Shared.HexColor(Shared.QUALITY_COLORS[quality] or "#ffffff")
            qualityMats_[quality] = Assets.MakeEmissiveMaterial(color, 1.8)
        end
        return qualityMats_[quality]
    end

    -- 掉落物模型全局缓存（避免每次掉落都走一遍缓存查找 + 包装）
    local dropModelCache_ = nil
    ---@return Model|nil
    function Assets.DropModelCached()
        if not dropModelCache_ then
            -- 优先用真实资源文件；没有才退回程序化几何体
            dropModelCache_ = cache:GetResource("Model", "Models/Octahedron.mdl")
            if not dropModelCache_ then
                dropModelCache_ = OctahedronGeometry(0.45):ToModel()
            end
        end
        return dropModelCache_
    end

    --- 技能特效材质（按技能 id 缓存）。
    ---
    --- ⚠️ 从自发光（PBRNoTexture + MatEmissiveColor）改成受光（DiffVCol + MatDiffColor）：
    ---     自发光是均匀亮色、不参与光照，任何几何形状在它渲染下都是一团「光斑」，
    ---     看不出八面体的棱角。改用 DiffVCol 后，每个面的朝向不同 → 光照算出的明暗不同，
    ---     棱角才显现。这是本批改动的核心。
    ---
    --- ⚠️ 顶点色是乘算：最终色 = 顶点色 × MatDiffColor。
    ---     几何体的顶点色是近白灰（0.85~1.0 面级抖动），所以 MatDiffColor 就是技能色本身。
    ---     若把 MatDiffColor 设得过暗，顶点色也救不回来（乘算只会更暗）。
    local fxMats_ = {}
    --- 取技能特效材质（按**形状**缓存：同形状共用一个材质，因为同形状共用一个颜色）。
    --- 主路径：fx_toon.shader（支持描边的 toon 材质）。
    --- 回退路径：DiffVCol（若 shader 加载失败，保证特效仍可见）。
    ---@param shapeType string
    ---@param color Color
    ---@return Material|nil
    function Assets.EffectMaterial(shapeType, color)
        if not fxMats_[shapeType] then
            local mat = Material:new()
            if mat:SetSurfaceShader("Shaders/BLGL/fx_toon.shader") then
                mat:SetShaderParameter("tint_color",
                    Variant(Color(color.r, color.g, color.b, 1)))
                fxMats_[shapeType] = mat
            else
                print("[Assets] ⚠️ fx_toon.shader 加载失败，回退 DiffVCol")
                local tech = cache:GetResource("Technique", "Techniques/DiffVCol.xml")
                if not tech then
                    print("[Assets] ⚠️ 也找不到 DiffVCol.xml，技能特效将不可见")
                    return nil
                end
                local fb = Material:new()
                fb:SetTechnique(0, tech)
                fb:SetShaderParameter("MatDiffColor",
                    Variant(Color(color.r, color.g, color.b, 1)))
                fxMats_[shapeType] = fb
            end
        end
        return fxMats_[shapeType]
    end

    Battle.Assets = Assets
end

-- ===== 模块：Items =====
do
    -- ============================================================
    -- client/Items.lua：地面掉落物
    -- 掉落物为本地表现，拾取后进背包（原实现同此设计）
    -- ============================================================
    local Items = {}
        -- 同文件内模块引用
    local Assets = Battle.Assets

    --- ⚠️ 延迟查表：Battle.Visual.Terrain 由 Battle_Visual.lua 在加载后注入，
    ---    加载 Items 时还不存在，所以必须运行时查表，不能加载时捕获。
    ---@param x number
    ---@param z number
    ---@return number
    local function TerrainH(x, z)
        return Battle.Visual.Terrain.GetHeight(x, z)
    end

    local PICKUP_RANGE = 2.2
    local LIFETIME     = 300   -- 5 分钟未拾取自动消失，避免无限堆积
    local MAX_DROPS    = 80    -- 同屏掉落物上限，超出则淘汰最旧的

    ---@type table<string, table>
    local groundItems = {}
    local scene_ = nil

    ---@type fun(item: table)|nil
    local onPickup_ = nil
    ---@type fun(): boolean
    local canPickup_ = nil

    function Items.SetCallbacks(cbs)
        onPickup_ = cbs.onPickup
        canPickup_ = cbs.canPickup
    end

    function Items.SetScene(scene) scene_ = scene end

    --- 懒创建掉落物节点（只在进入渲染距离时才建，省掉远处掉落物的 draw call）
    ---@param gi table
    local function EnsureDropNode(gi)
        if not scene_ or gi.node then return end
        local node = scene_:CreateChild("GroundItem_" .. gi.id, LOCAL)
        node.position = Vector3(gi.x, TerrainH(gi.x, gi.z) + 0.8, gi.z)
        local model = node:CreateComponent("StaticModel", LOCAL)
        local mdl = Assets.DropModelCached()
        if mdl then model.model = mdl end
        local mat = Assets.QualityMaterial(gi.item.quality or "normal")
        if mat then model:SetMaterial(mat) end
        -- 品质越高，掉落物模型越大（更容易被发现）
        local scaleMap = {
            normal = 1.0, magic = 1.2, rare = 1.4, legendary = 1.6, mythic = 1.8,
        }
        local sc = scaleMap[gi.item.quality or "normal"] or 1.0
        node:SetScale(sc)
        gi.node = node
    end

    --- 卸载节点但保留数据（离开渲染距离时调用，之后可再次 EnsureDropNode）
    ---@param gi table
    local function UnloadDropNode(gi)
        if not gi.node then return end
        local sm = gi.node:GetComponent("StaticModel", true)
        if sm then sm.model = nil end
        gi.node:Remove()
        gi.node = nil
    end

    ---@param item table
    ---@param x number
    ---@param z number
    ---@param ownerId? string 归属玩家（60 秒保护期内他人不可拾取）
    function Items.Spawn(item, x, z, ownerId)
        if not scene_ then return end

        local id = "g" .. math.random(100000, 999999)
        while groundItems[id] do id = "g" .. math.random(100000, 999999) end

        -- 🆕 不再立即建 node：只登记数据，进入渲染距离时由 Items.Update 懒创建
        groundItems[id] = {
            id = id, item = item, x = x, z = z, node = nil, age = 0,
            ownerId = ownerId,
            protectUntil = ownerId and (Now() + 60.0) or 0,  -- 60 秒归属保护
        }
    end

    --- 遍历全部地面掉落物（自动寻路拾取用）
    ---@return table[]
    function Items.GetAll()
        local list = {}
        for _, gi in pairs(groundItems) do list[#list + 1] = gi end
        return list
    end

    --- 彻底销毁一个掉落物（先卸 model 再删节点，避免残留引用）
    ---@param id string
    local function DestroyDrop(id)
        local gi = groundItems[id]
        if not gi then return end
        UnloadDropNode(gi)
        groundItems[id] = nil
    end

    ---@param dt number
    ---@param px number
    ---@param pz number
    function Items.Update(dt, px, pz)
        -- 超载保护：超过 MAX_DROPS 个时，优先删除最旧且无归属保护的掉落物
        local cnt = 0
        for _ in pairs(groundItems) do cnt = cnt + 1 end
        if cnt > MAX_DROPS then
            local oldestId, oldestAge = nil, -1
            for iid, gii in pairs(groundItems) do
                if (gii.age or 0) > oldestAge then
                    oldestAge = gii.age or 0
                    oldestId = iid
                end
            end
            if oldestId then DestroyDrop(oldestId) end
        end

        local myId = Data.GetPlayerId and Data.GetPlayerId()
        -- 视野固定 200（不再读 settings，见 Shared.C.VIEW_DISTANCE_DEFAULT）
        local renderDist = Shared.C.VIEW_DISTANCE_DEFAULT

        for id, gi in pairs(groundItems) do
            gi.age = gi.age + dt
            if gi.age > LIFETIME then
                DestroyDrop(id)
            else
                local d = Shared.Dist2D(px, pz, gi.x, gi.z)

                -- 🆕 距离剔除：远处只保留数据，不持有节点
                if d > renderDist then
                    UnloadDropNode(gi)
                else
                    EnsureDropNode(gi)
                    if gi.node then
                        gi.node:Rotate(Quaternion(dt * 120, Vector3.UP))
                        gi.node.position = Vector3(
                            gi.x,
                            TerrainH(gi.x, gi.z) + 0.8 + math.sin(gi.age * 3) * 0.15,
                            gi.z
                        )
                    end
                end

                -- 归属保护：非归属者永远不可拾取（保护期内受时间约束，保护期后直接锁定）
                local ownerOk = true
                if gi.ownerId and gi.ownerId ~= myId then
                    ownerOk = false
                end

                local canPick = (canPickup_ == nil) or canPickup_()
                -- ⚠️ onPickup 返回 false 表示拾取失败（如背包满），此时不能销毁掉落物，
                --    否则物品会凭空消失。只有明确非 false 才销毁。
                if canPick and ownerOk and d < PICKUP_RANGE then
                    local ok = true
                    if onPickup_ then ok = onPickup_(gi.item) end
                    if ok ~= false then DestroyDrop(id) end
                end
            end
        end
    end

    --- 玩家死亡时清空（避免满地残留）
    function Items.Clear()
        for id in pairs(groundItems) do DestroyDrop(id) end
    end
    Battle.Items = Items
end

-- ===== 模块：Enemies =====
do
    -- ============================================================
    -- client/Enemies.lua：怪物生成与 AI
    -- 仇恨 / 追击 / 脱战 / 攻击全部在这里，掉落结算通过回调交给 Client
    -- ============================================================
    local Enemies = {}
        -- 同文件内模块引用
    local Assets = Battle.Assets

    --- ⚠️ 延迟查表：Battle.Visual.Terrain 由 Battle_Visual.lua 在加载后注入。
    ---@param x number
    ---@param z number
    ---@return number
    local function TerrainH(x, z)
        return Battle.Visual.Terrain.GetHeight(x, z)
    end

    local SPAWN_INTERVAL = 3.0

    -- ============ 怪物属性分档表 ============
    -- 每段 4 个采样点，线性插值
    -- 字段：{ level, hp, atk, armor, dodge, hitRate }
    ---@type table<string, number[][]>
    local MONSTER_STATS = {
        normal = {
            { 1,  60,    2.0,   3.0,  0.02, 0.02 },
            { 3,  69,    2.3,   3.5,  0.02, 0.02 },
            { 6,  84,    2.8,   4.2,  0.02, 0.02 },
            { 9,  103,   3.4,   5.1,  0.02, 0.02 },
        },
        magic = {
            { 10, 120,   4.0,   6.0,  0.02, 0.02 },
            { 13, 138,   4.6,   6.9,  0.02, 0.02 },
            { 16, 159,   5.3,   8.0,  0.02, 0.02 },
            { 19, 183,   6.1,   9.2,  0.02, 0.02 },
        },
        rare = {
            { 20, 240,   8.0,   12.0, 0.02, 0.02 },
            { 23, 276,   9.2,   13.8, 0.02, 0.02 },
            { 26, 318,   10.6,  15.9, 0.02, 0.02 },
            { 29, 366,   12.2,  18.3, 0.02, 0.02 },
        },
        legendary = {
            { 30, 480,   16.0,  24.0, 0.02, 0.02 },
            { 33, 552,   18.4,  27.6, 0.02, 0.02 },
            { 36, 635,   21.2,  31.8, 0.02, 0.02 },
            { 39, 731,   24.4,  36.6, 0.02, 0.02 },
        },
        mythic = {
            { 40, 960,   32.0,  48.0, 0.02, 0.02 },
            { 43, 1104,  36.8,  55.2, 0.02, 0.02 },
            { 46, 1270,  42.3,  63.5, 0.02, 0.02 },
            { 49, 1461,  48.7,  73.1, 0.02, 0.02 },
        },
    }

    --- 按等级查怪物属性（线性插值）
    ---@param lv integer
    ---@return {hp:number, atk:number, armor:number, dodge:number, hitRate:number}
    local function GetMonsterStats(lv)
        local q = Shared.QualityOfMonsterLevel(lv)
        local table_ = MONSTER_STATS[q]
        if not table_ then
            return { hp = 300, atk = 5, armor = 3, dodge = 0.02, hitRate = 0.02 }
        end

        -- 找到相邻两个采样点
        local lo, hi = table_[1], table_[#table_]
        for i = 1, #table_ - 1 do
            local a, b = table_[i], table_[i + 1]
            if lv >= a[1] and lv <= b[1] then
                lo, hi = a, b
                break
            end
        end

        local span = hi[1] - lo[1]
        local t = (span > 0) and ((lv - lo[1]) / span) or 0
        local lerp = function(i)
            return lo[i] + (hi[i] - lo[i]) * t
        end
        return {
            hp      = lerp(2),
            atk     = lerp(3),
            armor   = lerp(4),
            dodge   = lerp(5),
            hitRate = lerp(6),
        }
    end

    -- BOSS_STATS 已收敛到 Shared.C.BOSS_STATS（客户端与服务端共用一份）

    -- 视野距离缓存：每帧由 Enemies.Update 从设置刷新一次，
    -- 供刷怪距离 / 渲染剔除使用（避免在热路径里反复构造设置表）。
    local viewDist_ = Shared.C.VIEW_DISTANCE_DEFAULT

    ---@type table<string, table>
    local enemies = {}
    ---@type table<string, Node>
    local nodes = {}
    local spawnTimer = 0
    local scene_ = nil
    -- 怪物冻结机制已删除（只有玩家会罚站，怪物不再冻结）

    --- 取怪物身上的可渲染组件（用于切换材质做受击闪烁）。
    --- ⚠️ 组件不在根节点上（Enemy → EnemyRig），必须递归查找。
    --- ⚠️ 视觉层用 CustomGeometry 构建模型（不是 StaticModel），
    ---    只查 StaticModel 会拿不到组件 → 受击闪烁静默失效。
    ---@param root Node|nil
    ---@return Drawable|nil
    local function RigModel(root)
        if not root then return nil end
        local cg = root:GetComponent("CustomGeometry", true)
        if cg then return cg end
        return root:GetComponent("StaticModel", true)
    end

    --- 切换怪物受击闪烁材质（红白自发光）
    ---@param e table
    ---@param on boolean
    local function SetHitFlash(e, on)
        local node = e.__nodeRef
        if not node then return end
        local sm = RigModel(node)
        if not sm then return end
        -- 材质可能构造失败（缺 Technique），返回 nil 时跳过，别把 model 材质清空
        if on then
            local m = Assets.HitFlashMaterial()
            if m then sm:SetMaterial(m) end
        else
            -- 切回该怪物原本的材质（normal / boss）
            local kind = e.isBoss and "boss" or "normal"
            local m = Battle.Visual.Monster.GetMaterial(kind)
            if m then sm:SetMaterial(m) end
        end
    end

    --- 记录一次受击（刷新脱战计时 + 触发闪烁），供 Combat 调用
    ---@param e table
    function Enemies.OnHit(e)
        if not e then return end
        e.lastHitTime = Now()
        -- 被攻击 → 立即进入仇恨，并取消回家（不依赖下一帧的距离检查）
        e.isAggro = true
        e.returning = false
        e.__flashTimer = 0.15
        SetHitFlash(e, true)
    end

    --- 由 Client.lua 注入
    ---@type fun(): boolean
    local canAttack_ = nil       -- 返回 true 表示玩家可被攻击（非罚站/非死亡）
    ---@type fun(enemy: table, stats: table)|nil
    local onAttackPlayer_ = nil
    ---@type fun(enemyId: string)|nil
    local onEnemyRemoved_ = nil

    function Enemies.SetCallbacks(cbs)
        canAttack_ = cbs.canAttack
        onAttackPlayer_ = cbs.onAttackPlayer
        onEnemyRemoved_ = cbs.onEnemyRemoved
    end

    function Enemies.SetScene(scene) scene_ = scene end

    function Enemies.GetAll() return enemies end

    --- 存活敌人列表（同时是攻击目标的唯一来源：自动战斗 / 手动锁定都走这里）
    ---
    --- ⚠️ isLocallyDead 当前恒为 false（见 SyncSharedBoss 的说明）。保留该判断是防御性的：
    ---    一旦它被置位，敌人会立刻从攻击目标中消失，共享 Boss 尤其危险
    ---    （会导致伤害上报中断 → 服务端永不判定死亡 → 打不死也不给奖励）。
    ---@return table[]
    function Enemies.GetAliveList()
        local list = {}
        for _, e in pairs(enemies) do
            if not e.isDead and not e.isLocallyDead then table.insert(list, e) end
        end
        return list
    end

    --- 统计"活跃"怪物数（不含已冻结的）。
    ---
    --- 用途：补怪判断——冻结的怪不计入 40 只上限。
    --- 否则玩家跑远后，旧怪冻结但仍在 enemies 表里占位，
    --- 新区域补怪逻辑会算出 needCount=0，玩家周围刷不出新怪。
    ---@return integer
    function Enemies.CountActive()
        local n = 0
        for _, e in pairs(enemies) do
            if not e.isDead and not e.frozenAt then n = n + 1 end
        end
        return n
    end

    function Enemies.MarkDead(id)
        local e = enemies[id]
        if not e then return end
        e.isDead = true
        local n = nodes[id]
        if n then
            -- ⚠️ StaticModel 挂在 EnemyRig/Body 子节点上，不在根节点，
            --    直接 n:GetComponent("StaticModel") 会返回 nil。
            local sm = RigModel(n)
            if sm then sm.model = nil end
            n:Remove()
            nodes[id] = nil
        end
    end

    ---@param x number
    ---@param z number
    ---@return table|nil
    local function DoSpawn(x, z)
        if not scene_ then return nil end

        -- 按距离算等级；缓冲区返回 nil，不刷怪
        local level = Shared.MonsterLevelOf(x, z)
        if not level then return nil end

        local id = "e" .. math.random(100000, 999999)
        while enemies[id] do id = "e" .. math.random(100000, 999999) end

        local radius = 0.5 + math.random() * 0.3
        local ms = GetMonsterStats(level)

        local enemy = {
            id = id, level = level, x = x, z = z, radius = radius,
            -- 家位置（脱战回走的目标）
            homeX = x, homeZ = z,
            hp = math.floor(ms.hp), maxHp = math.floor(ms.hp),
            atk = math.max(1, math.floor(ms.atk)),
            armor = math.floor(ms.armor),
            dodge = ms.dodge,
            hitRate = ms.hitRate,
            -- 统一攻速 1.0/s
            attackCooldown = 1.0,
            attackRange = 1.5,
            attackTimer = 0,
            isDead = false, isBoss = false,
            bobPhase = math.random() * math.pi * 2,
            aggroTarget = nil,
            isAggro = false,
            -- 回走状态（脱战后回家）
            returning = false,
            dots = nil,
        }

        local node = scene_:CreateChild("Enemy_" .. id, LOCAL)
        node.position = Vector3(x, TerrainH(x, z), z)
        node:SetScale(radius)

        Battle.Visual.Monster.Build(node, "normal")

        enemies[id] = enemy
        nodes[id] = node
        enemy.__nodeRef = node
        return enemy
    end

    -- SpawnEnemy 已删除（原为死代码，无调用点）

    ---@param dt number
    ---@param px number
    ---@param pz number
    ---@param stats table
    function Enemies.Update(dt, px, pz, stats)
        if not scene_ then return end

        -- 视野固定 200（不再读 settings，见 Shared.C.VIEW_DISTANCE_DEFAULT）
        viewDist_ = Shared.C.VIEW_DISTANCE_DEFAULT
        local renderDist = viewDist_
        -- destroyDist 已删除：销毁改为「冻结 30 秒后销毁」（见下方怪物循环）

        -- 怪物冻结：距玩家 > MONSTER_FREEZE_DIST 时停 AI，冻结满 MONSTER_FREEZE_TIMEOUT 秒后销毁（见下方怪物循环）

        spawnTimer = spawnTimer + dt
        if spawnTimer >= Shared.C.LOCAL_MONSTER_REFILL_INTERVAL then
            spawnTimer = 0
            -- 补足到上限：一次把缺的怪补齐，而不是每 25 秒只补 1 只
            -- 用 CountActive（不含冻结怪）：玩家跑远后旧怪冻结，
            -- 若不排除它们，needCount 会一直是 0，新区域刷不出怪。
            local needCount = Shared.C.LOCAL_MONSTER_MAX - Enemies.CountActive()
            if needCount > 0 then
                for _ = 1, needCount do
                    local sx, sz = FindValidSpawnPos(px, pz)
                    if sx then DoSpawn(sx, sz) end
                end
            end
        end

        local playerAttackable = canAttack_ and canAttack_() or false

        for id, e in pairs(enemies) do
            if e.isDead then
                -- ⚠️ 兜底销毁节点：不能假设调用方已经销毁。
                --    RemoveSharedBoss / SyncSharedBoss(hp<=0) 都只设 isDead 标记，
                --    早期版本因此留下永不消失的 Boss 尸体（节点仍挂在场景里）。
                local deadNode = nodes[id]
                if deadNode then
                    local sm = RigModel(deadNode)
                    if sm then sm.model = nil end
                    deadNode:Remove()
                    nodes[id] = nil
                end
                enemies[id] = nil
                if onEnemyRemoved_ then onEnemyRemoved_(id) end
            else
                local node = nodes[id]
                local dx, dz = px - e.x, pz - e.z
                local d = math.sqrt(dx * dx + dz * dz)

                -- 非共享 BOSS：超过冻结距离 → 冻结（停一切 AI），
                -- 冻结满 MONSTER_FREEZE_TIMEOUT 秒 → 销毁（节点 + 数据）。
                -- 玩家回到冻结距离内 → 立即解冻、重置计时。
                -- 共享 Boss 不冻结也不销毁：它是全服共享目标，玩家需要能看到它。
                if not e.isSharedBoss and d > Shared.C.MONSTER_FREEZE_DIST then
                    if not e.frozenAt then e.frozenAt = Now() end
                    if (Now() - e.frozenAt) >= Shared.C.MONSTER_FREEZE_TIMEOUT then
                        if node then
                            local sm = RigModel(node)
                            if sm then sm.model = nil end
                            node:Remove()
                        end
                        nodes[id] = nil
                        enemies[id] = nil
                        node = nil   -- 清掉局部引用：销毁帧跳过下方视觉更新，避免触碰已 Remove 的节点
                        if onEnemyRemoved_ then onEnemyRemoved_(id) end
                        spawnTimer = Shared.C.LOCAL_MONSTER_REFILL_INTERVAL
                    end
                    -- 冻结中：不跑任何 AI（位置静止），视觉由 if/else 之后的统一更新保留呼吸/摆动
                else
                    -- 解冻（玩家回到冻结距离内）→ 清冻结标记，让 AI 恢复
                    e.frozenAt = nil
                    -- ============ 回家逻辑（独立，不受距离限制）============
                    -- ⚠️ 回家必须放在 AI 距离判断**之外**：玩家跑远后 AI 停止，
                    --    但怪物仍需继续走回家，否则会永远停在脱战位置。
                    --    同时如果玩家回到仇恨范围内，取消回家、立即重新仇恨。
                    if e.returning then
                        if d <= Shared.C.MONSTER_HATE_RANGE then
                            -- 玩家回来了 → 取消回家、立即重新仇恨
                            e.returning = false
                            e.isAggro = true
                            e.lastHitTime = Now()
                        else
                            local hdx, hdz = e.homeX - e.x, e.homeZ - e.z
                            local hd = math.sqrt(hdx * hdx + hdz * hdz)
                            if hd < 0.5 then
                                e.returning = false
                                e.x = e.homeX
                                e.z = e.homeZ
                            else
                                -- 回走速度 = 追击速度 × 5 = 2.5 × 5 = 12.5 m/s
                                local speed = (5.0 * Shared.C.MONSTER_SPEED_FACTOR) * 5
                                e.x = e.x + (hdx / hd) * speed * dt
                                e.z = e.z + (hdz / hd) * speed * dt
                            end
                        end
                    end

                    -- ============ AI 逻辑（受距离限制，LEASH 范围内跑）============
                    -- ⚠️ 原来这里是 `if d <= 10 then`，会导致玩家跑出 10 米后
                    --    整块 AI 停摆。改为 LEASH 范围（25 米）：
                    --    超出 25 米 → 触发脱战 → 进入上面的回家逻辑。
                    if d <= Shared.C.MONSTER_LEASH_RANGE then
                        -- 仇恨：玩家进入 HATE 范围 → 进入仇恨
                        -- ⚠️ 无条件刷新 lastHitTime：若保留旧时间戳，
                        --    下一帧 noCombat 检查会立即超时 → 死循环站桩。
                        if not e.isAggro and not e.returning then
                            if d <= Shared.C.MONSTER_HATE_RANGE then
                                e.isAggro = true
                                e.lastHitTime = Now()
                            end
                        end
                        if e.isAggro then
                            local noCombat = e.lastHitTime
                                and (Now() - e.lastHitTime) > Shared.C.MONSTER_DEAGGRO_SEC
                            if d > Shared.C.MONSTER_LEASH_RANGE or noCombat then
                                e.isAggro = false
                                e.returning = true
                            end
                        end

                        -- 追击（仅在战斗状态）
                        if e.isAggro and not e.returning and d > (e.attackRange or 3) and d > 0 then
                            local speed = 5.0 * Shared.C.MONSTER_SPEED_FACTOR
                            e.x = e.x + (dx / d) * speed * dt
                            e.z = e.z + (dz / d) * speed * dt
                        end

                        -- 脱战回血
                        if not e.isSharedBoss and e.lastHitTime and (Now() - e.lastHitTime) > 10.0
                            and e.hp < e.maxHp and not e.isDead then
                            e.hp = math.floor(math.min(e.maxHp, e.hp + e.maxHp * 0.25 * dt))
                        end

                        -- 受击闪烁计时
                        if e.__flashTimer and e.__flashTimer > 0 then
                            e.__flashTimer = e.__flashTimer - dt
                            if e.__flashTimer <= 0 then
                                e.__flashTimer = nil
                                SetHitFlash(e, false)
                            end
                        end

                        -- 攻击玩家（回走状态下不攻击）
                        if e.isAggro and not e.returning
                            and d < (e.attackRange or 3) and playerAttackable then
                            e.attackTimer = e.attackTimer - dt
                            if e.attackTimer <= 0 then
                                e.attackTimer = e.attackCooldown
                                e.lastHitTime = Now()
                                if onAttackPlayer_ then onAttackPlayer_(e, stats) end
                            end
                        end
                    end
                end

                -- 视觉（统一更新，放在冻结/销毁分支之后）：
                -- 未销毁的怪一律更新视觉——冻结怪 node 仍在，
                -- 继续呼吸/摆动（位置不变）；销毁怪 node=nil，跳过。
                if node then
                    e.bobPhase = e.bobPhase + dt * 4.5
                    local bob = math.abs(math.sin(e.bobPhase)) * 0.07
                    node.position = Vector3(e.x, TerrainH(e.x, e.z) + bob, e.z)
                    if d > 0.001 then
                        node.rotation = Quaternion(math.atan2(dx, dz) * 180 / math.pi, Vector3.UP)
                    end
                    -- 超出渲染距离的怪物隐藏（省 draw call）
                    -- 共享 Boss 不隐藏：它是全服共享目标，玩家需要能看到它
                    if e.isSharedBoss then
                        node:SetEnabled(true)
                    else
                        node:SetEnabled(d <= renderDist)
                    end
                end
            end
        end
    end

    --- 生成一只「共享 Boss」的本地表现体。
    --- 它与普通怪共用同一套渲染/索敌路径，区别在于：
    ---   · id 用服务端下发的 monsterId（保证两端一致）
    ---   · isSharedBoss = true → 伤害本地结算，但把击杀上报服务端（见 Battle_Combat）
    ---   · 血量**由本客户端自己维护**：服务端已不校正血量，只在生成时广播一次满血
    ---     （SyncSharedBoss 仍保留，用于「中途加入时接住服务端推来的初始血量」）
    ---@param monsterId string
    ---@param x number
    ---@param z number
    ---@param hp number
    ---@param maxHp number
    ---@return table|nil
    function Enemies.SpawnSharedBoss(monsterId, x, z, hp, maxHp)
        if not scene_ then return nil end
        -- 已存在则只更新血量，不重建节点
        local existing = enemies[monsterId]
        if existing then
            -- ⚠️ hp/maxHp 来自 GetFloat，取整后再存，保证本地 HP 全程为整数
            existing.hp = math.floor(hp or 0)
            existing.maxHp = math.floor(maxHp or 0)
            return existing
        end

        -- Boss 等级 = 激活区域段位最高级
        local q = Shared.QualityOfMonsterLevel(Shared.MonsterLevelOf(x, z) or 1)
        local bossLv = Shared.C.TIER_MAX_LEVEL[q] or 9
        local bs = Shared.C.BOSS_STATS[q] or Shared.C.BOSS_STATS.normal

        local baseRadius = 0.5 + math.random() * 0.3
        local scale = 4.0
        local radius = baseRadius * scale

        local enemy = {
            id = monsterId,
            level = bossLv,
            x = x, z = z, radius = radius,
            homeX = x, homeZ = z,
            hp = math.floor(hp or 0), maxHp = math.floor(maxHp or 0),
            atk = bs.atk,
            armor = bs.armor,
            dodge = bs.dodge,
            hitRate = bs.hitRate,
            attackCooldown = 1.0,   -- 统一攻速
            -- BOSS 体型更大，攻击距离比普通怪更远（原 radius*2+3 会「隔空挨打」）
            attackRange = 2.5,
            attackTimer = 0,
            isDead = false,
            isBoss = true,
            isSharedBoss = true,
            isLocallyDead = false,
            -- 本地血量归零后只上报一次击杀（由 Battle_Combat 置位）。
            -- ⚠️ 服务端已不再校正血量，所以不会再有「纠正回正」把本标记复位；
            --    重置逻辑仍留在 SyncSharedBoss 里作为防御（收到 hp>0 时清标记）。
            __killReported = nil,
            bobPhase = math.random() * math.pi * 2,
            aggroTarget = nil,
            isAggro = false,
            returning = false,
            dots = nil,
        }

        local node = scene_:CreateChild("SharedBoss_" .. monsterId, LOCAL)
        node.position = Vector3(x, TerrainH(x, z), z)
        node:SetScale(scale)
        -- 共享 BOSS 固定用晶体花模型
        Battle.Visual.Monster.Build(node, "boss")

        enemies[monsterId] = enemy
        nodes[monsterId] = node
        enemy.__nodeRef = node
        -- ⚠️ hp 来自 eventData:GetFloat()，是浮点数。Lua 5.4 下 %d 传浮点会抛
        --    「number has no integer representation」，异常会中断 SpawnSharedBoss
        --    （节点已建、表已填，但函数没返回），导致 Boss 表现异常。
        --    凡是从网络读来的数值用于 %d 前，必须先 floor。
        print(string.format("[Battle] 共享 Boss 已渲染 %s Lv=%d hp=%d",
            monsterId, math.floor(enemy.level or 0), math.floor(hp or 0)))
        return enemy
    end

    --- 用服务端广播的血量同步本地 Boss。
    --- ⚠️ 服务端已不再做血量校正，本函数现在只在两种时机被调到：
    ---   · 生成时（服务端广播满血）→ 建立本地血量
    ---   · 中途加入时（PushSharedBossesTo 补推）→ 接住初始血量
    ---   此后本地血量由本客户端自己维护，不会再被覆盖。
    ---@param monsterId string
    ---@param hp number
    ---@param maxHp number
    function Enemies.SyncSharedBoss(monsterId, hp, maxHp)
        local e = enemies[monsterId]
        if not e then return end
        -- ⚠️ hp/maxHp 来自 GetFloat，取整后再存，保证本地 HP 全程为整数
        e.hp = math.floor(hp or 0)
        e.maxHp = math.floor(maxHp or 0)
        -- 清除「本地乐观死亡」标记（防御性保留）。
        -- ⚠️ 当前没有任何代码会把它设为 true：Battle_Combat 已不再因本地血量归零
        --    而停手（那会导致玩家打不到 Boss → 伤害上报中断 → 服务端永不判定死亡）。
        --    这里保留重置，是为了万一将来重新引入本地停手逻辑时不至于永久卡死。
        if hp > 0 then
            e.isLocallyDead = false
            -- ⚠️ 必须同时重置「击杀已上报」标记，否则：若 BOSS_KILLED 包丢失、
            --    服务端血量被纠正回来（hp > 0），玩家再次打死时不会重新上报，
            --    这只 Boss 就永远打不死也拿不到奖励。
            e.__killReported = nil
        end
        if hp <= 0 then e.isDead = true end
    end

    --- 移除一只共享 Boss（服务端通知被击杀或超时逃跑）
    ---@param monsterId string
    function Enemies.RemoveSharedBoss(monsterId)
        local e = enemies[monsterId]
        if e then e.isDead = true end
    end

    --- 找一个合规的刷怪点：远离出生点安全区、与玩家高度差不超过 5 米、
    --- 且与现有怪物保持最小间距。最多尝试 30 次，全部失败则返回 nil。
    ---
    --- ⚠️ 高度过滤是第三批新增：地形起伏加大后，若不加限制，怪会刷在
    ---    玩家够不到的崖顶/崖底（战斗距离判定全是 2D 距离，垂直差看不见）。
    ---@param px number
    ---@param pz number
    ---@return number|nil x, number|nil z
    function FindValidSpawnPos(px, pz)
        local maxDist = math.min(viewDist_ * Shared.C.MONSTER_REFRESH_RATIO,
                                 Shared.C.MONSTER_REFRESH_CAP)
        local minDist = Shared.C.LOCAL_MONSTER_SAFE_DIST
        local playerY = TerrainH(px, pz)

        -- 🔴 刷怪只在玩家当前段位：撒出的候选点必须与玩家同段位（普通/优秀/精良/…），
        --    否则玩家站在段位边缘时会刷出下一段位的怪（比如 Lv9 玩家周围刷出 Lv10）。
        local playerQuality = Shared.QualityOfMonsterLevel(Shared.MonsterLevelOf(px, pz))

        for _ = 1, 30 do
            local angle = math.random() * math.pi * 2
            local dist = minDist + math.random() * (maxDist - minDist)
            local x = px + math.cos(angle) * dist
            local z = pz + math.sin(angle) * dist

            local lv = Shared.MonsterLevelOf(x, z)
            -- 段位校验：必须与玩家同段位
            if Shared.QualityOfMonsterLevel(lv) == playerQuality
                and math.sqrt(x * x + z * z) >= Shared.C.LOCAL_MONSTER_SAFE_DIST then
                local spawnY = TerrainH(x, z)
                if math.abs(spawnY - playerY) <= 7.0 then
                    local tooClose = false
                    for _, e in ipairs(Enemies.GetAliveList()) do
                        if Shared.Dist2D(x, z, e.x, e.z) < Shared.C.LOCAL_MONSTER_MIN_DIST_BETWEEN then
                            tooClose = true
                            break
                        end
                    end
                    if not tooClose then return x, z end
                end
            end
        end
        return nil, nil
    end

    --- 请求立刻补满怪物（下次 Update 立即触发补怪，无需等满 25 秒）
    function Enemies.ForceRefill()
        spawnTimer = Shared.C.LOCAL_MONSTER_REFILL_INTERVAL
    end

    --- 玩家死亡/重连时清空全部怪物
    function Enemies.Clear()
        for id, n in pairs(nodes) do
            if n then n:Remove() end
            nodes[id] = nil
        end
        enemies = {}
        spawnTimer = 0
    end
    Battle.Enemies = Enemies
end

-- ===== 模块：Effects =====
do
    -- ============================================================
    -- client/Effects.lua：技能特效
    -- 用对象池避免每次触发都新建 Node + 克隆 Material（原实现每帧可能创建几十个）
    -- ============================================================
    local Effects = {}
        -- 同文件内模块引用
    local Assets = Battle.Assets

    --- ⚠️ 延迟查表：Battle.Visual.Terrain 由 Battle_Visual.lua 在加载后注入。
    ---@param x number
    ---@param z number
    ---@return number
    local function TerrainH(x, z)
        return Battle.Visual.Terrain.GetHeight(x, z)
    end

    -- E4：技能特效 Toon 化 —— 从「每技能一个颜色/大小」改为「形状 + 语义色」。
    -- 旧 CONFIG 表（38 项逐技能配色）已删除，颜色改由形状决定（见 SHAPE_COLOR）。

    -- 技能 → 形状（按语义分派）
    -- ⚠️ 不在表内的技能 fallback 到 "burst"（Effects.Play 里的 `or "burst"`）。
    local SKILL_SHAPE = {
        -- 攻击类
        arcChain = "slash", windCut = "slash",
        -- 即时伤害 / 被动增伤
        deadly = "burst", armorBreak = "burst", hunter = "burst",
        suppress = "burst", precision = "burst",
        -- 范围伤害 / 增益 / DoT / 减益
        moonBurst = "ring", resonance = "ring", backlash = "ring", soulChain = "ring",
        boilingBlood = "ring", frostFlow = "ring",
        ironCloth = "ring", lightBody = "ring", swift = "ring",
        boneErode = "ring", bloodErode = "ring", venom = "ring", bleed = "ring",
        dullArmor = "ring", slowStrike = "ring", shock = "ring", armorRend = "ring",
        -- ⚠️ fissure 是真实技能（Shared.SKILL_DEFS 里有），但上一版清单漏列；
        --    它是「受后续伤害 +20%」的减益，语义同其他 DoT/减益 → ring。
        fissure = "ring",
        -- 防御 / 反伤
        thornArmor = "shield", ironWall = "shield", stoneShield = "shield",
        reflect = "shield", scaleGuard = "shield",
        -- 治疗 / 吸血
        lifesteal = "pillar", vitality = "pillar", soulSiphon = "pillar",
        lastBreath = "pillar", rejuvenate = "pillar", bloodSurge = "pillar",
        bloodthirst = "pillar",
    }

    -- 形状 → 颜色（语义色系：金=攻击 / 青=增益 / 蓝=防御 / 绿=治疗）
    local SHAPE_COLOR = {
        slash  = { 1.00, 0.85, 0.40 },   -- 金
        ring   = { 0.55, 0.90, 1.00 },   -- 青蓝
        shield = { 0.65, 0.78, 1.00 },   -- 蓝白
        pillar = { 0.55, 1.00, 0.65 },   -- 翠绿
        burst  = { 1.00, 0.92, 0.55 },   -- 亮金
    }

    -- 形状 → 基础缩放
    local SHAPE_SIZE = {
        slash = 1.0, ring = 1.0, shield = 1.0, pillar = 1.0, burst = 1.0,
    }

    local LIFETIME = 0.5
    local MAX_POOL = 48

    ---@type table[]
    local active = {}
    ---@type table[]
    local pool = {}
    local scene_ = nil

    function Effects.SetScene(scene) scene_ = scene end

    ---@param shapeType string
    ---@return table|nil
    local function Acquire(shapeType)
        local fx
        if #pool > 0 then
            fx = table.remove(pool)
        else
            if not scene_ then return nil end

            local node = scene_:CreateChild("SkillFx", LOCAL)
            -- ⚠️ 用 CustomGeometry 组件而不是 StaticModel：特效需要顶点色，
            --    而顶点色只能由 CustomGeometry 产出。
            local geom = node:CreateComponent("CustomGeometry", LOCAL)
            -- ⚠️ 特效不投影：平面薄片投出来的影子很怪
            geom.castShadows = false
            -- 描边改在 BuildFXShape 里用顶点色渐变实现（见那里的注释）。
            -- 引擎级 outline 对平面薄片无效：所有顶点法线相同，
            -- 沿法线外扩等于整片平移，画不出边缘。
            node:SetEnabled(false)
            fx = { node = node, model = geom, shape = nil, matKey = nil }
        end
        -- 形状不同则重建 geometry（BuildFXShape 内部会先 Clear）
        if fx.shape ~= shapeType then
            Assets.BuildFXShape(fx.model, shapeType)
            fx.shape = shapeType
            fx.matKey = nil
        end
        return fx
    end

    local function Release(fx)
        if not fx or not fx.node then return end
        fx.node:SetEnabled(false)
        if #pool < MAX_POOL then
            table.insert(pool, fx)
        else
            fx.node:Remove()
        end
    end

    -- 挥砍特效（PlaySlash / UpdateSlash）已整体删除：
    -- 设置面板里的「挥砍特效」开关已移除，且该特效在移动端观感不佳，
    -- 改为只保留命中即播的技能特效（Effects.Play）。

    --- 播放一次技能特效
    ---@param skillId string
    ---@param x number
    ---@param z number
    ---@param value number
    function Effects.Play(skillId, x, z, value)
        if not scene_ then return end

        local shapeType = SKILL_SHAPE[skillId] or "burst"
        local rgb       = SHAPE_COLOR[shapeType] or { 1, 1, 1 }
        local color     = Color(rgb[1], rgb[2], rgb[3], 1.0)

        local fx = Acquire(shapeType)
        if not fx then return end

        -- 材质按形状缓存，避免每次 Clone
        if fx.matKey ~= shapeType then
            local mat = Assets.EffectMaterial(shapeType, color)
            if mat then fx.model:SetMaterial(mat) end
            fx.matKey = shapeType
        end

        -- 位置：pillar 是水平圆盘，贴地但抬高 0.05 —— 正好落在地面高度会与地形
        --       z-fighting（闪烁）。其他形状悬在目标上方 1m。
        local yBase = TerrainH(x, z)
        local yPos  = (shapeType == "pillar") and (yBase + 0.05) or (yBase + 1.0)
        fx.node.position = Vector3(x, yPos, z)

        -- 初始朝向：slash 随机偏转 ±30° 避免每次都在同一角度；其他朝向不变
        if shapeType == "slash" then
            fx.node.rotation = Quaternion(math.random(-30, 30), Vector3.UP)
            fx.rotAngle = 0
        else
            fx.node.rotation = Quaternion(0, Vector3.UP)
        end

        local baseSize = SHAPE_SIZE[shapeType] or 1.0
        fx.node:SetScale(baseSize)
        fx.node:SetEnabled(true)
        fx.life      = LIFETIME
        fx.maxLife   = LIFETIME
        fx.baseScale = baseSize
        fx.shapeType = shapeType
        fx.startY    = yPos

        table.insert(active, fx)
    end

    ---@param dt number
    function Effects.Update(dt)
        for i = #active, 1, -1 do
            local fx = active[i]
            fx.life = fx.life - dt
            if fx.life <= 0 then
                Release(fx)
                table.remove(active, i)
            else
                local progress = 1.0 - fx.life / fx.maxLife   -- 0 → 1

                if fx.shapeType == "slash" then
                    -- 绕 Y 轴快旋 + 轻微放大（挥砍轨迹残留感）
                    fx.rotAngle = (fx.rotAngle or 0) + dt * 540
                    fx.node.rotation = Quaternion(fx.rotAngle, Vector3.UP)
                    fx.node:SetScale(fx.baseScale * (1.0 + progress * 0.4))

                elseif fx.shapeType == "ring" then
                    -- 水平扩散（范围感）
                    fx.node:SetScale(fx.baseScale * (1.0 + progress * 0.8))

                elseif fx.shapeType == "shield" then
                    -- 轻微脉动（呼吸感）
                    local pulse = 1.0 + math.sin(progress * math.pi * 3) * 0.05
                    fx.node:SetScale(fx.baseScale * pulse)

                elseif fx.shapeType == "pillar" then
                    -- 水平圆盘：上升 + 放大（治疗扩散感）。
                    -- 俯视角下 Y 位移视觉不明显，主要靠放大传达"扩散"。
                    fx.node.position = Vector3(
                        fx.node.position.x,
                        fx.startY + progress * 0.4,
                        fx.node.position.z)
                    fx.node:SetScale(fx.baseScale * (1.0 + progress * 0.7))

                elseif fx.shapeType == "burst" then
                    -- 快速放大（命中爆点）
                    fx.node:SetScale(fx.baseScale * (1.0 + progress * 1.5))
                end
            end
        end
    end

    Battle.Effects = Effects
end

return Battle
