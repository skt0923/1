-- ============================================================
-- Client_State.lua：Client 及其兄弟文件的共享可变状态
--
-- ⚠️ 本文件不含任何函数，只导出一张表。
--    所有原本是 Client.lua 里 local 声明的跨函数变量，
--    全部搬到这里作为表字段。
--
-- 读写方式：local S = require("Client_State")，然后 S.myNode_ = ...
--
-- ⚠️ 不要在本文件里 require 任何项目文件（避免循环依赖）。
--    因此依赖 Shared.C 的相机初值（camPitch_ / camDist_）不在此处赋值，
--    由 Client.lua 在 require 后立即补上（保持与拆分前一致的初值）。
-- ============================================================

---@class ClientState
---@field scene_ Scene|nil
---@field cameraNode_ Node|nil
---@field cam_ Camera|nil
---@field myNode_ Node|nil
---@field myId_ string|nil
---@field joystick_ any
---@field light_ Light|nil
---@field lightNode_ Node|nil
---@field sunNode_ Node|nil
---@field sunDir_ Vector3|nil
---@field sunDist_ number
---@field localPlayerX_ number
---@field localPlayerZ_ number
---@field playerFacing_ number
---@field joyX_ number
---@field joyY_ number
---@field camYaw_ number
---@field camPitch_ number
---@field camDist_ number
---@field camSmoothY_ number|nil
---@field camSmoothT_ number
---@field meleeCooldown number
---@field normalAttackTargetId_ string|nil
---@field autoBattleTargetId_ string|nil
---@field localKillCount_ number
---@field localKillTier_ number|nil
---@field deathTimer_ number
---@field invincibleUntil_ number
---@field lookArea_ any
---@field pinchLastDist_ number
---@field bindRetry_ number
---@field timeTickAccum_ number
---@field timeDirtyAccum_ number
---@type ClientState
local S = {
    -- 场景 / 相机 / 节点
    scene_ = nil,
    cameraNode_ = nil,
    cam_ = nil,
    myNode_ = nil,
    myId_ = nil,
    joystick_ = nil,
    light_ = nil,
    lightNode_ = nil,
    sunNode_ = nil,
    sunDir_ = nil,
    sunDist_ = 0,

    -- 玩家运动状态
    localPlayerX_ = 0,
    localPlayerZ_ = 0,
    playerFacing_ = 0,
    joyX_ = 0,
    joyY_ = 0,

    -- 相机轨道（camPitch_ / camDist_ 由 Client.lua 补初值）
    camYaw_ = 0,
    camPitch_ = 0,
    camDist_ = 0,
    camSmoothY_ = nil,
    camSmoothT_ = 1.0,

    -- 战斗
    meleeCooldown = 0,
    normalAttackTargetId_ = nil,
    autoBattleTargetId_ = nil,   -- 自动战斗锁定目标（打到它死或超范围才换）
    localKillCount_ = 0,
    localKillTier_ = nil,

    -- 死亡
    deathTimer_ = 0,
    invincibleUntil_ = 0,

    -- 触摸（摇杆 + 视角 + 捏合）
    lookArea_ = nil,
    pinchLastDist_ = 0,

    -- 网络绑定
    bindRetry_ = 0,

    -- 计时累加
    timeTickAccum_ = 0,
    timeDirtyAccum_ = 0,
}

return S
