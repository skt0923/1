-- PostProcess.lua —— 后处理 pass 开关 + Zone 画面参数读写
--
-- 来源：由 RenderTest.lua / RenderTest_Shared.lua 裁剪合并而来
--   · 只保留「设置面板需要的底层能力」
--   · 已删除全部测试面板 / FPS 采样 / 截图 / 扫描 / 探针 / 按钮挂载
--
-- 职责：
--   1. PASS_TAGS / DEFAULT_ON：8 个后处理 pass 的 tag 清单与默认开关
--   2. SetEnabled / IsEnabled：读写 RenderPath 的 pass 开关
--   3. GetZone / Read / Write：读写 renderer.defaultZone 字段（画面参数）
--   4. ApplyFromSettings：按 Data.value.settings 应用 pass 开关
--
-- ⚠️ tag 必须与 RenderPath 里的真实 tag **逐字精确匹配**（大小写、空格都不能差）。
--    踩过的坑：rp:IsEnabled("bloom") = false，真实 tag 是 "BloomHDRPlus"。

local Shared = require("Shared")
local Data   = Shared.Data

local M = {}

-- ============================================================
-- pass 清单
-- ============================================================

--- 8 个后处理 pass 的真实 tag（来自 RenderPath 探测）
---@type {tag: string, label: string}[]
M.PASS_TAGS = {
    { tag = "BloomHDR Downsample", label = "Bloom Legacy 降采样" },
    { tag = "BloomHDR Upsample",   label = "Bloom Legacy 升采样" },
    { tag = "BloomHDRUE",          label = "Bloom UE" },
    { tag = "BloomHDRPlus",        label = "Bloom Plus（实际出图）" },
    { tag = "DOF",                 label = "景深 DOF" },
    { tag = "FXAA2",               label = "FXAA 抗锯齿" },
    { tag = "AutoExposure",        label = "自动曝光" },
    { tag = "GaussianBlur",        label = "高斯模糊" },
}

--- 默认开启的 pass（其余关闭）。
--- 🔴 Bloom 为什么关掉（2026-10-04 实测两次）：
---    天空盒材质 MatDiffColor = hdrBoost = 2.0（见 SkyUtils.CreateGradientSky，
---    用于补偿 ACES 色调映射）。Bloom 阈值一旦 < 2.0，**整片天空**都会参与泛光，
---    光晕铺满上半屏 → 画面发白。实测：0.85 发白；1.00 仍发白（天空 R=2.0 依然超阈值）。
---    要排除天空必须把阈值提到 > 2.0，但那样太阳（R=1.0）也不泛光了。
---    结论：Bloom 在本场景不划算，关掉。
---@type table<string, boolean>
M.DEFAULT_ON = {
    ["FXAA2"] = true,
}

--- 设置面板的 key ↔ tag 映射（settings 用扁平 key，避免嵌套）
--- 只暴露这两项；其余 pass 由 FORCED_OFF 强制关闭
---@type {key: string, tag: string, label: string}[]
M.SETTING_KEYS = {
    { key = "pp_FXAA2",        tag = "FXAA2",        label = "FXAA 抗锯齿" },
    { key = "pp_BloomHDRPlus", tag = "BloomHDRPlus", label = "Bloom 泛光" },
}

--- 强制关闭的 pass（不进设置面板，每次启动显式关掉）。
--- ⚠️ 这三项引擎默认是 enabled=true，必须显式关 —— 否则重启后又被引擎默认打开。
---   · AutoExposure  原神是固定曝光（见 Client.lua 的 autoExposureEnabled 注释）
---   · GaussianBlur  项目从未打算启用
---   · DOF           同上
---@type string[]
M.FORCED_OFF = {
    "AutoExposure",
    "GaussianBlur",
    "DOF",
}

-- ============================================================
-- RenderPath pass 开关
-- ============================================================

--- 设置某个 pass 的开关
---@param tag string
---@param on boolean
---@return boolean ok
function M.SetEnabled(tag, on)
    local rp = renderer and renderer.defaultRenderPath --[[@as any]]
    if not rp then return false end
    local ok = pcall(function() rp:SetEnabled(tag, on) end)
    print(string.format("[PostProcess] PASS %-22s -> %-5s ok=%s",
        tag, tostring(on), tostring(ok)))
    return ok
end

--- 读某个 pass 的开关状态
---@param tag string
---@return boolean enabled 是否开启
---@return boolean available 该 tag 是否可用（false = 查询失败）
function M.IsEnabled(tag)
    local rp = renderer and renderer.defaultRenderPath --[[@as any]]
    if not rp then return false, false end
    local ok, v = pcall(function() return rp:IsEnabled(tag) end)
    if not ok or type(v) ~= "boolean" then return false, false end
    ---@cast v boolean
    return v, true
end

-- ============================================================
-- Zone 画面参数读写（设置面板用）
-- ============================================================

---@return Zone|nil
function M.GetZone()
    return renderer and renderer.defaultZone
end

--- 读 Zone 某项当前值
---@param key string
---@return any
function M.Read(key)
    local z = M.GetZone() --[[@as any]]
    if not z then return nil end
    local ok, v = pcall(function() return z[key] end)
    if ok then return v end
    return nil
end

--- 写 Zone 某项
---@param key string
---@param value any
---@return boolean ok
function M.Write(key, value)
    local z = M.GetZone() --[[@as any]]
    if not z then return false end
    local ok = pcall(function() z[key] = value end)
    if ok then
        print(string.format("[PostProcess] SET %-28s -> %s", key, tostring(value)))
    else
        print(string.format("[PostProcess] SET-FAIL %-24s -> %s", key, tostring(value)))
    end
    return ok
end

-- ============================================================
-- 按 settings 应用
-- ============================================================

--- 按 Data.value.settings 应用后处理与画面参数。
--- ⚠️ SetEnabled 会**跨会话持久化** —— 只设"要开的"不够，
---    必须把不在表里的显式关掉，否则上次测试残留会一直生效。
function M.ApplyFromSettings()
    local st = Data and Data.GetSettings and Data.GetSettings() or nil
    if st == nil then
        print("[PostProcess] ⚠️ settings 不可用，用 DEFAULT_ON")
        st = {}
    end

    -- ---------- A. pass 开关 ----------
    local want = {}
    for _, m in ipairs(M.SETTING_KEYS) do
        local v = st[m.key]
        if v == nil then v = (M.DEFAULT_ON[m.tag] == true) end
        want[m.tag] = v == true
    end
    -- 强制关闭项优先级最高（引擎默认 true，必须显式关）
    for _, tag in ipairs(M.FORCED_OFF) do
        want[tag] = false
    end

    local on, off = {}, {}
    for _, p in ipairs(M.PASS_TAGS) do
        -- 不在设置面板里的 pass（如 Bloom Legacy / UE）按 DEFAULT_ON 处理
        local w = want[p.tag]
        if w == nil then w = (M.DEFAULT_ON[p.tag] == true) end
        M.SetEnabled(p.tag, w)
        if w then on[#on + 1] = p.tag else off[#off + 1] = p.tag end
    end
    print(string.format("[PostProcess] pass：开 [%s] | 关 [%s]",
        table.concat(on, ","), table.concat(off, ",")))

    -- ---------- B. Zone 画面参数 ----------
    local z = M.GetZone() --[[@as any]]
    if z ~= nil then
        -- 环境光模式**锁定 COLOR(2)**：PREBAKED/SKYBOX 已弃用
        -- （PREBAKED 依赖引擎预烘焙 IBL，程序化场景下不可控；见 Shared.lua 注释）
        pcall(function() z.ambientSource = 2 end)
        pcall(function() z.bloomThreshold = st.bloomThreshold or 1.00 end)
        pcall(function() z.bloomPlusIntensity = st.bloomIntensity or 0.35 end)
        pcall(function() z.ambientIntensity = st.ambientIntensity or 0.65 end)
        print(string.format("[PostProcess] Zone：ambientSource=2(COLOR 锁定) bloomThreshold=%.2f bloomPlusIntensity=%.2f ambientIntensity=%.2f",
            st.bloomThreshold or 1.00, st.bloomIntensity or 0.35, st.ambientIntensity or 0.65))
    end

    -- ---------- C. Toon 材质（惰性取，材质懒加载，拿不到就跳过）----------
    local okV, BV = pcall(require, "Battle_Visual")
    local Visual = okV and BV and BV.Visual or nil
    if Visual ~= nil then
        local terrMat = Visual.getTerrainMaterial and Visual.getTerrainMaterial() or nil
        if terrMat then
            pcall(function()
                terrMat:SetShaderParameter("toon_threshold",
                    Variant(st.toonThresholdTerrain or 0.72))
                terrMat:SetShaderParameter("toon_shadow_strength",
                    Variant(st.toonShadowStrength or 1.0))
            end)
        end
        local charMat = Visual.getCharacterMaterial and Visual.getCharacterMaterial() or nil
        if charMat then
            pcall(function()
                charMat:SetShaderParameter("toon_threshold",
                    Variant(st.toonThresholdCharacter or 0.30))
                charMat:SetShaderParameter("toon_shadow_strength",
                    Variant(st.toonShadowStrength or 1.0))
            end)
        end
        print(string.format("[PostProcess] Toon：地形=%.2f 角色=%.2f 暗面=%.2f",
            st.toonThresholdTerrain or 0.72,
            st.toonThresholdCharacter or 0.30,
            st.toonShadowStrength or 1.0))
    end
end

return M
