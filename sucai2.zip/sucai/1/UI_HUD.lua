-- ============================================================
-- UI_HUD.lua：常驻 HUD（胖主文件，自包含）
--
-- 职责：顶部资源栏（金币 / 血条 / 在线状态）、右侧功能按钮、普攻与自动战斗按钮、
--       世界坐标伤害飘字、Toast 提示、罚站遮罩层，以及虚拟画布缩放管理。
--
-- 依赖：Shared（含 Data / FormatTime）。**不 require 任何其他项目模块**。
--
-- 为什么缩放（UpdateScale）放在这里：
--   缩放只被 HUD 的 WorldToUI（世界坐标 → UI 坐标）使用，Panels 不需要。
--   由本文件自己持有 scale/offset 状态，比经中间层注入更简单、少一层间接。
--
-- 对外接口（Client 实际调用的部分）：
--   SetCamera / SetSceneProvider / SetCallbacks / Build / Update
--   Toast / ShowDamageNumber / UpdateDamageNumbers / UpdateMinimap
--   UpdateInfoLabels / UpdateUnitTags / SetOnlineCount / UpdateScale
--
-- Toast 是自绘的「纯文字通知」（无背景框），通过 globalComponent 绘制，
-- 保证面板打开时仍显示在最上层；同时最多 1 条，其余排队，每条 1 秒。
-- ============================================================
local Shared = require("Shared")
local Data   = Shared.Data
-- U3：取主题色。UI_Core 不 require UI_HUD，故无循环依赖。
-- ⚠️ UI_HUD 此前只依赖 Shared，这是本项目第一个反向依赖 UI_Core 的 HUD 侧引用；
--    加之前已核实 UI_Core 只 require("Shared")，安全。
local Core   = require("UI_Core")

local HUD = {}

-- ===== UI 坐标系（必须与 urhox-libs/UI 完全一致）=====
-- ⚠️ 这里的 uiScale_ 是「UI 基像素 → 物理像素」的缩放系数，必须取自 UI.GetScale()。
--
--    urhox-libs/UI 用 UI.Scale.DEFAULT（DPR_DENSITY_ADAPTIVE），坐标空间是
--    「物理像素 / scale」，且**没有居中偏移**（布局直接铺满全屏）。
--    早期实现自己按 1280x720 等比缩放 + 居中（letterbox），与 UI 库的坐标系
--    不一致 —— 屏幕宽高比越偏离 16:9，世界坐标转出来的 UI 位置偏得越远，
--    表现为「怪物/玩家的血条、伤害跳字整体错位」。
--
--    HUD 自身所有 absolute 布局都挂在 SafeAreaView(100%) 下，按 UI 坐标解析，
--    因此改用 UI 库的口径后，HUD 布局与世界坐标转 UI 的换算自动一致。
local uiScale_ = 1
local uiOffsetX_, uiOffsetY_ = 0, 0

--- 屏幕尺寸变化时重算画布缩放（由 Client 在启动与 resize 时调用）
---@param screenW number
---@param screenH number
function HUD.UpdateScale(screenW, screenH)
    local UI = require("urhox-libs/UI")
    -- UI 库初始化后才有效；未初始化时 GetScale() 返回 1，先按物理像素处理
    uiScale_ = UI.GetScale and UI.GetScale() or 1
    if uiScale_ <= 0 then uiScale_ = 1 end
    -- UI 坐标系无居中偏移（布局铺满全屏）
    uiOffsetX_, uiOffsetY_ = 0, 0
end

--- UI 坐标空间下的屏幕尺寸（屏外裁剪用）。
--- ⚠️ 不要写死 1280x720：UI 坐标空间 = 物理像素 / uiScale_，
---    在 2400x1080 这类宽屏上宽度远超 1280，写死会把右半屏的内容全部裁掉。
---@return number w, number h
local function UIScreenSize()
    local s = (uiScale_ > 0) and uiScale_ or 1
    return graphics:GetWidth() / s, graphics:GetHeight() / s
end

-- ============================================================
-- 顶部资源栏 + 右侧功能按钮 + 普攻按钮 + 伤害飘字 + Toast
-- 使用 urhox-libs/UI（Yoga + NanoVG）
-- ============================================================
local UI_ = nil

-- 控件引用（模式 A：保留 local 引用，避免 FindById 的类型收窄麻烦）
---@type Label|nil
local goldLabel_ = nil
---@type Label|nil
local onlineTimeLabel_ = nil
---@type Button|nil
local attackBtn_ = nil
--- 右下角自动战斗按钮：常驻，文字随开关切换 ⚔️ / ⏹
---@type Button|nil
local autoSmBtn_ = nil
---@type Panel|nil
local damageLayer_ = nil
---@type Panel|nil
local overlayLayer_ = nil

--- 钱庄红点（有利息可领时显示）
---@type Label|nil
local bankDot_ = nil

--- 段位名称（显示在小地图下方）
---@type Label|nil
local tierLabel_ = nil

--- 首领进度（区域标签正下方）：还需击杀多少只怪才会刷出共享首领
---@type Label|nil
local bossProgressLabel_ = nil
--- 读取器：返回 (还需击杀数, 当前阈值)。由 Client.lua 注入。
---@type fun(): integer|nil, integer|nil
local bossProgressProvider_ = nil

-- ---------- 小地图（A1）----------
---@type Panel|nil
local minimapBase_ = nil            -- 底盘（84x84 圆）
---@type table<string, Panel>
local minimapDots_ = {}             -- 复用池：key = "e_<id>" / "p_self"
local minimapTimer_ = 0
local MINIMAP_INTERVAL = 0.1
local MINIMAP_RANGE = 200           -- 超过这个距离的点不画（米）

-- ---------- 头顶标签（A2）----------
---@type table<string, table>
local unitTags_ = {}
local unitTagTimer_ = 0
local UNIT_TAG_INTERVAL = 0.2

-- 其他玩家扫描
local myIdProvider_ = nil
local sceneProvider_ = nil

function HUD.SetMyIdProvider(fn) myIdProvider_ = fn end
function HUD.SetSceneProvider(fn) sceneProvider_ = fn end

--- 昵称查询器：pid → TapTap 昵称（服务端广播，见 Net.OnPlayerInfo）
---@type fun(pid: string): string|nil
local nameProvider_ = nil
function HUD.SetNameProvider(fn) nameProvider_ = fn end

--- 由 Client 注入地形高度读取器（头顶标签要贴地形，不能用 y=0 常量）
---@type fun(x: number, z: number): number|nil
local terrainHeightProvider_ = nil
function HUD.SetTerrainHeightProvider(fn) terrainHeightProvider_ = fn end

--- 由 Client 注入玩家朝向读取器（小地图朝向指针）
---@type fun(): number|nil
local facingProvider_ = nil
function HUD.SetFacingProvider(fn) facingProvider_ = fn end

--- 内部工具：取地形高度（无 provider 时返回 0，退化为旧的绝对高度行为）
---@param x number
---@param z number
---@return number
local function TerrainH(x, z)
    if terrainHeightProvider_ then
        return terrainHeightProvider_(x, z) or 0
    end
    return 0
end

-- ---------- 分辨率/FPS（A11）----------
---@type Label|nil
local statsLabel_ = nil
local statsTimer_ = 0
local statsFrames_ = 0
local statsFps_ = 0

-- ---------- 在线人数 / 坐标（A15）----------
---@type Label|nil
local onlineLabel_ = nil
---@type Label|nil
local coordLabel_ = nil
local infoTimer_ = 0
local onlineCount_ = 1

---@type fun(action: string)|nil
local onAction_ = nil
---@type fun()|nil
local onAttack_ = nil
---@type fun()|nil
local onAutoToggle_ = nil

--- 由 Client.lua 注入相机（用于世界坐标 → 屏幕坐标）
---@type Camera|nil
local camera_ = nil
function HUD.SetCamera(cam) camera_ = cam end

--- 由 Client.lua 注入玩家坐标读取器（小地图/坐标/头顶标签都要用）
--- UI 层不反向依赖 Client，所以走注入。
---@type fun(): number|nil, number|nil
local playerPosProvider_ = nil
function HUD.SetPlayerPosProvider(fn) playerPosProvider_ = fn end

--- 由 Client.lua 注入存活怪物列表读取器
---@type fun(): table[]
local enemiesProvider_ = nil
function HUD.SetEnemiesProvider(fn) enemiesProvider_ = fn end

--- 当前物理分辨率（A11 显示用）
local screenW_, screenH_ = 0, 0

--- 世界坐标 + 高度 → UI 坐标空间。
--- ⚠️ 前向声明：定义在本文件后部（伤害飘字段落），但头顶标签更新函数在它之前调用。
---    Lua 的 local 作用域从声明之后开始，不先声明就会解析成全局 nil。
---@type fun(x: number, y: number, z: number): number|nil, number|nil
local WorldToUIEx

--- 由 Client 注入右侧按钮 / 普攻 / 自动战斗的回调
---@param cbs {onAction: fun(action:string), onAttack: fun(), onAutoToggle: fun()}
function HUD.SetCallbacks(cbs)
    onAction_ = cbs.onAction
    onAttack_ = cbs.onAttack
    onAutoToggle_ = cbs.onAutoToggle
end

-- HUD.SetEffectVisible 已删除（无调用方，特效开关走 Data.GetSettings() 直读）

---@return Panel
function HUD.Build()
    local UI = require("urhox-libs/UI")
    UI_ = UI

    -- ---------- 顶部资源栏 ----------
    goldLabel_ = UI.Label {
        text = "💰 20",
        fontSize = 14,
        fontColor = { 255, 210, 80, 255 },
        fontWeight = "bold",
    }

    -- 左上角血条与血量数值已移除（改由角色头顶/其他方式展示）

    -- 在线时长（在线卡 + 免费 合并显示），点击打开在线时长面板
    onlineTimeLabel_ = UI.Label {
        text = "⏱ 剩余在线时长 --:--:--",
        fontSize = 12,
        fontColor = { 140, 220, 255, 255 },
        marginTop = 2,
        paddingVertical = 8,
        pointerEvents = "auto",
        onClick = function()
            if onAction_ then onAction_("online") end
        end,
    }

    local topBar = UI.Panel {
        position = "absolute", top = 12, left = 12,
        flexDirection = "column",
        -- ⚠️ 不再整块可点：在线时长 Label 自己处理点击。
        --    box-none 让触摸穿透到子节点；金币 Label 未挂 onClick，点了没反应。
        pointerEvents = "box-none",
        children = {
            goldLabel_,
            onlineTimeLabel_,
        },
    }

    -- 左上角不再放血条：玩家血量改由头顶标签（player 样式）展示，见 UpdateUnitTags。

    -- ---------- 右下角功能按钮（2 行 3 列）----------
    -- 6 个入口：背包/角色/市场 + 邮件/强化/设置，贴右下角。
    -- （锻造 / 重铸由「强化」面板内的 Tab 进入，不再单独占按钮）
    local function ActionButton(label, action, variant)
        -- 从 variant 映射到主题色（与 UI_Core 的 QButton 同款）
        local bg = Core.THEME.btnSecond
        if variant == "primary"     then bg = Core.THEME.btnPrimary
        elseif variant == "success" then bg = Core.THEME.btnSuccess
        elseif variant == "danger"  then bg = Core.THEME.btnDanger
        end
        return UI.Button {
            text = label,
            width = 64, height = 48,
            fontSize = 13,
            paddingHorizontal = 0,
            borderRadius = 10,
            variant = variant or "secondary",
            backgroundColor = bg,
            borderWidth = 1,
            borderColor = Core.THEME.border,
            onClick = function() if onAction_ then onAction_(action) end end,
        }
    end

    local rightBar = UI.Panel {
        position = "absolute", right = 12, bottom = 12,
        flexDirection = "column",
        gap = 8,
        pointerEvents = "box-none",
        children = {
            UI.Panel {
                flexDirection = "row", gap = 8,
                -- 🔴 右对齐：两行按钮数不同（5 / 4），右对齐可让两行共用右边界，
                --    第二行位置因此与新增「天赋」按钮前完全一致
                --    （钱庄红点的像素坐标是按第二行位置算的，见下方 bankDot_）。
                justifyContent = "flex-end",
                children = {
                    ActionButton("背包", "inventory"),
                    ActionButton("角色", "character"),
                    ActionButton("天赋", "bd"),
                    ActionButton("市场", "market"),
                    ActionButton("邮件", "mail"),
                },
            },
            UI.Panel {
                flexDirection = "row", gap = 8,
                justifyContent = "flex-end",
                children = {
                    ActionButton("强化", "enhance"),
                    ActionButton("钱庄", "bank"),
                    ActionButton("宠物", "pet"),
                    ActionButton("设置", "settings"),
                },
            },
        },
    }

    -- ---------- 普攻 / 自动战斗（横排上移，位于功能按钮行上方）----------
    attackBtn_ = UI.Button {
        text = "普攻",
        width = 72, height = 72,
        fontSize = 15,
        variant = "danger",
        borderRadius = 36,
        -- 危险色保留（战斗按钮语义），加主题描边统一质感
        backgroundColor = Core.THEME.btnDanger,
        borderWidth = 1,
        borderColor = Core.THEME.border,
        position = "absolute", right = 88, bottom = 128,   -- 与自动按钮互换
        onClick = function() if onAttack_ then onAttack_() end end,
    }

    -- 自动战斗按钮：保留图标版（⚔️ / ⏹），已删除重复的「自动」文字按钮
    autoSmBtn_ = UI.Button {
        text = "自动",
        fontSize = 15,
        width = 72, height = 72,
        borderRadius = 36,
        variant = "success",
        backgroundColor = Core.THEME.btnSuccess,
        borderWidth = 1,
        borderColor = Core.THEME.border,
        position = "absolute", right = 12, bottom = 128,   -- 与普攻按钮互换
        onClick = function() if onAutoToggle_ then onAutoToggle_() end end,
    }

    -- 钱庄红点：在钱庄按钮右上角显示小红点
    bankDot_ = UI.Label {
        text = "●",
        fontSize = 14,
        fontColor = { 255, 80, 80, 255 },
        position = "absolute",
        -- 钱庄按钮在第二行第 2 列，rightBar 底部 12
        -- 第 1 行高 48，gap 8，第 2 行高 48
        -- 钱庄按钮右边距 = 12 + 48 + 8 + 48 + 8 = 124
        -- 钱庄按钮顶边 = 12 + 48 + 8 = 68
        right = 116, bottom = 72,
        pointerEvents = "none",
    }
    bankDot_:SetVisible(false)

    -- ---------- 伤害飘字层 ----------
    damageLayer_ = UI.Panel {
        position = "absolute", top = 0, left = 0, right = 0, bottom = 0,
        pointerEvents = "none",
    }

    -- ---------- Toast ----------
    -- ⚠️ 不再自绘浮层：HUD 里的任何控件都在「widget 树」中渲染，
    --    而 Modal 的 Render 会把自己的绘制塞进 UI 的 overlay 队列，
    --    在整棵树之后统一绘制 —— 所以自绘 Toast 永远会被弹窗盖住。
    --    改用 UI 库内置的 Toast：它注册成 global component，
    --    绘制发生在 overlay 队列之后，天然盖在所有弹窗之上。
    --    （见 HUD.Toast / urhox-libs/UI/Widgets/Toast.lua）

    -- ---------- 小地图底盘（A1）----------
    -- urhox-libs/UI 没有 Canvas，用「大圆 Panel 当底盘 + 每帧动态摆小圆点」模拟雷达。
    -- 圆盘中心 = 玩家；内部各点用相对坐标定位。
    minimapBase_ = UI.Panel {
        width = 84, height = 84,
        borderRadius = 42,
        backgroundColor = Core.THEME.bgPanelDeep,
        borderColor = Core.THEME.border,
        borderWidth = 1,
        position = "absolute", right = 12, top = 12,
        pointerEvents = "none",
    }

    -- 段位名称（小地图下方居中）
    tierLabel_ = UI.Label {
        text = "",
        fontSize = 11,
        fontColor = "#c8e6ff",
        position = "absolute",
        -- onlineLabel_ 在 top=78、高约 26（含 padding）→ 底边约 104，这里必须让开
        right = 12, top = 106,
        width = 84, textAlign = "center",
        backgroundColor = Core.THEME.bgPanelDeep,
        borderRadius = 6,
        paddingVertical = 2,
        pointerEvents = "none",
    }

    -- 首领进度（紧贴区域标签下方，同宽同右对齐）
    bossProgressLabel_ = UI.Label {
        text = "",
        fontSize = 10,
        fontColor = "#ffc878",
        position = "absolute",
        -- tierLabel_ 在 top=106、高约 20（含 padding）→ 底边约 126
        right = 12, top = 128,
        width = 84, textAlign = "center",
        backgroundColor = Core.THEME.bgPanelDeep,
        borderRadius = 6,
        paddingVertical = 2,
        pointerEvents = "none",
    }

    -- ---------- 在线人数 / 坐标（A15）----------
    onlineLabel_ = UI.Label {
        text = "在线: 1",
        fontSize = 13,
        -- fontColor / borderColor 保留绿色：在线状态是「状态色」不是装饰色
        fontColor = "#88ffbb",
        position = "absolute", top = 78, right = 12,
        backgroundColor = Core.THEME.bgPanelDeep,
        borderColor = Shared.HexRGB("#64dc8c", 115),   -- 保留绿色边框
        borderWidth = 1,
        borderRadius = 8,
        paddingHorizontal = 10, paddingVertical = 3,
    }

    coordLabel_ = UI.Label {
        text = "",
        fontSize = 11,
        fontColor = "#cce8ff",
        position = "absolute", top = 152, right = 12,
        paddingHorizontal = 8, paddingVertical = 3,
        backgroundColor = Core.THEME.bgPanelDeep,
        borderRadius = 6,
    }

    -- ---------- 分辨率/FPS（A11）----------
    statsLabel_ = UI.Label {
        text = "",
        fontSize = 12,
        fontColor = "#aaddff",
        position = "absolute", top = 168, left = 18,
        backgroundColor = Core.THEME.bgPanelDeep,
        paddingHorizontal = 10, paddingVertical = 4,
        borderRadius = 8,
    }
    statsLabel_:SetVisible(false)   -- 默认关（settings.showResolution / showFPS）

    -- ---------- 弹窗宿主层 ----------
    overlayLayer_ = UI.Panel {
        position = "absolute", top = 0, left = 0, right = 0, bottom = 0,
        pointerEvents = "box-none",
    }

    local safe = UI.SafeAreaView {
        width = "100%", height = "100%",
        pointerEvents = "box-none",
        children = {
            topBar, rightBar, attackBtn_, autoSmBtn_,
            minimapBase_, tierLabel_, bossProgressLabel_,
            onlineLabel_, coordLabel_, statsLabel_, bankDot_,
        },
    }

    -- ⚠️ damageLayer_ 必须挂在 root 上，不能放进 safe：
    --    SafeAreaView 把刘海安全区做成 **padding**，其子节点坐标系原点会被
    --    内缩到安全区左上角。头顶血条 / 伤害飘字是按「全屏 UI 坐标」绝对定位的，
    --    放进 safe 会整体偏移一个安全区边距（表现为标签/跳字错位）。
    --    挂在 root 下则原点 = 屏幕左上角，与 WorldToUI 的换算口径一致。
    return UI.Panel {
        width = "100%", height = "100%",
        pointerEvents = "box-none",
        children = { safe, damageLayer_, overlayLayer_ },
    }
end

-- ============ 每帧刷新 ============
---@param dt number
function HUD.Update(dt)
    if not UI_ then return end
    local d = Data.value

    if goldLabel_ then
        goldLabel_:SetText("💰 " .. d.gold)
    end

    -- 在线时长（只算在线卡）
    if onlineTimeLabel_ then
        local totalOnline = (d.onlineTokenSeconds or 0)
        if d.isStanding then
            onlineTimeLabel_:SetText("⛔ 剩余在线时长 00:00:00")
            onlineTimeLabel_:SetFontColor({ 255, 120, 120, 255 })
        else
            onlineTimeLabel_:SetText("⏱ 剩余在线时长 " .. Shared.FormatTime(totalOnline))
            onlineTimeLabel_:SetFontColor({ 140, 220, 255, 255 })
        end
    end

    -- 普攻按钮状态：自动战斗/罚站时隐藏
    if attackBtn_ then
        local show = not d.autoBattleOn and not d.isStanding and not d.isDead
        attackBtn_:SetVisible(show)
        attackBtn_:SetText(d.normalAttackOn and "取消" or "普攻")
    end
    -- 自动战斗按钮文字随开关切换（⚔️ 开 / ⏹ 关）
    if autoSmBtn_ then
        autoSmBtn_:SetVisible(not d.isDead)
        autoSmBtn_:SetText(d.autoBattleOn and "停止" or "自动")
    end

    -- Toast 的淡出/排队由 UI 库内置 Toast 自己处理（见 HUD.Toast）

    -- 钱庄红点：有利息可领时显示
    if bankDot_ then
        local hasInterest = false
        local deps = Data.value.bankDeposits
        if type(deps) == "table" then
            for _, dep in ipairs(deps) do
                -- 到期即可领本金，或今日有利息
                if dep.expiresAt and os.time() >= dep.expiresAt then
                    hasInterest = true
                    break
                end
            end
        end
        if (Data.value.bankForecastTomorrow or 0) > 0 then
            hasInterest = true
        end
        bankDot_:SetVisible(hasInterest)
    end

    -- 设置开关：小地图 / FPS / 名称血条
    local s = Data.GetSettings()
    if minimapBase_ then
        local show = s.showMinimap ~= false and not d.isDead
        minimapBase_:SetVisible(show)
        -- 隐藏时顺带清掉所有点，避免残留
        if not show then
            for _, dot in pairs(minimapDots_) do dot:SetVisible(false) end
        end
    end
    if onlineLabel_ then onlineLabel_:SetVisible(s.showMinimap ~= false) end
    if statsLabel_ then
        local showRes = s.showResolution == true
        local showFPS = s.showFPS == true
        if showRes or showFPS then
            statsLabel_:SetVisible(true)
            local parts = {}
            if showRes then
                table.insert(parts, string.format("%d×%d", screenW_ or 0, screenH_ or 0))
            end
            if showFPS then
                table.insert(parts, string.format("FPS %d", statsFps_ or 0))
            end
            statsLabel_:SetText(table.concat(parts, " | "))
        else
            statsLabel_:SetVisible(false)
        end
    end

    HUD.UpdateDamageNumbers(dt)
    HUD.UpdateSkillPopups(dt)
    HUD.UpdateMinimap(dt)
    HUD.UpdateUnitTags(dt)
    -- 紧跟在标签结构更新之后：用当前帧的模型位置覆盖 0.2 秒节流带来的滞后
    HUD.SyncOtherPlayerTagPositions()
    HUD.UpdateInfoLabels(dt)
    HUD.UpdateTierLabel()
    HUD.UpdateBossProgress()
    HUD.UpdateNotice(dt)
end

--- 更新段位名称（小地图下方）
function HUD.UpdateTierLabel()
    if not tierLabel_ then return end
    if not playerPosProvider_ then return end
    local px, pz = playerPosProvider_()
    if not px then
        tierLabel_:SetText("")
        return
    end
    -- ⚠️ 段位边界不能在这里硬编码：必须与 Shared.MonsterLevelOf 的分带表保持同一口径，
    --    否则标签显示的区域与实际刷怪等级会错位。
    local lv = Shared.MonsterLevelOf(px, pz)
    local text
    if not lv then
        text = "缓冲区"
    else
        local q = Shared.QualityOfMonsterLevel(lv)
        text = (Shared.QUALITY_NAMES[q] or q) .. "区域 Lv." .. lv
    end
    tierLabel_:SetText(text)
end

--- 更新首领进度（区域标签正下方）：还需击杀 N 只怪。
--- 数据来自 Client.lua 注入的 provider（读本地击杀计数，不额外依赖 Client）。
function HUD.UpdateBossProgress()
    if not bossProgressLabel_ then return end
    if not bossProgressProvider_ then
        bossProgressLabel_:SetText("")
        return
    end
    local remain, threshold = bossProgressProvider_()
    if not remain or not threshold then
        bossProgressLabel_:SetText("")
        return
    end
    -- 阈值恒 >= 1；remain 为 0 表示本次刚达标（下一帧会重置为 threshold）
    bossProgressLabel_:SetText(string.format("首领还需 %d 只", remain))
end

--- 注入首领进度读取器（Client.lua 调用）。
---@param fn fun(): integer|nil, integer|nil 返回 (还需击杀数, 当前阈值)
function HUD.SetBossProgressProvider(fn) bossProgressProvider_ = fn end

-- ============ 小地图（A1）============
--- 世界坐标 → 小地图内的相对坐标。
--- 圆盘 84x84，内边距 4，可用 76x76；以玩家为中心，可视半径 MINIMAP_RANGE。
---@param wx number
---@param wz number
---@param px number
---@param pz number
---@return number|nil x, number|nil y
local function WorldToMinimap(wx, wz, px, pz)
    local range = MINIMAP_RANGE
    local dx, dz = wx - px, wz - pz
    if math.abs(dx) > range or math.abs(dz) > range then return nil, nil end
    local x = (dx + range) / (range * 2) * 76
    local y = (dz + range) / (range * 2) * 76
    return x, y
end

--- 取（或新建）一个小圆点
---@param key string
---@param size number
---@param radius number
---@param color table
---@param borderColor table|nil
---@return Panel
local function AcquireMinimapDot(key, size, radius, color, borderColor)
    local dot = minimapDots_[key]
    if not dot then
        dot = UI_.Panel {
            position = "absolute",
            width = size, height = size,
            borderRadius = radius,
            backgroundColor = color,
            pointerEvents = "none",
        }
        minimapDots_[key] = dot
        if minimapBase_ then minimapBase_:AddChild(dot) end
    end
    dot:SetVisible(true)
    return dot
end

--- 每 0.1 秒重绘一次小地图（不每帧）
---@param dt number
function HUD.UpdateMinimap(dt)
    if not minimapBase_ or not camera_ then return end
    local s = Data.GetSettings()
    if s.showMinimap == false then return end
    -- 视野固定 200（不再读 settings，见 Shared.C.VIEW_DISTANCE_DEFAULT）
    MINIMAP_RANGE = Shared.C.VIEW_DISTANCE_DEFAULT * Shared.C.MINIMAP_RADIUS_RATIO
    if not playerPosProvider_ then return end

    minimapTimer_ = minimapTimer_ + dt
    if minimapTimer_ < MINIMAP_INTERVAL then return end
    minimapTimer_ = 0

    local px, pz = playerPosProvider_()
    if not px then return end

    -- 本轮出现过的 key，用于隐藏过期的点
    local alive = {}

    -- 玩家自身：始终在正中心
    local selfDot = AcquireMinimapDot("self", 6, 3, { 122, 247, 208, 255 })
    selfDot:SetStyle({ left = 76 / 2 + 4 - 3, top = 76 / 2 + 4 - 3 })
    alive["self"] = true

    -- 朝向指针：从中心朝玩家面向方向偏移一小段
    if facingProvider_ then
        local fa = facingProvider_()
        if fa then
            local dx = math.sin(fa) * 7
            local dz = math.cos(fa) * 7
            local arrow = minimapDots_["self_arrow"]
            if not arrow then
                arrow = UI_.Panel {
                    position = "absolute",
                    width = 2, height = 8,
                    backgroundColor = { 255, 255, 255, 220 },
                    pointerEvents = "none",
                }
                minimapDots_["self_arrow"] = arrow
                if minimapBase_ then minimapBase_:AddChild(arrow) end
            end
            arrow:SetVisible(true)
            arrow:SetStyle({
                left = 76 / 2 + 4 - 1 + dx * 0.4,
                top  = 76 / 2 + 4 - 4 + dz * 0.4,
            })
            alive["self_arrow"] = true
        end
    end

    -- 怪物 / 共享 Boss
    if enemiesProvider_ then
        for _, e in ipairs(enemiesProvider_()) do
            local key = "e_" .. tostring(e.id)
            local x, y = WorldToMinimap(e.x, e.z, px, pz)
            if x then
                local size, radius, color, border
                if e.isSharedBoss or e.isBoss then
                    size, radius = 7, 1
                    color = { 255, 85, 102, 255 }
                    border = { 255, 0, 0, 200 }
                else
                    size, radius = 3, 1.5
                    color = { 255, 150, 90, 216 }
                end
                local dot = AcquireMinimapDot(key, size, radius, color, border)
                dot:SetStyle({ left = x + 4 - size / 2, top = y + 4 - size / 2 })
                alive[key] = true
            end
        end
    end

    -- 隐藏本轮没出现的点
    for key, dot in pairs(minimapDots_) do
        if not alive[key] then dot:SetVisible(false) end
    end
end

-- ============ 头顶名字与血条（A2）============

--- 标签各类型的样式参数
--- yOffset(r) = 标签挂在脚底往上多少米（r 是怪物半径，体型越大挂得越高）
local UNIT_TAG_STYLE = {
    player = { nameSize = 14, barW = 60, barH = 8, fill = { 122, 247, 208, 255 },
               nameColor = "#a9e9ff", border = { 122, 247, 208, 90 },
               yOffset = function(_) return 2.35 end },
    otherPlayer = { nameSize = 12, barW = 0, barH = 0, fill = { 0, 0, 0, 0 },
               nameColor = "#aaffcc", border = { 100, 220, 140, 100 },
               yOffset = function(_) return 2.35 end },
    normal = { nameSize = 12, barW = 58, barH = 6, fill = { 255, 106, 106, 255 },
               nameColor = "#ffffff", border = { 122, 247, 208, 90 },
               yOffset = function(r) return (r or 0.5) * 1.2 + 1.4 end },
    boss   = { nameSize = 13, barW = 82, barH = 8, fill = { 255, 204, 68, 255 },
               nameColor = "#ffb15e", border = { 255, 140, 70, 153 },
               yOffset = function(r) return (r or 0.5) * 1.6 + 2.2 end },
}

--- 取（或新建）一个单位的头顶标签组。
--- 一组 = 父 Panel（absolute）内：名字 Label + 血条外框 Panel（内含填充 Panel）。
---@param unitId string
---@param tagType string  "player" | "otherPlayer" | "normal" | "boss"
---@return table
local function EnsureUnitTag(unitId, tagType)
    local tag = unitTags_[unitId]
    if tag then return tag end

    local st = UNIT_TAG_STYLE[tagType] or UNIT_TAG_STYLE.normal
    local nameLabel = UI_.Label {
        text = "",
        fontSize = st.nameSize,
        fontColor = Shared.HexRGB(st.nameColor),
        -- ⚠️ 去掉黑色描边（原 textStroke.width = 2）：
        --    对 12px 的字太粗，白色字芯周围会出现"黑边 + 灰过渡"的多层重影。
        --    改为纯白字，靠 fontColor 本身的亮度对比。
    }
    local fill = UI_.Panel {
        width = st.barW, height = st.barH - 2,
        backgroundColor = st.fill,
        borderRadius = 3,
    }
    local bar = UI_.Panel {
        width = st.barW, height = st.barH,
        backgroundColor = { 0, 0, 0, 190 },
        borderWidth = 1,
        borderColor = st.border,
        borderRadius = 4,
        children = { fill },
    }
    local root = UI_.Panel {
        position = "absolute",
        flexDirection = "column",
        alignItems = "center",
        gap = 6,
        pointerEvents = "none",
        children = { nameLabel, bar },
    }
    if damageLayer_ then damageLayer_:AddChild(root) end

    tag = {
        root = root, name = nameLabel, bar = bar, fill = fill,
        barW = st.barW, barH = st.barH,
    }
    unitTags_[unitId] = tag
    return tag
end

--- 移除某个其他玩家的头顶标签。
---
--- 玩家下线 / 重连换节点时调用：标签 key 是 "op_" .. pid，
--- 不清的话会留下一个不动的名字飘在场上（对应残留模型）。
--- 每 0.2 秒的 UpdateUnitTags 只会把没出现的标签 SetVisible(false)，
--- 对象本身仍在 unitTags_ 里占着，必须显式销毁。
---@param pid string
function HUD.RemoveOtherPlayerTag(pid)
    local key = "op_" .. tostring(pid)
    local tag = unitTags_[key]
    if not tag then return end
    if tag.root and tag.root.Destroy then tag.root:Destroy() end
    unitTags_[key] = nil
end

--- 移除某个怪物的头顶标签。
---
--- 怪物销毁（`onEnemyRemoved_`）时调用：标签 key 是 "e_" .. id。
--- 不清理的话，`unitTags_` 里的旧标签会残留 —— 它停在最后一次位置，
--- 与新怪物的标签同屏出现（视觉上"重复渲染"）。
---@param id string
function HUD.RemoveEnemyTag(id)
    local key = "e_" .. tostring(id)
    local tag = unitTags_[key]
    if not tag then return end
    if tag.root and tag.root.Destroy then tag.root:Destroy() end
    unitTags_[key] = nil
end

--- 每 0.2 秒更新一次头顶标签（坐标换算 + 可见性 + 血量）
---@param dt number
function HUD.UpdateUnitTags(dt)
    if not damageLayer_ or not camera_ then return end
    local s = Data.GetSettings()
    local showName = s.showName ~= false
    local showBar  = s.showHealthBar ~= false
    if not showName and not showBar then
        for _, t in pairs(unitTags_) do t.root:SetVisible(false) end
        return
    end

    unitTagTimer_ = unitTagTimer_ + dt
    if unitTagTimer_ < UNIT_TAG_INTERVAL then return end
    unitTagTimer_ = 0

    if not playerPosProvider_ then return end
    local px, pz = playerPosProvider_()
    if not px then return end

    local now = GetTime():GetElapsedTime()
    local alive = {}

    -- 玩家自己：常驻显示（血量条在头顶，替代原先左上角固定血条）
    local selfTag = EnsureUnitTag("self", "player")
    local sx, sy = WorldToUIEx(px,
        TerrainH(px, pz) + UNIT_TAG_STYLE.player.yOffset(0), pz)
    local sw, sh = UIScreenSize()
    if sx and sy and sx > -100 and sx < sw + 100 and sy > -100 and sy < sh + 100 then
        selfTag.root:SetStyle({ left = sx - selfTag.barW / 2, top = sy })
        local d = Data.value
        selfTag.name:SetText("自己")
        local hpPct = 0
        if (d.maxHp or 0) > 0 then
            hpPct = math.max(0, math.min(1, (d.hp or 0) / d.maxHp))
        end
        selfTag.fill:SetStyle({ width = math.max(1, selfTag.barW * hpPct), height = selfTag.barH - 2 })
        selfTag.name:SetVisible(showName)
        selfTag.bar:SetVisible(showBar)
        selfTag.root:SetVisible(not d.isDead)
        alive["self"] = true
    else
        selfTag.root:SetVisible(false)
    end

    -- 收集候选怪物：按距离排序，同屏最多 20 个
    local cands = {}
    if enemiesProvider_ then
        for _, e in ipairs(enemiesProvider_()) do
            local d = Shared.Dist2D(px, pz, e.x, e.z)
            local tagDist = s.nameTagDistance or Shared.C.NAME_TAG_DISTANCE_DEFAULT
            -- 受击显示规则：5 秒内被命中过才显示（玩家自己除外）
            local recentlyHit = e.lastHitTime and (now - e.lastHitTime) <= 5.0
            if d <= tagDist and recentlyHit then
                table.insert(cands, { e = e, d = d })
            end
        end
    end
    table.sort(cands, function(a, b) return a.d < b.d end)

    for i = 1, math.min(#cands, 20) do
        local e = cands[i].e
        local tagType = (e.isSharedBoss or e.isBoss) and "boss" or "normal"
        local key = "e_" .. tostring(e.id)
        local tag = EnsureUnitTag(key, tagType)

        local st = UNIT_TAG_STYLE[tagType] or UNIT_TAG_STYLE.normal
        local ux, uy = WorldToUIEx(e.x,
            TerrainH(e.x, e.z) + st.yOffset(e.radius), e.z)
        if ux and ux > -100 and ux < sw + 100 and uy and uy > -100 and uy < sh + 100 then
            tag.root:SetStyle({ left = ux - tag.barW / 2, top = uy })
            local lv = e.level or 1
            if tagType == "boss" then
                tag.name:SetText("BOSS Lv." .. lv)
            else
                tag.name:SetText("怪物 Lv." .. lv)
            end
            -- 血条填充宽度（不用弹性布局，直接算宽度）
            local pct = 0
            if (e.maxHp or 0) > 0 then
                pct = math.max(0, math.min(1, (e.hp or 0) / e.maxHp))
            end
            tag.fill:SetStyle({ width = math.max(1, tag.barW * pct), height = tag.barH - 2 })
            tag.name:SetVisible(showName)
            tag.bar:SetVisible(showBar)
            tag.root:SetVisible(true)
            alive[key] = true
        else
            tag.root:SetVisible(false)
        end
    end

    -- 其他玩家头顶标签
    --
    -- 🔴 顺序很重要：必须在「隐藏本轮没出现的」**之前**执行。
    --    本函数由 unitTagTimer_（0.2 秒）节流，而其他玩家扫描原先自带
    --    另一个 0.5 秒节流。若把清理放在前面，
    --    就会出现：0.2/0.4 秒这两轮清理时其他玩家还没被标记 alive →
    --    标签被隐藏；只有 0.6 秒那轮能存活 —— 表现为名字「偶尔闪一下就没了」。
    --    现在改为跟随主节奏（每 0.2 秒一次），与其他标签共用同一张 alive 表。
    if sceneProvider_ and myIdProvider_ then
        local sc = sceneProvider_()
        local myId = myIdProvider_()
        if sc then
            local n = sc:GetNumChildren()
            for i = 1, n do
                local child = sc:GetChild(i - 1)
                if child and child.name and child.name:sub(1, 7) == "Player_" then
                    local pid = child.name:sub(8)
                    if pid ~= myId then
                        local pos = child.position
                        local key = "op_" .. pid
                        local tag = EnsureUnitTag(key, "otherPlayer")
                        local ux, uy = WorldToUIEx(pos.x,
                            TerrainH(pos.x, pos.z) + UNIT_TAG_STYLE.otherPlayer.yOffset(0), pos.z)
                        -- 对方超出广播范围时模型已被隐藏（见 Client_Network.HIDE_RADIUS），
                        -- 名字要跟着一起隐藏，否则会出现「名字飘在空地上」
                        if ux and ux > -100 and ux < sw + 100 and child:IsEnabled() then
                            tag.root:SetStyle({ left = ux - 30, top = uy })
                            -- 优先显示 TapTap 昵称；还没收到映射时回退成 pid
                            local shown = nameProvider_ and nameProvider_(pid)
                            tag.name:SetText(shown or pid)
                            tag.name:SetVisible(showName)
                            tag.bar:SetVisible(false)
                            -- 其他玩家只有名字、没有血条：关掉「名称」时整块都该隐藏，
                            -- 否则会留下一个不可见的空标签占位
                            tag.root:SetVisible(showName)
                            alive[key] = true
                        else
                            tag.root:SetVisible(false)
                        end
                    end
                end
            end
        end
    end

    -- 隐藏本轮没出现的（必须放在所有 alive[key] = true 之后）
    --
    -- ⚠️ 怪物标签（"e_" 前缀）直接销毁：避免 unitTags_ 无限积累已销毁怪物的标签，
    --    也顺带解决"怪物死亡后标签滞后 0.2 秒消失"的问题。
    -- 其他玩家标签（"op_" 前缀）只隐藏不销毁：对方可能只是暂时走出广播范围，
    --    回来时应复用同一对象（"op_" 的销毁走 RemoveOtherPlayerTag，见 PlayerLeave）。
    for key, t in pairs(unitTags_) do
        if not alive[key] then
            if key:sub(1, 2) == "e_" then
                if t.root and t.root.Destroy then t.root:Destroy() end
                unitTags_[key] = nil
            else
                t.root:SetVisible(false)
            end
        end
    end
end

--- 每帧同步其他玩家标签的坐标。
---
--- ⚠️ 为什么单独拆出来：
---    UpdateUnitTags 由 UNIT_TAG_INTERVAL（0.2 秒）节流，而其他玩家的模型位置
---    是每帧插值更新的。若标签坐标只在 0.2 秒那一轮取，按 5 m/s 移动算
---    最多滞后 1 米 —— 表现为「名字在后面追着人跑」。
---    这里只重算 left/top，不做 EnsureUnitTag / 可见性判断（那些仍归 0.2 秒那轮管），
---    所以开销很小：同屏最多 4 名玩家，每帧 4 次 WorldToUIEx。
function HUD.SyncOtherPlayerTagPositions()
    if not sceneProvider_ or not myIdProvider_ then return end
    local sc = sceneProvider_()
    if not sc then return end
    local myId = myIdProvider_()

    for i = 1, sc:GetNumChildren() do
        local child = sc:GetChild(i - 1)
        if child and child.name and child.name:sub(1, 7) == "Player_" then
            local pid = child.name:sub(8)
            if pid ~= myId then
                local tag = unitTags_["op_" .. pid]
                -- 只动「已存在且可见」的标签：结构由 UpdateUnitTags 维护
                -- child:IsEnabled() 为 false = 对方超出范围、模型已隐藏，标签不动
                if tag and tag.root and tag.root.visible ~= false and child:IsEnabled() then
                    local pos = child.position
                    local ux, uy = WorldToUIEx(pos.x,
                        TerrainH(pos.x, pos.z) + UNIT_TAG_STYLE.otherPlayer.yOffset(0), pos.z)
                    if ux then
                        tag.root:SetStyle({ left = ux - 30, top = uy })
                    end
                end
            end
        end
    end
end

-- ============ 在线人数 / 坐标（A15）============
--- 由 Client 更新在线人数（服务端 ONLINE_COUNT 广播 → Client → 此处）
---@param n integer
function HUD.SetOnlineCount(n) onlineCount_ = n or 1 end

--- 每 0.15 秒刷新一次文本
---@param dt number
function HUD.UpdateInfoLabels(dt)
    infoTimer_ = infoTimer_ + dt
    if infoTimer_ < 0.15 then return end
    infoTimer_ = 0

    if onlineLabel_ then
        onlineLabel_:SetText("在线: " .. onlineCount_)
    end
    if coordLabel_ and playerPosProvider_ then
        local px, pz = playerPosProvider_()
        if px then
            coordLabel_:SetText(string.format("X %.0f   Z %.0f", px, pz))
        end
    end
end

-- ============ 分辨率 / FPS（A11）============
--- 由 Client 注入当前物理分辨率
---@param w integer
---@param h integer
function HUD.SetScreenSize(w, h) screenW_, screenH_ = w, h end

--- 每 0.25 秒刷新一次 FPS 采样。
--- ⚠️ 这里**不要**再 SetText：文本由 HUD.Update 按
---    settings.showResolution / showFPS 组合（本函数在 HUD.Update 之后被调用，
---    无条件 SetText 会把组合结果覆盖成「分辨率+帧率」全显示）。
---@param dt number
function HUD.UpdateStats(dt)
    statsFrames_ = statsFrames_ + 1
    statsTimer_ = statsTimer_ + dt
    if statsTimer_ < 0.25 then return end
    statsFps_ = math.floor(statsFrames_ / statsTimer_ + 0.5)
    statsFrames_ = 0
    statsTimer_ = 0
end

-- 画质切换遮罩已删除（引擎无画质切换 API，属 H5 移植遗留）。

-- ============ Toast（自绘纯文字通知）============
--- 系统提示：屏幕中上方一行纯文字，无背景无边框。
---
--- ⚠️ 为什么不用 UI 库内置的 Toast：
---    内置组件的背景 alpha 硬编码 250（不透明）+ 阴影 + 左侧色条，无法关闭，
---    视觉上是个「黑框」；且 maxToasts 是「挤掉最旧的」而非排队，语义不符。
---    这里自绘，只画文字。
---
--- ⚠️ 为什么必须注册成 global component：
---    UI 库的绘制顺序是 widget 树 → overlayQueue → globalComponents。
---    Modal 的内容走 overlayQueue，所以挂在 widget 树里的自绘内容
---    （如 damageLayer_）会被弹窗盖住。只有 globalComponent 能盖在弹窗之上。
local NOTICE_DURATION = 1.0   -- 每条提示的显示时长（秒）
---@type table[] 待显示的提示队列（FIFO）
local noticeQueue_ = {}
---@type table|nil 当前正在显示的提示
local noticeCurrent_ = nil
---@type number 当前提示的剩余显示时间
local noticeTimer_ = 0
---@type number 当前提示的淡出进度（0~1，用于末段渐隐）
local noticeAlpha_ = 1.0
---@type table|nil 自绘通知组件实例（只注册一次）
local noticeComp_ = nil
---@type boolean 首帧诊断是否已输出（确认无误后可删）
local noticeRenderLogged_ = false

--- 提示文字颜色：默认白色，可传 "#rrggbb" 覆盖
---@param colorHex string|nil
---@return integer r, integer g, integer b
local function NoticeColor(colorHex)
    if colorHex then
        local c = Shared.HexRGB(colorHex)
        if c then
            return math.floor(c[1]), math.floor(c[2]), math.floor(c[3])
        end
    end
    return 255, 255, 255
end

--- 队列空时从队列取一条开始显示
local function NoticePump()
    if noticeCurrent_ or #noticeQueue_ == 0 then return end
    noticeCurrent_ = table.remove(noticeQueue_, 1)
    noticeTimer_ = NOTICE_DURATION
    noticeAlpha_ = 1.0
end

--- 每帧推进：由 HUD.Update 调用（globalComponent 的 Render 只负责画）
---@param dt number
function HUD.UpdateNotice(dt)
    NoticePump()
    if not noticeCurrent_ then return end

    noticeTimer_ = noticeTimer_ - (dt or 0)
    if noticeTimer_ <= 0 then
        noticeCurrent_ = nil
        noticeAlpha_ = 1.0
        NoticePump()   -- 立刻接上下一条，避免队列有积压时出现空档
        return
    end
    -- 末段 0.25 秒渐隐，避免文字突然消失
    local FADE = 0.25
    noticeAlpha_ = (noticeTimer_ < FADE) and (noticeTimer_ / FADE) or 1.0
end

--- 绘制当前提示（注册为 globalComponent，Render 被 UI 库每帧调用）
--- ⚠️ 必须是冒号方法（第一个参数是 self）：
---    UI 库的调用是 `component:Render(nvg)`，即 Render(component, nvg)。
---    写成单参数的 local function 会让 nvg 收到组件自身、真正的 context 丢失，
---    表现为「不报错但什么都不显示」。
---@param self table 组件自身（由 UI 库冒号调用传入）
---@param nvg NVGContextWrapper
local function RenderNotice(self, nvg)
    if not noticeCurrent_ then return end
    local a = math.max(0, math.min(1, noticeAlpha_))
    if a <= 0 then return end

    -- ⚠️ globalComponent 的 Render 在 nvgBeginFrame(logicalW, logicalH, scale) 之后，
    --    坐标空间是「逻辑像素」，与 UI.GetWidth/GetHeight 同一口径。
    local w = UI_.GetWidth and UI_.GetWidth() or 800
    local h = UI_.GetHeight and UI_.GetHeight() or 600

    -- 顶部居中（水平居中于屏幕，垂直固定在顶部往下 40px）。
    -- ⚠️ 用固定像素而非 h * 比例：比例在不同宽高比下会飘，
    --    顶部提示应当始终贴着顶边。
    -- 左上 topBar 是 left=12 起始的窄条（金币 + 两行时长，约 130px 宽），
    -- 居中文字不会与之重叠；右上小地图从 right=12 开始，也不受影响。
    local cx = w * 0.5
    local cy = 40
    local fontSize = 24      -- 从 26 降到 24，给背景框留呼吸空间

    -- 一次性诊断：确认 Render 真的被调用、且 nvg 句柄与坐标正常。
    -- 只在首帧输出，避免刷屏；确认无误后可删。
    if not noticeRenderLogged_ then
        noticeRenderLogged_ = true
        print(string.format("[Notice] 首帧渲染 msg=%s nvg=%s 屏幕=%.0fx%.0f 绘制点=%.0f,%.0f",
            tostring(noticeCurrent_.msg), tostring(nvg), w, h, cx, cy))
    end

    -- 保存/恢复 nvg 状态：本函数改了字体、字号、对齐、填充色，
    -- 不还原会污染后续绘制（如 inspector 树）。
    nvgSave(nvg)

    nvgFontFace(nvg, "sans")
    nvgFontSize(nvg, fontSize)
    nvgTextAlign(nvg, NVG_ALIGN_CENTER + NVG_ALIGN_MIDDLE)

    -- ① 测文字宽度。降级：字符数 × fontSize × 0.55（中文约 1.0×fontSize 宽）
    local textW = fontSize * #noticeCurrent_.msg * 0.55
    pcall(function()
        local minx, _, maxx = nvgTextBounds(nvg, cx, cy, noticeCurrent_.msg, nil)
        if type(maxx) == "number" and type(minx) == "number" then
            textW = maxx - minx
        end
    end)

    -- ② 背景框参数
    local padH, padV = 28, 12
    local bgW = textW + padH * 2
    local bgH = fontSize + padV * 2
    local bgX = cx - bgW * 0.5
    local bgY = cy - bgH * 0.5
    local corner = 14

    -- ③ 圆角矩形 + 金棕描边。三级降级：
    --    a) nvgRoundedRect + nvgStroke 全可用 → 圆角 + 描边
    --    b) 圆角不可用 → 直角矩形
    --    c) 矩形也不可用 → 纯文字（保留黑描边，可读性保底）
    --    ⚠️ 本项目此前从未用过 nvgRoundedRect / nvgStroke / nvgRect
    --       （只在 .emmylua 里有声明），所以必须容错。
    local bgDrawn = pcall(function()
        nvgBeginPath(nvg)
        nvgRoundedRect(nvg, bgX, bgY, bgW, bgH, corner)
        nvgFillColor(nvg, nvgRGBA(46, 40, 34, math.floor(220 * a)))
        nvgFill(nvg)

        nvgStrokeColor(nvg, nvgRGBA(200, 169, 107, math.floor(180 * a)))
        nvgStrokeWidth(nvg, 1.0)
        nvgStroke(nvg)
    end)
    if not bgDrawn then
        pcall(function()
            nvgBeginPath(nvg)
            nvgRect(nvg, bgX, bgY, bgW, bgH)
            nvgFillColor(nvg, nvgRGBA(46, 40, 34, math.floor(220 * a)))
            nvgFill(nvg)
        end)
    end

    local r, g, b = NoticeColor(noticeCurrent_.color)

    -- ④ 描边：四个方向各偏移 1.0px 画深色。
    --    从 1.5 缩到 1.0 —— 有背景框时 1.5 太粗；背景画失败时仍保底可读。
    --    不用 nvgStrokeText：描边会跟着字形轮廓走，中文小字号下容易糊成一团。
    local OUTLINE = 1.0
    local oa = math.floor(180 * a)
    nvgFillColor(nvg, nvgRGBA(0, 0, 0, oa))
    for _, off in ipairs({ { -OUTLINE, 0 }, { OUTLINE, 0 }, { 0, -OUTLINE }, { 0, OUTLINE } }) do
        nvgText(nvg, cx + off[1], cy + off[2], noticeCurrent_.msg, nil)
    end

    -- 主体文字
    nvgFillColor(nvg, nvgRGBA(r, g, b, math.floor(255 * a)))
    nvgText(nvg, cx, cy, noticeCurrent_.msg, nil)

    nvgRestore(nvg)
end

--- 系统提示入口（保持原 HUD.Toast 签名，调用方无需改动）
---@param msg string
---@param colorHex string|nil 形如 "#ff7878"
function HUD.Toast(msg, colorHex)
    if not UI_ then return end
    if not msg or msg == "" then return end

    -- 只注册一次
    if not noticeComp_ then
        noticeComp_ = { Render = RenderNotice }
        if UI_.RegisterGlobalComponent then
            UI_.RegisterGlobalComponent("TextNotice", noticeComp_)
        end
    end

    table.insert(noticeQueue_, { msg = msg, color = colorHex })
end

-- ============ 伤害飘字（对象池）============
local DMG_POOL_MAX = 40
---@type table[]
local dmgPool_ = {}
---@type table[]
local dmgActive_ = {}

---@return Label|nil
local function AcquireDamageLabel()
    if #dmgPool_ > 0 then
        return table.remove(dmgPool_) --[[@as Label]]
    end
    if not damageLayer_ then return nil end
    return UI_.Label {
        text = "",
        fontSize = 14,
        fontColor = { 255, 120, 120, 255 },
        textStroke = { width = 2, color = "#000000" },
        position = "absolute",
    }
end

--- 世界坐标 → UI 坐标空间（所有飘字/头顶标签都走这里）
---
--- ⚠️ 本引擎的 `Camera:WorldToScreenPoint` 返回的是**归一化坐标 [0,1]**，
---    不是 Urho3D 的物理像素！（实测：屏幕中心的世界原点 → (0.5, 0.5)）
---    所以必须先乘物理分辨率还原成像素，再做「减居中偏移、除以等比缩放」。
---    早期实现直接当像素用，导致所有屏幕定位算出来都是负数而被判为屏外。
---@param x number
---@param y number
---@param z number
---@return number|nil, number|nil
local function WorldToDesign(x, y, z)
    if not camera_ then return nil, nil end
    local pos = camera_:WorldToScreenPoint(Vector3(x, y, z))
    local physW, physH = graphics:GetWidth(), graphics:GetHeight()
    return (pos.x * physW - uiOffsetX_) / uiScale_,
           (pos.y * physH - uiOffsetY_) / uiScale_
end

--- 世界坐标 → UI 基准像素坐标（贴地形高度 + 1.6，用于伤害数字/技能飘字）
--- 注意：`WorldToUI` 定义在 TerrainH 之后，但 TerrainH 是 local function，
---       其作用域从声明处开始 —— 本函数在下方调用点执行时 TerrainH 已可见。
---@param x number
---@param z number
---@return number|nil, number|nil
local function WorldToUI(x, z)
    return WorldToDesign(x, TerrainH(x, z) + 1.6, z)
end

--- 世界坐标 + 高度 → UI 坐标空间（用于头顶标签）
---@param x number
---@param y number
---@param z number
---@return number|nil, number|nil
function WorldToUIEx(x, y, z)
    return WorldToDesign(x, y, z)
end

---@param x number
---@param z number
---@param text string|number
---@param kind string "" | "crit" | "heal" | "player" | "miss"
function HUD.ShowDamageNumber(x, z, text, kind)
    if not damageLayer_ then return end
    if Data.GetSettings().dmgNumbers == false then return end
    local ux, uy = WorldToUI(x, z)
    if not ux then return end
    -- 屏幕边缘裁剪：超出 UI 坐标空间直接丢弃，避免飘字在屏外堆积
    local sw, sh = UIScreenSize()
    if ux < -100 or ux > sw + 100 or uy < -100 or uy > sh + 100 then return end

    local el = AcquireDamageLabel()
    if not el then return end

    local color = { 255, 120, 120, 255 }
    local size = 14
    if kind == "crit" then
        color = { 255, 230, 80, 255 }; size = 20
    elseif kind == "heal" then
        color = { 130, 255, 140, 255 }
    elseif kind == "player" then
        color = { 255, 130, 130, 255 }
    elseif kind == "miss" then
        color = { 180, 230, 255, 255 }
    end

    el:SetText(tostring(text))
    el:SetFontSize(size)
    el:SetFontColor(color)
    el:SetStyle({
        position = "absolute",
        left = ux + math.random(-14, 14) - 20,
        top = uy - 20,
        opacity = 1,
    })
    el:SetVisible(true)

    -- ⚠️ 必须无条件挂载：池中元素在过期时已被 RemoveChild，
    --    复用时不重新 AddChild 就永远不会显示（原实现只在「无活跃飘字」时挂载）。
    damageLayer_:AddChild(el)
    el:SetVisible(true)
    table.insert(dmgActive_, { el = el, life = 0.95, maxLife = 0.95 })
end

---@param dt number
function HUD.UpdateDamageNumbers(dt)
    for i = #dmgActive_, 1, -1 do
        local d = dmgActive_[i]
        d.life = d.life - dt
        if d.life <= 0 then
            d.el:SetVisible(false)
            if damageLayer_ then damageLayer_:RemoveChild(d.el) end
            if #dmgPool_ < DMG_POOL_MAX then
                table.insert(dmgPool_, d.el)
            else
                d.el:Destroy()
            end
            table.remove(dmgActive_, i)
        else
            local t = d.life / d.maxLife
            d.el:SetStyle({ opacity = math.min(1, t * 1.6), translateY = (1 - t) * -26 })
        end
    end
end

-- ============ 技能触发弹跳文字（A7）============
-- 与伤害数字同样的对象池思路，但独立一套：
--   字号更大、颜色随技能、带初速度 + 逐帧衰减、存活更久（1.5 秒）。
local SKILL_POOL_MAX = 30
---@type table[]
local skillPool_ = {}
---@type table[]
local skillActive_ = {}

---@return Label|nil
local function AcquireSkillLabel()
    if #skillPool_ > 0 then
        return table.remove(skillPool_) --[[@as Label]]
    end
    if not damageLayer_ then return nil end
    return UI_.Label {
        text = "",
        fontSize = 16,
        fontColor = { 255, 255, 255, 255 },
        textStroke = { width = 2, color = "#000000" },
        position = "absolute",
    }
end

--- 在 (x, z) 处弹出一段技能文字
---@param x number
---@param z number
---@param text string
---@param color string  形如 "#7affa0"
function HUD.ShowSkillPopup(x, z, text, color)
    if not damageLayer_ then return end
    local s = Data.GetSettings()
    if s.dmgNumbers == false then return end

    local ux, uy = WorldToUI(x, z)
    if not ux then return end
    local sw, sh = UIScreenSize()
    if ux < -100 or ux > sw + 100 or uy < -100 or uy > sh + 100 then return end

    local el = AcquireSkillLabel()
    if not el then return end

    -- ⚠️ 错位排布：一次攻击可能同时触发多个技能（onHit + onKill + onHurt …），
    --    它们坐标、初速度完全相同，不错位就会严丝合缝叠成一坨、谁都看不清。
    --    统计「当前仍在同一点附近飘着的」数量作为槽位，逐个向下错开一行。
    local slot = 0
    for _, d in ipairs(skillActive_) do
        if math.abs(d.ux - ux) < 60 and math.abs(d.uy - uy) < 60 then
            slot = slot + 1
        end
    end
    local SLOT_H = 20
    local offY = slot * SLOT_H

    el:SetText(text)
    el:SetFontSize(16)
    el:SetFontColor(Shared.HexRGB(color or "#ffffff"))
    el:SetStyle({
        position = "absolute",
        left = ux - 30,
        top = uy - 24 + offY,
        opacity = 1,
    })
    el:SetVisible(true)
    damageLayer_:AddChild(el)
    el:SetVisible(true)

    -- 向上初速度 1.8 米/秒（屏幕像素近似），逐帧乘 0.94 衰减
    table.insert(skillActive_, {
        el = el, life = 1.5, maxLife = 1.5,
        offsetY = 0, vy = 26,
        -- 记录基准坐标：新飘字靠它判断「是否与已有飘字挤在同一位置」
        ux = ux, uy = uy,
    })
end

---@param dt number
function HUD.UpdateSkillPopups(dt)
    for i = #skillActive_, 1, -1 do
        local d = skillActive_[i]
        d.life = d.life - dt
        if d.life <= 0 then
            d.el:SetVisible(false)
            if damageLayer_ then damageLayer_:RemoveChild(d.el) end
            if #skillPool_ < SKILL_POOL_MAX then
                table.insert(skillPool_, d.el)
            else
                d.el:Destroy()
            end
            table.remove(skillActive_, i)
        else
            d.vy = d.vy * 0.94          -- 减速
            d.offsetY = d.offsetY - d.vy * dt
            local t = d.life / d.maxLife
            d.el:SetStyle({ opacity = math.min(1, t * 1.4), translateY = d.offsetY })
        end
    end
end

return HUD
