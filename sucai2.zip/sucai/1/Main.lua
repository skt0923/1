-- ============================================================
-- Main.lua：入口
-- 服务器模式 → Server.lua，客户端模式 → Client.lua
-- ============================================================
local Module = nil

function Start()
    if IsServerMode() then
        Module = require("Server")
    elseif IsClientMode() then
        Module = require("Client")
    else
        print("[Main] ⚠️ 既非服务器模式也非客户端模式，未启动任何逻辑")
        return
    end

    if Module and Module.Start then
        Module.Start()
    end
end

function Stop()
    if Module and Module.Stop then
        Module.Stop()
    end
end
