-- ============================================================
-- Server_Cloud.lua：云存档（Server.lua 的兄弟文件）
--
-- 职责：快照序列化 / 异步读取 / 落盘 / 清档，独占全部 serverCloud: 调用。
--
-- 与 Server.lua 共享状态：Server.lua 在 Start() 里通过 Cloud.Init 注入 players 表。
-- 跨文件调用走 Cloud.*：
--   Cloud.Init / Cloud.RunOneShotWipe / Cloud.PushCloud /
--   Cloud.LoadSaveAsync / Cloud.SaveToCloud / Cloud.SAVE_KEY
--   （Server.lua 侧另建 local 别名，沿用拆分前的短名）
--
-- 依赖：Shared。**不 require Server.lua**（避免循环）。
-- ============================================================
local Shared = require("Shared")

local Cloud = {}

--- 由 Server.lua 注入的共享 players 表（Start 里调用一次 Cloud.Init 填充）。
--- ⚠️ 必须声明在 Cloud.Init **之前**：Lua 的 local 作用域从声明处开始，
---    否则 Init 里的赋值会静默落到全局 players 上，本模块读到的仍是空表。
---@type table<string, ServerPlayer>
local players = {}

--- 由 Server.lua 注入：按 pid 查连接（落盘失败时通知客户端用）。
---@type fun(pid: string): Connection|nil
local getConnection_ = nil

--- 由 Server.lua 注入共享状态（Start 里调用一次）
---@param c table { players: table<string, ServerPlayer>, getConnection: fun(pid: string): Connection|nil }
function Cloud.Init(c)
    if c.players then players = c.players end
    if c.getConnection then getConnection_ = c.getConnection end
end

--- 标记玩家数据可信（读档成功 / 收到客户端实质上报时调用）。
---
--- 🔴 集中管理 __hasValidClientData 与 __saveFailedNotified 的状态转移。
---    之前这两个标志散落在 SaveToCloud / LoadSaveAsync 回调 / OnInvSync 三处，
---    加新的重置点容易漏 —— 「重试失败后不重新弹门」就是这么漏出来的。
---@param p ServerPlayer
function Cloud.MarkClientDataValid(p)
    p.__hasValidClientData = true
    -- 数据可信后，失败通知标志清零：若后续再次落到不可信状态，允许重新弹门
    p.__saveFailedNotified = nil
end


-- ============ 云存档 ============
-- ⚠️ 两个必须遵守的约束：
--
-- 1) 服务端文件 I/O 被引擎完全屏蔽（见 recipes/file-storage.md「服务端模式」），
--    所以服务端存档只能走 serverCloud，不能用 File/FileSystem。
--    拍卖行行情同理，放在内存 + 云变量里。
--
-- 2) serverCloud 是「异步回调式」，且第一个参数必须是数字 userId：
--      serverCloud:Set(uid, key, value, events)
--      serverCloud:Get(uid, key, { ok = function(scores, iscores) end })
--    原实现写成了 serverCloud:Get("player_xxx_core") 同步取返回值，完全用错了 —— 存档从未生效。

--- 从 pid 还原数字 userId（pid 形如 "u12345"）
---@param pid string
---@return integer|nil
local function UserIdOf(pid)
    local n = tostring(pid):match("^u(%d+)$")
    if not n then return nil end
    local id = tonumber(n)
    if not id then return nil end
    return math.floor(id)
end

--- 把玩家状态序列化成一份快照 JSON
---@param p ServerPlayer
---@return string
local function SnapshotJson(p)
    -- 防御性补全：SaveToCloud 已门控数据可信度，这里只兜底结构完整性
    if not Shared.IsPetDataValid(p.pets) then p.pets = Shared.NewPetData() end
    if not (type(p.petGacha) == "table" and type(p.petGacha.counters) == "table") then
        p.petGacha = Shared.NewPetGachaData()
    end
    if not Shared.IsBDTreeValid(p.bdTree) then p.bdTree = Shared.NewBDTree() end
    return cjson.encode({
        saveVersion        = Shared.SAVE_VERSION,
        gold               = p.gold,
        level              = p.level,
        bagPageCount       = p.bagPageCount,
        autoDecompose      = p.autoDecompose,
        autoDecomposeUnid  = p.autoDecomposeUnid,
        autoRepair         = p.autoRepair or false,
        nextMailId         = p.nextMailId or 1,
        -- settings 已客户端化，不写云（老档里的该字段下次写出时自然消失）
        onlineTokenMinutes = p.onlineTokenMinutes or 0,
        adCountToday       = p.adCountToday,
        adLastTime         = p.adLastTime,
        lastResetDate      = p.lastResetDate,
        lastDailyGiftDate  = p.lastDailyGiftDate or "",
        starterGiftReceived = p.starterGiftReceived or false,
        dailyGiftDate      = p.dailyGiftDate or "",
        equipment          = p.equipment,
        mails              = p.mails or {},
        inventory          = p.inventory,
        bankDeposits       = p.bankDeposits or {},
        bankTodayEarnings  = p.bankTodayEarnings or 0,
        bankLastSettledDate = p.bankLastSettledDate or "",
        levelStone         = p.levelStone,
        levelStoneGiftReceived = p.levelStoneGiftReceived or false,
        -- 宠物系统（结构已在函数开头归一化，这里直接写）
        pets               = p.pets,
        petGacha           = p.petGacha,
        -- 天赋树（结构已在函数开头归一化，这里直接写）
        bdTree             = p.bdTree,
        x                  = (p.save and p.save.x) or 0,
        z                  = (p.save and p.save.z) or 0,
    })
end

-- ============================================================
-- 云存档键
--
-- 🔴 改这里的键名 = 对全体玩家清档。**不要为了「发新版本」改它。**
--    新增字段 / 改字段含义 → 改 Shared.SAVE_VERSION。
--    键名只用于「确实想清档」这一种情况。
--
-- ⚠️ 为什么用「改键名」而不是「逐个删除」：
--    serverCloud 是按 (uid, key) 存取的，**没有枚举 API** ——
--    服务端只知道本次会话连上来的 uid，无法遍历云端所有玩家，
--    所以「遍历所有玩家并删除」在接口层面做不到。
--    改键名后所有玩家读到的都是空档（等效清档），
--    而旧数据原样留在旧键下 —— 想回滚，把版本号改回去即可。
--
-- 清档历史：
--   v1 = "player_save"          已废弃（2026-09-30 清档切到 v3，数据仍留在该键下）
--   v2 = "player_save_v2"       从未使用过
--   v3 = "player_save_v3"       已废弃（2026-10-02 清档切到 v4，数据仍留在该键下）
--   v4 = "player_save_v4"       ← 当前使用
--
-- 🔴 当前是**刻意清档**状态：只读 V4，不回溯 v1 / v2 / v3，
--    所以全体玩家从空档重新开始。这是有意为之，不是 bug。
--
--    想回滚（把老玩家的数据找回来）：把 SAVE_KEY 改回 "player_save_v3"
--    即可 —— 旧数据原封不动躺在那个键下，从未被删除。
-- ============================================================
local SAVE_KEY = "player_save_v4"
Cloud.SAVE_KEY = SAVE_KEY

-- ============================================================
-- 【一次性】指定 uid 清档
--
-- 用法：把要清档的 uid 填进下面的列表 → 构建发布 → 服务端启动时执行一次删除。
-- ⚠️ 用完必须把列表清空（或删掉整段）再构建一次，否则每次重启都会再删一遍。
-- ============================================================
local ONE_SHOT_WIPE_UIDS = {}

--- ⚠️ 全局函数（不是 local）：Start() 定义在文件更靠前的位置，
---    局部变量在那里不可见；全局函数在「调用时」解析，从 Start 里能调到。
function Cloud.RunOneShotWipe()
    if #ONE_SHOT_WIPE_UIDS == 0 then return end
    for _, uid in ipairs(ONE_SHOT_WIPE_UIDS) do
        serverCloud:Delete(uid, SAVE_KEY, {
            ok = function()
                print(string.format("[Server] 🗑 已删除玩家存档 uid=%d（key=%s）", uid, SAVE_KEY))
            end,
            error = function(code, reason)
                print(string.format("[Server] ❌ 删除存档失败 uid=%d code=%s reason=%s",
                    uid, tostring(code), tostring(reason)))
            end,
        })
    end
end

--- 把一份 JSON 存档写入云变量
--- ⚠️ 全局函数（不是 local）：Start() 定义在文件更靠前的位置，局部变量在那里不可见，
---    而 Start 里的 Sys.Init 要把本函数注入给 Server_System 用（云存档写入）。
---    全局函数在「调用时」解析，从 Start 里能安全引用到。
---@param pid string
---@param json string
function Cloud.PushCloud(pid, json)
    local uid = UserIdOf(pid)
    if not uid then
        -- 无认证环境（预览）下没有数字 userId，云存档不可用
        return
    end
    serverCloud:Set(uid, SAVE_KEY, json, {
        ok = function() end,
        error = function(code, reason)
            print("[Server] 云存档写入失败 " .. pid .. " code=" .. tostring(code)
                .. " reason=" .. tostring(reason))
        end,
    })
end

--- 把云变量回调里的原始值解析成存档表
---@param raw any
---@return table|nil
local function DecodeSave(raw)
    if type(raw) == "string" then return Shared.SafeDecode(raw) end
    if type(raw) == "table" then return raw end
    return nil
end

--- 异步读取云存档；无论成功、失败还是超时，cb 都会被调用一次。
---
--- ⚠️ 这里刻意用 `serverCloud:Get` 而**不用 BatchGet**：
---    Get 是本项目一直在跑、已被验证可用的 API（改之前存档读写都正常），
---    而 BatchGet 在这个运行时里没有实机验证过 —— 万一它不可用，
---    后果是「存档既读不到也写不进」，比原来的 bug 更严重。
---
--- cb 签名：(save, loaded)
---   loaded = true  → 云端确实读到了（save 可能为 nil，表示新玩家）
---   loaded = false → 读取失败（重试耗尽），save 为 nil
---
--- ⚠️ 调用方必须区分这两种情况：
---    loaded=true  + save=nil  → 新玩家，可下发默认档
---    loaded=false + save=nil  → 数据不可信，**不应下发/落盘**（否则覆盖玩家真实进度）

-- ⚠️⚠️ 【临时】读档失败模拟开关 —— 上线前必须删掉 ⚠️⚠️
--    用途：验证「读档失败 → 弹门 → 点重试 → 恢复」的完整链路。
--    填入要模拟的 pid（如 "u2085037753"），该账号读档必然失败。
--    置 nil 即恢复正常行为（默认 nil）。
local SIMULATE_LOAD_FAIL_PID = nil  -- 例如 "u2085037753"

---@param pid string
---@param cb fun(save: table|nil, loaded: boolean)
function Cloud.LoadSaveAsync(pid, cb)
    local uid = UserIdOf(pid)
    if not uid then
        cb(nil, false)
        return
    end

    -- 【临时】模拟读档失败（仅对指定 pid 生效）
    if SIMULATE_LOAD_FAIL_PID and pid == SIMULATE_LOAD_FAIL_PID then
        print("[Server] ⚠️【模拟】" .. pid .. " 读档失败")
        cb(nil, false)
        return
    end

    local done = false
    local function Finish(save, loaded)
        if done then return end
        done = true
        if loaded and type(save) == "table" then
            print("[Server] " .. pid .. " 云存档已恢复（结构 v"
                .. tostring(save.saveVersion) .. "）")
        elseif loaded then
            print("[Server] " .. pid .. " 无历史存档，按新玩家处理")
        else
            print("[Server] " .. pid .. " 云存档读取失败（重试耗尽）")
        end
        cb(save, loaded)
    end

    -- 只读 V3，失败重试 3 次
    local retries = 0
    local MAX_RETRIES = 3

    local function TryRead()
        serverCloud:Get(uid, SAVE_KEY, {
            ok = function(scores)
                local save = DecodeSave(scores and scores[SAVE_KEY])
                -- 读到 scores 即成功（save 可能为 nil，表示云端确实没档）
                Finish(save, true)
            end,
            error = function(code, reason)
                retries = retries + 1
                print("[Server] 云存档读取失败 " .. pid
                    .. " code=" .. tostring(code)
                    .. " reason=" .. tostring(reason)
                    .. " (" .. retries .. "/" .. MAX_RETRIES .. ")")
                if retries < MAX_RETRIES then
                    TryRead()
                else
                    Finish(nil, false)
                end
            end,
        })
    end

    TryRead()
end

--- 存档落盘（玩家在线时调用）
---
--- 🔴 云存档读回之前**一律拒绝落盘**。
---
--- 竞态（这是「更新版本后数据被清空」的真正元凶）：
---   OnClientReady 是「先建默认档 → players[pid] = p → 异步读云档」，
---   期间任何把 __dirty 置真的路径（例如服务端主动写邮件 / 改背包）都会让
---   随后的云档回调误判为「玩家已有新操作」：
---     ① 默认档（空背包 / 初始金币）先占位
---     ② 加载窗口内某处 MarkPlayerDirty → __dirty = true
---     ③ 云档几十~几百 ms 后才回来 → 回调看到 __dirty 为真
---        → 走「玩家已有新操作，保留本地游戏性字段」分支
---        → 把**空的默认档**写回云端，玩家的真实进度被永久覆盖
---   所以必须在落盘这一层兜底。
---
--- 云档读回后（无论读成功还是确认无档）才放开。
---@param pid string
function Cloud.SaveToCloud(pid)
    local p = players[pid]
    if not p then return end
    if not p.saveLoaded then
        print("[Server] " .. pid .. " 云存档尚未读回，跳过本次落盘（防覆盖真实进度）")
        return
    end
    -- 🔴 数据不可信（读档失败 + 会话内从未收到客户端实质上报）→ 拒绝落盘。
    --    否则会把服务端的默认空档写进云变量，永久覆盖玩家的真实存档。
    if not p.__hasValidClientData then
        print("[Server] " .. pid .. " 数据不可信（读档失败且无客户端上报），拒绝落盘")
        -- 只在首次失败时通知客户端（避免每 30 秒周期落盘骚扰玩家）
        if not p.__saveFailedNotified then
            p.__saveFailedNotified = true
            local conn = getConnection_ and getConnection_(pid)
            if conn then
                conn:SendRemoteEvent(Shared.EVENTS.SAVE_FAILED, true, Shared.ToVariantMap({}))
            end
        end
        return
    end
    -- 数据可信 → 清掉失败标志（下次真的再次失败时会重新通知）
    p.__saveFailedNotified = nil
    Cloud.PushCloud(pid, SnapshotJson(p))
end

--- 云存档读取看门狗超时（秒）。Server.lua 的 OnUpdate 用。
Cloud.SAVE_LOAD_TIMEOUT = 8.0

return Cloud
