-- ============================================================
-- Shared.lua：客户端和服务器共用
-- 只放「纯数据 + 纯函数」，不碰引擎对象，保证两端行为一致
-- ============================================================
Shared = {}

-- ============ 事件名 ============
Shared.EVENTS = {
    CLIENT_READY     = "ClientReady",
    INV_SYNC         = "InventorySync",
    REQUEST_MARKET   = "RequestMarket",
    ASSIGN_PLAYER    = "AssignPlayer",
    MAIL_UPDATE      = "MailUpdate",
    MAIL_CLAIM       = "MailClaim",
    -- 领取结果回包（服务端 → 客户端，用于汇总 Toast）
    MAIL_CLAIM_RESULT = "MailClaimResult",
    -- 邮箱分页
    REQUEST_MAIL_PAGE = "RequestMailPage",
    MAIL_PAGE_RESULT  = "MailPageResult",
    -- 背包满时掉落物转邮件
    BAG_OVERFLOW      = "BagOverflowToMail",
    -- 脏标记同步协议
    SYNC_REQUEST      = "SyncRequest",
    SYNC_ACK          = "SyncAck",
    -- 共享 BOSS 相关
    REPORT_LOCAL_KILL = "ReportLocalKill",
    ATTACK_BOSS       = "AttackBoss",
    -- 客户端本地把 Boss 打到 0 血 → 上报击杀，服务端据此给「首个上报者」发奖励。
    -- ⚠️ 与 ATTACK_BOSS 的区别：ATTACK_BOSS 是血量增量上报（服务端权威扣血），
    --    本事件是击杀事件（一次性），用于解决「本地血量归零后停手、
    --    服务端永远收不满伤害」的死锁。服务端以首个上报者为准。
    BOSS_KILLED       = "BossKilled",
    PLAYER_DEATH      = "PlayerDeath",
    SHARED_BOSS_UPDATE = "SharedBossUpdate",
    SHARED_BOSS_REMOVE = "SharedBossRemove",
    -- 服务端通用提示 / 顶号
    TOAST            = "Toast",
    KICKED           = "Kicked",
    -- 服务端读档 / 落盘失败 → 客户端弹「进度同步失败」门（可手动重试）
    SAVE_FAILED      = "SaveFailed",
    -- 客户端本地权威位置：服务端把玩家位置转发给其他在线玩家
    PLAYER_MOVE      = "PlayerMoveBroadcast",
    -- 玩家昵称广播（服务端 → 所有客户端，用于头顶显示 TapTap 昵称）
    PLAYER_INFO      = "PlayerInfoBroadcast",
    -- 新手礼包已自动穿戴提示（服务端 → 客户端，仅新玩家首次触发）
    STARTER_GIFT     = "StarterGift",
    -- 在线人数广播（服务端 → 所有客户端，HUD 左上角显示）
    ONLINE_COUNT     = "OnlineCount",
    -- 服务器满员（服务端 → 被拒的客户端）。载荷 { Max = 上限人数 }
    SERVER_FULL      = "ServerFull",
    -- 玩家下线（服务端 → 所有客户端）。载荷 { PlayerId = pid }
    -- 客户端据此清掉残留模型 / 位置缓存 / 头顶标签。
    -- ⚠️ 节点虽是 REPLICATED，但客户端不能只依赖引擎同步：同名节点竞态
    --    会让 GetChild 拿错对象（见 Client_Network.UpdateRemotePlayers）。
    PLAYER_LEAVE     = "PlayerLeave",
    -- 【调试】请求服务器玩家列表（客户端 → 服务端）
    DEBUG_QUERY_SERVER_INFO = "DebugQueryServerInfo",
    -- 【调试】服务器玩家列表回包（服务端 → 客户端）
    DEBUG_SERVER_INFO       = "DebugServerInfo",
    -- 钱庄（存款 / 取款 / 领取利息）
    BANK_DEPOSIT        = "BankDeposit",
    BANK_WITHDRAW       = "BankWithdraw",
    BANK_STATE_REQUEST  = "BankStateRequest",
    BANK_STATE          = "BankState",
    BANK_RESULT         = "BankResult",
    -- 升级请求（金币驱动）
    LEVEL_UP            = "LevelUp",
    -- 降级请求
    LEVEL_DOWN          = "LevelDown",
    -- 召唤卷：客户端请求使用（服务端权威 roll + 冷却/距离校验）
    USE_SUMMON_SCROLL      = "UseSummonScroll",
    -- 召唤卷结果回包（服务端 → 客户端）
    SUMMON_SCROLL_RESULT   = "SummonScrollResult",
    -- 拍卖行服务端分页：客户端按页拉取（筛选条件一并上报）
    REQUEST_MARKET_PAGE    = "RequestMarketPage",
    -- 拍卖行分页回包（服务端 → 客户端）
    MARKET_PAGE_RESULT     = "MarketPageResult",
}

-- 服务器需要接收的远程事件（客户端 → 服务器）
Shared.SERVER_EVENTS = {
    Shared.EVENTS.CLIENT_READY,
    Shared.EVENTS.SYNC_REQUEST,
    Shared.EVENTS.REQUEST_MARKET,
    Shared.EVENTS.MAIL_CLAIM,
    Shared.EVENTS.REQUEST_MAIL_PAGE,
    Shared.EVENTS.BAG_OVERFLOW,
    Shared.EVENTS.REPORT_LOCAL_KILL,
    Shared.EVENTS.ATTACK_BOSS,
    Shared.EVENTS.BOSS_KILLED,
    Shared.EVENTS.PLAYER_DEATH,
    Shared.EVENTS.BANK_DEPOSIT,
    Shared.EVENTS.BANK_WITHDRAW,
    Shared.EVENTS.BANK_STATE_REQUEST,
    Shared.EVENTS.LEVEL_UP,
    Shared.EVENTS.LEVEL_DOWN,
    Shared.EVENTS.USE_SUMMON_SCROLL,
    Shared.EVENTS.REQUEST_MARKET_PAGE,
    Shared.EVENTS.DEBUG_QUERY_SERVER_INFO,
}

-- 客户端需要接收的远程事件（服务器 → 客户端）
Shared.CLIENT_EVENTS = {
    Shared.EVENTS.ASSIGN_PLAYER,
    Shared.EVENTS.MAIL_UPDATE,
    Shared.EVENTS.INV_SYNC,
    Shared.EVENTS.MAIL_PAGE_RESULT,
    Shared.EVENTS.MAIL_CLAIM_RESULT,
    Shared.EVENTS.SYNC_ACK,
    Shared.EVENTS.SHARED_BOSS_UPDATE,
    Shared.EVENTS.SHARED_BOSS_REMOVE,
    Shared.EVENTS.TOAST,
    Shared.EVENTS.KICKED,
    Shared.EVENTS.SAVE_FAILED,
    Shared.EVENTS.PLAYER_MOVE,
    Shared.EVENTS.PLAYER_INFO,
    Shared.EVENTS.STARTER_GIFT,
    Shared.EVENTS.ONLINE_COUNT,
    Shared.EVENTS.SERVER_FULL,
    Shared.EVENTS.PLAYER_LEAVE,
    Shared.EVENTS.BANK_STATE,
    Shared.EVENTS.BANK_RESULT,
    Shared.EVENTS.SUMMON_SCROLL_RESULT,
    Shared.EVENTS.MARKET_PAGE_RESULT,
    Shared.EVENTS.DEBUG_SERVER_INFO,
}

-- ⚠️ 远程事件必须先注册才能收到，漏注册会静默收不到消息
function Shared.RegisterServerEvents()
    for _, name in ipairs(Shared.SERVER_EVENTS) do
        network:RegisterRemoteEvent(name)
    end
end

function Shared.RegisterClientEvents()
    for _, name in ipairs(Shared.CLIENT_EVENTS) do
        network:RegisterRemoteEvent(name)
    end
end

-- ============ 常量 ============
Shared.C = {
    MAX_LEVEL              = 49,
    -- 升级系统：升级改为金币驱动，见 Shared.GetLevelUpCost
    -- （KILL_PER_LEVEL 已删除）
    -- 共享 Boss 刷新阈值：按区域段位递增。
    --   lv 1~9 区域  → 100 只
    --   lv 10~19     → 200 只
    --   lv 20~29     → 300 只
    --   lv 30~39     → 400 只
    --   lv 40~49     → 500 只
    -- 即 threshold = KILL_THRESHOLD_PER_TIER × (tier + 1)，tier = floor(lv / 10)。
    -- ⚠️ 服务端还会做上限校验：Boss 数不得超过当前在线人数（见 Server.OnReportLocalKill）。
    KILL_THRESHOLD_PER_TIER = 100,
    LOCAL_MONSTER_MAX = 40,
    LOCAL_MONSTER_REFILL_INTERVAL = 25,
    LOCAL_MONSTER_SAFE_DIST = 15,
    LOCAL_MONSTER_MIN_DIST_BETWEEN = 2,
    -- 怪物冻结阈值（米）：与玩家距离超过此值时冻结 AI（停仇恨/追击/回家/攻击/回血）
    MONSTER_FREEZE_DIST    = 50,
    -- 冻结持续此秒数后销毁节点和数据。玩家回到 50 米内会立即解冻、重置计时。
    MONSTER_FREEZE_TIMEOUT = 30,
    BAG_PAGE_SIZE          = 48,
    MAX_INVENTORY          = 48,
    MARKET_TAX_RATE        = 0.05,
    -- 每个玩家在拍卖行的**上架格子上限（固定 20 格）**。
    -- ⚠️ 服务端按此拒绝超额上架，客户端按此显示「N/20」并提前拦住，
    --    两端必须共用本常量，否则又会出现「服务端收了但界面看不到」。
    MARKET_SLOT_MAX        = 20,
    -- 拍卖行单笔挂单售价上限（21 亿）。
    -- ⚠️ 防止 1e+23 这类溢出值进市场：客户端拦不住被绕过的包，服务端必须再挡一道。
    MARKET_PRICE_MAX       = 2100000000,
    -- 全服挂单总量上限（防内存/存储爆；单玩家上限见 MARKET_SLOT_MAX）。
    MARKET_GLOBAL_MAX      = 10000,
    -- 拍卖行一页条数（服务端分页；与 MARKET_SLOT_MAX 语义不同，别混用）。
    MARKET_PAGE_SIZE       = 100,
    SAVE_INTERVAL          = 30,
    -- 位置上报周期（秒）。
    -- ⚠️ 这个值同时决定「其他玩家看到你移动」的流畅度：
    --    服务端只在收到上报且位移 > 0.1 米时才广播 PLAYER_MOVE，
    --    所以周期越大，别人看你越像「瞬移」。
    --    从 2.0 降到 0.2：多人同屏时的移动观感从「跳帧」变为连续。
    --    代价是上行包变多（5 次/秒），对 KCP 而言可接受。
    SYNC_INTERVAL          = 0.2,
    -- 耐久
    -- ⚠️ 鉴定费 / 死亡耐久损失已改为「按品质」计算（见 Shared.GetIdentifyCost /
    --    Shared.GetDeathDurabilityLoss），不要再加回固定值常量，否则两套口径会打架。
    -- 耐久改为按品质查表，见 Shared.QUALITY_DURABILITY
    -- DEFAULT_DURABILITY / MAX_DURABILITY 仅作旧存档兜底
    DEFAULT_DURABILITY     = 1000,
    MAX_DURABILITY         = 1000,
    KILL_DURABILITY_LOSS   = 1,
    -- 掉落：装备掉落率已按段位查表（见 Shared.RollDrops）
    -- 碎片
    FRAGMENT_STACK_MAX     = 9999,
    TOKEN_STACK_MAX        = 99,
    SUMMON_SCROLL_STACK_MAX = 999,
    -- ============ 宠物系统 ============
    PET_MATERIAL_STACK_MAX  = 9999,   -- 宠物蛋 / 材料堆叠上限
    PET_ATTR_ACTIVATE_CHANCE = 0.5,   -- 12 种属性各 50% 概率激活
    PET_GACHA_PITY_COUNT    = 50,     -- 50 连保底（各池独立）
    -- 抽卡金币消耗（按蛋品质递增：1000 / 2000 / 3000 / 4000 / 5000）
    PET_GACHA_COST_GOLD     = {
        normal = 1000, magic = 2000, rare = 3000, legendary = 4000, mythic = 5000,
    },
    PET_POOL_MAX            = 100,    -- 待选池容量
    PET_EGG_DROP_CHANCE     = 0.02,   -- 打怪掉蛋概率（第二批接入）
    -- 锻造 / 重铸：消耗已改为按品质直接配在函数里（见 GetForgeCostMap / GetReforgeCostMap）
    REFORGE_LOCK_PENALTY   = 0.90,
    SKILL_FORGE_CHANCE     = 0.20,
    -- 邮件（无限：设一个大数作为云端防爆兜底，实际不裁剪）
    -- 每张在线卡提供的时长
    ONLINE_TOKEN_SECONDS   = 30 * 60,
    -- 新手装备固定技能条数
    STARTER_GEAR_SKILLS    = 5,
    -- 新手装备固定随机属性词条条数（基础词条之外的随机部分）
    STARTER_GEAR_ATTRS     = 6,
    -- 广告
    AD_DAILY_LIMIT         = 20,
    AD_COOLDOWN_SECONDS    = 60,
    -- 怪物 AI
    MONSTER_HATE_RANGE     = 15,
    MONSTER_DEAGGRO_SEC    = 10,
    MONSTER_LEASH_RANGE    = 25,
    MONSTER_SPEED_FACTOR   = 0.5,
    -- 初始金币
    INIT_GOLD              = 20,
    -- 视野 / 相机
    VIEW_DISTANCE_DEFAULT      = 200,
    CAM_DIST_DEFAULT           = 10,
    CAM_DIST_MIN               = 3,
    CAM_DIST_MAX               = 20,
    -- 默认 20（原 60），落在 [CAM_PITCH_MIN, CAM_PITCH_MAX] 内。
    -- ⚠️ 默认值必须落在范围内，否则 ApplyCameraSettings() 的 Clamp 会静默夹掉它。
    --
    -- 从 60 降到 20 的原因：60° 是强俯视，屏幕顶部在水平线下 30°，
    -- 看不到任何天空 —— 太阳（Client.lua 的 SUN_DIR）因此永远不可见。
    -- 20° 时屏幕顶部到水平线上方 10°，能看到天空和太阳。
    -- ⚠️ 与太阳仰角联动：太阳仰角必须 ≤ 30 − pitch 才可见。
    --    调大本值前先确认太阳还在视野内。
    CAM_PITCH_DEFAULT          = 20,
    -- 俯仰角范围 1~89（度）。角度越大越俯视：
    --   horiz = cos(pitch) × dist、vert = sin(pitch) × dist
    --   1°  ≈ 几乎平视（贴着地平线看）；89° ≈ 近乎垂直俯瞰。
    --   上限取 89 不取 90：正好 90° 时 horiz 归零，相机与玩家正上方重合，
    --   视线方向退化（LookAt 的 up 向量与视线平行），画面会抖/翻转。
    --   下限取 1 不取 0：同理，0° 是纯水平，地平线会占满屏幕。
    CAM_PITCH_MIN              = 1,
    CAM_PITCH_MAX              = 89,
    NAME_TAG_DISTANCE_DEFAULT  = 20,
    -- 联动比例
    MONSTER_REFRESH_RATIO      = 0.35,
    -- 刷怪环外圈上限 50 米（原 80）。
    -- 与"50 米冻结"联动：新刷的怪必须落在 50 米内，否则刚出生就被冻结。
    MONSTER_REFRESH_CAP        = 50,
    MINIMAP_RADIUS_RATIO       = 0.4,

    -- ============ 新增：品质段位 ============
    -- 每个品质的最大重铸条数（= 技能条数上限）
    -- 与 SKILL_MAX_BY_QUALITY 数值一致，但语义独立
    QUALITY_MAX_REFORGE = {
        normal = 6, magic = 8, rare = 10, legendary = 12, mythic = 14,
    },
    -- 每个品质的装备耐久上限
    QUALITY_DURABILITY = {
        normal = 1000, magic = 1500, rare = 2000, legendary = 2500, mythic = 3000,
    },
    -- 每个品质的重铸基础概率（无锁定时，单槽填充概率）
    REFORGE_BASE_CHANCE = {
        normal = 1.00, magic = 0.80, rare = 0.64, legendary = 0.512, mythic = 0.4096,
    },

    -- ============ 新增：精魄 ============
    SPIRIT_STACK_MAX = 999,
    -- 精魄掉落率（按怪物段位）
    SPIRIT_DROP_CHANCE = {
        normal = 0.20, magic = 0.16, rare = 0.12, legendary = 0.08, mythic = 0.05,
    },

    -- ============ 新增：怪物距离分带 ============
    -- 每级占多少米（已砍半：50 → 25）
    MONSTER_BAND_WIDTH = 25,
    -- 缓冲区宽度（已废弃，保留常量避免旧引用报错）
    MONSTER_BUFFER_WIDTH = 0,
    -- 怪物等级上限
    MONSTER_MAX_LEVEL = 49,
    -- 各段位最高怪物等级（用于共享 Boss / 段位判定等）
    TIER_MAX_LEVEL = {
        normal = 9, magic = 19, rare = 29, legendary = 39, mythic = 49,
    },

    -- 共享 Boss 分档数值（客户端渲染 + 服务端权威共用一份）
    BOSS_STATS = {
        normal    = { hp = 3240,   atk = 38,   armor = 90,   dodge = 0.15, hitRate = 0.15 },
        magic     = { hp = 6600,   atk = 76,   armor = 360,  dodge = 0.22, hitRate = 0.22 },
        rare      = { hp = 13200,  atk = 150,  armor = 870,  dodge = 0.30, hitRate = 0.30 },
        legendary = { hp = 26400,  atk = 300,  armor = 1560, dodge = 0.38, hitRate = 0.38 },
        mythic    = { hp = 57600,  atk = 640,  armor = 2340, dodge = 0.45, hitRate = 0.45 },
    },

    -- ============ 新增：等级压制 ============
    -- 玩家对怪物的伤害倍率：1 - min(0.95, 压制 × 0.08)
    SUPPRESS_PLAYER_DMG_PER_LEVEL = 0.08,
    SUPPRESS_PLAYER_DMG_MIN = 0.95,
    -- 怪物对玩家的伤害倍率：1 + min(3.0, 压制 × 0.15)
    SUPPRESS_MONSTER_DMG_PER_LEVEL = 0.15,
    SUPPRESS_MONSTER_DMG_MAX = 3.0,
    -- 高等级玩家回低段位的怪物减伤：min(90%, 等级差 × 5%)
    HIGH_LEVEL_REDUCE_PER_LEVEL = 0.05,
    HIGH_LEVEL_REDUCE_MAX = 0.90,
}

-- 全局 UI 状态标志（Client 触摸事件会读这两个值，用于屏蔽 3D 触摸输入）
Shared.UIState = {
    modalOpen = false,   -- 是否有 Modal 弹窗打开
    inputFocus = false,  -- 是否有输入框获得焦点
}

-- ============ 品质 ============
Shared.QUALITY_NAMES = {
    normal = "普通", magic = "优秀", rare = "精良", legendary = "史诗", mythic = "传说",
}
Shared.QUALITY_COLORS = {
    normal = "#dddddd", magic = "#4488ff", rare = "#ffdd44",
    legendary = "#ff8844", mythic = "#cc2266",
}
Shared.QUALITY_RANK = { normal = 0, magic = 1, rare = 2, legendary = 3, mythic = 4 }
Shared.QUALITY_LIST = { "normal", "magic", "rare", "legendary", "mythic" }
Shared.QUALITY_WEAR = { normal = 1, magic = 10, rare = 20, legendary = 30, mythic = 40 }
Shared.QUALITY_MULT = { normal = 1.0, magic = 1.1, rare = 1.25, legendary = 1.4, mythic = 1.6 }
Shared.QUALITY_MAX_ENHANCE = { normal = 20, magic = 22, rare = 24, legendary = 26, mythic = 30 }

-- ============ 碎片 ============
Shared.FRAGMENT_DISPLAY = {
    normal    = { name = "普通碎片", icon = "⬜" },
    magic     = { name = "优秀碎片", icon = "🟦" },
    rare      = { name = "精良碎片", icon = "🟨" },
    legendary = { name = "史诗碎片", icon = "🟧" },
    mythic    = { name = "传说碎片", icon = "🟥" },
}

-- ============ 精魄 ============
Shared.SPIRIT_DISPLAY = {
    normal    = { name = "普通精魄", icon = "⚪" },
    magic     = { name = "优秀精魄", icon = "🔵" },
    rare      = { name = "精良精魄", icon = "🟡" },
    legendary = { name = "史诗精魄", icon = "🟠" },
    mythic    = { name = "传说精魄", icon = "🔴" },
}

-- ============ 装备部位 ============
Shared.SLOTS = {
    weapon   = { name = "武器", icon = "🗡️" },
    helmet   = { name = "头盔", icon = "🪖" },
    chest    = { name = "胸甲", icon = "🛡️" },
    gloves   = { name = "手套", icon = "🧤" },
    boots    = { name = "鞋子", icon = "👢" },
    ring     = { name = "戒指", icon = "💍" },
    necklace = { name = "项链", icon = "📿" },
    belt     = { name = "衣服", icon = "👕" },
}
Shared.SLOT_LIST = { "weapon", "helmet", "chest", "gloves", "boots", "ring", "necklace", "belt" }

-- ============ 词条 ============
Shared.MOD_DEFS = {
    atk          = { name = "攻击",     type = "flat" },
    maxHp        = { name = "最大生命", type = "flat" },
    critChance   = { name = "暴击几率", type = "percent" },
    critDamage   = { name = "暴击伤害", type = "percent" },
    atkSpeed     = { name = "攻击速度", type = "percent" },
    moveSpeed    = { name = "移动速度", type = "percent" },
    armorPen     = { name = "破甲",     type = "percent" },
    killHeal     = { name = "击杀回复", type = "flat" },
    armor        = { name = "护甲",     type = "flat" },
    damageReduce = { name = "减伤",     type = "percent" },
    dodge        = { name = "闪避",     type = "percent" },
    hitRate      = { name = "命中",     type = "percent" },
}
Shared.MOD_IDS = {
    "atk", "maxHp", "critChance", "critDamage", "atkSpeed", "moveSpeed",
    "armorPen", "killHeal", "armor", "damageReduce", "dodge", "hitRate",
}
Shared.MOD_BASE_MAX = {
    atk = 1.5, maxHp = 30, critChance = 0.015, critDamage = 0.05,
    atkSpeed = 0.025, moveSpeed = 0.025, armorPen = 0.02,
    killHeal = 50, armor = 15, damageReduce = 0.015, dodge = 0.008, hitRate = 0.025,
}
Shared.SLOT_SPEC = {
    weapon   = { { "atk",        1.5   } },
    helmet   = { { "maxHp",      25    } },
    chest    = { { "maxHp",      40    } },
    gloves   = { { "atkSpeed",   0.03  } },
    boots    = { { "moveSpeed",  0.03  } },
    ring     = { { "critChance", 0.015 } },
    necklace = { { "critDamage", 0.05  } },
    belt     = { { "armorPen",   0.02  } },
}

-- ============ 技能（37 个）============
Shared.SKILL_DEFS = {
    arcChain     = { name="弧光链", icon="⚡", type="onHit",   chance=0.10, desc="链至2米内最多2个敌人，各80%伤害",  params={range=2.0, maxTargets=2, damageRatio=0.8} },
    moonBurst    = { name="月震爆", icon="💥", type="onHit",   chance=0.10, desc="2.5米范围120%伤害",  params={range=2.5, damageRatio=1.2} },
    boneErode    = { name="蚀骨",   icon="☠️", type="onHit",   chance=0.10, desc="5秒内每秒15%伤害，可叠3层", params={duration=5, tickInterval=1.0, dpsRatio=0.15, maxStacks=3} },
    fissure      = { name="崩裂",   icon="🪨", type="onHit",   chance=0.10, desc="目标受到后续伤害+20%，持续5秒", params={duration=5, damageBonus=0.2} },
    bloodErode   = { name="血蚀",   icon="🩸", type="onHit",   chance=0.10, desc="4秒内每秒12%伤害，自身回复等量", params={duration=4, tickInterval=1.0, dpsRatio=0.12} },
    boilingBlood = { name="沸血",   icon="🔥", type="onKill",  chance=0.10, desc="击杀后攻速+30%，持续3秒", params={duration=3, atkSpeedBonus=0.30} },
    frostFlow    = { name="霜流",   icon="❄️", type="onKill",  chance=0.10, desc="击杀后攻速+20%、移速+20%，持续4秒", params={duration=4, atkSpeedBonus=0.20, moveSpeedBonus=0.20} },
    thornArmor   = { name="棘甲",   icon="🛡️", type="onHurt",  chance=0.10, desc="受击时反弹40%伤害", params={reflectRatio=0.4} },
    soulChain    = { name="魂链",   icon="⛓️", type="onHurt",  chance=0.10, desc="受击时30%伤害分摊给3米内随机敌人", params={range=3.0, splitRatio=0.3} },
    windCut      = { name="风切",   icon="🌀", type="passive", chance=0.10, desc="额外攻击1次，50%伤害", params={damageRatio=0.5} },
    lifesteal    = { name="吮血",   icon="🩸", type="onHit",   chance=0.10, desc="命中时回复本次伤害的8%生命", params={healRatio=0.08} },
    vitality     = { name="生机",   icon="💚", type="onHit",   chance=0.10, desc="命中时回复最大生命的1%", params={healMaxHpRatio=0.01} },
    soulSiphon   = { name="汲魂",   icon="🔮", type="onHit",   chance=0.10, desc="命中时回复当前攻击力的20%生命", params={healAtkRatio=0.20} },
    lastBreath   = { name="净息",   icon="🌿", type="onKill",  chance=0.10, desc="击杀后回复最大生命的5%", params={healMaxHpRatio=0.05} },
    rejuvenate   = { name="回春",   icon="🍀", type="onHurt",  chance=0.10, desc="受击时回复最大生命的3%", params={healMaxHpRatio=0.03} },
    bloodSurge   = { name="血涌",   icon="🩹", type="onKill",  chance=0.10, desc="生命低于50%时击杀敌人，回复最大生命的10%", params={hpThreshold=0.50, healMaxHpRatio=0.10} },
    bloodthirst  = { name="嗜血",   icon="🧛", type="onKill",  chance=0.10, desc="击杀后3秒内每次攻击回复伤害的5%生命", params={duration=3, lifestealRatio=0.05} },
    ironWall     = { name="铁壁",   icon="🏰", type="onHurt",  chance=0.10, desc="受击时当次伤害减少20%", params={reduceRatio=0.20} },
    stoneShield  = { name="磐盾",   icon="🪨", type="onHurt",  chance=0.10, desc="受击后5秒内护甲+40%", params={duration=5, armorBonus=0.40} },
    reflect      = { name="反弹",   icon="🪞", type="onHurt",  chance=0.10, desc="受击时反弹30%伤害", params={reflectRatio=0.30} },
    scaleGuard   = { name="闪鳞",   icon="🐟", type="onHurt",  chance=0.10, desc="受击后3秒内闪避+10%", params={duration=3, dodgeBonus=0.10} },
    dullArmor    = { name="钝甲",   icon="🔨", type="onHurt",  chance=0.10, desc="受击时削弱怪物攻击15%，持续3秒", params={duration=3, atkDebuff=0.15} },
    slowStrike   = { name="迟滞",   icon="🐌", type="onHurt",  chance=0.10, desc="受击时削弱怪物攻速20%，持续3秒", params={duration=3, atkSpeedDebuff=0.20} },
    ironCloth    = { name="铁衣",   icon="🧥", type="onHit",   chance=0.10, desc="攻击命中后3秒内护甲+30%", params={duration=3, armorBonus=0.30} },
    lightBody    = { name="轻身",   icon="🪶", type="onHit",   chance=0.10, desc="攻击命中后3秒内闪避+8%", params={duration=3, dodgeBonus=0.08} },
    swift        = { name="迅捷",   icon="👟", type="onHit",   chance=0.10, desc="攻击命中后3秒内移速+15%", params={duration=3, moveSpeedBonus=0.15} },
    hunter       = { name="猎杀",   icon="🎯", type="passive", chance=0.10, desc="对生命低于30%的敌人伤害+15%", params={hpThreshold=0.30, damageBonus=0.15} },
    deadly       = { name="致命",   icon="💀", type="passive", chance=0.10, desc="对满血目标伤害+25%", params={damageBonus=0.25} },
    armorBreak   = { name="破军",   icon="⚔️", type="passive", chance=0.10, desc="攻击时无视目标10%护甲", params={ignoreArmor=0.10} },
    bleed        = { name="割裂",   icon="🩸", type="onCrit",  chance=0.10, desc="暴击时附加流血：3秒内每秒伤害5%", params={duration=3, tickInterval=1.0, tickRatio=0.05} },
    suppress     = { name="压制",   icon="🔻", type="passive", chance=0.10, desc="对生命低于50%的敌人伤害+10%", params={hpThreshold=0.50, damageBonus=0.10} },
    precision    = { name="精准",   icon="🎯", type="passive", chance=0.10, desc="命中率+8%", params={hitRateBonus=0.08} },
    shock        = { name="感电",   icon="⚡", type="onHit",   chance=0.10, desc="命中时削弱怪物攻速15%，持续3秒", params={duration=3, atkSpeedDebuff=0.15} },
    venom        = { name="毒牙",   icon="🐍", type="onHit",   chance=0.10, desc="命中时使目标中毒：5秒内每秒伤害5%", params={duration=5, tickInterval=1.0, tickRatio=0.05} },
    backlash     = { name="反噬",   icon="💢", type="onHurt",  chance=0.10, desc="受击时对3米内随机敌人造成50%伤害", params={range=3.0, reflectRatio=0.50} },
    armorRend    = { name="破势",   icon="🪓", type="onHit",   chance=0.10, desc="命中时削弱目标护甲10%，持续4秒", params={duration=4, armorDebuff=0.10} },
    resonance    = { name="共鸣",   icon="💫", type="onKill",  chance=0.10, desc="击杀时对3米内敌人造成击杀目标最大生命8%的伤害", params={range=3.0, aoeRatio=0.08} },
}

-- ⚠️ 必须排序：pairs() 的遍历顺序受 Lua 字符串 hash 随机种子影响，跨进程不稳定。
--    两端若顺序不一致，同样的 random 序列会抽出不同技能 → 结果对不上。
Shared.SKILL_IDS = {}
for k in pairs(Shared.SKILL_DEFS) do table.insert(Shared.SKILL_IDS, k) end
table.sort(Shared.SKILL_IDS)

-- 🔴 词条**总条数上限**（属性词条 + 技能词条 合计）。
-- 语义（2026-10-04 定稿）：
--   · 约束的是「条数总和」，**不校验唯一性** —— 允许 6 条完全相同的技能词条。
--   · 技能词条按「种类」计条，不看层数（同一种技能 7 层仍只算 1 条）。
--   · 属性词条与技能词条**一同计入**这个上限。
Shared.SKILL_MAX_BY_QUALITY = {
    normal = 6, magic = 8, rare = 10, legendary = 12, mythic = 14,
}

--- 🔴 词条上限口径（2026-10-04 二次定稿，所有品质通用）：
---   · **基础词条不计入任何上限**（见 SLOT_SPEC），独立于上限之外。
---   · **属性与技能各自独立上限**，互不占用对方额度：
---       属性上限 = QUALITY_BONUS_MAX[品质]   （普通 6）
---       技能上限 = SKILL_MAX_BY_QUALITY[品质] （普通 6）
---     毕业形态示例（普通）：1 基础 + 6 属性 + 6 技能。
---   · 技能按**层数**计条（1 层 = 1 条）。`{skillA = 6}` 就是 6 条，不是 1 条。
---     ——「不校验唯一性、允许重复堆叠」的直接结果。
---   · ⚠️ 曾是「属性 + 技能共享一个总额度」，已废弃：那样永远达不到 6+6。

--- 统计一件装备的**随机属性**条数（不含基础词条）。
---@param item table|nil
---@return integer
function Shared.CountAttrAffixes(item)
    if not item then return 0 end
    local specCount = #(Shared.SLOT_SPEC[item.slot] or {})
    local n = #(item.bonuses or {}) - specCount
    if n < 0 then n = 0 end
    return n
end

--- 统计技能词条的**总层数**（= 技能条数，不是种类数）。
---@param skills table|nil
---@return integer
function Shared.CountSkillLayers(skills)
    local n = 0
    for _, layers in pairs(skills or {}) do n = n + (layers or 1) end
    return n
end

--- 受限词条合计（属性 + 技能），仅用于显示，**不用于上限判定**。
---@param item table|nil
---@return integer
function Shared.CountItemAffixes(item)
    if not item then return 0 end
    return Shared.CountAttrAffixes(item) + Shared.CountSkillLayers(item.skills)
end

--- 某品质的「随机属性」上限。
---@param quality string|nil
---@return integer
function Shared.MaxAttrAffixes(quality)
    return Shared.QUALITY_BONUS_MAX[quality] or 6
end

--- 某品质的「技能」上限。
---@param quality string|nil
---@return integer
function Shared.MaxSkillAffixes(quality)
    return Shared.SKILL_MAX_BY_QUALITY[quality] or 6
end

--- 清洗一件装备「超出上限」的词条（存量数据修复，原地修改）。
---
--- 移除顺序（超出上限时循环裁到合规）：
---   ① 先删**随机属性词条**（从末尾删，保留靠近基础词条的部分）
---   ② 仍超限则删**技能词条**（按 skillId 排序后从末尾删，保证确定性）
--- 偏好：优先保留技能词条（技能是构筑核心，属性是数值填充）。
--- ⚠️ **基础词条永远保留**（`bonuses` 前 `#SLOT_SPEC[slot]` 条，不参与裁剪）。
---@param item table
---@return integer removed 移除的词条数（0 = 未超限，未改动）
function Shared.SanitizeItemAffixes(item)
    if type(item) ~= "table" or not item.slot then return 0 end
    -- 属性与技能各自独立上限
    local maxAttr  = Shared.MaxAttrAffixes(item.quality)
    local maxSkill = Shared.MaxSkillAffixes(item.quality)
    local specCount = #(Shared.SLOT_SPEC[item.slot] or {})
    local bonuses = item.bonuses or {}
    local skills = item.skills or {}

    local removed = 0

    -- ① 裁随机属性：保留前 maxAttr 条（基础词条不参与裁剪）
    local randCount = #bonuses - specCount
    if randCount < 0 then randCount = 0 end
    if randCount > maxAttr then
        local kept = {}
        for i = 1, specCount + maxAttr do
            if bonuses[i] then table.insert(kept, bonuses[i]) end
        end
        removed = removed + (#bonuses - #kept)
        item.bonuses = kept
    end

    -- ② 裁技能层数：保留前 maxSkill 层
    --    ⚠️ 按层数裁（不是按种类）。按 skillId 排序后逐个扣层，保证确定性。
    local skillLayers = Shared.CountSkillLayers(skills)
    if skillLayers > maxSkill then
        local ids = {}
        for sid in pairs(skills) do ids[#ids + 1] = sid end
        table.sort(ids)   -- 确定性：不依赖 pairs 的哈希顺序
        local kept, left = {}, maxSkill
        for _, sid in ipairs(ids) do
            if left <= 0 then break end
            local take = math.min(skills[sid] or 1, left)
            kept[sid] = take
            left = left - take
        end
        removed = removed + (skillLayers - Shared.CountSkillLayers(kept))
        item.skills = kept
    end

    if removed > 0 then
        item.reforgeLevel = Shared.CountSkillLayers(item.skills)
    end
    return removed
end

--- 把强化等级夹回该件装备的上限内（存量数据修复，原地修改）。
--- 上限优先取物品自带 maxEnhance，缺失时回退品质表。
---@param item table
---@return boolean changed
function Shared.ClampItemEnhance(item)
    if type(item) ~= "table" or not item.slot then return false end
    local maxEnh = item.maxEnhance or Shared.QUALITY_MAX_ENHANCE[item.quality] or 20
    if (item.enhanceLevel or 0) > maxEnh then
        item.enhanceLevel = maxEnh
        return true
    end
    return false
end

--- 清洗一个装备容器（装备栏 map 或背包数组），返回移除的词条总数。
---@param container table|nil
---@return integer removed, integer fixedItems
function Shared.SanitizeAffixContainer(container)
    if type(container) ~= "table" then return 0, 0 end
    local removed, fixed = 0, 0
    for _, it in pairs(container) do
        if type(it) == "table" and it.slot then
            local r = Shared.SanitizeItemAffixes(it)
            if r > 0 then
                removed = removed + r
                fixed = fixed + 1
            end
        end
    end
    return removed, fixed
end

-- 属性词条的「随机部分」上限（不含固定 1 条特化词条）
-- ⚠️ 与 SKILL_MAX_BY_QUALITY 数值相同，但语义独立：那个是技能循环次数，这个是属性词条条数。
Shared.QUALITY_BONUS_MAX = {
    normal = 6, magic = 8, rare = 10, legendary = 12, mythic = 14,
}

-- ============ 特殊物品 ============
Shared.TOKEN_TYPES = {
    -- desc 只在渲染时读取（见 UI_Core.BuildItemSummaryLayout），
    -- ⚠️ 不写进物品存档 —— 否则老物品拿不到描述。
    online = { name = "在线卡", icon = "🎟️", color = "#44ddff",
               desc = "增加 30 分钟在线时长" },
}

-- 召唤卷（5 品质）：击杀怪物达标时按怪物等级品质产出，使用后必定召唤共享 BOSS。
-- 物品字段：type = "summonScroll"，品质存在 item.scrollType。
Shared.SUMMON_SCROLL = {
    normal    = { name = "普通召唤卷", icon = "📜" },
    magic     = { name = "优秀召唤卷", icon = "📜" },
    rare      = { name = "精良召唤卷", icon = "📜" },
    legendary = { name = "史诗召唤卷", icon = "📜" },
    mythic    = { name = "传说召唤卷", icon = "📜" },
}
-- 使用冷却（秒）
Shared.SUMMON_SCROLL_COOLDOWN = 30
-- 出生点禁用半径（米）
Shared.SUMMON_SCROLL_MIN_DIST = 50

-- ============ 宠物系统 ============
--- 各品质宠物的等级上限（同时决定固定特性保底 = 上限的一半）
Shared.PET_QUALITY_MAX_LEVEL = {
    normal = 20, magic = 40, rare = 60, legendary = 80, mythic = 100,
}

--- 抽卡品质权重（传说池的基础分布）。
--- 其它池子按"可出的最高品质"归一化（见 Pet_System 内部 NormalizeWeights）。
Shared.PET_GACHA_QUALITY_WEIGHTS = {
    normal = 54, magic = 30, rare = 12, legendary = 2, mythic = 2,
}

--- 宠物蛋的显示数据（5 品质）
Shared.PET_EGG_DISPLAY = {
    normal    = { name = "普通宠物蛋", icon = "🥚" },
    magic     = { name = "优秀宠物蛋", icon = "🥚" },
    rare      = { name = "精良宠物蛋", icon = "🥚" },
    legendary = { name = "史诗宠物蛋", icon = "🥚" },
    mythic    = { name = "传说宠物蛋", icon = "🥚" },
}

--- 宠物升级材料的显示数据（5 品质）
Shared.PET_MATERIAL_DISPLAY = {
    normal    = { name = "普通宠物精粹", icon = "🟢" },
    magic     = { name = "优秀宠物精粹", icon = "🔵" },
    rare      = { name = "精良宠物精粹", icon = "🟡" },
    legendary = { name = "史诗宠物精粹", icon = "🟠" },
    mythic    = { name = "传说宠物精粹", icon = "🔴" },
}

-- ============ 物品详细说明 ============
-- 用途：物品详情面板 / 拍卖行详情面板的"用途 + 获取"两段说明。
--
-- 🔴 关键设计：本表是**纯静态数据**，按「类型 + 子类型」索引。
--    渲染时由 UI_Core.BuildItemSummaryLayout 查表，**绝不写进物品实例**。
--    否则说明会被写进存档、上报服务端，改文案时云端旧值会覆盖新值。
--    （与 TOKEN_TYPES.desc 同样的设计约束，见那里的注释。）
--
-- 结构：
--   { [type] = { [subType] = { uses = {...}, obtain = {...} } } }
--   type    : "fragment" | "spirit" | "token" | "summonScroll"
--   subType : 品质 key（token 只用 "online"）
--
-- ⚠️ 修改文案只改这张表，不需要动任何物品结构、存档、服务端。
---@type table<string, table<string, {uses: string[], obtain: string[]}>>
Shared.ITEM_DETAILS = {
    -- ===== 碎片（5 品质）=====
    -- ⚠️ "锻造/重铸"两行在 5 种品质里**完全一样**，这是刻意的：
    --    它告诉玩家"无论手里是哪一档碎片，锻造/重铸都要用它"。
    --    这是解决"玩家以为普通碎片到优秀后没用"误解的核心。
    fragment = {
        normal = {
            uses = {
                "强化普通装备（满强化约 60 片/件）",
                "锻造任意品质装备（普通 25 → 传说 800 片）",
                "重铸任意品质装备（普通 2 → 传说 80 片/次）",
            },
            obtain = { "分解普通装备 ×1" },
        },
        magic = {
            uses = {
                "强化优秀装备（满强化约 132 片/件）",
                "锻造任意品质装备（普通 25 → 传说 800 片）",
                "重铸任意品质装备（普通 2 → 传说 80 片/次）",
            },
            obtain = { "分解优秀装备 ×1" },
        },
        rare = {
            uses = {
                "强化精良装备（满强化约 156 片/件）",
                "锻造任意品质装备（普通 25 → 传说 800 片）",
                "重铸任意品质装备（普通 2 → 传说 80 片/次）",
            },
            obtain = { "分解精良装备 ×1" },
        },
        legendary = {
            uses = {
                "强化史诗装备（满强化约 182 片/件）",
                "锻造任意品质装备（普通 25 → 传说 800 片）",
                "重铸任意品质装备（普通 2 → 传说 80 片/次）",
            },
            obtain = { "分解史诗装备 ×1" },
        },
        mythic = {
            uses = {
                "强化传说装备（满强化约 240 片/件）",
                "锻造任意品质装备（普通 25 → 传说 800 片）",
                "重铸任意品质装备（普通 2 → 传说 80 片/次）",
            },
            obtain = { "分解传说装备 ×1" },
        },
    },

    -- ===== 精魄（5 品质）=====
    -- ⚠️ 文案里明确写"XX 装备"，这就是"只用同品质"的正面表述
    --    （精魄不跨品质，与碎片不同）。
    spirit = {
        normal = {
            uses = {
                "锻造普通装备（1 个/次）",
                "重铸普通装备技能（1 个/次）",
            },
            obtain = { "普通怪物掉落（20% 概率）" },
        },
        magic = {
            uses = {
                "锻造优秀装备（2 个/次）",
                "重铸优秀装备技能（2 个/次）",
            },
            obtain = { "优秀怪物掉落（16% 概率）" },
        },
        rare = {
            uses = {
                "锻造精良装备（4 个/次）",
                "重铸精良装备技能（4 个/次）",
            },
            obtain = { "精良怪物掉落（12% 概率）" },
        },
        legendary = {
            uses = {
                "锻造史诗装备（8 个/次）",
                "重铸史诗装备技能（8 个/次）",
            },
            obtain = { "史诗怪物掉落（8% 概率）" },
        },
        mythic = {
            uses = {
                "锻造传说装备（16 个/次）",
                "重铸传说装备技能（16 个/次）",
            },
            obtain = { "传说怪物掉落（5% 概率）" },
        },
    },

    -- ===== 在线卡 =====
    -- ⚠️ 只此一种 token，subType 固定 "online"。
    --    "自动续费"默认开启（见 NewDefaultSettings.autoUseOnlineToken），
    --    写明"可在设置关闭"是必要的——否则玩家遇到"卡莫名消失"会以为 bug。
    token = {
        online = {
            uses = {
                "手动使用：+30 分钟在线时长",
                "自动续费：剩余 ≤5 秒时自动消耗 1 张（可在「设置 → 自动续费」关闭）",
                "开启自动战斗：当前时长为 0 时消耗 1 张启动",
                "拍卖行：可挂单出售",
            },
            obtain = {
                "每日礼包 ×1",
                "观看广告 ×1（每日上限 20 次）",
            },
        },
    },

    -- ===== 召唤卷（5 品质共用文案）=====
    -- 使用规则与品质无关（品质只影响召唤出的 BOSS 等级，那是效果不是规则）。
    -- ⚠️ magic/rare/legendary/mythic 故意不写 key（写 `= nil` 会被 LSP 判
    --    类型不符，且 Lua 里本就等价于不存在）；渲染时缺失回退 normal，
    --    见 UI_Core.BuildItemSummaryLayout。
    summonScroll = {
        normal = {
            uses = {
                "使用后召唤共享 BOSS（全服玩家可共同攻击）",
                "冷却 30 秒",
                "出生点 50 米内不可使用",
                "缓冲区（无怪物区域）不可使用",
            },
            obtain = {
                "击杀怪物达到阈值时随机产出",
                "也可在拍卖行购买",
            },
        },
    },

    -- ===== 宠物蛋（5 品质）=====
    -- ⚠️ 5 品质的"用途/获取"结构一致，只有蛋的品质不同。
    --    "可出宠物品质"随蛋品质递增（见 Shared.PET_GACHA_QUALITY_WEIGHTS）。
    petEgg = {
        normal = {
            uses = {
                "在宠物面板抽卡（每次消耗 1 蛋 + 1000 金币）",
                "只可抽出普通品质宠物",
                "宠物等级上限随机（普通 10~20）",
                "每池独立保底：50 连必出该池最高品质",
                "可在拍卖行出售",
            },
            obtain = { "击杀 Lv1~9 怪物 2% 概率掉落" },
        },
        magic = {
            uses = {
                "在宠物面板抽卡（每次消耗 1 蛋 + 2000 金币）",
                "可抽出普通或优秀品质宠物",
                "宠物等级上限随机（优秀 20~40）",
                "每池独立保底：50 连必出该池最高品质",
                "可在拍卖行出售",
            },
            obtain = { "击杀 Lv10~19 怪物 2% 概率掉落" },
        },
        rare = {
            uses = {
                "在宠物面板抽卡（每次消耗 1 蛋 + 3000 金币）",
                "可抽出普通~精良品质宠物",
                "宠物等级上限随机（精良 30~60）",
                "每池独立保底：50 连必出该池最高品质",
                "可在拍卖行出售",
            },
            obtain = { "击杀 Lv20~29 怪物 2% 概率掉落" },
        },
        legendary = {
            uses = {
                "在宠物面板抽卡（每次消耗 1 蛋 + 4000 金币）",
                "可抽出普通~史诗品质宠物",
                "宠物等级上限随机（史诗 40~80）",
                "每池独立保底：50 连必出该池最高品质",
                "可在拍卖行出售",
            },
            obtain = { "击杀 Lv30~39 怪物 2% 概率掉落" },
        },
        mythic = {
            uses = {
                "在宠物面板抽卡（每次消耗 1 蛋 + 5000 金币）",
                "可抽出全部品质宠物（含传说 2%）",
                "宠物等级上限随机（传说 50~100）",
                "每池独立保底：50 连必出史诗或传说",
                "可在拍卖行出售",
            },
            obtain = { "击杀 Lv40~49 怪物 2% 概率掉落" },
        },
    },

    -- ===== 宠物精粹（5 品质）=====
    -- ⚠️ 材料只用于升级对应"宠物品质及以下"的宠物（见 Pet_System.UpgradePet）。
    --    高品质宠物需要全部低品质材料各 N 个。
    petMaterial = {
        normal = {
            uses = {
                "用于升级普通宠物（按等级逐级消耗）",
                "升级高等级宠物时也需要（品质越高需要的材料种类越多）",
                "可在拍卖行出售",
            },
            obtain = { "转换普通品质宠物为材料 ×1" },
        },
        magic = {
            uses = {
                "用于升级优秀宠物（按等级逐级消耗）",
                "升级精良及以上宠物时也需要",
                "可在拍卖行出售",
            },
            obtain = { "转换优秀品质宠物为材料 ×1" },
        },
        rare = {
            uses = {
                "用于升级精良宠物（按等级逐级消耗）",
                "升级史诗及以上宠物时也需要",
                "可在拍卖行出售",
            },
            obtain = { "转换精良品质宠物为材料 ×1" },
        },
        legendary = {
            uses = {
                "用于升级史诗宠物（按等级逐级消耗）",
                "升级传说宠物时也需要",
                "可在拍卖行出售",
            },
            obtain = { "转换史诗品质宠物为材料 ×1" },
        },
        mythic = {
            uses = {
                "用于升级传说宠物（按等级逐级消耗）",
                "可在拍卖行出售",
            },
            obtain = { "转换传说品质宠物为材料 ×1" },
        },
    },

    -- ===== 宠物（作为物品在背包里时）=====
    -- 用固定 sub "pet"，因为宠物本体说明与品质无关（只有一份文案）。
    petItem = {
        pet = {
            uses = {
                "可在拍卖行上架出售",
                "可放回待选池（用于装备到槽位、升级等操作）",
            },
            obtain = {
                "从待选池放入背包",
                "从市场购买（邮件领取）",
                "从槽位放入背包",
            },
        },
    },
}

-- ============ 强化率 ============
Shared.ENHANCE_RATES = {}
for L = 0, 40 do
    Shared.ENHANCE_RATES[L] = math.max(0.50, 1.0 - L * 0.015)
end

-- ============ 画面/特效设置 ============
--- 设置的默认值。单独抽成函数，方便：
---   · NewPlayerSave 初始化
---   · 旧存档缺字段时兜底补齐（见 Data.ApplyServerPayload）
--- 范围/步进与 Panels.OpenSettingsPanel 里的滑动条一一对应。
---@return table
function Shared.NewDefaultSettings()
    return {
        -- 相机
        -- ⚠️ 已废弃：视野固定 200，本字段不再被读取。
        --    保留是为了兼容旧存档（避免读档时字段缺失导致的其他副作用）。
        viewDistance      = Shared.C.VIEW_DISTANCE_DEFAULT,
        camDist           = Shared.C.CAM_DIST_DEFAULT,
        camPitch          = Shared.C.CAM_PITCH_DEFAULT,
        nameTagDistance   = Shared.C.NAME_TAG_DISTANCE_DEFAULT,
        -- 界面显示（名字/血条已拆开）
        showName          = true,
        showHealthBar     = true,
        showMinimap       = true,
        showResolution    = false,
        showFPS           = false,
        -- 战斗特效
        dmgNumbers        = true,
        showSkillPopup    = true,
        -- 技能特效默认开启：几何化后（八面体 + 受光）开销远低于原粒子方案，
        -- 且尺寸已缩到 0.4 米直径，同屏叠加不会再糊成一坨。
        -- 低端机仍可在「设置 → 画面与特效」里关掉。
        showSkillEffect   = true,
        -- 自动续费（默认开启，在线卡不足时自动跳过）
        autoUseOnlineToken = true,

        -- ===== 画面（阶段 1 实测定稿）=====
        --
        -- 定稿值一览（阶段 1.1~1.4 逐项实测所得）：
        --   1.1 Bloom     bloomThreshold 0.70 / bloomIntensity 1.20 / bloomMode 1(Plus)
        --   1.2 环境光    ambientSource 2(COLOR) / ambientIntensity 0.65
        --   1.3 阴影      castShadows true / shadowMapSize 2048
        --   1.4 Toon      terrain 0.72 / character 0.30 / shadowStrength 1.0
        --
        -- ⚠️ 以上 1.1~1.4 的生效路径不是本函数，而是 Client.lua Start() 开头的
        --    "视觉参数强制刷新"块：它每次启动都把这几个字段无条件写一遍。
        --    改这些值必须**两处同步改**（这里 + Client.lua），否则实机不生效。
        --
        -- ⚠️ Bloom 是占位定稿：当前低多边形平光场景没有真正的亮源，
        --    等阶段 2 做完水面/金属高光/阳光斑驳后必须重调。

        -- 🔴 0.85/1.00 → 1.00/0.35（2026-10-04 实测修正）。
        --
        -- 为什么 0.85 会全屏发白（关键数值）：
        --    天空盒材质用 MatDiffColor = hdrBoost(2.0)（见 SkyUtils.CreateGradientSky），
        --    而太阳 5 层发光色是 (1.00, 0.96, 0.85) ~ (1.00, 0.88, 0.60)，
        --    **R 通道恒为 1.00**。所以阈值 0.85 时：
        --      · 天空 R 通道 = 2.0 > 0.85 → **整个天空参与泛光**
        --      · 太阳 5 层的 R 全部 = 1.0 > 0.85 → 全部参与
        --    → 泛光源不止太阳，还包括整片天空 → 光晕铺满上半屏 → 画面发白。
        --
        -- 为什么 1.00 能修：天空 R = 2.0 **仍然** > 1.00，依然泛光；
        --    但太阳的 L2/Halo/L4/Glow 发光色（0.94/0.92/0.90/0.88）低于 1.00，不再触发。
        --    泛光源只剩"太阳核心 + 天空"，比原来小得多。
        --    ⚠️ 若仍偏白，说明天空贡献仍太大 —— 那只能关掉 Bloom（天空的 hdrBoost=2.0
        --    是它自身设计，不能为 Bloom 改）。
        --
        -- ⚠️ 这些画面参数由设置面板「后处理」Tab 调（PostProcess.ApplyFromSettings）。
        bloomThreshold = 1.00,
        bloomIntensity = 0.35,
        bloomMode      = 1,      -- 1 = Plus（引擎默认，画质/开销平衡）

        -- 环境光模式：**锁定 COLOR(2)**，PREBAKED(0)/SKYBOX(1) 已弃用。
        -- 🔴 弃用原因：PREBAKED 依赖引擎预烘焙 IBL，在程序化场景下表现不可控；
        --    SKYBOX 用天空盒做 IBL/SH 烘焙，实测观感未通过（阶段 1.2 遗留问题）。
        --    COLOR 是明确的均匀冷蓝补光，暗部颜色可预期 —— 当前唯一生产模式。
        -- ⚠️ 字段保留是为了 Client.lua 消费侧（defaultZone.ambientSource）读取；
        --    实际值由 PostProcess.ApplyFromSettings() 硬编码为 2，不再走设置面板。
        ambientSource  = 2,
        -- 0.65：暗部不要被填平，保留明暗对比。
        -- 原神是"暗部有颜色、但确实暗"，不是"暗部被照亮"。
        -- ⚠️ 由设置面板「后处理」Tab 调（PostProcess.ApplyFromSettings）。
        ambientIntensity = 0.65,

        -- 阴影（阶段 1.3 定稿：默认开启）。
        -- 🔴 实测：必须 castShadows + renderer.drawShadows **同时**为 true 才出阴影，
        --    单开任一个都无效。Client.lua 已用这一个字段同步设置两者。
        -- 贴图 1024：512 边缘锯齿太糙，2048 移动端开销翻倍，1024 是平衡点。
        -- normalOffset 必须为 0（设 0.5 会让阴影整体消失），见 Client.lua 注释。
        castShadows    = true,
        -- 2048：云游戏跑在服务器 GPU 上（不是手机），2048 完全可行。
        -- 如果本地调试帧率敏感，可临时回调到 1024。
        shadowMapSize  = 2048,

        -- Toon 明暗分界阈值（SurfaceShader 参数，地形与角色各一套）
        -- 实测地形 5 档（0.5/0.6/0.65/0.7/0.8）：
        --   0.50 草地偏暗、暗面占比大；0.60 暗部仍多；0.65 中间态
        --   0.70 草地大部分明亮鲜绿、远处略暗  ← 选它（接近草原调子）
        --   0.80 几乎全亮、失去层次
        -- 角色阈值默认 0.30：角色是竖直圆柱，N·L 上限 ≈0.707，阈值必须明显更低。
        -- 地形 0.70→0.72：暗面占比略降，草地更多落在亮部
        -- 角色 0.30 不变（竖直圆柱 N·L 上限 0.707，阈值不能再高）
        -- 暗面强度回到 1.0（标准值）。0.85 会把暗面提亮 15%（0.85×2=1.70），
        -- 配合主光提亮后画面失去暗部 → 看起来"糊"。
        toonThresholdTerrain   = 0.72,
        toonThresholdCharacter = 0.30,
        toonShadowStrength     = 1.0,

        -- ===== 后处理开关（设置面板「后处理」Tab）=====
        -- ⚠️ key 是扁平名（避免嵌套），tag 的映射见 PostProcess.lua 的 SETTING_KEYS。
        --    默认只开 FXAA2；Bloom 因天空 hdrBoost=2.0 与阈值冲突已关（2026-10-04 实测）。
        --    AutoExposure / GaussianBlur / DOF 不在此表 —— 由 PostProcess.FORCED_OFF 强制关闭。
        pp_FXAA2        = true,
        pp_BloomHDRPlus = false,

        -- 自动分解 - 未鉴定装备"先鉴定后分解"开关（按品质）。
        -- ⚠️ 放在 settings 里是为了复用现有的持久化路径：Settings 是整表 JSON
        --    上报，加字段会自动跟存档走，不需要单独加网络字段。
        autoIdThenDecompose = {
            normal = false, magic = false, rare = false, legendary = false, mythic = false,
        },
    }
end

-- ============ 玩家存档结构 ============
--- 存档结构版本（单一事实来源，Server.lua / Server_System.lua 共用）。
---
--- ⚠️ 与云变量键名（player_save_v4）是两件事：
---    新增/改字段 → 这里 +1；
---    改键名     → 那是「对全体玩家清档」，不要为了发版这么做。
--- 用法：SnapshotJson 写入、离线存档原样透传。
Shared.SAVE_VERSION = 2

-- ============ 逻辑函数 ============
-- 所有纯函数 / Data / Notify 模块都在 Shared_Logic.lua，由下面这行填进本表。
-- ⚠️ 必须在 return 之前：Shared_Logic 里的函数引用 Shared.C / Shared.QUALITY_* 等数据表，
--    依赖上面已全部就绪。
require("Shared_Logic")

return Shared
