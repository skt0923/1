-- ============================================================
-- Battle_Visual.lua：视觉层（玩家 / 怪物）
--
-- 与 Battle_World.lua 共享同一张 Battle 表：
--   · Battle_World 先建表并 return
--   · 本文件 require("Battle_World") 拿到同一张表，往 Battle.Visual 里填内容
--   · Battle_World 里的 Items / Enemies / Effects 通过 Battle.Visual.xxx 运行时查表
--     （见各自模块顶部的 TerrainH 延迟查表函数）
--
-- 内容：
--   Visual.Player    玩家（机械师/探险者，7 节点合并网格，纯代码生成）
--   Visual.Monster   怪物（种子囊袋 + 晶体花 BOSS）
--
-- 兄弟文件：
--   Battle_Terrain.lua  地形（渐变抬升 + 4 色硬边界 + 顶点色 + 装饰）
--       · 本文件在**末尾** require 它，把 Battle.Visual.Terrain 填好后再统一导出
--       · 顶点工具走 Battle.V，地形材质走 Battle.getTerrainMaterial
--
-- 依赖：Shared + Battle_World（拿 Battle 表和 Assets 工具）。
--       不依赖 UI，也不依赖 Battle_Combat。
-- ============================================================
require("Shared")
local Battle = require("Battle_World")

-- ============================================================
-- 通用顶点构建辅助（Player / Monster 共用）
--
-- 设计：所有部件都用 CustomGeometry 手工拼顶点，合并到少量节点里，
--       用顶点色区分不同部件的颜色。DrawCall 由「节点数」决定，不由「部件数」。
--
-- 绕序约定：三角形顶点按「从外侧看逆时针」传入，法线取 (v2-v1) × (v3-v1)。
--           旋转体和球体需要反向绕序（因为从外侧看是顺时针），已内部处理。
--
-- ⚠️ 引擎的叉乘方法名是 `CrossProduct`，**没有** `Cross`（实测 Cross = nil）。
-- ============================================================
-- 顶点工具通过 Battle.V 共享给 Battle_Terrain.lua（后者在文件末尾 require）
Battle.V = Battle.V or {}
local V = Battle.V

--- 添加一个三角形（从外侧看逆时针）
---@param g CustomGeometry
---@param v1 Vector3
---@param v2 Vector3
---@param v3 Vector3
---@param c number[] {r,g,b} 顶点色，0~1
function V.tri(g, v1, v2, v3, c)
    local n = (v2 - v1):CrossProduct(v3 - v1)
    local len = n:Length()
    if len > 1e-6 then
        n = n:Normalized()
    else
        n = Vector3(0, 1, 0)
    end
    local col = Color(c[1] or 1, c[2] or 1, c[3] or 1, 1)
    g:DefineVertex(v1); g:DefineNormal(n); g:DefineColor(col)
    g:DefineVertex(v2); g:DefineNormal(n); g:DefineColor(col)
    g:DefineVertex(v3); g:DefineNormal(n); g:DefineColor(col)
end

--- 添加一个四边形（分裂成 2 个三角形）
function V.quad(g, v1, v2, v3, v4, c)
    V.tri(g, v1, v2, v3, c)
    V.tri(g, v1, v3, v4, c)
end

--- 轴对齐盒（6 面 12 三角形）
---@param cx number 中心 X
---@param cy number 中心 Y
---@param cz number 中心 Z
---@param sx number X 边长
---@param sy number Y 边长
---@param sz number Z 边长
function V.box(g, cx, cy, cz, sx, sy, sz, c)
    local hx, hy, hz = sx * 0.5, sy * 0.5, sz * 0.5
    local x0, x1 = cx - hx, cx + hx
    local y0, y1 = cy - hy, cy + hy
    local z0, z1 = cz - hz, cz + hz
    -- +Z 面
    V.quad(g, Vector3(x0,y0,z1), Vector3(x1,y0,z1), Vector3(x1,y1,z1), Vector3(x0,y1,z1), c)
    -- -Z 面
    V.quad(g, Vector3(x1,y0,z0), Vector3(x0,y0,z0), Vector3(x0,y1,z0), Vector3(x1,y1,z0), c)
    -- +X 面
    V.quad(g, Vector3(x1,y0,z1), Vector3(x1,y0,z0), Vector3(x1,y1,z0), Vector3(x1,y1,z1), c)
    -- -X 面
    V.quad(g, Vector3(x0,y0,z0), Vector3(x0,y0,z1), Vector3(x0,y1,z1), Vector3(x0,y1,z0), c)
    -- +Y 面
    V.quad(g, Vector3(x0,y1,z1), Vector3(x1,y1,z1), Vector3(x1,y1,z0), Vector3(x0,y1,z0), c)
    -- -Y 面
    V.quad(g, Vector3(x0,y0,z0), Vector3(x1,y0,z0), Vector3(x1,y0,z1), Vector3(x0,y0,z1), c)
end

--- 旋转体：把 (r, y) 轮廓绕 Y 轴旋转
---@param cx number 旋转轴 X
---@param cz number 旋转轴 Z
---@param profile number[][] { {r1,y1}, {r2,y2}, ... } 从下到上
---@param segs integer 圆周分段数
function V.revolve(g, cx, cz, profile, segs, c)
    local n = #profile
    for i = 0, segs - 1 do
        local a1 = 2 * math.pi * i / segs
        local a2 = 2 * math.pi * (i + 1) / segs
        local cs1, sn1 = math.cos(a1), math.sin(a1)
        local cs2, sn2 = math.cos(a2), math.sin(a2)
        for j = 1, n - 1 do
            local p1 = profile[j]
            local p2 = profile[j + 1]
            local v1 = Vector3(cx + p1[1]*cs1, p1[2], cz + p1[1]*sn1)
            local v2 = Vector3(cx + p1[1]*cs2, p1[2], cz + p1[1]*sn2)
            local v3 = Vector3(cx + p2[1]*cs2, p2[2], cz + p2[1]*sn2)
            local v4 = Vector3(cx + p2[1]*cs1, p2[2], cz + p2[1]*sn1)
            -- 反向绕序：从外侧看是逆时针
            V.quad(g, v1, v4, v3, v2, c)
        end
    end
    -- 底部封盖（朝下法线）
    if profile[1][1] > 0.001 then
        local p = profile[1]
        local center = Vector3(cx, p[2], cz)
        for i = 0, segs - 1 do
            local a1 = 2 * math.pi * i / segs
            local a2 = 2 * math.pi * (i + 1) / segs
            local v1 = Vector3(cx + p[1]*math.cos(a1), p[2], cz + p[1]*math.sin(a1))
            local v2 = Vector3(cx + p[1]*math.cos(a2), p[2], cz + p[1]*math.sin(a2))
            V.tri(g, center, v1, v2, c)
        end
    end
    -- 顶部封盖（朝上法线）
    if profile[n][1] > 0.001 then
        local p = profile[n]
        local center = Vector3(cx, p[2], cz)
        for i = 0, segs - 1 do
            local a1 = 2 * math.pi * i / segs
            local a2 = 2 * math.pi * (i + 1) / segs
            local v1 = Vector3(cx + p[1]*math.cos(a1), p[2], cz + p[1]*math.sin(a1))
            local v2 = Vector3(cx + p[1]*math.cos(a2), p[2], cz + p[1]*math.sin(a2))
            V.tri(g, center, v2, v1, c)
        end
    end
end

--- UV 球
---@param cx number 球心 X
---@param cy number 球心 Y
---@param cz number 球心 Z
---@param r number 半径
---@param segs integer 经线分段
---@param rings integer 纬线分段
function V.sphere(g, cx, cy, cz, r, segs, rings, c)
    for j = 0, rings - 1 do
        local lat0 = math.pi * j / rings - math.pi / 2
        local lat1 = math.pi * (j + 1) / rings - math.pi / 2
        local y0 = cy + r * math.sin(lat0)
        local y1 = cy + r * math.sin(lat1)
        local r0 = r * math.cos(lat0)
        local r1 = r * math.cos(lat1)
        for i = 0, segs - 1 do
            local a1 = 2 * math.pi * i / segs
            local a2 = 2 * math.pi * (i + 1) / segs
            local v1 = Vector3(cx + r0*math.cos(a1), y0, cz + r0*math.sin(a1))
            local v2 = Vector3(cx + r0*math.cos(a2), y0, cz + r0*math.sin(a2))
            local v3 = Vector3(cx + r1*math.cos(a2), y1, cz + r1*math.sin(a2))
            local v4 = Vector3(cx + r1*math.cos(a1), y1, cz + r1*math.sin(a1))
            V.quad(g, v1, v4, v3, v2, c)
        end
    end
end

--- 平滑版旋转体：用法与参数和 V.revolve 完全一致，只有法线不同。
---
--- 与 V.revolve 的区别：
---   · V.revolve 用每个四边形的**面法线**，三顶点共用 → 硬折面
---   · 本函数按轮廓切线算每个顶点的**平滑法线**，绕轴旋转到对应角度
---     → 曲面平滑，Toon 分界能沿"一条曲线"走
---
--- ⚠️ 只用于需要平滑的部件（如玩家 Torso）。地形/树/石头请继续用 V.revolve，
---    它们的低多边形风格依赖硬折面。
---@param g CustomGeometry
---@param cx number 旋转轴 X
---@param cz number 旋转轴 Z
---@param profile number[][] { {r1,y1}, {r2,y2}, ... } 从下到上
---@param segs integer 圆周分段数
---@param c number[] {r,g,b} 顶点色
function V.revolveSmooth(g, cx, cz, profile, segs, c)
    local n = #profile

    --- 轮廓点 j（1-based）在 r-y 平面内的平滑法线
    ---@param j integer
    ---@return number nr, number ny
    local function profileNormal(j)
        local rPrev, yPrev, rNext, yNext
        if j == 1 then
            rPrev, yPrev = profile[1][1], profile[1][2]
            rNext, yNext = profile[2][1], profile[2][2]
        elseif j == n then
            rPrev, yPrev = profile[n - 1][1], profile[n - 1][2]
            rNext, yNext = profile[n][1], profile[n][2]
        else
            rPrev, yPrev = profile[j - 1][1], profile[j - 1][2]
            rNext, yNext = profile[j + 1][1], profile[j + 1][2]
        end
        -- 轮廓切线 (tr, ty)，在 r-y 平面内逆时针转 90° 得外法线 (ty, -tr)
        local tr, ty = rNext - rPrev, yNext - yPrev
        local nr, ny = ty, -tr
        local len = math.sqrt(nr * nr + ny * ny)
        if len < 1e-6 then return 1, 0 end
        return nr / len, ny / len
    end

    --- 按顶点法线输出一个三角形
    local function emitTri(v1, n1, v2, n2, v3, n3)
        local col = Color(c[1] or 1, c[2] or 1, c[3] or 1, 1)
        g:DefineVertex(v1); g:DefineNormal(n1); g:DefineColor(col)
        g:DefineVertex(v2); g:DefineNormal(n2); g:DefineColor(col)
        g:DefineVertex(v3); g:DefineNormal(n3); g:DefineColor(col)
    end

    for i = 0, segs - 1 do
        local a1 = 2 * math.pi * i / segs
        local a2 = 2 * math.pi * (i + 1) / segs
        local cs1, sn1 = math.cos(a1), math.sin(a1)
        local cs2, sn2 = math.cos(a2), math.sin(a2)
        for j = 1, n - 1 do
            local p1, p2 = profile[j], profile[j + 1]
            -- 4 个位置顶点
            local v1 = Vector3(cx + p1[1]*cs1, p1[2], cz + p1[1]*sn1)
            local v2 = Vector3(cx + p1[1]*cs2, p1[2], cz + p1[1]*sn2)
            local v3 = Vector3(cx + p2[1]*cs2, p2[2], cz + p2[1]*sn2)
            local v4 = Vector3(cx + p2[1]*cs1, p2[2], cz + p2[1]*sn1)
            -- 每点各自的平滑法线（r-y 平面法线绕轴旋转）
            local nr1, ny1 = profileNormal(j)
            local nr2, ny2 = profileNormal(j + 1)
            local n1 = Vector3(nr1*cs1, ny1, nr1*sn1):Normalized()
            local n2 = Vector3(nr1*cs2, ny1, nr1*sn2):Normalized()
            local n3 = Vector3(nr2*cs2, ny2, nr2*sn2):Normalized()
            local n4 = Vector3(nr2*cs1, ny2, nr2*sn1):Normalized()
            -- 反向绕序，与 V.revolve 一致
            emitTri(v1, n1, v4, n4, v3, n3)
            emitTri(v1, n1, v3, n3, v2, n2)
        end
    end

    -- 底部封盖（法线朝下，平整面用常量法线即可）
    if profile[1][1] > 0.001 then
        local p = profile[1]
        local center = Vector3(cx, p[2], cz)
        local nc = Vector3(0, -1, 0)
        for i = 0, segs - 1 do
            local a1 = 2 * math.pi * i / segs
            local a2 = 2 * math.pi * (i + 1) / segs
            local v1 = Vector3(cx + p[1]*math.cos(a1), p[2], cz + p[1]*math.sin(a1))
            local v2 = Vector3(cx + p[1]*math.cos(a2), p[2], cz + p[1]*math.sin(a2))
            emitTri(center, nc, v1, nc, v2, nc)
        end
    end

    -- 顶部封盖
    if profile[n][1] > 0.001 then
        local p = profile[n]
        local center = Vector3(cx, p[2], cz)
        local nc = Vector3(0, 1, 0)
        for i = 0, segs - 1 do
            local a1 = 2 * math.pi * i / segs
            local a2 = 2 * math.pi * (i + 1) / segs
            local v1 = Vector3(cx + p[1]*math.cos(a1), p[2], cz + p[1]*math.sin(a1))
            local v2 = Vector3(cx + p[1]*math.cos(a2), p[2], cz + p[1]*math.sin(a2))
            emitTri(center, nc, v2, nc, v1, nc)
        end
    end
end

--- 平滑版球：球面法线 = normalize(顶点 - 球心)。
--- 参数与 V.sphere 完全一致。
---@param cx number
---@param cy number
---@param cz number
---@param r number
---@param segs integer
---@param rings integer
---@param c number[]
function V.sphereSmooth(g, cx, cy, cz, r, segs, rings, c)
    local center = Vector3(cx, cy, cz)

    local function emitTri(v1, n1, v2, n2, v3, n3)
        local col = Color(c[1] or 1, c[2] or 1, c[3] or 1, 1)
        g:DefineVertex(v1); g:DefineNormal(n1); g:DefineColor(col)
        g:DefineVertex(v2); g:DefineNormal(n2); g:DefineColor(col)
        g:DefineVertex(v3); g:DefineNormal(n3); g:DefineColor(col)
    end

    for j = 0, rings - 1 do
        local lat0 = math.pi * j / rings - math.pi / 2
        local lat1 = math.pi * (j + 1) / rings - math.pi / 2
        local y0 = cy + r * math.sin(lat0)
        local y1 = cy + r * math.sin(lat1)
        local r0 = r * math.cos(lat0)
        local r1 = r * math.cos(lat1)
        for i = 0, segs - 1 do
            local a1 = 2 * math.pi * i / segs
            local a2 = 2 * math.pi * (i + 1) / segs
            local v1 = Vector3(cx + r0*math.cos(a1), y0, cz + r0*math.sin(a1))
            local v2 = Vector3(cx + r0*math.cos(a2), y0, cz + r0*math.sin(a2))
            local v3 = Vector3(cx + r1*math.cos(a2), y1, cz + r1*math.sin(a2))
            local v4 = Vector3(cx + r1*math.cos(a1), y1, cz + r1*math.sin(a1))
            local n1 = (v1 - center):Normalized()
            local n2 = (v2 - center):Normalized()
            local n3 = (v3 - center):Normalized()
            local n4 = (v4 - center):Normalized()
            emitTri(v1, n1, v4, n4, v3, n3)
            emitTri(v1, n1, v3, n3, v2, n2)
        end
    end
end

--- 创建一个带 CustomGeometry 的节点，返回 (node, geom)。
--- 调用方负责调用 geom:Commit()。
---@param parent Node
---@param name string
---@param x number
---@param y number
---@param z number
---@return Node, CustomGeometry
function V.beginPart(parent, name, x, y, z)
    local node = parent:CreateChild(name, LOCAL)
    node.position = Vector3(x, y, z)
    local geom = node:CreateComponent("CustomGeometry", LOCAL)
    geom:SetNumGeometries(1)
    geom:BeginGeometry(0, TRIANGLE_LIST)
    return node, geom
end

--- 取 DiffVCol 材质（顶点色 + 漫反射光照），单例复用
---@return Material|nil
local function getVColMaterial()
    if not V._vcolMat then
        local tech = cache:GetResource("Technique", "Techniques/DiffVCol.xml")
        if not tech then
            print("[Visual] ⚠️ 找不到 Techniques/DiffVCol.xml")
            return nil
        end
        local mat = Material:new()
        mat:SetTechnique(0, tech)
        V._vcolMat = mat
    end
    return V._vcolMat
end
V.getVColMaterial = getVColMaterial

--- 取地形 / 装饰专用材质（terrain_toon.shader，单例复用）。
---
--- ⚠️ 为什么不直接改 getVColMaterial：
---    getVColMaterial 被 Player（makePart）和 Monster（makeTintedMaterial）共用，
---    且 Monster 依赖 base:GetTechnique(0) 复制技术并叠加 MatDiffColor 染色。
---    SurfaceShader 材质没有 Technique(0)，改它会让怪物材质直接崩掉。
---    所以地形走独立函数，玩家/怪物仍用 DiffVCol（第二批再处理）。
---@return Material|nil
local function getTerrainMaterial()
    if not V._terrainMat then
        local mat = Material:new()
        if mat:SetSurfaceShader("Shaders/BLGL/terrain_toon.shader") then
            V._terrainMat = mat
            print("[Visual] 地形/装饰材质已切换为 Toon SurfaceShader")
        else
            print("[Visual] ⚠️ terrain_toon.shader 加载失败，回退到 DiffVCol")
            return getVColMaterial()
        end
    end
    return V._terrainMat
end
V.getTerrainMaterial = getTerrainMaterial
Battle.getTerrainMaterial = getTerrainMaterial   -- 供 Battle_Terrain.lua 复用

--- 取角色 / 其他玩家的 Toon 材质（单例复用）。
---
--- ⚠️ 与 getTerrainMaterial 分开：角色用 character_toon.shader
---    （阈值不同、暗面色偏更冷、带 outline）。
---    地形不带 outline（否则地形会变成"网格线框"）。
---@return Material|nil
local function getCharacterMaterial()
    if not V._charMat then
        local mat = Material:new()
        if mat:SetSurfaceShader("Shaders/BLGL/character_toon.shader") then
            V._charMat = mat
            print("[Visual] 角色材质已切换为 Toon SurfaceShader")
        else
            print("[Visual] ⚠️ character_toon.shader 加载失败，回退到 DiffVCol")
            return getVColMaterial()
        end
    end
    return V._charMat
end
V.getCharacterMaterial = getCharacterMaterial

--- 假阴影材质：纯黑半透明，贴在物体脚下模拟阴影。
---
--- 用 PBRNoTextureAlpha（本项目已验证可用 —— 太阳的 Halo/Glow 层就是它）。
--- ⚠️ 不能用 PBRNoTexture：那个不透明 Technique 会**忽略 alpha**，
---    圆盘会变成一块实心黑斑。
---
--- 黑色 × 任何光照 = 黑色，所以视觉上不受光照方向影响 —— 这正是假阴影
--- 需要的：不随相机/光照变化，因此不会像引擎阴影那样漂移。
---
--- ⚠️ 放在**顶层**（不是 Player 模块内）：Monster 与 Battle_Terrain 也要用。
---@return Material|nil
local function getShadowMaterial()
    if not V._shadowMat then
        local tech = cache:GetResource("Technique", "Techniques/PBR/PBRNoTextureAlpha.xml")
        if not tech then
            print("[Visual] ⚠️ PBRNoTextureAlpha.xml 缺失，假阴影不可用")
            return nil
        end
        local mat = Material:new()
        mat:SetTechnique(0, tech)
        -- alpha 基数 0.6：顶点色 alpha 会乘上去，最终中心 = 0.6 × 1.0 = 0.6
        mat:SetShaderParameter("MatDiffColor", Variant(Color(0, 0, 0, 0.6)))
        mat:SetShaderParameter("MatEmissiveColor", Variant(Color(0, 0, 0)))
        mat:SetShaderParameter("Metallic", Variant(0.0))
        mat:SetShaderParameter("Roughness", Variant(1.0))
        V._shadowMat = mat
        print("[Visual] 假阴影材质已创建（黑 alpha=0.6）")
    end
    return V._shadowMat
end
V.getShadowMaterial = getShadowMaterial

--- 往**已有** CustomGeometry 追加一个径向渐变假阴影圆盘（XZ 平面，法线 +Y）。
---
--- 渐变实现：顶点色 alpha 从中心到边缘递减 —— 中心 1.0、中环 0.5、外缘 0.0。
--- 配合材质的 MatDiffColor.a，最终 ≈ 中心 0.6、中环 0.3、边缘 0。
---
--- ⚠️ 本函数是**追加**（append），不调用 Clear/BeginGeometry ——
---    调用方需先 SetNumGeometries(1) + BeginGeometry(0, TRIANGLE_LIST)，
---    全部追加完再 Commit。这样多个圆盘可以合进一个 geometry（省 draw call）。
---
--- ⚠️ 顶点色 alpha 是否生效取决于 Technique 是否声明 VERTEXCOLOR。
---    若实测边缘仍是硬边（alpha 未生效），降级方案见对话记录。
---
---@param g CustomGeometry
---@param cx number 中心 X（世界坐标）
---@param cz number 中心 Z（世界坐标）
---@param radius number 半径（米）
---@param y number 放置高度（世界 Y）
---@param segs? integer 圆周分段（默认 16；树/石可用 8 省顶点）
function V.appendShadowDisc(g, cx, cz, radius, y, segs)
    segs = segs or 16
    local n = Vector3(0, 1, 0)
    -- 3 环：内 0.4、中 0.7、外 1.0，对应 alpha 1.0 / 0.5 / 0.0
    local rings  = { 0.4, 0.7, 1.0 }
    local alphas = { 1.0, 0.5, 0.0 }

    local function pt(r, a)
        return Vector3(
            cx + r * radius * math.cos(a),
            y,
            cz + r * radius * math.sin(a))
    end

    -- 中心扇形（中心 → 内环）：整片 alpha = 1.0
    local ca_in = Color(1, 1, 1, alphas[1])
    local vc = Vector3(cx, y, cz)
    for i = 0, segs - 1 do
        local a1 = 2 * math.pi * i / segs
        local a2 = 2 * math.pi * (i + 1) / segs
        local v1 = pt(rings[1], a1)
        local v2 = pt(rings[1], a2)
        -- 逆时针：center → v2 → v1（叉乘验证过法线朝 +Y）
        g:DefineVertex(vc); g:DefineNormal(n); g:DefineColor(ca_in)
        g:DefineVertex(v2); g:DefineNormal(n); g:DefineColor(ca_in)
        g:DefineVertex(v1); g:DefineNormal(n); g:DefineColor(ca_in)
    end

    -- 环带（第 k 环 → 第 k+1 环）：内环 alpha=a0，外环 alpha=a1
    for k = 1, #rings - 1 do
        local r0, r1 = rings[k], rings[k + 1]
        local ca0 = Color(1, 1, 1, alphas[k])
        local ca1 = Color(1, 1, 1, alphas[k + 1])
        for i = 0, segs - 1 do
            local ang1 = 2 * math.pi * i / segs
            local ang2 = 2 * math.pi * (i + 1) / segs
            local v1a = pt(r0, ang1)   -- 内-起
            local v1b = pt(r0, ang2)   -- 内-终
            local v2a = pt(r1, ang1)   -- 外-起
            local v2b = pt(r1, ang2)   -- 外-终
            -- 三角形 1：内-起 → 内-终 → 外-终
            g:DefineVertex(v1a); g:DefineNormal(n); g:DefineColor(ca0)
            g:DefineVertex(v1b); g:DefineNormal(n); g:DefineColor(ca0)
            g:DefineVertex(v2b); g:DefineNormal(n); g:DefineColor(ca1)
            -- 三角形 2：内-起 → 外-终 → 外-起
            g:DefineVertex(v1a); g:DefineNormal(n); g:DefineColor(ca0)
            g:DefineVertex(v2b); g:DefineNormal(n); g:DefineColor(ca1)
            g:DefineVertex(v2a); g:DefineNormal(n); g:DefineColor(ca1)
        end
    end
end

-- ============================================================
-- 玩家配色（机械师 / 探险者，蓝白主调 + 皮革工具带）
-- ============================================================
local PC = {
    skin     = { 0.95, 0.82, 0.72 },
    skinDark = { 0.82, 0.68, 0.58 },
    hair     = { 0.24, 0.18, 0.14 },
    hairHi   = { 0.34, 0.26, 0.20 },
    shirt    = { 0.30, 0.52, 0.82 },   -- 浅蓝上衣
    shirt2   = { 0.88, 0.92, 0.96 },   -- 白内衬
    pants    = { 0.18, 0.24, 0.38 },   -- 深蓝裤
    leather  = { 0.38, 0.26, 0.16 },
    leather2 = { 0.28, 0.18, 0.10 },
    boot     = { 0.24, 0.16, 0.10 },
    metal    = { 0.72, 0.74, 0.78 },
    brass    = { 0.78, 0.60, 0.28 },
    lens     = { 0.42, 0.72, 0.82 },
    eyeWhite = { 0.96, 0.96, 0.94 },
    eyeDark  = { 0.08, 0.10, 0.16 },
    mouth    = { 0.62, 0.28, 0.28 },
    blade    = { 0.82, 0.86, 0.92 },
}

-- ============================================================
-- 怪物配色（顶点色；再由材质 MatDiffColor 染色）
-- ============================================================
local MC = {
    body     = { 1.00, 1.00, 1.00 },   -- 白（被材质染色）
    bodyDark = { 0.55, 0.55, 0.55 },
    crack    = { 0.72, 0.72, 0.72 },
    eye      = { 0.08, 0.10, 0.12 },
    core     = { 1.00, 1.00, 0.55 },   -- 发光核心（偏黄）
    seed     = { 1.00, 1.00, 0.80 },
    bud      = { 0.80, 1.00, 0.80 },
}

-- ============================================================
-- Visual.Terrain 已拆到 Battle_Terrain.lua（本文件末尾 require）。
-- 顶点工具经 Battle.V 共享，地形材质经 Battle.getTerrainMaterial 共享。
-- ============================================================

-- ============================================================
-- ===== 模块：Visual.Player =====
--
-- 机械师 / 探险者。7 节点：
--   PlayerRig（根，脚底 y=0）
--   ├── Torso（髋部 y=0.85；几何体从局部 0 到 0.60）
--   ├── Head（脖子 y=1.40；几何体局部 0 到 0.40）
--   ├── ArmL（肩 y=1.32，x=+0.22；= 玩家右手，持剑；几何体局部 0 到 -0.70）
--   ├── ArmR（肩 y=1.32，x=-0.22；= 玩家左手，空手）
--   ├── LegL（髋 y=0.85，x=+0.10；几何体局部 0 到 -0.85）
--   └── LegR（髋 y=0.85，x=-0.10；同上）
-- ⚠️ 模型默认朝 +Z，面朝 +Z 时 +X 是玩家右手 —— 故节点名的 L/R 与实际左右相反。
--
-- 每个节点一个 CustomGeometry，内部把多个部件合并成一份顶点列表。
-- DrawCall = 7（1 个节点 1 个 mesh）。
-- ============================================================
do
    local Player = {}

    -- 每个玩家节点各有一份动画状态。
    --
    -- ⚠️ 不能用模块级单例：Update 现在会对「自己 + 所有其他玩家」逐个调用，
    --    共用一份状态会互相覆盖 —— 表现为「别人在附近走动时，自己的角色抽搐」。
    --
    -- 🔴 键必须用**节点名字**，不能用 Node 对象本身：
    --    引擎绑定层每次 GetChild 可能返回新的 Lua 包装对象，
    --    以对象为键会导致「每帧都查不到、每帧都重新初始化」——
    --    表现是朝向每帧从 0 开始重转，永远转不到位（看起来在不停旋转）。
    --    节点名字（"Player_u123"）稳定且唯一，是可靠的主键。
    ---@type table<string, table>
    local states_ = {}

    --- 取（或初始化）某节点的动画状态
    ---@param parentNode Node
    ---@return table
    local function StateOf(parentNode)
        local key = parentNode.name or "?"
        local s = states_[key]
        if not s then
            s = { walkPhase = 0, facingDeg = 0, attackTimer = 0, amp = 0 }
            states_[key] = s
        end
        return s
    end

    --- 玩家下线时清理其动画状态（避免 states_ 无限增长）
    ---@param nodeName string
    function Player.ClearState(nodeName)
        states_[nodeName] = nil
    end

    local ATTACK_DURATION = 0.28   -- 整个挥剑动作耗时（秒）

    -- ---------- 单节点几何体构建 ----------

    --- 躯干：髋/腰/胸/脖 + 腰带 + 胸甲 + 肩甲 + 工具袋
    --- 局部坐标原点在髋部（节点 y=0.85），几何体向上延伸到 0.60
    local function buildTorso(g)
        -- 髋 + 腰（裤色）
        V.revolve(g, 0, 0, {
            { 0.18, 0.00 },
            { 0.21, 0.04 },
            { 0.20, 0.09 },
            { 0.17, 0.16 },
            { 0.17, 0.22 },
        }, 10, PC.pants)

        -- 胸（衬衫）
        V.revolve(g, 0, 0, {
            { 0.17, 0.22 },
            { 0.20, 0.28 },
            { 0.23, 0.40 },
            { 0.23, 0.48 },
            { 0.18, 0.53 },
        }, 10, PC.shirt)

        -- 白内衬（V 领）
        V.revolve(g, 0, 0, {
            { 0.13, 0.45 },
            { 0.11, 0.52 },
            { 0.06, 0.55 },
        }, 8, PC.shirt2)

        -- 脖子
        V.revolve(g, 0, 0, {
            { 0.07, 0.53 },
            { 0.07, 0.60 },
        }, 8, PC.skin)

        -- 腰带（皮带）
        V.revolve(g, 0, 0, {
            { 0.19, 0.12 },
            { 0.21, 0.12 },
            { 0.21, 0.17 },
            { 0.19, 0.17 },
        }, 10, PC.leather)

        -- 腰带扣（前中）
        V.box(g, 0, 0.145, 0.21, 0.06, 0.05, 0.02, PC.brass)

        -- 左工具袋（右侧腰）
        V.box(g, 0.17, 0.10, 0.06, 0.10, 0.14, 0.10, PC.leather2)
        -- 右工具袋
        V.box(g, -0.17, 0.10, 0.06, 0.10, 0.14, 0.10, PC.leather2)

        -- 左胸甲（金属片）
        V.box(g, 0.10, 0.40, 0.18, 0.10, 0.16, 0.03, PC.metal)
        -- 右胸甲
        V.box(g, -0.10, 0.40, 0.18, 0.10, 0.16, 0.03, PC.metal)

        -- 左肩甲（半球形）
        V.sphere(g, 0.23, 0.47, 0, 0.10, 8, 5, PC.metal)
        -- 右肩甲
        V.sphere(g, -0.23, 0.47, 0, 0.10, 8, 5, PC.metal)
    end

    --- 头部：头骨 + 头发（头顶/后脑/鬓角/刘海） + 护目镜 + 五官
    --- 局部原点在脖子（节点 y=1.40）；头骨中心局部 y=0.20
    local function buildHead(g)
        -- 头骨
        V.sphere(g, 0, 0.20, 0, 0.16, 10, 6, PC.skin)

        -- 下巴（略前伸的小方块）
        V.box(g, 0, 0.10, 0.10, 0.14, 0.08, 0.10, PC.skin)

        -- 头发：头顶半球
        V.sphere(g, 0, 0.24, 0, 0.17, 10, 5, PC.hair)
        -- 头发：后脑
        V.sphere(g, 0, 0.20, -0.05, 0.17, 10, 6, PC.hair)
        -- 鬓角（左右）
        V.box(g, 0.16, 0.18, 0, 0.03, 0.20, 0.20, PC.hair)
        V.box(g, -0.16, 0.18, 0, 0.03, 0.20, 0.20, PC.hair)
        -- 刘海（3 片）
        V.box(g, 0.00, 0.32, 0.16, 0.16, 0.04, 0.06, PC.hair)
        V.box(g, 0.13, 0.30, 0.13, 0.10, 0.04, 0.06, PC.hair)
        V.box(g, -0.13, 0.30, 0.13, 0.10, 0.04, 0.06, PC.hair)

        -- 护目镜：头带（环绕）
        V.revolve(g, 0, 0, {
            { 0.175, 0.30 },
            { 0.185, 0.30 },
            { 0.185, 0.33 },
            { 0.175, 0.33 },
        }, 12, PC.leather)
        -- 护目镜：左框
        V.revolve(g, 0, 0, {
            { 0.05, 0.30 },
            { 0.06, 0.30 },
            { 0.06, 0.33 },
            { 0.05, 0.33 },
        }, 10, PC.brass)
        -- 护目镜：右框
        V.revolve(g, 0, 0, {
            { 0.05, 0.30 },
            { 0.06, 0.30 },
            { 0.06, 0.33 },
            { 0.05, 0.33 },
        }, 10, PC.brass)
        -- 镜片（左右）
        V.sphere(g, 0.055, 0.315, 0.17, 0.045, 8, 4, PC.lens)
        V.sphere(g, -0.055, 0.315, 0.17, 0.045, 8, 4, PC.lens)

        -- 眼睛（眼白 + 瞳孔）
        V.sphere(g, 0.055, 0.22, 0.14, 0.025, 6, 4, PC.eyeWhite)
        V.sphere(g, -0.055, 0.22, 0.14, 0.025, 6, 4, PC.eyeWhite)
        V.sphere(g, 0.055, 0.22, 0.16, 0.014, 6, 4, PC.eyeDark)
        V.sphere(g, -0.055, 0.22, 0.16, 0.014, 6, 4, PC.eyeDark)

        -- 眉毛
        V.box(g, 0.055, 0.27, 0.15, 0.05, 0.012, 0.02, PC.hair)
        V.box(g, -0.055, 0.27, 0.15, 0.05, 0.012, 0.02, PC.hair)

        -- 嘴
        V.box(g, 0, 0.15, 0.155, 0.04, 0.008, 0.02, PC.mouth)
    end

    --- 单侧手臂；mirror = 1（左） / -1（右）
    --- 局部原点在肩关节；几何体向下延伸到 y=-0.70
    ---@param mirror number
    ---@param withSword boolean
    local function buildArm(g, mirror, withSword)
        -- 肩球
        V.sphere(g, 0, 0, 0, 0.08, 8, 5, PC.shirt)

        -- 上臂（肤色）
        V.revolve(g, 0, 0, {
            { 0.065, 0.00 },
            { 0.065, -0.18 },
            { 0.055, -0.32 },
        }, 8, PC.skin)

        -- 肘
        V.sphere(g, 0, -0.32, 0, 0.058, 8, 5, PC.skinDark)

        -- 前臂
        V.revolve(g, 0, 0, {
            { 0.055, -0.32 },
            { 0.050, -0.50 },
            { 0.055, -0.62 },
        }, 8, PC.skin)

        -- 护腕
        V.revolve(g, 0, 0, {
            { 0.068, -0.55 },
            { 0.075, -0.55 },
            { 0.075, -0.61 },
            { 0.068, -0.61 },
        }, 8, PC.leather)

        -- 手
        V.sphere(g, 0, -0.68, 0, 0.060, 8, 5, PC.skin)

        -- 剑（仅右手）
        if withSword then
            -- 剑柄
            V.box(g, 0, -0.72, 0.02, 0.03, 0.08, 0.03, PC.leather)
            -- 护手
            V.box(g, 0, -0.77, 0.02, 0.14, 0.02, 0.05, PC.brass)
            -- 剑刃
            V.box(g, 0, -0.92, 0.02, 0.04, 0.28, 0.015, PC.blade)
            -- 剑尖（短锥）
            V.revolve(g, 0, 0.02, {
                { 0.022, -1.06 },
                { 0.000, -1.12 },
            }, 6, PC.blade)
        end
    end

    --- 单侧腿；mirror = 1（左） / -1（右）
    --- 局部原点在髋关节；几何体向下延伸到 y=-0.85
    ---@param mirror number
    local function buildLeg(g, mirror)
        -- 大腿（裤色）
        V.revolve(g, 0, 0, {
            { 0.085, 0.00 },
            { 0.090, -0.20 },
            { 0.080, -0.38 },
        }, 8, PC.pants)

        -- 膝
        V.sphere(g, 0, -0.40, 0, 0.078, 8, 5, PC.pants)

        -- 小腿
        V.revolve(g, 0, 0, {
            { 0.080, -0.40 },
            { 0.072, -0.62 },
            { 0.085, -0.75 },
        }, 8, PC.boot)

        -- 靴子
        V.box(g, 0, -0.80, 0.03, 0.15, 0.10, 0.22, PC.boot)
        -- 靴头（金属包边）
        V.box(g, 0, -0.80, 0.14, 0.12, 0.06, 0.02, PC.brass)
    end

    --- 创建一个部件节点
    ---@param parent Node
    ---@param name string
    ---@param x number
    ---@param y number
    ---@param z number
    ---@param buildFn fun(g: CustomGeometry)
    ---@return Node
    local function makePart(parent, name, x, y, z, buildFn)
        local node, g = V.beginPart(parent, name, x, y, z)
        buildFn(g)
        g:Commit()
        -- 第二批改动：玩家全部部件换成 Toon 材质 + 加黑色描边。
        -- ⚠️ 本函数只被 Player 模块使用（其他玩家模型也走 Player.Build，
        --    因此它们也会一起 Toon 化）；Monster 模块不走这里。
        local mat = getCharacterMaterial()
        if mat then g:SetMaterial(mat) end
        g:SetOutlineEnabled(true)
        g:SetOutlineThickness(0.008)
        g:SetOutlineColor(Color(0.0, 0.0, 0.0, 1.0))
        -- 🔴 关掉引擎阴影投射（2026-10-04）。
        --    原因：方向光的阴影由**相机视锥**驱动，相机转动时阴影方向会漂移
        --    （表现为被拉长、乱跑）。这是引擎固有行为，已实测无法用参数修正。
        --    角色阴影改由 ShadowDisc 假阴影承担（不依赖引擎阴影，故不漂移）。
        --    ⚠️ 若恢复成 true，假阴影会和漂移的引擎阴影**同时出现**，更难看。
        g.castShadows = false
        return node
    end

    --- 触发一次挥剑动画。多次调用只重置计时（不会叠加）。
    ---@param parentNode Node 玩家根节点（自己的或别人的）
    function Player.PlayAttack(parentNode)
        if not parentNode then return end
        StateOf(parentNode).attackTimer = ATTACK_DURATION
    end

    --- 构建玩家模型（挂在 parentNode 下，创建 PlayerRig 子节点）
    ---@param parentNode Node
    function Player.Build(parentNode)
        -- 避免重复挂载
        if parentNode:GetChild("PlayerRig", false) then return end

        local root = parentNode:CreateChild("PlayerRig", LOCAL)

        -- 假阴影：贴在角色脚下的半透明黑色圆盘（替代引擎阴影）。
        -- 🔴 挂在 parentNode（玩家节点）下，**不挂 PlayerRig 下** ——
        --    PlayerRig 会随角色朝向旋转（见 Player.Update 的平滑转向），
        --    而阴影不该跟着转。玩家节点本身不旋转，是正确的位置。
        -- ⚠️ Y = 0.05：略高于地面，避免与地形 z-fighting 闪烁。
        --    坡地上圆盘是水平的、地面是斜的 → 边缘可能穿插，属已知限制。
        local shadowNode = parentNode:CreateChild("ShadowDisc", LOCAL)
        shadowNode.position = Vector3(0, 0.05, 0)
        -- 椭圆：X 略宽、Z 略窄，模拟斜射光下被拉长的投影
        shadowNode:SetScale(Vector3(0.9, 1.0, 0.55))
        local shadowGeom = shadowNode:CreateComponent("CustomGeometry", LOCAL)
        shadowGeom:SetNumGeometries(1)
        shadowGeom:BeginGeometry(0, TRIANGLE_LIST)
        V.appendShadowDisc(shadowGeom, 0, 0, 1.0, 0, 16)
        shadowGeom:Commit()
        local smat = V.getShadowMaterial()
        if smat then shadowGeom:SetMaterial(smat) end
        shadowGeom.castShadows = false   -- 假阴影自己不投影

        makePart(root, "Torso", 0, 0.85, 0, buildTorso)
        makePart(root, "Head",  0, 1.40, 0, buildHead)
        -- ⚠️ 命名与实际左右的对应关系：
        --    玩家模型默认朝 +Z。面朝 +Z 时，+X 侧是玩家的**右手**，-X 侧是**左手**。
        --    所以 "ArmL" 节点（x=+0.22）实际是玩家**右手**（持剑），
        --    "ArmR" 节点（x=-0.22）实际是玩家**左手**（空手）。
        --    命名沿用历史（改起来要动所有引用），靠这条注释对齐实际左右。
        makePart(root, "ArmL",  0.22, 1.32, 0, function(g) buildArm(g,  1, true)  end)
        makePart(root, "ArmR", -0.22, 1.32, 0, function(g) buildArm(g, -1, false) end)
        makePart(root, "LegL",  0.10, 0.85, 0, function(g) buildLeg(g,  1) end)
        makePart(root, "LegR", -0.10, 0.85, 0, function(g) buildLeg(g, -1) end)

        print("[Visual.Player] 玩家模型已挂载（7 节点）")
    end

    --- 每帧驱动玩家动画
    ---@param parentNode Node 玩家根节点（myNode_）
    ---@param dt number
    ---@param isMoving boolean
    ---@param facing number 朝向弧度（YawAngle 口径）
    function Player.Update(parentNode, dt, isMoving, facing)
        local root = parentNode:GetChild("PlayerRig", false)
        if not root then return end

        local st = StateOf(parentNode)

        -- 平滑转向（facing 为 nil 表示「暂无朝向数据」，保持当前朝向不动）
        if facing then
            local targetDeg = facing * 180 / math.pi
            -- 最短角度差。用取模而非 while 循环：facingDeg 长期累积后可能远超 ±360，
            -- 单次 while 减不完，会算出「绕远路」的差值 → 模型来回甩（抽搐）。
            local diff = (targetDeg - st.facingDeg + 180) % 360 - 180
            st.facingDeg = st.facingDeg + diff * math.min(1, dt * 14)
            -- 归一化到 (-180, 180]，避免无限累积
            st.facingDeg = (st.facingDeg + 180) % 360 - 180
            root.rotation = Quaternion(st.facingDeg, Vector3.UP)
        end

        -- ⚠️ 父节点（Player_<pid>）的旋转保持为单位四元数：
        --    root 是它的**子节点**，子旋转是相对父旋转的。父节点一旦带上旋转，
        --    模型世界朝向 = 父 × 子，会翻倍/漂移。朝向一律只由 root 负责。

        -- 走路摆动
        st.walkPhase = st.walkPhase + dt * 8

        -- 摆动幅度做平滑过渡（约 0.12 秒到位）。
        -- ⚠️ 直接用 `isMoving and 32 or 0` 会让腿在起步/停步时**瞬间**弹到极限或弹回，
        --    看起来像抽搐。平滑后起步是「渐入」、停步是「渐出」，自然得多。
        local targetAmp = isMoving and 32 or 0
        st.amp = st.amp + (targetAmp - st.amp) * math.min(1, dt * 8)

        local amp = st.amp
        local legSwing = math.sin(st.walkPhase) * amp
        local armSwing = -legSwing * 0.75

        local legL = root:GetChild("LegL", false)
        local legR = root:GetChild("LegR", false)
        local armL = root:GetChild("ArmL", false)   -- 玩家右手（持剑）
        local armR = root:GetChild("ArmR", false)   -- 玩家左手（空手）

        if legL then legL.rotation = Quaternion( legSwing, Vector3.RIGHT) end
        if legR then legR.rotation = Quaternion(-legSwing, Vector3.RIGHT) end

        -- 左手：只有走路摆动
        if armR then armR.rotation = Quaternion(-armSwing, Vector3.RIGHT) end

        -- 右手（节点名 ArmL）：攻击动画优先于走路摆动
        if armL then
            if st.attackTimer > 0 then
                st.attackTimer = st.attackTimer - dt
                if st.attackTimer < 0 then st.attackTimer = 0 end

                local t = 1 - st.attackTimer / ATTACK_DURATION   -- 0 → 1
                -- 前 30%：抬臂（0 → -70°，负角度是向后抬）
                -- 后 70%：挥下（-70° → +80°，正向挥到前方）
                local angle
                if t < 0.30 then
                    angle = -70 * (t / 0.30)
                else
                    angle = -70 + 150 * ((t - 0.30) / 0.70)
                end
                armL.rotation = Quaternion(angle, Vector3.RIGHT)
            else
                armL.rotation = Quaternion(armSwing, Vector3.RIGHT)
            end
        end
    end

    -- 注入
    Battle.Visual = Battle.Visual or {}
    Battle.Visual.Player = Player
end

-- ============================================================
-- ===== 模块：Visual.Monster =====
--
-- 普通怪 / 精英怪：同一几何体，不同材质（顶点色白，材质 MatDiffColor 染主色）。
-- BOSS：晶体花，3 节点（核心晶体 / 花瓣组 / 根须组），做旋转呼吸。
-- ============================================================
do
    local Monster = {}

    -- BOSS 动画相位：node → phase（用弱键表，节点销毁后自动回收）
    ---@type table<Node, number>
    local bossPhase_ = setmetatable({}, { __mode = "k" })

    -- ---------- 普通怪 / 精英怪：种子囊袋 ----------
    -- 几何体局部原点在脚下 y=0，囊体从 0 到约 0.95m
    local function buildSeedSac(g)
        -- 主囊（水滴形：底部宽，顶部窄）
        V.revolve(g, 0, 0, {
            { 0.00, 0.00 },
            { 0.34, 0.06 },
            { 0.48, 0.21 },
            { 0.52, 0.41 },
            { 0.48, 0.64 },
            { 0.38, 0.83 },
            { 0.20, 1.00 },
            { 0.00, 1.10 },
        }, 10, MC.body)

        -- 表面裂纹（4 条纵向凸起）
        for k = 0, 3 do
            local a = k * math.pi / 2 + math.pi / 8
            local nx, nz = math.cos(a), math.sin(a)
            -- 沿径向向外凸的小方块
            V.box(g,
                nx * 0.48, 0.49, nz * 0.48,
                0.07, 0.33, 0.07,
                MC.crack)
        end

        -- 两只小眼挤在一起（前方偏下）
        V.sphere(g, 0.10, 0.35, 0.48, 0.05, 8, 5, MC.eye)
        V.sphere(g, -0.10, 0.35, 0.48, 0.05, 8, 5, MC.eye)

        -- 顶部发芽（3 片小叶）
        V.box(g, 0, 1.14, 0, 0.04, 0.12, 0.09, MC.bud)
        V.box(g, 0.06, 1.19, 0, 0.07, 0.07, 0.05, MC.bud)
        V.box(g, -0.06, 1.19, 0, 0.07, 0.07, 0.05, MC.bud)

        -- 内部发光核心（从顶部露出一点点）
        V.sphere(g, 0, 1.03, 0, 0.09, 8, 5, MC.core)
    end

    -- ---------- BOSS：晶体花（3 节点）----------

    --- 核心晶体（八面体，自发光金）
    local function buildBossCore(g)
        -- 上下两个锥体拼成八面体
        V.revolve(g, 0, 0, {
            { 0.00, -0.60 },
            { 0.55, -0.10 },
            { 0.55,  0.10 },
            { 0.00,  0.60 },
        }, 8, MC.core)
    end

    --- 花瓣组（8 片向外放射，略倾斜向上）
    local function buildBossPetals(g)
        local nPetals = 8
        local innerR  = 0.45
        local outerR  = 1.30
        local petalW  = 0.22
        local petalT  = 0.08
        local tilt    = 0.55   -- 向上倾斜比例

        for i = 0, nPetals - 1 do
            local a = 2 * math.pi * i / nPetals
            local c, s = math.cos(a), math.sin(a)

            -- 花瓣底部（在核心外缘）
            local bx, bz = c * innerR, s * innerR
            local by = 0
            -- 花瓣顶部（外缘 + 上抬）
            local tx, tz = c * outerR, s * outerR
            local ty = tilt * (outerR - innerR)

            -- 切线方向 = (-sin, 0, cos)，即垂直于花瓣径向
            local tgx, tgz = -s, c
            local hw = petalW * 0.5
            local ht = petalT * 0.5

            -- 8 个顶点：沿切线方向展开宽度，沿竖直方向展开厚度
            local function pv(signW, signT, x, y, z)
                return Vector3(x + tgx * hw * signW, y + ht * signT, z + tgz * hw * signW)
            end
            local b00 = pv(-1, -1, bx, by, bz)
            local b10 = pv( 1, -1, bx, by, bz)
            local b11 = pv( 1,  1, bx, by, bz)
            local b01 = pv(-1,  1, bx, by, bz)
            local t00 = pv(-1, -1, tx, ty, tz)
            local t10 = pv( 1, -1, tx, ty, tz)
            local t11 = pv( 1,  1, tx, ty, tz)
            local t01 = pv(-1,  1, tx, ty, tz)

            -- 4 侧面 + 2 端面
            V.quad(g, b00, b10, t10, t00, MC.core)   -- -Y 侧
            V.quad(g, b01, t01, t11, b11, MC.core)   -- +Y 侧
            V.quad(g, b00, t00, t01, b01, MC.core)   -- -T 侧
            V.quad(g, b10, b11, t11, t10, MC.core)   -- +T 侧
            V.tri (g, b00, b01, b11, MC.core)        -- 底端
            V.tri (g, b00, b11, b10, MC.core)
            V.tri (g, t00, t10, t11, MC.core)        -- 顶端
            V.tri (g, t00, t11, t01, MC.core)
        end
    end

    --- 根须组（3 条向下延伸的细长柱）
    local function buildBossRoots(g)
        for i = 0, 2 do
            local a = 2 * math.pi * i / 3
            local c, s = math.cos(a), math.sin(a)
            local ox, oz = c * 0.22, s * 0.22
            V.revolve(g, ox, oz, {
                { 0.05, -0.70 },
                { 0.07, -0.80 },
                { 0.10, -1.20 },
                { 0.04, -1.35 },
            }, 6, MC.bodyDark)
        end
    end

    -- ---------- 材质缓存 ----------
    local mats_ = {}     -- kind → Material

    --- 取怪物材质（Toon SurfaceShader + tint 染色）。
    ---
    --- ⚠️ 从 "DiffVCol + MatDiffColor" 改为 "character_toon.shader + tint_color"：
    ---    SurfaceShader 是否支持引擎内置的 MatDiffColor 未验证，
    ---    改用自定义 uniform 更可靠（fragment() 里明确读 tint_color）。
    ---
    --- ⚠️ 保留旧路径作为回退：SurfaceShader 加载失败时走 DiffVCol 分支。
    ---@param kind string "normal" | "boss"
    ---@return Material|nil
    local function makeTintedMaterial(kind)
        local r, g, b = 1, 1, 1
        if kind == "normal" then
            r, g, b = 0.42, 0.92, 0.72   -- 青绿
        elseif kind == "boss" then
            r, g, b = 1.00, 0.85, 0.45   -- 金
        end

        -- 主路径：Toon SurfaceShader + tint_color
        local mat = Material:new()
        if mat:SetSurfaceShader("Shaders/BLGL/character_toon.shader") then
            mat:SetShaderParameter("tint_color", Variant(Color(r, g, b, 1)))
            return mat
        end

        -- 回退路径：旧 DiffVCol + MatDiffColor
        print("[Monster] ⚠️ character_toon.shader 加载失败，回退到 DiffVCol")
        local base = getVColMaterial()
        if not base then return nil end
        local fallback = Material:new()
        fallback:SetTechnique(0, base:GetTechnique(0))
        fallback:SetShaderParameter("MatDiffColor", Variant(Color(r, g, b, 1)))
        return fallback
    end

    --- 取某 kind 的主材质
    ---@param kind string
    ---@return Material|nil
    function Monster.GetMaterial(kind)
        kind = kind or "normal"
        if not mats_[kind] then
            mats_[kind] = makeTintedMaterial(kind)
        end
        return mats_[kind]
    end

    --- 给怪物几何体设置材质 + 开启描边。
    ---
    --- ⚠️ character_toon.shader 声明了 render_mode outline，但描边是**逐 Drawable**
    ---    开关（SetOutlineEnabled），材质本身不会自动给所有使用者开描边。
    ---    玩家侧在 makePart 里开了，怪物侧必须同样显式开，否则怪物没有黑边。
    ---@param geom CustomGeometry
    ---@param mat Material|nil
    local function applyMonsterMat(geom, mat)
        if mat then geom:SetMaterial(mat) end
        geom:SetOutlineEnabled(true)
        geom:SetOutlineThickness(0.008)
        geom:SetOutlineColor(Color(0.0, 0.0, 0.0, 1.0))
        -- 关掉引擎阴影投射（同 makePart 的理由：方向光阴影会随相机漂移）。
        -- ⚠️ 怪物暂时**没有**假阴影（本轮只给玩家做了）。
        --    若实测怪物"脚下发飘"，下一轮用同样的 ShadowDisc 方式补上。
        geom.castShadows = false
    end

    --- 给节点挂上怪物模型
    ---
    --- ⚠️ 每个怪物独立构建几何体（没有共享 Model 的接口）。
    ---    本模型约 400 顶点，25 个怪 = 1 万顶点，开销可接受。
    ---@param parentNode Node
    ---@param kind string "normal" | "boss"
    function Monster.Build(parentNode, kind)
        kind = kind or "normal"

        if kind == "boss" then
            -- BOSS 晶体花：3 节点
            local root = parentNode:CreateChild("BossRig", LOCAL)
            local matBoss = Monster.GetMaterial("boss")

            local _, coreG = V.beginPart(root, "Core", 0, 1.4, 0)
            buildBossCore(coreG)
            coreG:Commit()
            applyMonsterMat(coreG, matBoss)

            local _, petalsG = V.beginPart(root, "Petals", 0, 1.4, 0)
            buildBossPetals(petalsG)
            petalsG:Commit()
            applyMonsterMat(petalsG, matBoss)

            local _, rootsG = V.beginPart(root, "Roots", 0, 1.4, 0)
            buildBossRoots(rootsG)
            rootsG:Commit()
            applyMonsterMat(rootsG, matBoss)

            -- 初始化 BOSS 相位（每个 BOSS 独立计时器）
            bossPhase_[parentNode] = 0
            return
        end

        -- 假阴影（与玩家同款，但更小）。
        -- ⚠️ 挂在 parentNode 下、不挂 EnemyRig 下：怪物模型也可能转向，
        --    阴影不该跟着转（与玩家同样的理由）。
        local shadowNode = parentNode:CreateChild("ShadowDisc", LOCAL)
        shadowNode.position = Vector3(0, 0.05, 0)
        shadowNode:SetScale(Vector3(0.6, 1.0, 0.4))   -- 怪物比玩家小
        local shadowGeom = shadowNode:CreateComponent("CustomGeometry", LOCAL)
        shadowGeom:SetNumGeometries(1)
        shadowGeom:BeginGeometry(0, TRIANGLE_LIST)
        V.appendShadowDisc(shadowGeom, 0, 0, 1.0, 0, 16)
        shadowGeom:Commit()
        local smat = V.getShadowMaterial()
        if smat then shadowGeom:SetMaterial(smat) end
        shadowGeom.castShadows = false

        -- 普通 / 精英怪：种子囊袋（单节点）
        local _, g = V.beginPart(parentNode, "EnemyRig", 0, 0, 0)
        buildSeedSac(g)
        g:Commit()

        local mat = Monster.GetMaterial(kind)
        applyMonsterMat(g, mat)
    end

    --- 每帧驱动 BOSS 动画（花瓣旋转 + 核心呼吸）
    ---@param parentNode Node
    ---@param dt number
    function Monster.Update(parentNode, dt)
        local root = parentNode:GetChild("BossRig", false)
        if not root then return end

        -- 相位按节点存（不用 Node:SetVar/GetVar：那是 Variant 接口，
        -- 每帧装箱/拆箱既慢又要手工包 Variant()）。
        local phase = (bossPhase_[parentNode] or 0) + dt
        bossPhase_[parentNode] = phase

        -- 花瓣缓慢旋转
        local petals = root:GetChild("Petals", false)
        if petals then
            petals.rotation = Quaternion(phase * 20, Vector3.UP)
        end

        -- 核心上下浮动（呼吸感）
        local core = root:GetChild("Core", false)
        if core then
            core.position = Vector3(0, 1.4 + math.sin(phase * 1.4) * 0.10, 0)
        end
    end

    -- 注入
    Battle.Visual = Battle.Visual or {}
    Battle.Visual.Monster = Monster
end

-- 🔴 必须在 return 之前 require：Battle_Terrain 会把 Battle.Visual.Terrain 填好，
--    而 Client_Network.lua 在加载期就取 require("Battle_Visual").Visual.Terrain，
--    因此 Terrain 必须在本文件返回之前就位。
--    （Battle_Terrain 只 require Battle_World，不反向 require 本文件，无循环。）
require("Battle_Terrain")

-- 返回 Battle.Visual（供 Client.lua 通过 require("Battle_Visual").Visual 拿到）
return { Visual = Battle.Visual }
