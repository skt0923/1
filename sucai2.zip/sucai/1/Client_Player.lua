-- ============================================================
-- Client_Player.lua：玩家控制 / 攻击 / 死亡 / 拾取（Client.lua 的兄弟文件）
--
-- 职责：摇杆驱动的移动、普攻与自动战斗、击杀结算与掉落、死亡复活、
--       升级/降级请求、受击处理、玩家节点绑定、普攻锁定、拾取入包。
--
-- 与 Client.lua 的关系：
--   · 跨函数共享状态走 Client_State（local S），不 require Client.lua
--   · 两个两边共用的常量（MOVE_SPEED_FALLBACK / AUTO_BATTLE_PICKUP_RANGE）
--     由 Client.lua 在 Start() 里通过 Player.Init 注入，保持单一数据源
--   · Client.lua 侧保留 local 别名（PlayerCtl / UpdateAttack / …），调用点不变
--
-- 依赖：Shared + Client_State + Client_Network + UI_Core + Battle_World /
--       Battle_Visual / Battle_Combat。**不 require Client.lua**。
-- ============================================================
local Shared  = require("Shared")
local Data    = Shared.Data
local Notify  = Shared.Notify
local S       = require("Client_State")
local Net     = require("Client_Network")
local Panels  = require("UI_Core")
local World       = require("Battle_World")
local Visual      = require("Battle_Visual").Visual
local CombatBundle = require("Battle_Combat")

local Terrain = Visual.Terrain
local Enemies = World.Enemies
local Items   = World.Items
local Skills  = CombatBundle.Skills
local Combat  = CombatBundle.Combat

local Player = {}

-- 与 Client.lua 共用的常量（默认值 = 拆分前原值；Start() 里 Player.Init 会覆盖）
Player.MOVE_SPEED_FALLBACK      = 5.0
Player.AUTO_BATTLE_PICKUP_RANGE = 15

-- 只在本文件使用的常量（随玩家逻辑一并迁入）
-- 玩家近战攻击距离（米）。实际判定 = MELEE_RANGE + 怪物半径。
local MELEE_RANGE = 1
-- 自动战斗的「主动寻怪」搜索半径（米）。只在「15m 内无掉落物」时生效。
local AUTO_BATTLE_SEARCH_RANGE = 80
-- 普攻锁定：目标跑出该距离自动取消
local NORMAL_ATTACK_LEASH = 5.0
-- 自动维修间隔（秒）：每 30 分钟自动修一次全身已穿戴装备
local AUTO_REPAIR_INTERVAL = 30 * 60

--- 由 Client.lua 注入共用常量（Start 里调用一次）
---@param c table { MOVE_SPEED_FALLBACK: number, AUTO_BATTLE_PICKUP_RANGE: number }
function Player.Init(c)
    if c.MOVE_SPEED_FALLBACK then Player.MOVE_SPEED_FALLBACK = c.MOVE_SPEED_FALLBACK end
    if c.AUTO_BATTLE_PICKUP_RANGE then Player.AUTO_BATTLE_PICKUP_RANGE = c.AUTO_BATTLE_PICKUP_RANGE end
end

--- 某件装备修满需要的金币（缺失耐久 × 品质单价）
---@param eq table
---@return integer cost, integer missing
local function RepairCostOf(eq)
    local maxDur = math.floor(eq.maxDurability or Shared.C.MAX_DURABILITY or 100)
    local curDur = math.floor(eq.durability or 0)
    local missing = math.max(0, maxDur - curDur)
    return missing * Shared.GetRepairCostPerDurability(eq.quality), missing
end

--- 执行一次自动维修：按「耐久度最低优先」逐件修满全身已穿戴装备。
--- 金币不足时停止，未修的部分留到下次。
---@return integer repaired, integer spent
function Player.DoAutoRepair()
    local d = Data.value

    -- 收集需要维修的装备，按耐久比例从低到高排序（比例 = 对品质差异更公平）
    local need = {}
    for _, slot in ipairs(Shared.SLOT_LIST) do
        local eq = d.equipment[slot]
        if eq then
            local cost, missing = RepairCostOf(eq)
            if missing > 0 and cost > 0 then
                local maxDur = math.floor(eq.maxDurability or Shared.C.MAX_DURABILITY or 100)
                table.insert(need, {
                    slot = slot,
                    eq = eq,
                    cost = cost,
                    ratio = maxDur > 0 and (math.floor(eq.durability or 0) / maxDur) or 1,
                })
            end
        end
    end
    if #need == 0 then return 0, 0 end
    table.sort(need, function(a, b) return a.ratio < b.ratio end)

    local repaired, spent = 0, 0
    for _, n in ipairs(need) do
        if (d.gold or 0) < n.cost then
            -- 金币不足：停止，剩余装备下次再修
            break
        end
        Data.SpendGold(n.cost)
        n.eq.durability = math.floor(n.eq.maxDurability or Shared.C.MAX_DURABILITY or 100)
        repaired = repaired + 1
        spent = spent + n.cost
    end

    if repaired > 0 then
        Data.MarkDirty("equipment")
        Data.MarkDirty("gold")
        Notify.Toast(string.format("自动维修：修复 %d 件装备，消耗 %d 金币", repaired, spent))
    end
    return repaired, spent
end

--- 自动维修：每 30 分钟一次（开启时由调用方立即先修一次）。
---@param dt number
function Player.UpdateAutoRepair(dt)
    local d = Data.value
    if not d.autoRepair then
        d.autoRepairTimer = 0
        return
    end

    d.autoRepairTimer = (d.autoRepairTimer or 0) + dt
    if d.autoRepairTimer < AUTO_REPAIR_INTERVAL then return end
    d.autoRepairTimer = 0

    Player.DoAutoRepair()
end

--- 掉落物当前是否真的捡得起来。
--- ⚠️ 必须与 Items.Update / Items.SetCallbacks(onPickup) 的拾取条件保持一致。
---    否则会出现死循环：地上留着一个「捡不起来」的掉落物（归属保护期内 /
---    背包满且未连服没有邮箱兜底），自动战斗会一直判定「有掉落物」→
---    站在原地既不捡也不找怪，挂机彻底卡死。
---@param gi table
---@return boolean
function Player.CanPickDrop(gi)
    local d = Data.value
    if d.isStanding or d.isDead then return false end
    -- 非归属者永远捡不起来（与 Items.Update 的 ownerOk 判定保持一致）：
    -- 保护期内不可捡，保护期过后也不开放给他人，掉落物等 LIFETIME 超时消失。
    if gi.ownerId and gi.ownerId ~= Data.GetPlayerId() then
        return false
    end
    -- 背包满 + 非堆叠物 + 未连服（没有邮箱兜底）→ onPickup 会返回 false
    -- ⚠️ 用 Data.IsStackable（单一事实来源）：手写类型列表会漏新增的堆叠类型。
    local inv = d.inventory
    if #inv >= Data.BagCapacity()
        and not Data.IsStackable(gi.item)
        and not Net.conn then
        return false
    end
    return true
end

function Player.CancelNormalAttackLock()
    S.normalAttackTargetId_ = nil
    Data.value.normalAttackOn = false
end
-- ============ 玩家控制 ============


---@param dt number
---@param stats table
function Player.Update(dt, stats)
    if not S.myNode_ then return end
    local d = Data.value
    if d.isDead or d.isStanding then return end

    local mag = math.sqrt(S.joyX_ * S.joyX_ + S.joyY_ * S.joyY_)
    if mag > 0.16 then
        -- ⚠️ 摇杆是**屏幕坐标系**：x > 0 向右、y < 0 向上（见 VirtualControls：
        --    keyUp 时 ky = ky - 1，右移时 kx = kx + 1）。
        --    本引擎（Urho3D 左手系 + 相机 LookAt）下，相机在玩家 +Z 侧看向 -Z 时，
        --    世界 +X 出现在屏幕**左**侧 —— 已用红/蓝方块实测确认。
        --    因此屏幕右 = 世界 -X，摇杆 x 必须取反，否则左右操作完全镜像
        --    （表现为「摇杆只能前进」：左右也能走，但方向反了）。
        --    前推 = 屏幕 -y，取反后即相机前进方向。
        local nx, ny = -S.joyX_ / mag, -S.joyY_ / mag

        local sy, cy = math.sin(S.camYaw_), math.cos(S.camYaw_)
        local dirX = -ny * sy + nx * cy
        local dirZ = -ny * cy - nx * sy
        local speed = (stats.moveSpeed or Player.MOVE_SPEED_FALLBACK) * math.min(1, mag / 0.85)
        -- ⚠️ 只改本地权威变量，由 OnUpdate 每帧统一写回节点
        local nxp = S.localPlayerX_ + dirX * speed * dt
        local nzp = S.localPlayerZ_ + dirZ * speed * dt
        -- 地图边界
        S.localPlayerX_ = Shared.Clamp(nxp, -5000, 5000)
        S.localPlayerZ_ = Shared.Clamp(nzp, -5000, 5000)
        -- 朝向：面朝移动方向（供 Net.SyncToServer 上报给其他玩家）
        S.playerFacing_ = math.atan2(dirX, dirZ)
    end
end
-- ============ 攻击 ============
---@param dt number
---@param stats table
function Player.UpdateAttack(dt, stats)
    if S.meleeCooldown > 0 then
        S.meleeCooldown = S.meleeCooldown - dt
    end

    local d = Data.value
    if d.isDead or d.isStanding then
        if d.normalAttackOn then Player.CancelNormalAttackLock() end
        S.autoBattleTargetId_ = nil   -- 死亡/罚站时清自动战斗锁定
        return
    end

    -- 关闭自动战斗时清锁定（避免重新开启时沿用旧目标）
    if not d.autoBattleOn and S.autoBattleTargetId_ then
        S.autoBattleTargetId_ = nil
    end

    -- 自动战斗与普攻锁定互斥
    if d.autoBattleOn and d.normalAttackOn then
        Player.CancelNormalAttackLock()
    end

    -- ============ 自动战斗分支 ============
    if d.autoBattleOn then
        if d.isStanding or d.onlineTokenSeconds <= 0 then return end

        local px, pz = S.localPlayerX_, S.localPlayerZ_
        local alive = Enemies.GetAliveList()

        -- 判断是否有「捡得起来」的掉落物（15m 内）→ 有的话，只打「贴脸怪」，
        -- 不主动寻远处的怪（捡不到的掉落物不能算，否则会站在原地卡死）
        local hasDrop = false
        for _, gi in ipairs(Items.GetAll()) do
            if Shared.Dist2D(px, pz, gi.x, gi.z) < Player.AUTO_BATTLE_PICKUP_RANGE
                and Player.CanPickDrop(gi) then
                hasDrop = true
                break
            end
        end

        -- 找最近的怪（用于两种情况）
        local nearest, minD = nil, math.huge
        for _, e in ipairs(alive) do
            local dist = Shared.Dist2D(px, pz, e.x, e.z)
            if dist < minD then minD = dist; nearest = e end
        end
        if not nearest then return end

        -- 有掉落物时：只反击「已经贴脸（近战范围内）」的怪，不打远处的怪
        if hasDrop then
            local reach = MELEE_RANGE + (nearest.radius or 0.5)
            -- ⚠️ 先转向目标，再判断是否攻击。否则站位刚好在范围内时，
            --    玩家会保持原朝向挥剑（背对怪物），视觉上像在打空气。
            if minD > 0.001 then
                local dx, dz = nearest.x - px, nearest.z - pz
                S.playerFacing_ = math.atan2(dx, dz)
            end
            if minD <= reach then
                if S.meleeCooldown <= 0 then
                    S.meleeCooldown = 1.0 / math.max(0.15, stats.atkSpeed or 1.0)
                    Combat.PlayerAttack(stats, nearest, alive)
                    if Visual.Player.PlayAttack then Visual.Player.PlayAttack(S.myNode_) end
                end
            end
            return
        end

        -- 无掉落物时：使用**锁定目标**（打到它死或超搜索范围才换）。
        --
        -- 🔴 不能每帧重新找最近的怪：第二只怪从侧面走近、距离更近时，
        --    会抢走攻击目标（表现为"玩家正在打 A，B 过来就切去打 B"）。
        --    改为锁定：一旦选定 target，就只打它，直到它死亡、被销毁、
        --    或超出 AUTO_BATTLE_SEARCH_RANGE。

        -- ① 检查当前锁定目标是否仍有效
        local target = nil
        if S.autoBattleTargetId_ then
            for _, e in ipairs(alive) do
                if e.id == S.autoBattleTargetId_ then target = e; break end
            end
            -- 锁定目标已消失（死亡/被销毁）→ 清锁定
            if not target then S.autoBattleTargetId_ = nil end
        end

        -- ② 无有效锁定 → 选最近的怪作为新目标（限制在搜索范围内）
        if not target then
            if minD > AUTO_BATTLE_SEARCH_RANGE then return end
            target = nearest
            S.autoBattleTargetId_ = target.id
        end

        -- ③ 锁定目标超出搜索范围 → 清锁定，下一帧重新选
        local targetD = Shared.Dist2D(px, pz, target.x, target.z)
        if targetD > AUTO_BATTLE_SEARCH_RANGE then
            S.autoBattleTargetId_ = nil
            return
        end

        -- ④ 攻击/追击锁定的目标
        local reach = MELEE_RANGE + (target.radius or 0.5)

        if targetD > 0.001 then
            local dx, dz = target.x - px, target.z - pz
            S.playerFacing_ = math.atan2(dx, dz)
        end

        if targetD <= reach then
            if S.meleeCooldown <= 0 then
                S.meleeCooldown = 1.0 / math.max(0.15, stats.atkSpeed or 1.0)
                Combat.PlayerAttack(stats, target, alive)
                if Visual.Player.PlayAttack then Visual.Player.PlayAttack(S.myNode_) end
            end
        else
            local dx, dz = target.x - px, target.z - pz
            local speed = stats.moveSpeed or Player.MOVE_SPEED_FALLBACK
            S.localPlayerX_ = S.localPlayerX_ + (dx / targetD) * speed * dt
            S.localPlayerZ_ = S.localPlayerZ_ + (dz / targetD) * speed * dt
        end
        return
    end

    -- ============ 普攻锁定分支：只打被锁定的那只 ============
    if not d.normalAttackOn or not S.normalAttackTargetId_ then return end

    local target = nil
    for _, e in ipairs(Enemies.GetAliveList()) do
        if e.id == S.normalAttackTargetId_ then target = e; break end
    end
    if not target then
        Player.CancelNormalAttackLock()
        return
    end

    local px, pz = S.localPlayerX_, S.localPlayerZ_
    local dist = Shared.Dist2D(px, pz, target.x, target.z)
    -- 目标跑太远则脱锁
    if dist > NORMAL_ATTACK_LEASH then
        Player.CancelNormalAttackLock()
        return
    end

    -- ⚠️ 先转向目标（同自动战斗分支的理由：否则会在攻击瞬间背对目标挥剑）
    if dist > 0.001 then
        local dx, dz = target.x - px, target.z - pz
        S.playerFacing_ = math.atan2(dx, dz)
    end

    local reach = MELEE_RANGE + (target.radius or 0.5)
    if dist > reach then
        -- 只在自己没操作摇杆时自动贴近，避免和玩家输入打架
        local joyMag = math.sqrt(S.joyX_ * S.joyX_ + S.joyY_ * S.joyY_)
        if joyMag <= 0.16 and dist > 0.001 then
            local dx, dz = target.x - px, target.z - pz
            local speed = stats.moveSpeed or Player.MOVE_SPEED_FALLBACK
            S.localPlayerX_ = S.localPlayerX_ + (dx / dist) * speed * dt
            S.localPlayerZ_ = S.localPlayerZ_ + (dz / dist) * speed * dt
        end
        return
    end

    if S.meleeCooldown <= 0 then
        S.meleeCooldown = 1.0 / math.max(0.15, stats.atkSpeed or 1.0)
        Combat.PlayerAttack(stats, target, Enemies.GetAliveList())
        if Visual.Player.PlayAttack then Visual.Player.PlayAttack(S.myNode_) end
    end
end
-- ============ 击杀结算 ============
---@param enemy table
function Player.HandleEnemyKilled(enemy)
    if enemy.__killedHandled then return end
    enemy.__killedHandled = true

    -- 共享 Boss 完全由服务端处理：本地血量归零不代表真的死了
    -- （可能有别的玩家/服务端判定），击杀奖励由服务端走邮件发放。
    if enemy.isSharedBoss then return end

    -- 🆕 击杀回复（killHeal）：无条件触发，不论谁杀的。
    --    之前写在 Combat.PlayerAttack 里只能覆盖「普攻直接击杀」，
    --    DoT 击杀走 Skills.Update 不经过那里 → 技能击杀不回血。
    local stats = Combat.ComputeStats(Data.value.equipment)
    if (stats.killHeal or 0) > 0 then
        Data.value.hp = math.floor(math.min(stats.maxHp, Data.value.hp + stats.killHeal))
    end

    -- 锁定的目标死了就解锁，避免一直对着尸体发呆
    if S.normalAttackTargetId_ == enemy.id then
        Player.CancelNormalAttackLock()
    end

    -- 本地击杀累计：单计数器，跨段位自动清零。
    -- ⚠️ 用「怪物等级」而非「玩家位置」判定区域：击杀的是哪一级的怪，
    --    就属于哪个段位的进度。
    local enemyLv = math.max(1, math.floor(enemy.level or 1))
    local tier = math.floor(enemyLv / 10)
    if S.localKillTier_ ~= tier then
        -- 换段位 → 丢弃上一段位的进度，从头计
        S.localKillTier_ = tier
        S.localKillCount_ = 0
    end
    S.localKillCount_ = S.localKillCount_ + 1
    local threshold = Shared.BossKillThreshold(enemyLv)
    if S.localKillCount_ >= threshold then
        S.localKillCount_ = S.localKillCount_ - threshold
        if Net.conn and S.myNode_ then
            Net.conn:SendRemoteEvent(Shared.EVENTS.REPORT_LOCAL_KILL, true, Shared.ToVariantMap({
                KillType = "boss", X = S.myNode_.position.x, Z = S.myNode_.position.z,
            }))
            -- ⚠️ 措辞不能写「已获得」：是否出卷由服务端 roll 决定，
            --    结果由 Net.OnSummonScrollResult 回包后弹出。
            Notify.Toast("击杀累计达标，正在判定…")
        end
    end

    -- 升级改为金币驱动 + 段位门槛（服务端权威，见 Server_System.OnLevelUp）
    -- 客户端不再本地升级

    Enemies.MarkDead(enemy.id)

    local d = Data.value
    local drops, gold, spirits = Shared.RollDrops(enemy.level)

    if gold > 0 then
        d.gold = d.gold + gold
        Data.MarkDirty("gold")
        Notify.Toast("💰 +" .. gold)
    end

    for _, item in ipairs(drops) do
        Items.Spawn(
            item,
            enemy.x + (math.random() * 2 - 1) * 1.5,
            enemy.z + (math.random() * 2 - 1) * 1.5,
            S.myId_   -- 归属权：60 秒内只有自己可拾取
        )
    end

    -- 精魄直接入背包（不走地面掉落）
    for _, spiritType in ipairs(spirits or {}) do
        Shared.AddSpiritsToInventory(d.inventory, spiritType, 1)
        Data.MarkDirty("inventory")
        local disp = Shared.SPIRIT_DISPLAY[spiritType]
        if disp then
            Notify.Toast(string.format("✨ 获得 %s ×1", disp.name))
        end
    end

    -- 宠物蛋掉落（2% 概率，品质对应怪物段位）
    -- ⚠️ 与精魄一样直接入背包，不走地面掉落
    --    （蛋是可堆叠的，落地会与其他装备掉落混淆）
    if math.random() < Shared.C.PET_EGG_DROP_CHANCE then
        local eggQ = Shared.QualityOfMonsterLevel(enemyLv)
        Shared.AddPetEggsToInventory(d.inventory, eggQ, 1)
        Data.MarkDirty("inventory")
        local disp = Shared.PET_EGG_DISPLAY[eggQ]
        if disp then
            Notify.Toast(string.format("🥚 获得 %s ×1", disp.name))
        end
    end

    -- 击杀扣耐久：耐久最高的 3 件中随机 1 件 -1
    local equipped = {}
    for slot, eq in pairs(d.equipment) do
        if eq and (eq.durability or 0) > 0 then
            table.insert(equipped, { slot = slot, eq = eq })
        end
    end
    if #equipped > 0 then
        table.sort(equipped, function(a, b)
            return (a.eq.durability or 0) > (b.eq.durability or 0)
        end)
        local topN = math.min(3, #equipped)
        local pick = equipped[math.random(topN)]
        pick.eq.durability = math.max(0, pick.eq.durability - Shared.C.KILL_DURABILITY_LOSS)
        Data.MarkDirty("equipment")
    end
end
-- ============ 死亡与复活 ============
local RESPAWN_DELAY = 5.0
-- 无敌截止时间（墙钟秒）。
-- ⚠️ 不能用 os.clock()：本引擎的 os.clock 是 CPU 时间，空闲时不推进。
--    统一用 World.Now()（内部是 GetTime():GetElapsedTime()）。

---@param dt number
---@param stats table
function Player.UpdateDeath(dt, stats)
    S.deathTimer_ = S.deathTimer_ + dt

    -- A3：死亡结算面板的倒计时文字每帧刷新
    if Panels.IsDeathPanelOpen and Panels.IsDeathPanelOpen() then
        Panels.UpdateDeathCountdown(RESPAWN_DELAY - S.deathTimer_)
    end

    if S.deathTimer_ >= RESPAWN_DELAY then
        S.deathTimer_ = 0
        local d = Data.value
        d.isDead = false
        d.hp = stats.maxHp
        -- 回到出生点：只改本地权威变量，节点由 OnUpdate 每帧写回
        S.localPlayerX_ = 0
        S.localPlayerZ_ = 0
        Enemies.Clear()
        Enemies.ForceRefill()
        Player.CancelNormalAttackLock()
        S.invincibleUntil_ = World.Now() + 3.0
        -- 关掉死亡结算面板（若还开着）
        if Panels.IsDeathPanelOpen and Panels.IsDeathPanelOpen() then
            Panels.CloseCurrent()
        end
        Notify.Toast("已在出生点复活（3 秒无敌）")
    end
end
--- A3：死亡结算面板的「立即复活」按钮 → 把死亡计时直接推到终点
function Player.RequestRespawn()
    if Data.value.isDead then
        S.deathTimer_ = RESPAWN_DELAY
    end
end
-- ============ 升级 / 降级请求 ============
--- 等级石升级：消耗金币 → 等级石等级 +1 → 玩家等级同步。
--- 客户端本地权威，与背包/金币/装备一致。
function Player.RequestLevelUp()
    local d = Data.value
    local stone = d.levelStone

    if type(stone) ~= "table" or not stone.level then
        Notify.Toast("请先装备等级石")
        return
    end

    local curLv = stone.level
    if curLv >= Shared.C.MAX_LEVEL then
        Notify.Toast("等级石已达最高等级 Lv." .. Shared.C.MAX_LEVEL)
        return
    end

    local cost = Shared.GetLevelUpCost(curLv)
    if not Data.SpendGold(cost) then
        Notify.Toast(string.format("金币不足（需 %d）", cost))
        return
    end

    stone.level = curLv + 1
    Data.MarkDirty("level")

    -- 里程碑提示
    if stone.level == 10 or stone.level == 20
        or stone.level == 30 or stone.level == 40 then
        Notify.Toast(string.format("💎 等级石升至 Lv.%d（里程碑）", stone.level), "#ffdd44")
    else
        Notify.Toast(string.format("等级石升至 Lv.%d", stone.level))
    end

    if Panels.RefreshIfOpen then
        Panels.RefreshIfOpen("character", Panels.OpenCharacter)
    end
end

--- 等级石降级：无金币消耗，纯惩罚。
--- 降级后检查装备 requiredLevel，超出的卸下（背包满进邮件）。
function Player.RequestLevelDown()
    local d = Data.value
    local stone = d.levelStone

    if type(stone) ~= "table" or not stone.level then
        Notify.Toast("请先装备等级石")
        return
    end

    local curLv = stone.level
    if curLv <= 1 then
        Notify.Toast("等级石已是最低等级")
        return
    end

    -- 🔴 预检：可能卸下 8 件装备，需保证背包有 8 格空间
    --    （降级只有可能卸装备，不会卸等级石本身）
    local freeSlots = Data.BagCapacity() - #d.inventory
    if freeSlots < #Shared.SLOT_LIST then
        Notify.Toast(string.format("背包空间不足（需 %d 格，现有 %d 格）",
            #Shared.SLOT_LIST, freeSlots))
        return
    end

    stone.level = curLv - 1
    local newLv = stone.level

    -- 检查全身 8 件装备
    local unequipped = {}
    for _, slotKey in ipairs(Shared.SLOT_LIST) do
        local eq = d.equipment[slotKey]
        if eq then
            local reqLv = eq.requiredLevel or 1
            if newLv < reqLv then
                table.insert(unequipped, eq)
                d.equipment[slotKey] = nil
            end
        end
    end

    -- 卸下的装备进背包，满则进邮件
    if #unequipped > 0 then
        local inv = d.inventory
        local overflow = {}
        for _, eq in ipairs(unequipped) do
            if #inv < Data.BagCapacity() then
                table.insert(inv, eq)
            else
                table.insert(overflow, eq)
            end
        end
        -- ⚠️ 溢出装备需要发邮件（走服务端机制）——此处仅标脏，
        --    实际邮件发送由服务端响应"装备栏变化"时处理（或客户端调用 ctx 方法）
        if #overflow > 0 then
            -- ⚠️ 本文件的 S 是 ClientState（无 ctx 字段），ctx 在 UI_Core.shared 上
            local ctx = Panels.shared and Panels.shared.ctx
            if ctx and ctx.notifyOverflowEquip then
                ctx.notifyOverflowEquip(overflow)
            else
                print("[Client_Player] ⚠️ notifyOverflowEquip 缺失，回滚降级操作")
                -- 回滚：等级石等级还原
                stone.level = curLv
                -- 装备还原
                for _, eq in ipairs(unequipped) do
                    if eq.slot then d.equipment[eq.slot] = eq end
                end
                for i = #inv, 1, -1 do
                    for _, eq in ipairs(unequipped) do
                        if inv[i] == eq then table.remove(inv, i); break end
                    end
                end
                Data.MarkDirty("equipment")
                Data.MarkDirty("level")
                Notify.Toast("操作失败，请重试")
                return
            end
        end
        Data.MarkDirty("inventory")
    end

    Data.MarkDirty("equipment")
    Data.MarkDirty("level")

    Notify.Toast(string.format("等级石降至 Lv.%d（未返还金币）", newLv))

    if Panels.RefreshIfOpen then
        Panels.RefreshIfOpen("character", Panels.OpenCharacter)
    end
end

function Player.HandleEnemyAttack(enemy, stats)
    -- 复活后的无敌保护期内免疫一切伤害
    if World.Now() < S.invincibleUntil_ then return end

    local before = Data.value.hp
    Combat.EnemyAttack(enemy, stats, Enemies.GetAliveList())
    if Data.value.isDead and before > 0 then
        S.deathTimer_ = 0
        Items.Clear()

        local brokenBefore = {}
        for _, key in ipairs(Shared.SLOT_LIST) do
            local eq = Data.value.equipment[key]
            if eq and (eq.durability or 0) <= 0 then brokenBefore[key] = true end
        end

        -- 全身每件按品质扣耐久（普通 -1 … 传说 -5）
        for _, key in ipairs(Shared.SLOT_LIST) do
            local eq = Data.value.equipment[key]
            if eq then
                local loss = Shared.GetDeathDurabilityLoss(eq.quality)
                eq.durability = math.max(0, (eq.durability or 0) - loss)
            end
        end
        Data.MarkDirty("equipment")

        local damagedSlots = {}
        for _, key in ipairs(Shared.SLOT_LIST) do
            local eq = Data.value.equipment[key]
            if eq and (eq.durability or 0) <= 0 and not brokenBefore[key] then
                table.insert(damagedSlots, Shared.SLOTS[key].name or key)
            end
        end

        local killerSnapshot = {
            name = enemy.name or "怪物",
            level = enemy.level or 1,
            hp = math.max(0, math.floor(enemy.hp or 0)),
            maxHp = math.floor(enemy.maxHp or 0),
            atk = math.floor(enemy.atk or 0),
            armor = math.floor(enemy.armor or 0),
            dodge = enemy.dodge or 0,
            hitRate = enemy.hitRate or 0,
            attackCooldown = enemy.attackCooldown or 1,
            attackRange = enemy.attackRange or 3,
            isBoss = enemy.isBoss or false,
        }
        Panels.OpenDeathPanel(killerSnapshot, damagedSlots)

        if Net.conn then
            Net.conn:SendRemoteEvent(Shared.EVENTS.PLAYER_DEATH, true, Shared.ToVariantMap({}))
        end
    end
end
-- ============ 玩家节点绑定 ============

function Player.TryBindPlayerNode()
    if not S.scene_ or not S.myId_ then return end
    local want = "Player_" .. S.myId_
    local node = S.scene_:GetChild(want, true)
    if not node then
        S.bindRetry_ = S.bindRetry_ + 1
        if S.bindRetry_ % 60 == 0 then
            -- 打印场景现有子节点，便于判断是「服务器没下发」还是「名字对不上」
            local names = {}
            for i = 1, S.scene_:GetNumChildren() do
                names[#names + 1] = S.scene_:GetChild(i - 1).name
            end
            print("[Client] 仍在等待玩家节点同步... 重试 " .. S.bindRetry_
                .. " 查找=" .. want
                .. " 场景子节点=[" .. table.concat(names, ",") .. "]")
        end
        return
    end

    S.myNode_ = node
    -- ⚠️ 用本地权威变量恢复位置（断线重连时 OnAssignPlayer 已把服务端 X/Z 写进这两个变量）
    node.position = Vector3(
        S.localPlayerX_,
        Terrain.GetHeight(S.localPlayerX_, S.localPlayerZ_),
        S.localPlayerZ_)

    -- 模型只挂一次（走 Visual.Player.Build：机械师 7 节点模型）
    if not node:GetChild("PlayerRig", false) then
        Visual.Player.Build(node)
    end

    -- 初始血量
    local stats = Combat.ComputeStats(Data.value.equipment)
    Data.value.maxHp = stats.maxHp
    Data.value.hp = stats.maxHp

    -- ⚠️ 玩家进入游戏立即补满怪物：ForceRefill 把 spawnTimer 拉满，
    --    下一帧 Enemies.Update 立刻刷怪。否则要等 25 秒才出第一波。
    Enemies.ForceRefill()

    print("[Client] 玩家节点已绑定：" .. node.name)
    print(string.format("[Client]   位置=%.2f,%.2f,%.2f  子节点=%d",
        node.position.x, node.position.y, node.position.z, node:GetNumChildren()))
end

--- 切换普攻锁定：按一次锁定最近的怪，再按一次取消。
--- 附近没怪时静默不锁定（不弹提示，避免打断挂机节奏）。
function Player.ToggleNormalAttack()
    local d = Data.value
    if d.isStanding or d.autoBattleOn then return end
    if not S.myNode_ then return end

    if d.normalAttackOn then
        Player.CancelNormalAttackLock()
        return
    end

    local px, pz = S.myNode_.position.x, S.myNode_.position.z
    local nearest, minD = nil, math.huge
    for _, e in ipairs(Enemies.GetAliveList()) do
        local dist = Shared.Dist2D(px, pz, e.x, e.z)
        if dist < minD then minD = dist; nearest = e end
    end
    if not nearest then return end

    S.normalAttackTargetId_ = nearest.id
    d.normalAttackOn = true
end
-- ============ 拾取入包 ============
--- 背包满的装备由 onPickup 里的邮箱兜底处理，不会走到这里；
--- 这里保留一次校验作为最后防线（例如服务端回推导致本地超出）。
---@param item table
function Player.ClientAddToInventory(item)
    -- 自动鉴定 / 分解：判定统一走 Data.DecideAutoHandle，
    -- 避免和邮件路径（Data.ProcessAutoHandleFromSync）的逻辑漂移。
    if Shared.IsEquipment(item) then
        local mode = Data.DecideAutoHandle(item)
        if mode == "decompose" then
            local inv = Data.value.inventory
            if item.identified == false then
                local gold = Shared.GetDecomposeGold(item.quality)
                Data.AddGold(gold)
                Notify.Toast(string.format("自动分解（+%d💰）：%s", gold, item.name or ""))
            else
                Shared.AddFragmentsToInventory(inv, item.quality, 1)
                Notify.Toast("自动分解（碎片）：" .. (item.name or ""))
            end
            Data.MarkDirty("inventory")
            Data.MarkDirty("gold")
            return
        elseif mode == "identify_then_decompose" then
            local inv = Data.value.inventory
            local cost = Shared.GetIdentifyCost(item.quality)
            if Data.SpendGold(cost) then
                item.identified = true
                Shared.AddFragmentsToInventory(inv, item.quality, 1)
                Notify.Toast(string.format(
                    "自动鉴定+分解（-%d💰 → 碎片）：%s", cost, item.name or ""))
                Data.MarkDirty("inventory")
                Data.MarkDirty("gold")
                return
            end
            -- 金币不足：落到下面正常入包
        end
    end

    local inv = Data.value.inventory
    -- ⚠️ 新增可堆叠类型时这里必须同步加分支：漏掉会走 else 被当装备
    --    直接 insert（不堆叠、还受背包格数限制）。
    if Shared.IsFragment(item) then
        Shared.AddFragmentsToInventory(inv, item.fragmentType, item.count or 1)
    elseif Shared.IsSpirit(item) then
        Shared.AddSpiritsToInventory(inv, item.spiritType, item.count or 1)
    elseif Shared.IsToken(item) then
        Shared.AddTokenToInventory(inv, item.tokenType or "online", item.count or 1)
    elseif Shared.IsSummonScroll(item) then
        Shared.AddSummonScrollToInventory(inv, item.scrollType, item.count or 1)
    elseif Shared.IsPetEgg(item) then
        Shared.AddPetEggsToInventory(inv, item.eggQuality, item.count or 1)
    elseif Shared.IsPetMaterial(item) then
        Shared.AddPetMaterialsToInventory(inv, item.materialQuality, item.count or 1)
    else
        if #inv >= Data.BagCapacity() then
            Notify.Toast("背包已满")
            return
        end
        table.insert(inv, item)
    end
    Data.MarkDirty("inventory")
end

return Player
