-- ============================================================
-- Client.lua：客户端主控
--
-- 职责：场景与相机搭建、网络事件处理、UI 装配、虚拟摇杆、主循环、
--       存档上报、击杀结算。
--
-- 兄弟文件：
--   Client_State.lua   跨函数共享的可变状态（场景/相机/玩家/触摸…）→ local S
--   Client_Player.lua  玩家控制/攻击/死亡/拾取
--       · 本文件保留 local 别名（PlayerCtl / UpdateAttack / …），调用点不变
--       · 共用常量由本文件 Start() 里 Player.Init 注入（单一数据源在此）
--   Client_Touch.lua   虚拟摇杆/视角拖动/捏合缩放
--       · Start() 调 Touch.Setup()，OnUpdate() 每帧调 Touch.UpdatePinchZoom()
--       · 相机轨道上下限由本文件 Start() 里 Touch.Init 注入
--   Client_Loop.lua   主循环 OnUpdate + 其他玩家模型/动画（全局函数）
--   Client_Ad.lua     激励广告（请求 / 播放 / 发奖 / 加载弹窗 / 无回调兜底）
--       · 本文件保留 RequestAd 的 local 别名，调用点不变
--       · 广告兜底倒计时由本文件主循环调用 Ad.Tick(dt) 驱动
--
-- ⚠️ 原「全局状态」区的 local 变量已全部搬进 Client_State.lua，
--    本文件通过 local S 读写（S.myNode_ / S.camYaw_ …）。
--
-- 依赖关系（严格单向，无环）
--   Client        → Battle_World（世界：Assets / Terrain / Items / Enemies / Effects）
--   Client        → Battle_Combat（战斗：Skills / Combat）
--   Client        → UI_HUD / UI_Panels
--   Client        → Shared
--   以上所有模块 → Shared
--
--   Battle_World 与 Battle_Combat 之间**零交叉引用**；
--   UI_HUD 与 UI_Panels 之间**零交叉引用**。
--   四条支线只通过本文件汇合，因此不存在循环依赖。
--
-- 说明：UI 层不依赖战斗层。角色面板需要的属性计算，由本文件在 SetupUI 里
--       通过 Panels.SetStatProvider(Combat.ComputeStats) 注入。
--       画布缩放由 HUD.UpdateScale 持有（伤害飘字换算用）。
-- ============================================================
local Shared  = require("Shared")

-- 世界层（Assets / Terrain / Items / Enemies / Effects）
local World       = require("Battle_World")
-- 视觉层（Terrain / Player / Monster）—— 加载时会把 Battle.Visual 注入到同一张 Battle 表
local Visual      = require("Battle_Visual").Visual
-- 战斗计算层（Skills / Combat）
local CombatBundle = require("Battle_Combat")
-- UI 层（HUD 与 Panels 各自自包含，互不依赖）
local HUD    = require("UI_HUD")
-- UI_Panels 已按功能域拆为三个文件（2026-09 重构，原 2524 行）：
--   UI_Core   共享基础设施（Modal 栈 / 通用控件 / 通用对话框 / 物品详情列）
--   UI_Items  背包 / 装备 / 角色 / 强化-锻造-重铸
--   UI_System 市场 / 邮箱 / 自动战斗 / 在线时长 / 设置 / 死亡结算 / 网络门控
-- 三者写入**同一张表**，所以下面这个 Panels 就是合并后的完整门面，
-- 本文件其余调用一行都不用改。
local Net = require("Client_Network")   -- 网络层：同步 / flush / 下行事件
local Water = require("Battle_Water")   -- 湖泊水面（阶段 2.2）

local Panels = require("UI_Core")
local Ad     = require("Client_Ad")     -- 激励广告：Request / PlayRewardAd / Tick
require("UI_Items")
require("UI_Enhance")
require("UI_System")
require("UI_Trade")
require("UI_Pet")
require("UI_BD")

local Data    = Shared.Data
local Notify  = Shared.Notify
local Terrain = Visual.Terrain      -- ← 走 Visual，不再走 World
local Enemies = World.Enemies
local Items   = World.Items
local Effects = World.Effects
local Skills  = CombatBundle.Skills
local Combat  = CombatBundle.Combat

local UI = require("urhox-libs/UI")   -- 引擎 UI 控件库（与上面的 UI_HUD / UI_Panels 无关）

-- 沿用拆分前的短名（广告逻辑已迁至 Client_Ad.lua）
local RequestAd    = Ad.Request

-- 跨函数共享的可变状态（场景/相机/玩家/触摸…）
---@type ClientState
local S = require("Client_State")

-- 相机轨道初值：依赖 Shared.C，故在此补上（Client_State 不 require 项目文件）
S.camPitch_ = math.rad(Shared.C.CAM_PITCH_DEFAULT)
S.camDist_  = Shared.C.CAM_DIST_DEFAULT

-- 主循环 + 其他玩家（拆分后提供全局函数 OnUpdate / EnsureOtherPlayersBuilt 等）
require("Client_Loop")

-- 玩家控制 / 攻击 / 死亡 / 拾取（已拆到 Client_Player.lua）
local Player = require("Client_Player")

-- 沿用拆分前的短名（调用点不变）
local PlayerCtl            = Player
local UpdateAttack         = Player.UpdateAttack
local HandleEnemyKilled    = Player.HandleEnemyKilled
local UpdateDeath          = Player.UpdateDeath
local RequestRespawn       = Player.RequestRespawn
local RequestLevelUp       = Player.RequestLevelUp
local RequestLevelDown     = Player.RequestLevelDown
local HandleEnemyAttack    = Player.HandleEnemyAttack
local TryBindPlayerNode    = Player.TryBindPlayerNode
local ToggleNormalAttack   = Player.ToggleNormalAttack
local ClientAddToInventory = Player.ClientAddToInventory
local CanPickDrop          = Player.CanPickDrop

-- 虚拟摇杆 / 视角触摸 / 捏合缩放（已拆到 Client_Touch.lua）
local Touch = require("Client_Touch")

require "urhox-libs.UI.VirtualControls"   -- 摇杆/虚拟按钮，注册全局 VirtualControls

-- ============ 全局状态 ============
-- 跨函数共享的可变状态已全部搬到 Client_State.lua，通过 local S 访问。
-- ⚠️ 连接（conn）/ Seq / flush / 上架队列 等网络状态已迁至 Client_Network.lua，
--    通过 Net.conn、Net.pendingListings、Net.initialDataReady … 访问。

-- 移动速度兜底（米/秒）。与 Client_Player 共用，Start() 里 Player.Init 注入。
local MOVE_SPEED_FALLBACK = 5.0

-- 自动战斗的「捡东西」搜索半径（米）。优先级高于寻怪。
-- 与 Client_Player 共用，Start() 里 Player.Init 注入。
local AUTO_BATTLE_PICKUP_RANGE = 15


-- ============ 客户端本地权威位置（方案 B） ============
-- ⚠️ 玩家位置由客户端独占维护：
--    · 所有移动逻辑只改这两个变量
--    · OnUpdate 每帧把这两个值写回 S.myNode_.position（覆盖 REPLICATED 回推）
--    · 上报时读这两个变量，不读 S.myNode_.position
--    · 服务端不再写 p.node.position（见 Server.OnInvSync）

--- 玩家朝向（弧度，YawAngle 口径）。由 Net.SyncToServer 上报，供其他玩家渲染朝向。
--- ⚠️ S.myNode_.rotation 从未被移动逻辑更新过，不能拿来当朝向源。

-- ============ 相机轨道参数（与摇杆解耦） ============
local CAM_DIST_MIN_  = Shared.C.CAM_DIST_MIN
local CAM_DIST_MAX_  = Shared.C.CAM_DIST_MAX
local CAM_PITCH_MIN_ = math.rad(Shared.C.CAM_PITCH_MIN)
local CAM_PITCH_MAX_ = math.rad(Shared.C.CAM_PITCH_MAX)

-- 相机平滑状态：
--   S.camSmoothY_ = 平滑后的玩家基准高度（吞掉地形小起伏引起的上下抖动），
--                 nil = 尚未初始化（首帧直接取玩家 y）
--   S.camSmoothT_ = 地形避让系数（1 = 无遮挡全距离，0 = 完全收到玩家眼睛处）

-- ============ 普攻锁定 ============
--- 当前锁定的怪物 id（nil = 未锁定）

--- 本地累计击杀数（单计数器，只对「当前所在段位」有效）。
--- 换段位时清零重算：例如在 lv1~9 区攒了 99 只，跑到 lv10~19 区后从 0 开始。
--- ⚠️ 必须同时记录计数所属段位，否则跨区后会把旧进度算进新阈值。
--- 当前计数所属段位（lv/10 向下取整）。nil 表示尚未开始计数。

-- gateNotified_ 已删除（升级不再本地处理）

--- 主光源引用（C16：阴影开关/分辨率需要它）

-- ============ 设置生效点 ============
--- 当前已生效的视野距离（用于判断是否需要重建装饰）

--- 相机参数同步（设置面板改动时也调）
function ApplyCameraSettings()
    local s = Data.GetSettings()
    S.camDist_  = Shared.Clamp(s.camDist or Shared.C.CAM_DIST_DEFAULT,
                             CAM_DIST_MIN_, CAM_DIST_MAX_)
    S.camPitch_ = Shared.Clamp(math.rad(s.camPitch or Shared.C.CAM_PITCH_DEFAULT),
                             CAM_PITCH_MIN_, CAM_PITCH_MAX_)
end

--- 视野 / 雾联动（fogEnd = 视野 × 5.0，fogStart = 视野 × 1.6）
---
--- 原神风格：雾起始远、过渡带宽，消除"雾墙"。
---
--- 视野固定 200（Shared.C.VIEW_DISTANCE_DEFAULT）：
---   fogStart = 200 × 1.6 = 320m 起雾，fogEnd = 200 × 5.0 = 1000m 完全雾化。
---   树/石装饰半径与怪物销毁距离均在 150~200m，落在起雾点之前，
---   pop 会有但被雾过渡部分遮掩。
function ApplyViewDistanceSettings()
    -- 视野固定 200（不再读 settings，见 Shared.C.VIEW_DISTANCE_DEFAULT 注释）
    local v = Shared.C.VIEW_DISTANCE_DEFAULT
    renderer.defaultZone.fogEnd   = v * 5.0
    renderer.defaultZone.fogStart = v * 1.6
    -- 装饰不再随视野重建（见第二批装饰分块改动）
end

--- 服务端回传设置后按需重新生效。
--- 相机值本身很轻，直接同步；视野已固定，无需按需重应用。
function ReapplyServerSettingsIfChanged()
    ApplyCameraSettings()
    -- 视野已固定，无需按需重应用
end

-- S.light_ 保留：Start() 里仍在创建主光源。


-- ============================================================
-- 激励广告（RequestAd / 加载弹窗 / 兜底）已拆到 Client_Ad.lua。
-- 本文件保留 local 别名 RequestAd，调用点不变。
-- ============================================================

-- ============ UI 装配 ============
function SetupUI()
    -- ⚠️ default-dark 主题默认字体是 Fonts/NotoSansSC-*.ttf，本项目资源里没有。
    --    显式覆盖为脚手架同款 MiSans，避免 UI 文字整片缺失。
    -- 加载提示已提前 UI.Init（见 Start），这里只在未初始化时补
    if not UI.GetNVGContext() then
        UI.Init({
            theme = "default-dark",
            fonts = {
                { family = "sans", weights = {
                    normal = "Fonts/MiSans-Regular.ttf",
                    bold   = "Fonts/MiSans-Regular.ttf",
                } },
            },
            scale = UI.Scale.DEFAULT,
        })
    end

    Notify.SetImpl(function(text, color) HUD.Toast(text, color) end)
    HUD.SetCamera(S.cam_)
    HUD.SetMyIdProvider(function() return S.myId_ end)
    HUD.SetSceneProvider(function() return S.scene_ end)
    -- 头顶显示 TapTap 昵称（服务端广播，见 Net.OnPlayerInfo）
    HUD.SetNameProvider(function(pid) return Net.playerNames and Net.playerNames[pid] end)

    -- HUD 需要玩家坐标 / 怪物列表来画小地图、坐标、头顶标签。
    -- UI 层不反向依赖 Client，所以在这里注入读取器。
    HUD.SetPlayerPosProvider(function()
        if S.myNode_ then return S.myNode_.position.x, S.myNode_.position.z end
        return nil, nil
    end)
    HUD.SetEnemiesProvider(function() return Enemies.GetAliveList() end)
    -- 首领进度：还需击杀多少只怪才刷出共享首领（显示在区域标签下方）。
    -- ⚠️ 阈值按「当前区域」算，不是按击杀计数的段位：
    --    跨段位时 localKillCount_ 会被清零，用当前区域等级取阈值才不会显示错。
    HUD.SetBossProgressProvider(function()
        local px, pz = S.myNode_ and S.myNode_.position.x, S.myNode_ and S.myNode_.position.z
        if not px then return nil, nil end
        local lv = Shared.MonsterLevelOf(px, pz)
        if not lv then return nil, nil end   -- 缓冲区不刷怪，也就没有首领进度
        local threshold = Shared.BossKillThreshold(lv)
        -- ⚠️ localKillCount_ 只在**击杀时**跨段位清零（见 Client_Player）。
        --    玩家刚走进新区域、还没杀怪时，它仍带着旧区域的计数。
        --    这里比对段位：不匹配就当作 0，否则会显示成「还需 阈值−旧计数」的错误值。
        ---@type integer
        local done = 0
        if S.localKillTier_ == math.floor(lv / 10) then
            -- localKillCount_ 在 Client_State 里声明为 number，这里取整
            done = math.floor(S.localKillCount_ or 0)
        end
        ---@type integer
        local remain = threshold - done
        if remain < 0 then remain = 0 end
        return remain, threshold
    end)
    -- 头顶标签要贴地形（地图有 40m 阶梯，用 y=0 常量会让标签浮空/沉地）
    HUD.SetTerrainHeightProvider(function(x, z)
        return Terrain.GetHeight(x, z)
    end)
    -- 小地图朝向指针
    HUD.SetFacingProvider(function()
        return S.myNode_ and S.myNode_.rotation:YawAngle() or 0
    end)
    HUD.SetScreenSize(graphics:GetWidth(), graphics:GetHeight())

    HUD.SetCallbacks({
        onAction = function(action)
            if action == "inventory" then
                Panels.OpenInventory()
            elseif action == "character" then
                Panels.OpenCharacter()
            elseif action == "bd" then
                Panels.OpenBD()
            elseif action == "market" then
                Panels.OpenMarket()
                Net.RequestMarketPage(0)   -- 打开市场拉第一页（带当前筛选）
            elseif action == "mail" then
                Panels.OpenMail()
            elseif action == "enhance" then
                Panels.OpenEnhanceTab("enhance")
            elseif action == "forge" then
                Panels.OpenEnhanceTab("forge")
            elseif action == "reforge" then
                Panels.OpenEnhanceTab("reforge")
            elseif action == "online" then
                Panels.OpenOnline()
            elseif action == "settings" then
                Panels.OpenSettingsPanel()
            elseif action == "bank" then
                -- 先请求最新状态，回包后 OnBankState 会 RefreshIfOpen("bank") 重建面板
                if Net.conn then
                    Net.conn:SendRemoteEvent(Shared.EVENTS.BANK_STATE_REQUEST, true,
                        Shared.ToVariantMap({}))
                end
                Panels.OpenBank()
            elseif action == "pet" then
                Panels.OpenPet()
            end
        end,
        onAttack = function()
            ToggleNormalAttack()
        end,
        -- ⚔️ 按钮：直接开关自动战斗
        onAutoToggle = function()
            Panels.ToggleAutoBattle()
        end,
    })

    -- UI 层不反向依赖 Battle，属性计算由这里注入
    Panels.SetStatProvider(Combat.ComputeStats)
    Panels.SetSkillStacksProvider(Skills.GetStacks)

    Panels.Init({
        --- 市场请求：
        ---   · list（只读）→ 直连，不需要等 flush
        ---   · buy / cancel 等写操作 → 先 flush 再发，
        ---     否则服务端可能拿旧背包/旧金币判定（表现为「金币不足」「背包已满」）
        sendMarket = function(payload)
            if not Net.conn then return end
            local action = payload.Action

            if action == "list" then
                Net.RequestMarketPage(0)
                return
            end

            -- onDone 不额外提示：Net.FlushThenSend 内部失败时已经 Toast 过了，
            -- 再加一条会连弹两个「失败」（幂等由服务端 ListingId / 结果缓存保证）
            Net.FlushThenSend(Shared.EVENTS.REQUEST_MARKET, {
                Action    = action,
                ListingId = payload.ListingId or "",
                ItemId    = payload.ItemId or "",
                Price     = payload.Price or 0,
                Quantity  = payload.Quantity or 1,
            }, function(ok)
                -- 买/下架成功后主动拉一次当前页：
                -- 服务端已不再广播行情（见 Server_System 的 BroadcastMarket 删除），
                -- 不拉的话已成交的挂单会一直留在列表里，点了报「商品不存在」。
                -- ⚠️ 拉「当前页」而非第一页：保持玩家所在页码；
                --    若当前页被下空，服务端会把页码夹回上一页，回包会同步。
                if ok then Net.RequestMarketPage() end
            end)
        end,
        claimMail = function(mailId)
            if Net.conn then
                Net.conn:SendRemoteEvent(Shared.EVENTS.MAIL_CLAIM, true, Shared.ToVariantMap({ MailId = mailId }))
            end
        end,
        requestAd = function(rewardType)
            RequestAd(rewardType)
        end,
        requestMailPage = function(page)
            if Net.conn then
                Net.conn:SendRemoteEvent(Shared.EVENTS.REQUEST_MAIL_PAGE, true, Shared.ToVariantMap({ Page = page }))
            end
        end,
        requestRespawn = function() RequestRespawn() end,
        requestLevelUp = function() RequestLevelUp() end,
        requestLevelDown = function() RequestLevelDown() end,
        -- 钱庄
        bankDeposit = function(amount, term)
            if Net.conn then
                Net.conn:SendRemoteEvent(Shared.EVENTS.BANK_DEPOSIT, true,
                    Shared.ToVariantMap({ Amount = amount, Term = term }))
            end
        end,
        bankWithdraw = function(index)
            if Net.conn then
                Net.conn:SendRemoteEvent(Shared.EVENTS.BANK_WITHDRAW, true,
                    Shared.ToVariantMap({ Index = index }))
            end
        end,
        bankStateRequest = function()
            if Net.conn then
                Net.conn:SendRemoteEvent(Shared.EVENTS.BANK_STATE_REQUEST, true,
                    Shared.ToVariantMap({}))
            end
        end,
        --- 拍卖行服务端分页：拉指定页（省略 = 当前页）
        requestMarketPage = function(page) Net.RequestMarketPage(page) end,
        --- 更新拍卖行筛选条件（翻页时带上，避免丢筛选）
        setMarketFilter = function(f) Net.SetMarketFilter(f) end,
        --- 开启自动维修时立即先修一次
        autoRepairNow = function() Player.DoAutoRepair() end,
        --- 使用召唤卷（服务端权威 roll + 冷却/距离校验）
        useSummonScroll = function(scrollType)
            if Net.conn then
                Net.conn:SendRemoteEvent(Shared.EVENTS.USE_SUMMON_SCROLL, true,
                    Shared.ToVariantMap({ ScrollType = scrollType }))
            end
        end,
        applySettings = function()
            ApplyCameraSettings()
            ApplyViewDistanceSettings()
            -- 后处理 pass 开关 + Zone 画面参数 + Toon 材质
            local ok, PP = pcall(require, "PostProcess")
            if ok and PP then PP.ApplyFromSettings() end
        end,
        forceSync = function() Net.ForceSyncNow() end,
        requestFlush = function(onAck) Net.RequestFlush(onAck) end,
        --- 网络门控的按钮回调（见 Client_Network 的 Reconnect / RetrySave）
        reconnect  = function() Net.Reconnect() end,
        retrySave  = function() Net.RetrySave() end,
        forceLogin = function() Net.Reconnect() end,
        appendPendingListing = function(pl)
            table.insert(Net.pendingListings, pl)
        end,
        --- 取本地权威玩家坐标（掉落物自动寻路、飘字挂点等 UI 逻辑用）
        getPlayerPos = function()
            return S.localPlayerX_, S.localPlayerZ_
        end,
        --- 通用「先 flush 再发事件」（邮箱领取、市场写操作等都走这个）
        flushThenSend = function(eventName, payload, onDone)
            Net.FlushThenSend(eventName, payload, onDone)
        end,
        --- 只 flush 不发额外事件（上架意图在 Net.pendingListings 里，随 Net.SyncToServer 一起上报）
        flushOnly = function(onDone) Net.FlushOnly(onDone) end,
        --- 溢出装备通知：把无法进背包的装备发到玩家邮箱
        --- （复用服务端已有的 BAG_OVERFLOW 事件）
        ---@param items table[]
        notifyOverflowEquip = function(items)
            if not Net.conn then return end
            for _, item in ipairs(items) do
                Net.conn:SendRemoteEvent(Shared.EVENTS.BAG_OVERFLOW, true,
                    Shared.ToVariantMap({
                        ItemJson = cjson.encode(item),
                    }))
            end
        end,
        -- 【调试】服务器玩家列表
        queryServerInfo = function() Net.QueryServerInfo() end,
        getServerInfo   = function() return Net.serverInfo end,
    })

    local root = UI.Panel {
        width = "100%", height = "100%",
        pointerEvents = "box-none",
        children = { HUD.Build() },
    }
    UI.SetRoot(root)
    -- UI 就绪：通知网络层，并补弹「事件早于 UI 到达」的新手礼包提示
    Net.uiReady = true
    if Net.FlushStarterGift then Net.FlushStarterGift() end
    print("[Client] UI 初始化完成")

    -- ============================================================
    -- 后处理：按 settings 应用 pass 开关 + Zone 画面参数 + Toon 材质
    -- （替代原测试面板；设置面板「后处理」Tab 调这些值）
    -- ============================================================
    pcall(function() require("PostProcess").ApplyFromSettings() end)
end

-- ============================================================
-- 虚拟摇杆 / 视角拖动 / 捏合缩放已拆到 Client_Touch.lua。
-- Start() 调 Touch.Setup()，OnUpdate() 每帧调 Touch.UpdatePinchZoom()。
-- ============================================================

-- ============ 入口 ============
function Start()
    print("[Client] Starting...")

    -- 视觉参数已迁移到 settings（见 Shared.NewDefaultSettings 的 bloomThreshold /
    -- ambientIntensity / toon* 等字段），由设置面板「后处理」Tab 调整。
    -- 原「强制刷新块」已删除：它每次启动无条件覆盖这些字段，会让设置面板失效。
    -- 当前无本地持久化，settings 每次启动由 NewDefaultSettings() 重建（含同值默认）。

    S.localKillCount_ = 0
    S.localKillTier_ = nil

    -- 注入 Client_Player 与 Client.lua 共用的常量（单一数据源在本文件）
    Player.Init({
        MOVE_SPEED_FALLBACK      = MOVE_SPEED_FALLBACK,
        AUTO_BATTLE_PICKUP_RANGE = AUTO_BATTLE_PICKUP_RANGE,
    })

    -- 注入 Client_Touch 与 Client.lua 共用的相机轨道上下限（单一数据源在本文件）
    Touch.Init({
        CAM_PITCH_MIN_ = CAM_PITCH_MIN_,
        CAM_PITCH_MAX_ = CAM_PITCH_MAX_,
        CAM_DIST_MIN_  = CAM_DIST_MIN_,
        CAM_DIST_MAX_  = CAM_DIST_MAX_,
    })

    -- 【诊断】把 SDK 能拿到的身份信息全打出来，用于定位 TapTap ID 来源。
    -- 已知 identity["user_id"]（服务端）拿到的是游戏内 ID，不是 TapTap 平台 ID。
    -- 找到正确接口后这段可以删掉。
    if sdk then
        local ok1, uid = pcall(function() return sdk:GetUserID() end)
        local ok2, uname = pcall(function() return sdk:GetUserName() end)
        print(string.format("[Client][诊断] sdk:GetUserID=%s (ok=%s), sdk:GetUserName=%s (ok=%s)",
            tostring(uid), tostring(ok1), tostring(uname), tostring(ok2)))
    else
        print("[Client][诊断] sdk 不可用")
    end

    -- 场景
    S.scene_ = Scene()
    S.scene_:CreateComponent("Octree", LOCAL)
    S.scene_:CreateComponent("PhysicsWorld", LOCAL)

    -- 相机
    S.cameraNode_ = S.scene_:CreateChild("Camera", LOCAL)
    S.cam_ = S.cameraNode_:CreateComponent("Camera", LOCAL)
    S.cam_.farClip = 8000
    S.cam_.fov = 60
    S.cameraNode_.position = Vector3(0, 6, -10)
    renderer:SetViewport(0, Viewport(S.scene_, S.cam_))
    print(string.format("[Client] 初始相机 pos=%.2f,%.2f,%.2f farClip=%.0f fov=%.0f",
        S.cameraNode_.position.x, S.cameraNode_.position.y, S.cameraNode_.position.z,
        S.cam_.farClip, S.cam_.fov))

    -- ============================================================
    -- 启动加载提示（方向 1）
    --
    -- 场景构建（地形 90000 高度图 + 100 块网格）是同步阻塞的，
    -- 期间画面是黑的（相机对空世界）。这里提前初始化 UI 并显示
    -- 一个极简的"加载中"面板，让玩家至少知道游戏在跑。
    --
    -- ⚠️ SetupUI 里会再次 UI.Init（已有 if 守卫），并用完整的 HUD
    --    替换掉这里的 root。所以此段是"临时占位"。
    -- ⚠️ 若引擎在 Start() 期间不渲染帧，此标签不会显示——但不影响
    --    功能，只是"没有反馈"回到原样。
    -- ============================================================
    do
        local UI_early = require("urhox-libs/UI")
        if not UI_early.GetNVGContext() then
            UI_early.Init({
                theme = "default-dark",
                fonts = {
                    { family = "sans", weights = {
                        normal = "Fonts/MiSans-Regular.ttf",
                        bold   = "Fonts/MiSans-Regular.ttf",
                    } },
                },
                scale = UI_early.Scale.DEFAULT,
            })
        end
        local loadingPanel = UI_early.Panel {
            width = "100%", height = "100%",
            justifyContent = "center", alignItems = "center",
            backgroundColor = { 20, 24, 32, 255 },
            children = {
                UI_early.Label {
                    text = "加载中…",
                    fontSize = 20,
                    fontColor = { 200, 220, 255, 255 },
                },
                UI_early.Label {
                    text = "首次加载需要几秒钟",
                    fontSize = 12,
                    fontColor = { 130, 140, 160, 255 },
                },
            },
        }
        UI_early.SetRoot(loadingPanel)
    end

    -- 光照（服务器不创建，客户端本地建）
    -- ============================================================
    -- 主光：DirectionalLight（2026-10-04 从 SpotLight 回退）
    --
    -- 🔴 回退原因：SpotLight 的阴影确实稳定（光源视锥驱动，与相机无关），
    --    但它有**几何硬限制**：覆盖半径 = 光源高度 × tan(fov/2)。
    --    实测 H=50/fov=130 → 仅覆盖 107 米，而雾要到 fogStart=800m 才起，
    --    于是 107~800m 是一圈"无光也无雾"的纯黑地带，无法接受。
    --    要覆盖 500 米视野需 fov≈169°（近乎整个半球），已失去聚光灯的意义。
    --    且光照被迫垂直朝下（否则光锥中心偏离玩家，实测偏过 60 米），
    --    丢失了斜射感。综合代价高于收益，故回退。
    --
    -- ✅ 阴影漂移问题改走**几何层假阴影**（见 Battle_Visual 的 ShadowDisc）：
    --    角色脚下贴一个半透明黑圆盘，不依赖引擎阴影，因此不会漂移。
    -- ============================================================
    local lightNode = S.scene_:CreateChild("Light", LOCAL)
    lightNode.position = Vector3(0, 40, -20)
    S.light_ = lightNode:CreateComponent("Light", LOCAL)
    S.light_.lightType = LIGHT_DIRECTIONAL
    -- 存进 S（方向光的 position 不参与光照/阴影计算，此引用仅备查）
    S.lightNode_ = lightNode
    -- 低多边形风格：主光偏亮，压出明暗面；配合下面的 AMBIENT_COLOR 环境光
    -- 保证背光面不死黑（low-poly 场景里纯黑背光面会显得"缺了一块"）。
    -- 主光加暖色：纯白光照会让暖调色板显得"发灰"，
    -- 而带一点橙黄的暖光能把地面绿色"提鲜"、把岩石灰"染暖"，
    -- 配合明暗对比拉开，画面会有"晴天下午"的通透感。
    -- 主光走过 1.20 → 1.30 → 1.40 → 1.20 → 1.35 → 1.55。
    -- 单独提亮只让亮部过曝；配合环境光压暗后再提亮，才是"拉对比"。
    -- ⚠️ 提亮会让 Toon 的亮/暗面都提亮约 8%，对比度基本不变。
    --     主要风险是雪白地形（heightColor 最高档）可能过曝。
    -- 配合 ambientIntensity 0.85→0.65：环境光压暗后主光必须提亮，
    -- 否则整体会过暗。1.55 是"亮部够亮、暗部够暗"的分界点。
    S.light_.brightness = 1.55
    -- 色温更暖：原神阳光是"午后金黄"，不是"中性白"
    S.light_.color = Color(1.00, 0.95, 0.83, 1.0)
    -- 阴影（阶段 1.3 定稿：默认开启）。值来自设置表，玩家可在设置面板改。
    --
    -- 🔴 实测（4 状态对照）：阴影必须**两个开关同时打开**才生效 ——
    --      castShadows=T drawShadows=T  → 有阴影
    --      castShadows=T drawShadows=F  → 无
    --      castShadows=F drawShadows=T  → 无
    --      castShadows=F drawShadows=F  → 无
    --    所以这里用**同一个字段**同步设置两者，不要只设其中一个。
    local shadowOn = (Data.value.settings and Data.value.settings.castShadows) == true
    S.light_.castShadows = shadowOn
    renderer.drawShadows = shadowOn

    -- 🔴 阴影参数（实测）：
    --    normalOffset 必须为 0 —— 设成 0.5 就会让阴影**整体消失**（不是变淡，是全没）。
    --    constantBias 0.0005 出图正常，形态干净。
    --    这里显式写死，避免引擎默认值或别处代码把它改成非 0。
    if shadowOn then
        S.light_.shadowBias = BiasParameters(0.0005, 2.0, 0.0)

        -- ⚠️ 已删除 shadowFocus 设置（2026-10-04）：
        --    那是为 DirectionalLight 的阴影漂移做的尝试，实测两轮均失败
        --    （focus=false → 阴影消失；focus=true+autoSize=false → 无效）。
        --    SpotLight 的阴影由光源自身视锥定义，不需要 shadowFocus，
        --    留着可能干扰引擎默认行为，故移除。

        -- 贴图 2048（云游戏跑服务器 GPU，非移动端）：512 边缘锯齿太糙。
        -- ⚠️ fallback 仍是 1024：老存档 settings 缺此字段时走这里，见下方说明。
        renderer.shadowMapSize =
            (Data.value.settings and Data.value.settings.shadowMapSize) or 1024

        -- ⚠️ 阴影"随相机漂移"已查证，结论是**引擎固有行为**，无 API 可改：
        --    · 方向光的阴影由**相机视锥**驱动（light space 从视锥反推），
        --      光源节点 position 不参与阴影投影 → "光源跟随玩家"无效。
        --    · FocusParameters 的 focus 语义是"聚焦到**相机可见区**以提高
        --      有效分辨率"，不是"锁定到某个世界点" → shadowFocus 也无效。
        --    · Renderer 没有控制阴影覆盖范围的字段（只有 shadowMapSize/Quality/
        --      Softness），Light 也没有 focus 目标点参数。
        --    要真正稳定，只能改用 SpotLight（阴影基于光源自身视锥，不随相机转），
        --    代价是引入距离衰减。详见对话记录。
        -- ⚠️ 本段提到的 shadowFocus **从未在本项目中落地**（全项目零设置点），
        --    它只是"查证过但无效"的方案，不要误以为代码里已有该缓解措施。
    end
    -- ⚠️ 斜射方向（45° 俯角 + 35° 偏航）。
    --    SpotLight 时代实测过：这个组合算出的 forward 是 (-0.57,-0.58,+0.58)，
    --    方向光下无所谓（平行光照全场），但聚光灯会因此把光锥打偏 60 米。
    --    现已回退方向光，此值恢复为原调好的斜射方向，**不要改成垂直朝下** ——
    --    那是 SpotLight 为了对准玩家而做的妥协，方向光不需要。
    lightNode.rotation = Quaternion(45, Vector3.RIGHT) * Quaternion(-35, Vector3.UP)

    -- 环境光
    --
    -- 环境光是**加法贡献**。COLOR 模式下贡献 = intensity × ambientColor。
    -- ⚠️ 当前是 COLOR(2) + intensity 0.65：
    --    实际贡献 = 0.65 × (0.10, 0.13, 0.20) ≈ (0.065, 0.085, 0.130)
    --    —— 是很弱的冷蓝补光，暗部会"有颜色但很暗"，符合原神调子。
    --    要让暗部更亮，调大下面 ambientColor 或 ambientIntensity（两者相乘）。
    --
    -- 阶段 1 曾实测选 PREBAKED（天空浅蓝/草地鲜绿），但那是低饱和写实调子下的
    -- 结论；转二次元高饱和后改用 COLOR，原因见 Shared.lua 的 ambientSource 注释。
    --
    -- ambientSource：**锁定 COLOR(2)**，PREBAKED/SKYBOX 已弃用（见 Shared.lua 注释）。
    local ambSrc = (Data.value.settings and Data.value.settings.ambientSource) or 2
    renderer.defaultZone.ambientSource = ambSrc
    renderer.defaultZone.ambientIntensity =
        (Data.value.settings and Data.value.settings.ambientIntensity) or 1.0
    -- ambientColor 仅在 COLOR 模式下生效；PREBAKED / SKYBOX 下不参与。
    -- ⚠️ 现在是 COLOR 模式，这个值**真实生效**（以前只是备用基准值）。
    --    0.10 的冷蓝偏暗，配合 0.65 强度后补光很弱 —— 有意为之，别误当 bug。
    renderer.defaultZone.ambientColor  = Color(0.10, 0.13, 0.20)
    print(string.format("[Client] 环境光 ambientSource=%d(%s) intensity=%.2f",
        ambSrc,
        ({ [0] = "PREBAKED", [1] = "SKYBOX", [2] = "COLOR" })[ambSrc] or "?",
        renderer.defaultZone.ambientIntensity))

    -- Bloom 泛光（阶段 1.1 占位值，随设置走）
    local st = Data.value.settings
    if st.bloomThreshold then renderer.defaultZone.bloomThreshold = st.bloomThreshold end
    if st.bloomIntensity then renderer.defaultZone.bloomPlusIntensity = st.bloomIntensity end
    if st.bloomMode then renderer.defaultZone.bloomMode = st.bloomMode end
    print(string.format("[Client] Bloom 阈值=%.2f 强度=%.2f 模式=%d",
        renderer.defaultZone.bloomThreshold,
        renderer.defaultZone.bloomPlusIntensity,
        renderer.defaultZone.bloomMode))

    -- 关闭自动曝光。
    -- 原神是固定曝光（晴天永远那个亮度），不是随画面明暗浮动。
    -- 开启时会出现：跑进树林画面突然变亮、出树林突然变暗 —— 原神没有这个现象。
    -- 而且云游戏串流会做二次编码，曝光浮动会被放大成"画面一闪一闪"。
    -- ⚠️ 引擎默认 autoExposureEnabled = true（见 PostProcess.lua 的 pass 清单），
    --    所以这行是真实的开关，不是重复设置。
    renderer.defaultZone.autoExposureEnabled = false
    print("[Client] 自动曝光已关闭（固定曝光）")

    -- 天空盒：程序化三色渐变（天顶浅蓝 / 地平线暖米黄 / 地面暗绿褐）
    -- ⚠️ Skybox shader 在 postopaque pass 渲染、不计算雾，所以天空不受雾色影响，
    --     无论雾多浓天空都正常可见。
    -- ⚠️ CreateGradientSky 内部已做 ACES 曝光补偿（hdrBoost = 2.0），不需要手工推 HDR。
    -- ⚠️ 地平线色必须和 fogColor 基本对齐，否则远处地平线会出现明显的色差接缝。
    --     这里让两者近乎相等（只留极小差），接缝因此不可见。
    -- skyExp = 0.60（源码语义：t = elev^skyExp，指数越小渐变越陡、深蓝区越大）。
    --     默认 0.5 是"过渡集中在底部"，0.85 会变"平"（浅色铺满天空，反效果）。
    --     0.60 取中间偏陡，天顶深蓝占主体、地平线浅色只留底部一条。
    local SkyUtils = require("urhox-libs.Rendering.SkyUtils")
    SkyUtils.CreateGradientSky(S.scene_, {
        -- zenith 再压深 + 更饱和：截图里天顶的深蓝被"压平"成浅蓝，
        -- 需要更极端的输入值才能在 ACES 映射后仍显深色。
        zenith  = Color(0.10, 0.36, 1.00),
        -- horizon 降下来：0.88,0.94,1.00 太接近纯白，地平线附近像"发光带"。
        -- 0.78,0.88,0.96 → 0.72,0.82,0.92：与地面交界处仍顶到接近 1.0 成白带，再压 6%。
        -- ⚠️ 与 fogColor (0.50,0.64,0.88) 对齐（±0.02 内），否则地平线出接缝。
        --    两者必须同步改。
        -- 地平线压深压蓝：从"浅蓝灰"往"深蓝"靠，接近原神地平线的色相。
        horizon = Color(0.52, 0.66, 0.88),
        ground  = Color(0.35, 0.38, 0.32),
        -- skyExp 0.60→0.40：过渡再陡一档，深蓝区占上半屏。
        skyExp  = 0.40,
        size    = 64,
    })

    -- 雾 / 视野（跟随设置面板的「视野距离」联动）
    -- ⚠️ fogEnd 必须与 Battle_World 的怪物/掉落物剔除距离（renderDist）一致：
    --    否则物体在剔除距离处凭空出现/消失，而雾还没糊上来，会看到明显的 pop。
    -- 与 horizon (0.52,0.66,0.88) 对齐（±0.02 内），否则远处地平线出接缝。
    -- ⚠️ 改这里必须同步改上面的 horizon —— 两者是对齐关系。
    renderer.defaultZone.fogColor = Color(0.50, 0.64, 0.88)

    -- ============================================================
    -- 太阳圆盘（L3·S1）
    --
    -- 🔴 关键设计：太阳不跟随相机。
    --    每帧把太阳的位置设为「玩家位置 + 固定方向 × 大距离」，所以：
    --      · 相机转动 → 太阳在世界空间不动 → 屏幕上太阳跟着视角移动（正确）
    --      · 玩家移动 → 太阳跟着平移，相对玩家方向不变（像无限远天体）
    --    ❌ 绝不挂到相机节点下、也不要每帧读相机位置 ——
    --       那会让太阳永远贴在屏幕同一位置，完全失去"天体"感。
    --
    -- ⚠️ 三层用不同 Technique（不是同一材质改 alpha）：
    --    核心：PBRNoTexture + MatEmissiveColor（不透明自发光，本模式已验证可用）
    --    光晕/外泛光：PBRNoTextureAlpha（**必须**用这个才能让 A 生效）
    --    若三层都用 PBRNoTexture，alpha 会被忽略 → 三层全是不透明球，
    --    外泛光(直径最大)会完全遮住核心，三层结构失效。
    --
    -- ⚠️ 不要对核心调 SetEnabled(false)：那是关闭组件渲染，不是"关光照"。
    --    自发光由 Technique 决定，无需关闭组件。加了它核心会直接不可见。
    -- ============================================================
    do
        -- 太阳方向：对齐相机默认朝向（-Z）+ 仰角约 5°、水平偏 +X 约 11°。
        --
        -- 🔴 可见性几何（决定这个值能取多大）：
        --    屏幕顶部的仰角 = 半FOV − pitch。
        --    vFOV 60° 时半 FOV = 30°，所以太阳仰角必须 ≤ 30 − pitch 才可见。
        --      pitch=60（原默认）→ 顶部仰角 −30° → 整个屏幕都是地面，看不到天空
        --      pitch=20（新默认）→ 顶部仰角 +10° → 仰角 5° 的太阳可见，留 5° 余量
        --    ⚠️ 若把 CAM_PITCH_DEFAULT 调大，太阳会重新移出视野。
        --    改这两个值时要一起算，别只改一个。
        --
        -- 太阳居中（X=0，屏幕正中央偏上，原神常见构图）。
        -- 旧 X=0.19 在屏幕左侧约 11°，偏边。
        -- 仰角仍约 5.7°，与 CAM_PITCH_DEFAULT=20 的可见范围匹配。
        -- Y 保持正数（太阳在天上）—— 主光朝下、太阳在上，反向是对的，不是 bug。
        local SUN_DIR  = Vector3(0.0, 0.10, -0.995):Normalized()
        local SUN_DIST = 6000     -- 距离玩家 6000 米（farClip 8000 内）

        local sphereMdl = cache:GetResource("Model", "Models/Sphere.mdl")

        -- 不透明自发光材质（核心用）
        local function MakeCoreMat(r, g, b)
            local tech = cache:GetResource("Technique", "Techniques/PBR/PBRNoTexture.xml")
            if not tech then return nil end
            local mat = Material:new()
            mat:SetTechnique(0, tech)
            mat:SetShaderParameter("MatDiffColor", Variant(Color(r, g, b, 1)))
            mat:SetShaderParameter("MatEmissiveColor", Variant(Color(r, g, b)))
            mat:SetShaderParameter("Metallic", Variant(0.0))
            mat:SetShaderParameter("Roughness", Variant(1.0))
            return mat
        end

        -- 半透明自发光材质（光晕 / 外泛光用）。⚠️ 必须用 PBRNoTextureAlpha，
        -- 否则 A 通道被忽略。
        local function MakeGlowMat(r, g, b, a)
            local tech = cache:GetResource("Technique", "Techniques/PBR/PBRNoTextureAlpha.xml")
            if not tech then return nil end
            local mat = Material:new()
            mat:SetTechnique(0, tech)
            mat:SetShaderParameter("MatDiffColor", Variant(Color(r, g, b, a)))
            mat:SetShaderParameter("MatEmissiveColor", Variant(Color(r, g, b)))
            mat:SetShaderParameter("Metallic", Variant(0.0))
            mat:SetShaderParameter("Roughness", Variant(1.0))
            return mat
        end

        local sunRoot = S.scene_:CreateChild("Sun", LOCAL)
        sunRoot.position = SUN_DIR * SUN_DIST

        -- 🔴 太阳专用 Zone：让它免疫雾。
        --    根因：renderer.defaultZone.fogEnd = viewDistance × 1.6
        --          （默认视野 500 → fogEnd 仅 800 米），而太阳在 6000 米外。
        --    天空盒不受雾影响（它在 postopaque pass 渲染、不算雾），
        --    但太阳是 StaticModel、走标准管线、**受雾** → 会被完全糊成雾色。
        --    这就是"天空正常可见、太阳却不见"的原因。
        --
        --    Urho3D 按 **drawable 位置**选 Zone（不是按相机位置），
        --    所以给太阳挂一个高优先级 + 无雾的 Zone 即可。
        --    boundingBox 是**局部空间**，随 sunRoot 每帧移动 → 始终罩住太阳。
        --
        -- ⚠️ 数值核对（2026-10-04）：
        --    当前 fogStart = viewDistance × 1.6 = 800m、fogEnd = viewDistance × 5.0 = 2500m。
        --    太阳在 6000m 处 → **远超 fogEnd**，若不挂这个 Zone 会被 100% 雾色覆盖
        --    （太阳核心变淡蓝紫、几乎看不见）。本 Zone 是它可见的**唯一保障**。
        --    包围盒 ±600 相对最大层半径（1100/2 = 550）够用。
        --
        -- ⚠️ 曾因排查阴影而临时注释掉本段，结论是"对阴影无影响"（阴影由相机视锥
        --    驱动，与 Zone 无关）。现已恢复 —— 若再次注释，太阳会立刻被雾吃掉。
        local sunZone = sunRoot:CreateComponent("Zone", LOCAL)
        sunZone.boundingBox = BoundingBox(Vector3(-600, -600, -600),
                                          Vector3(600, 600, 600))
        sunZone.fogStart = 100000
        sunZone.fogEnd   = 200000
        sunZone.priority = 100
        sunZone.ambientColor = Color(0, 0, 0)

        -- 五层：(名称, 直径, 材质工厂)
        --
        -- 从三层加到五层的原因：三层各自实心、边界明显 → 看起来像"球套球"。
        -- 五层把 alpha 阶梯细化（1.0 → 0.50 → 0.28 → 0.14 → 0.07），
        -- 相邻层重叠区形成连续渐隐，接近真实的"光晕衰减"。
        --
        -- ⚠️ 光晕层必须走 MakeGlowMat（PBRNoTextureAlpha）才让 alpha 生效 ——
        --    这是上一轮已经踩过的坑。若误用 MakeCoreMat（不透明），
        --    五层会变成五个不透明球套球，比三层更难看。
        --    真机日志已确认 PBRNoTextureAlpha 可用（曾打出 "层数=3/3"）。
        --
        -- 核心 220 米 @ 6000 米 ≈ 2.1° 视角。
        -- ⚠️ 包围盒（上面 sunZone）按最大 scale 1100 取 ±600 不够（半径 550），
        --    但 Zone 的 boundingBox 只用于判定"哪些 drawable 归这个 Zone"，
        --    太阳自身位置在盒心，仍被覆盖；若出现太阳不受 Zone 影响再调大。
        local LAYERS = {
            { name = "Core", scale = 220, mat = MakeCoreMat(1.00, 0.96, 0.85) },
            { name = "L2",   scale = 350, mat = MakeGlowMat(1.00, 0.94, 0.78, 0.50) },
            { name = "Halo", scale = 550, mat = MakeGlowMat(1.00, 0.92, 0.72, 0.28) },
            { name = "L4",   scale = 800, mat = MakeGlowMat(1.00, 0.90, 0.66, 0.14) },
            { name = "Glow", scale = 1100, mat = MakeGlowMat(1.00, 0.88, 0.60, 0.07) },
        }
        local built = 0
        for _, L in ipairs(LAYERS) do
            if sphereMdl and L.mat then
                local n = sunRoot:CreateChild(L.name, LOCAL)
                local mdl = n:CreateComponent("StaticModel", LOCAL)
                mdl:SetModel(sphereMdl)
                mdl:SetMaterial(L.mat)
                n:SetScale(L.scale)
                mdl.castShadows = false   -- 太阳不投影
                built = built + 1
            end
        end

        -- 存进 S，供每帧更新位置
        S.sunNode_ = sunRoot
        S.sunDir_  = SUN_DIR
        S.sunDist_ = SUN_DIST

        -- ⚠️ 分母用 #LAYERS，不要硬编码数字 —— 加层时忘记同步会打出"5/3"这种误导日志。
        print(string.format(
            "[Client] 太阳已创建 dir=(%.2f,%.2f,%.2f) dist=%.0f 层数=%d/%d",
            SUN_DIR.x, SUN_DIR.y, SUN_DIR.z, SUN_DIST, built, #LAYERS))
        if built < #LAYERS then
            print("[Client] ⚠️ 太阳部分层未创建 —— 检查 Models/Sphere.mdl 与 Technique 是否可用")
        end
    end

    ApplyCameraSettings()
    ApplyViewDistanceSettings()

    -- 地形
    Terrain.Build(S.scene_)
    Enemies.SetScene(S.scene_)
    Items.SetScene(S.scene_)
    Effects.SetScene(S.scene_)

    -- 湖泊水面（阶段 2.2 批 1：只验证位置/尺寸/高度）
    -- ⚠️ 必须在地形之后：湖泊信息与水位由 Terrain 提供。
    Water.Build(S.scene_)

    -- Toon 明暗分界阈值（阶段 1.4 实测定稿）
    -- 必须在地形/角色材质创建之后再设，否则材质还是懒加载、拿不到。
    -- 地形 0.70：实测草地大部分明亮鲜绿、远处略暗，接近草原调子。
    -- 角色 0.30：角色是竖直圆柱、N·L 上限 ≈0.707，阈值必须明显更低。
    do
        local ts = Data.value.settings
        local terrMat = Visual.getTerrainMaterial and Visual.getTerrainMaterial() or nil
        if terrMat then
            terrMat:SetShaderParameter("toon_threshold",
                Variant(ts.toonThresholdTerrain or 0.70))
            terrMat:SetShaderParameter("toon_shadow_strength",
                Variant(ts.toonShadowStrength or 1.0))
        end
        local charMat = Visual.getCharacterMaterial and Visual.getCharacterMaterial() or nil
        if charMat then
            charMat:SetShaderParameter("toon_threshold",
                Variant(ts.toonThresholdCharacter or 0.30))
            charMat:SetShaderParameter("toon_shadow_strength",
                Variant(ts.toonShadowStrength or 1.0))
        end
        print(string.format("[Client] Toon 阈值 地形=%.2f 角色=%.2f 暗面深浅=%.2f",
            ts.toonThresholdTerrain or 0.70,
            ts.toonThresholdCharacter or 0.30,
            ts.toonShadowStrength or 1.0))
    end

    -- 回调接线
    Combat.SetCallbacks({
        onEnemyKilled = HandleEnemyKilled,
        playEffect = function(skillId, x, z, value) Effects.Play(skillId, x, z, value) end,
        showDamage = function(x, z, text, kind) HUD.ShowDamageNumber(x, z, text, kind) end,
        onEnemyHit = function(enemy) Enemies.OnHit(enemy) end,
        -- 共享 Boss 的伤害不在本地结算，改为上报服务端（服务端权威扣血）
        reportBossDamage = function(enemy, damage)
            if Net.conn then
                Net.conn:SendRemoteEvent(Shared.EVENTS.ATTACK_BOSS, true, Shared.ToVariantMap({
                    MonsterId = enemy.id,
                    Damage    = damage,
                }))
            end
        end,
        -- 本地把 Boss 打到 0 血 → 上报击杀。服务端给**首个上报者**发奖励并移除 Boss。
        -- ⚠️ 不依赖服务端血量累计到 0：本地归零后玩家会停手，
        --    若此时服务端仍有残血（节流丢包），光靠伤害上报会永久卡死。
        reportBossKilled = function(enemy)
            if Net.conn then
                Net.conn:SendRemoteEvent(Shared.EVENTS.BOSS_KILLED, true, Shared.ToVariantMap({
                    MonsterId = enemy.id,
                }))
            end
        end,
        -- A7：技能触发弹跳文字
        showSkillPopup = function(x, z, text, color)
            HUD.ShowSkillPopup(x, z, text, color)
        end,
        -- 玩家受到的伤害/闪避：飘字挂在自己头顶（而不是怪物身上）
        getPlayerPos = function() return S.localPlayerX_, S.localPlayerZ_ end,
    })

    -- 血蚀吸血回调 + AoE 击杀结算
    Skills.SetCallbacks({
        onLifesteal = function(amount)
            local stats = Combat.ComputeStats(Data.value.equipment)
            Data.value.hp = math.floor(math.min(stats.maxHp, Data.value.hp + amount))
        end,
        -- ⚠️ 必须和上面 Combat.SetCallbacks 的 onEnemyKilled 指向同一函数：
        --    AoE 技能（共鸣 / 反噬 / 魂链）打死怪时，Skills 内部直接扣血，
        --    不经过 Combat 的击杀分支。没有这个回调，那些怪不会掉落/给金币/
        --    累计击杀数（表现为"打死了像没死"）。
        onEnemyKilled = HandleEnemyKilled,
    })
    Enemies.SetCallbacks({
        canAttack = function()
            local d = Data.value
            return not d.isStanding and not d.isDead
        end,
        onAttackPlayer = HandleEnemyAttack,
        -- 怪物被销毁时清理头顶标签，避免残留标签与新怪物同屏
        onEnemyRemoved = function(id)
            if HUD.RemoveEnemyTag then HUD.RemoveEnemyTag(id) end
        end,
    })
    Items.SetCallbacks({
        canPickup = function()
            local d = Data.value
            return not d.isStanding and not d.isDead
        end,
        --- 返回值约定：false = 拾取失败，掉落物必须保留（Items.Update 据此决定不销毁）。
        ---@return boolean
        onPickup = function(item)
            local inv = Data.value.inventory
            local cap = Data.BagCapacity()
            -- 背包已满：可堆叠物（碎片/精魄/令牌）不受限，装备则转投邮箱（避免掉落凭空消失）
            if #inv >= cap and not Data.IsStackable(item) then
                if Net.conn then
                    Net.conn:SendRemoteEvent(Shared.EVENTS.BAG_OVERFLOW, true, Shared.ToVariantMap({
                        ItemJson = cjson.encode(item),
                    }))
                else
                    -- 离线（未连服）时没有服务端兜底：返回 false 让掉落物留在地上，
                    -- 否则物品会被销毁却无处可去，直接消失。
                    Notify.Toast("背包已满，无法拾取 " .. (item.name or "物品"))
                    return false
                end
                Notify.Toast("背包已满，物品已发送到📬邮箱")
                return true
            end
            ClientAddToInventory(item)
            Notify.Toast("获得 " .. (item.name or "物品"))
            return true
        end,
    })

    -- 网络层注入：游戏侧状态以访问器形式交给 Client_Network，
    -- 网络层不直接持有游戏对象（坐标/朝向/节点都在本文件维护）
    Net.Init({
        getPlayerPos    = function() return S.localPlayerX_, S.localPlayerZ_ end,
        getPlayerFacing = function() return S.playerFacing_ end,
        getMyNode       = function() return S.myNode_ end,
        getMyId         = function() return S.myId_ end,
        setMyId         = function(v) S.myId_ = v end,
        setPlayerPos    = function(x, z) S.localPlayerX_, S.localPlayerZ_ = x, z end,
        getScene        = function() return S.scene_ end,
        bindPlayerNode  = function()
            S.bindRetry_ = 0
            TryBindPlayerNode()
        end,
        applyServerSettings = function() ReapplyServerSettingsIfChanged() end,
    })

    -- 网络
    Shared.RegisterClientEvents()
    SubscribeToEvent(Shared.EVENTS.ASSIGN_PLAYER, Net.OnAssignPlayer)
    SubscribeToEvent(Shared.EVENTS.INV_SYNC, Net.OnInvSync)
    SubscribeToEvent(Shared.EVENTS.PLAYER_MOVE, Net.OnPlayerMoveBroadcast)
    SubscribeToEvent(Shared.EVENTS.PLAYER_INFO, Net.OnPlayerInfo)
    SubscribeToEvent(Shared.EVENTS.MAIL_UPDATE, Net.OnMailUpdate)
    SubscribeToEvent(Shared.EVENTS.MAIL_PAGE_RESULT, Net.OnMailPageResult)
    SubscribeToEvent(Shared.EVENTS.MAIL_CLAIM_RESULT, Net.OnMailClaimResult)
    SubscribeToEvent(Shared.EVENTS.SYNC_ACK, Net.OnSyncAck)
    SubscribeToEvent(Shared.EVENTS.SHARED_BOSS_UPDATE, Net.OnSharedBossUpdate)
    SubscribeToEvent(Shared.EVENTS.SHARED_BOSS_REMOVE, Net.OnSharedBossRemove)
    SubscribeToEvent(Shared.EVENTS.TOAST, Net.OnServerToast)
    SubscribeToEvent(Shared.EVENTS.STARTER_GIFT, Net.OnStarterGift)
    SubscribeToEvent(Shared.EVENTS.KICKED, Net.OnKicked)
    SubscribeToEvent(Shared.EVENTS.SAVE_FAILED, Net.OnSaveFailed)
    SubscribeToEvent(Shared.EVENTS.ONLINE_COUNT, "OnOnlineCount")
    SubscribeToEvent(Shared.EVENTS.SERVER_FULL, Net.OnServerFull)
    SubscribeToEvent(Shared.EVENTS.PLAYER_LEAVE, Net.OnPlayerLeave)
    SubscribeToEvent(Shared.EVENTS.BANK_STATE, Net.OnBankState)
    SubscribeToEvent(Shared.EVENTS.BANK_RESULT, Net.OnBankResult)
    SubscribeToEvent(Shared.EVENTS.SUMMON_SCROLL_RESULT, Net.OnSummonScrollResult)
    SubscribeToEvent(Shared.EVENTS.MARKET_PAGE_RESULT, Net.OnMarketPageResult)
    SubscribeToEvent(Shared.EVENTS.DEBUG_SERVER_INFO, Net.OnDebugServerInfo)
    -- 客户端侧断线（引擎事件）：清连接 + 弹重连门
    SubscribeToEvent("ServerDisconnected", Net.OnServerDisconnected)
    SubscribeToEvent("Update", "OnUpdate")
    SubscribeToEvent("ScreenMode", "OnScreenModeChanged")

    Net.conn = network:GetServerConnection()
    if Net.conn then
        Net.conn.scene = S.scene_
        Net.conn:SendRemoteEvent(Shared.EVENTS.CLIENT_READY, true)
        print("[Client] 已向服务器发送 ClientReady")
    else
        print("[Client] ⚠️ 未取得服务器连接")
    end

    SetupUI()
    Touch.Setup()

    -- 初始化 UI 坐标换算（取 UI.GetScale()），伤害飘字/世界坐标转 UI 都依赖它
    local w, h = graphics:GetWidth(), graphics:GetHeight()
    HUD.UpdateScale(w, h)

    -- 锁 60 帧
    engine.maxFps = 60
    print("[Client] 帧率上限已锁定为 60 FPS（maxFps=60）")

    print("[Client] 启动完成")
end

--- 屏幕尺寸变化时重新计算 UI 缩放
--- ⚠️ 必须是全局函数：SubscribeToEvent 传字符串时按全局名查找
function OnScreenModeChanged()
    if HUD and HUD.UpdateScale then
        local w, h = graphics:GetWidth(), graphics:GetHeight()
        HUD.UpdateScale(w, h)
    end
end

--- 在线人数广播（服务端 → HUD 左上角「在线: N」）
--- ⚠️ 全局函数：SubscribeToEvent 传字符串时按全局名查找
---@param eventType string
---@param eventData VariantMap
function OnOnlineCount(eventType, eventData)
    local n = eventData:GetInt("Count")
    if n and n > 0 then HUD.SetOnlineCount(n) end
end

return { Start = Start }
